"""No model/preprocessor fits: boundary, timing and composition checks."""
from light_dual import *
from models035 import forbid_fits

def run():
    tests=[];cut=pd.Period('2001-12','M')
    def fr(offsets,oil,days=None):return pd.DataFrame({'NY':[str(cut-i) for i in offsets],'RCYL':oil,'SCTS':days or [10.]*len(offsets)})
    def equal(a,z):return all(b.safe._same_feature_value(a[k],z[k]) for k in a)
    with forbid_fits(extra_classes=(Ridge,HistGradientBoostingRegressor)):
        f=fr([0,1],[0.,2.]);v=sequence_values(f,cut,2.)
        assert v['seq__oil_log_ratio__oldest_11']==0. and v['seq__oil_observed__oldest_11']==1.;tests.append('zero oil retained as finite observed')
        assert v['seq__oil_log_ratio__oldest_10']==np.log1p(1.);tests.append('oil ratio uses supplied raw legal scale')
        assert v['seq__operating_fraction__oldest_11']==10/31;tests.append('operating days normalized by actual month days')
        assert np.isnan(v['seq__oil_log_ratio__oldest_00']) and v['seq__oil_observed__oldest_00']==0.;tests.append('absent calendar month is missing plus explicit mask')
        assert equal(v,sequence_values(f.iloc[::-1],cut,2.));tests.append('sequence sorted by calendar, not CSV order')
        g=pd.concat([f,fr([-1,-2],['forbidden','forbidden'],['forbidden','forbidden'])],ignore_index=True)
        assert equal(v,sequence_values(g,cut,2.));tests.append('future strings never enter numeric parsing')
        assert equal(v,sequence_values(pd.concat([f,fr([12],[900.])],ignore_index=True),cut,2.));tests.append('observation older than12 month excluded')
        z=sequence_values(fr([0],[np.inf]),cut,1.);assert z['seq__oil_observed__oldest_11']==0;tests.append('infinite observation has missing mask')
        for frame,code in [(fr([0,0],[1.,2.]),'duplicate month'),(fr([0],[-1.]),'negative oil'),(fr([0],[1.],[32.]),'invalid operating days')]:
            try:sequence_values(frame,cut,1.)
            except RuntimeError:tests.append(code+' rejected')
            else:raise AssertionError(code+' accepted')
        a=expand_time(v,1);z=expand_time(v,12);assert len(a)==len(z)==195 and a['seq__hpow1']==1/12 and z['seq__hpow3']==1.;tests.append('195 time features and forecast horizon basis')
        assert z['seq__oil_log_ratio__oldest_10__hpow3']==v['seq__oil_log_ratio__oldest_10'];tests.append('horizon interaction exact at month12')
        q=pd.DataFrame({'__scale035':[1.,2.],'RCYL':[0.,3.]});y=b.transform_target(q,b.load_variant(b.HERE/'configs/B0.json'))
        np.testing.assert_array_equal(y,np.log1p(q.RCYL.to_numpy()/q['__scale035'].to_numpy()));tests.append('frozen target expression unchanged')
        pred=b.inverse_target(np.array([-.5,0.]),q);assert (pred==0).all();tests.append('nonnegative inverse of additive log output')
        r,h=models();assert r.alpha==100. and h.max_iter==120 and h.max_leaf_nodes==7 and h.early_stopping is False;tests.append('locked small model construction, no fit')
        p=pd.DataFrame({'WELL_ID':['synthetic_A']*12+['synthetic_B']*12,'horizon':list(range(1,13))*2,'RCYL':np.ones(24)})
        assert b.summary(p,np.ones(24))['official_score']==100.;tests.append('official metric equal-well reference')
    return {'passed':len(tests),'tests':tests,'model_fits':0,'preprocessor_fits':0,'test_data_used':False}
