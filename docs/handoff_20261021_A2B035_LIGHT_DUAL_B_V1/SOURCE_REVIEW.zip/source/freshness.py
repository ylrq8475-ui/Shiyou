"""One fixed causal missing-memory feature block on the frozen B0 input."""
from pathlib import Path
import sys, json
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'base'))
import cv035 as b
from models035 import estimator_for
np,pd=b.np,b.pd
FIELDS=('CCJHWND','CCYND','LY','CMD','XXDL')
WINDOW=12
EXTRA=[f'fresh__{f}__{kind}' for f in FIELDS for kind in ('last_valid_12','age_months_cap12')]

def fixed_spec():
    return {'name':'B0_FRESH10_ET400','control':'B0','history_cutoff':'M_minus_1','fields':list(FIELDS),'calendar_window_months':12,'new_columns':EXTRA,'feature_count':335,'method':'append last finite observation in cutoff-11..cutoff and calendar age; absent value NaN and age12; finite zero is valid; original325 and scale untouched','model':{'name':'ExtraTrees','n_estimators':400,'min_samples_leaf':6,'max_features':.75,'random_state':20260916,'n_jobs':-1},'target':'original log1p(RCYL/s), original last legal raw RCYL finite>0 else1','no_replacement_of_original_values':True}

def extra_values(legal,cutoff):
    periods=pd.to_datetime(legal.NY,errors='raise').dt.to_period('M')
    chosen=(periods<=cutoff)&(periods>=cutoff-(WINDOW-1))
    # Filter by time before touching dynamic values, including in mutation tests.
    local=legal.loc[chosen].copy();local['__p']=periods.loc[chosen]
    b.require(not local.__p.duplicated().any(),'FRESH_DUPLICATE_MONTH')
    local=local.sort_values('__p',kind='stable');out={}
    for f in FIELDS:
        values=pd.to_numeric(local[f],errors='coerce').to_numpy(float)
        valid=np.flatnonzero(np.isfinite(values))
        if len(valid):
            index=int(valid[-1]);value=float(values[index]);age=cutoff.ordinal-local.__p.iloc[index].ordinal
            b.require(0<=age<WINDOW,'FRESH_AGE_RANGE')
        else:value=np.nan;age=WINDOW
        out[f'fresh__{f}__last_valid_12']=value
        out[f'fresh__{f}__age_months_cap12']=float(age)
    return out

def build(history,policy,legacy):
    c=b.load_variant(b.HERE/'configs/B0.json')
    control,features,audit=b.build_variant_train(history,policy,legacy,c)
    expected=json.loads((b.HERE/'DATA_CONTRACT.json').read_bytes())['B0_identity']
    b.require(b.identity(control,features)==expected,'CONTROL_FROZEN_IDENTITY')
    candidate=control.copy();metadata=[]
    for f in EXTRA:candidate[f]=np.nan
    for wid,g in control.groupby('WELL_ID',sort=False):
        t0=pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1
        legal,cutoff=b.legal_history(history,wid,t0,'M_minus_1',legacy)
        values=extra_values(legal,cutoff)
        for f,value in values.items():candidate.loc[g.index,f]=value
        latest=legal.assign(__p=pd.to_datetime(legal.NY).dt.to_period('M')).sort_values('__p',kind='stable')
        raw=float(pd.to_numeric(latest.RCYL,errors='coerce').iloc[-1])
        bx=float(pd.to_numeric(latest.BX,errors='coerce').iloc[-1])
        days=float(pd.to_numeric(latest.SCTS,errors='coerce').iloc[-1])
        production=pd.to_numeric(latest.RCYL,errors='coerce').to_numpy(float);finite=production[np.isfinite(production)&(production>=0)]
        earlier=pd.to_numeric(latest.loc[latest.__p==cutoff-1,'RCYL'],errors='coerce')
        previous=float(earlier.iloc[0]) if len(earlier) else np.nan
        ratio=raw/previous if np.isfinite(raw) and np.isfinite(previous) and previous>0 else np.nan
        row={'WELL_ID':wid,'scale_state':'positive' if np.isfinite(raw) and raw>0 else 'fallback','BX_state':'missing' if not np.isfinite(bx) else 'outside_0_100' if bx<0 or bx>100 else 'within_0_100','production_level':float(np.mean(finite)) if len(finite) else np.nan,'recent_ratio':'unknown' if not np.isfinite(ratio) else 'below_0.5' if ratio<.5 else '0.5_to_2' if ratio<=2 else 'above_2','operating_fraction':'unknown' if not np.isfinite(days) else 'below_0.8' if days/cutoff.days_in_month<.8 else 'other'}
        for f in FIELDS:
            age=values[f'fresh__{f}__age_months_cap12'];row['age_'+f]='observed_now' if age==0 else 'missing_1_month' if age==1 else 'missing_2plus_months'
        metadata.append(row)
    b.require(candidate[control.columns].equals(control),'BASE_FEATURE_TARGET_SCALE_CHANGED')
    b.require(len(features)==325 and len(features+EXTRA)==335 and len(set(features+EXTRA))==335,'FRESH_FEATURE_COUNT')
    b.require(candidate[['WELL_ID','horizon','RCYL','__scale035']].equals(control[['WELL_ID','horizon','RCYL','__scale035']]),'TARGET_SCALE_CHANGED')
    return control,candidate,features,features+EXTRA,pd.DataFrame(metadata)

def fit(panel,features,legacy,ledger,stage):
    b.require(ledger.value['models_entered']<63,'LOCAL_FIT_ENTRY_BUDGET')
    c=b.load_variant(b.HERE/'configs/B0.json');x=panel[features];y=b.transform_target(panel,c)
    prep=b.training._preprocessor(x);model=estimator_for(c,x,legacy)
    transformed=ledger.run('preprocessor',stage,lambda:prep.fit_transform(x,y))
    ledger.run('model',stage,lambda:model.fit(transformed,y))
    return {'preprocessor':prep,'model':model,'features':features,'spec':fixed_spec(),'member_config':c}

def predict(artifact,panel):
    with b.joblib.parallel_backend('sequential'):
        raw=artifact['model'].predict(artifact['preprocessor'].transform(panel[artifact['features']]))
    return b.inverse_target(raw,panel)

def metadata_labels(metadata,panel,folds):
    labels=metadata.set_index('WELL_ID').copy()
    labels['production_tertile']='unknown'
    for tr,va in folds:
        train=panel.iloc[tr].WELL_ID.drop_duplicates();valid=panel.iloc[va].WELL_ID.drop_duplicates()
        b.require(not set(train)&set(valid),'GROUP_CUTPOINT_OVERLAP')
        values=labels.loc[train,'production_level'].to_numpy(float);values=values[np.isfinite(values)]
        lo,hi=np.quantile(values,[1/3,2/3])
        for wid in valid:
            v=labels.loc[wid,'production_level'];labels.loc[wid,'production_tertile']='unknown' if not np.isfinite(v) else 'low' if v<=lo else 'middle' if v<=hi else 'high'
    return labels.drop(columns='production_level')

def error_groups(panel,baseline,candidate,metadata,folds):
    labels=metadata_labels(metadata,panel,folds);y=panel.RCYL.to_numpy(float);weights=2.**(-panel.horizon.to_numpy(float));groups={}
    losses=[weights*np.abs(y-p)/(np.abs(y)+np.abs(p)+1e-6) for p in (baseline,candidate)]
    n=panel.WELL_ID.nunique()
    for field in labels:
        counts=labels[field].value_counts()
        if min(counts)<5:
            groups[field]={'status':'ENTIRE_DIMENSION_SUPPRESSED_LT5','scope':'all group counts and complements suppressed'};continue
        rows=[]
        for name,count in sorted(counts.items()):
            members=labels.index[labels[field]==name];mask=panel.WELL_ID.isin(members).to_numpy()
            a,z=[float(w[mask].sum()/count) for w in losses]
            row={'group':name,'wells':int(count),'B0_mean_weighted_loss':a,'candidate_mean_weighted_loss':z,'candidate_minus_B0_group_score':100*(a-z),'net_total_score_contribution':100*(a-z)*count/n}
            for label,p,loss in zip(('B0','candidate'),(baseline,candidate),losses):
                row[label+'_total_loss_share']=float(loss[mask].sum()/loss.sum()) if loss.sum()>0 else None
                row[label+'_over_prediction_loss']=float(loss[mask&(p>y)].sum()/count)
                row[label+'_under_prediction_loss']=float(loss[mask&(p<y)].sum()/count)
            rows.append(row)
        groups[field]={'status':'REPORTED','rows':rows,'dimensions_overlap_do_not_sum':True}
    return {'groups':groups,'grouping':'prediction-time inputs only; production tertiles from outer training wells only; members vary across splits','model_fits':0,'preprocessor_fits':0,'does_not_prove_causation':True}
