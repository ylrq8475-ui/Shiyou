"""One locked small temporal model plus a nonlinear feature residual model."""
from freshness import b, np, pd, extra_values, EXTRA, FIELDS
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from models035 import estimator_for

TEMPORAL_BASE = [f'seq__{field}__oldest_{i:02d}' for field in ('oil_log_ratio','oil_observed','operating_fraction','operating_observed') for i in range(12)]
TEMPORAL = [f'{name}__hpow{power}' for power in range(4) for name in TEMPORAL_BASE] + ['seq__hpow1','seq__hpow2','seq__hpow3']

def models():
    return (Ridge(alpha=100., fit_intercept=True, solver='svd'),
            HistGradientBoostingRegressor(loss='squared_error', learning_rate=.05,
                max_iter=120, max_leaf_nodes=7, max_depth=3, min_samples_leaf=20,
                l2_regularization=5., max_bins=255, max_features=1.,
                categorical_features=None, early_stopping=False, random_state=20260916))

def spec():
    ridge,hgb=models()
    return {'name':'RIDGE_HGB_RESIDUAL_120','candidate_count':1,
            'temporal_model':{'class':'Ridge','parameters':ridge.get_params(), 'input_columns':195,
                'input':'12 calendar months ending M-1, log1p(RCYL/s), SCTS/calendar_days and separate finite masks; each interacts with normalized horizon powers0..3, plus horizon powers1..3'},
            'feature_model':{'class':'HistGradientBoostingRegressor','parameters':hgb.get_params(), 'input_columns':335,
                'input':'original325 plus frozen10 missing-memory fields',
                'training_target':'log1p(RCYL/s) minus same-outer-training-fitted Ridge prediction on those training rows'},
            'composition':'z=Ridge(time)+HGB(feature residual); RCYL=max(0,expm1(z)*s)',
            'residual_scope':'ordinary additive residual training; no validation prediction or label enters either fit; not nested/cross-fitted stacking',
            'history_cutoff':'M_minus_1','target_window':'M+1..M+12','scale':'raw last legal RCYL if finite and >0 else1',
            'weights':'no sample weights; no tuned blend or routing','model_size_budget_bytes':2097152,
            'baseline':'fresh same-runtime B0, ExtraTrees400 original325',
            'not_a_claim':'branch names describe intended roles, not a causal decomposition or proven importance'}

def sequence_values(frame,cutoff,scale):
    periods=pd.to_datetime(frame.NY,errors='raise').dt.to_period('M')
    chosen=(periods<=cutoff)&(periods>=cutoff-11)
    # Remove all forbidden rows before numeric dynamic fields are parsed.
    local=frame.loc[chosen,['NY','RCYL','SCTS']].copy();local['__p']=periods.loc[chosen]
    b.require(not local.__p.duplicated().any(),'TIME_DUPLICATE_MONTH')
    b.require(np.isfinite(scale) and scale>0,'TIME_SCALE_INVALID')
    lookup=local.set_index('__p');oil=[];omask=[];days=[];dmask=[]
    for month in [cutoff-i for i in range(11,-1,-1)]:
        if month in lookup.index:
            q=float(pd.to_numeric(pd.Series([lookup.loc[month,'RCYL']]),errors='coerce').iloc[0])
            d=float(pd.to_numeric(pd.Series([lookup.loc[month,'SCTS']]),errors='coerce').iloc[0])
        else:q=d=np.nan
        b.require(not np.isfinite(q) or q>=0,'NEGATIVE_LEGAL_OIL')
        b.require(not np.isfinite(d) or 0<=d<=month.days_in_month,'INVALID_LEGAL_OPERATING_DAYS')
        oil.append(float(np.log1p(q/scale)) if np.isfinite(q) else np.nan);omask.append(float(np.isfinite(q)))
        days.append(d/month.days_in_month if np.isfinite(d) else np.nan);dmask.append(float(np.isfinite(d)))
    return dict(zip(TEMPORAL_BASE,oil+omask+days+dmask))

def expand_time(values,horizon):
    h=float(horizon)/12.;b.require(1<=horizon<=12,'TIME_HORIZON')
    out={f'{n}__hpow{power}':v*(h**power) for power in range(4) for n,v in values.items()}
    out.update({f'seq__hpow{power}':h**power for power in range(1,4)})
    b.require(list(out)==TEMPORAL and len(out)==195,'TIME_FEATURE_ORDER')
    return out

def build(history,policy,legacy):
    import freshness as f
    control,features_panel,af,ff,metadata=f.build(history,policy,legacy)
    time_rows=[];future_checks=0
    for wid,g in control.groupby('WELL_ID',sort=False):
        t0=pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1
        legal,cutoff=b.legal_history(history,wid,t0,'M_minus_1',legacy);scale=float(g['__scale035'].iloc[0])
        v=sequence_values(legal,cutoff,scale)
        # Real-input boundary metamorphism, retaining only an allowed prefix.
        local=history.loc[history.WELL_ID==wid].copy();local[['RCYL','SCTS']]=local[['RCYL','SCTS']].astype(object)
        p=pd.to_datetime(local.NY).dt.to_period('M');local.loc[p>cutoff,['RCYL','SCTS']]='FORBIDDEN_DYNAMIC_SENTINEL'
        again=sequence_values(local,cutoff,scale)
        b.require(all(b.safe._same_feature_value(v[k],again[k]) for k in v),'TIME_FUTURE_SENSITIVE')
        future_checks+=len(v)
        for h in g.horizon:time_rows.append(expand_time(v,int(h)))
    temporal=pd.DataFrame(time_rows,index=control.index,columns=TEMPORAL)
    b.require(temporal.shape==(972,195),'TIME_PANEL_SHAPE')
    b.require(control[['WELL_ID','horizon','RCYL','__scale035']].equals(features_panel[['WELL_ID','horizon','RCYL','__scale035']]),'PAIRED_TARGET_SCALE')
    return control,features_panel,temporal,af,ff,metadata,{'real_future_mutation_feature_checks':future_checks,'temporal_features':195,'feature_model_features':335,'original_features_unchanged':True}

def fit_control(panel,features,legacy,ledger,stage):
    c=b.load_variant(b.HERE/'configs/B0.json');x=panel[features];y=b.transform_target(panel,c)
    prep=b.training._preprocessor(x);model=estimator_for(c,x,legacy)
    xx=ledger.run('preprocessor',stage,lambda:prep.fit_transform(x,y))
    ledger.run('model',stage,lambda:model.fit(xx,y))
    return {'preprocessor':prep,'model':model,'features':features}

def predict_control(artifact,panel):
    with b.joblib.parallel_backend('sequential'):
        z=artifact['model'].predict(artifact['preprocessor'].transform(panel[artifact['features']]))
    return b.inverse_target(z,panel)

def fit_dual(panel,temporal,features,ledger,stage):
    b.require(panel.index.equals(temporal.index),'TIME_TRAIN_ROW_ALIGNMENT')
    c=b.load_variant(b.HERE/'configs/B0.json');y=b.transform_target(panel,c);ridge,hgb=models()
    prep_time=Pipeline([('imputer',SimpleImputer(strategy='median',keep_empty_features=True)),('scale',StandardScaler())])
    xt=ledger.run('preprocessor',stage+'-temporal',lambda:prep_time.fit_transform(temporal,y))
    ledger.run('model',stage+'-temporal',lambda:ridge.fit(xt,y))
    training_trend=np.asarray(ridge.predict(xt),float);residual=y-training_trend
    prep_feature=b.training._preprocessor(panel[features])
    xf=ledger.run('preprocessor',stage+'-feature',lambda:prep_feature.fit_transform(panel[features],residual))
    ledger.run('model',stage+'-feature',lambda:hgb.fit(xf,residual))
    return {'temporal':{'preprocessor':prep_time,'model':ridge,'features':TEMPORAL},
            'feature':{'preprocessor':prep_feature,'model':hgb,'features':features},'spec':spec()}

def predict_dual(artifact,panel,temporal,return_temporal=False):
    b.require(panel.index.equals(temporal.index),'TIME_PREDICT_ROW_ALIGNMENT')
    t=artifact['temporal'];f=artifact['feature']
    z=np.asarray(t['model'].predict(t['preprocessor'].transform(temporal[t['features']])),float)
    correction=np.asarray(f['model'].predict(f['preprocessor'].transform(panel[f['features']])),float)
    pred=b.inverse_target(z+correction,panel)
    return (pred,b.inverse_target(z,panel)) if return_temporal else pred
