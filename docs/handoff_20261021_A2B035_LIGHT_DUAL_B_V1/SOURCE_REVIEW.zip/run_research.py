"""Locked light two-model experiment, grouped CV, no persisted row predictions."""
from pathlib import Path
import sys,json,hashlib,shutil,time,platform,importlib.metadata as im
from datetime import datetime,timezone,timedelta
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'source'))
PREVIOUS=T.parent/'A2B035_FEATURE_FRESHNESS_20261021_v2'

def enc(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,v):
    p=T/path;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),'OUTPUT_ALREADY_EXISTS:'+p.name;p.write_bytes(enc(v))
def environment():
    return {'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({x.metadata['Name']:x.version for x in im.distributions()}.items()))}
def bootstrap():
    for src,target in [(PREVIOUS/'source/base',T/'source/base'),(PREVIOUS/'source/freshness.py',T/'source/freshness.py')]:
        files=src.rglob('*') if src.is_dir() else [src]
        for p in files:
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
            dest=target/p.relative_to(src) if src.is_dir() else target;dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():assert sha(dest)==sha(p),'FROZEN_COPY_CHANGED'
            else:shutil.copyfile(p,dest)

def inputs(args):
    import light_dual as d
    b=d.b;policy,legacy=b.load_locked_policy(args.policy);allowed=set(legacy['data']['sources']['train']['history'])
    class TrainingOnly(b.Inputs):
        def raw(self,name):
            b.require(name in allowed,'NO_TEST_OR_OTHER_TABLE_ACCESS')
            return super().raw(name)
    store=TrainingOnly(args.data)
    try:history=b.load_train(store,legacy)
    finally:store.close()
    return d,legacy,d.build(history,policy,legacy)

def history_check():
    paths=[T.parent/'A2B021_20261009_v1/PLAN.json',T.parent/'A2B024_20261012_v1/PLAN_R2.json',T.parent/'A2B035_R16_20261020_v2/PLAN_R16.json',PREVIOUS/'execution/RESULT_FRESHNESS.json']
    rows=[{'task':'A2B-021','mechanism':'early-month HGB branches and fixed fusions, not Ridge time plus residual HGB','equivalent':False},
          {'task':'A2B-024','mechanism':'two cutoff ExtraTrees alternatives','equivalent':False},
          {'task':'R16','mechanism':'LightGBM/CatBoost/TabPFN and cutoff fusions; stopped R17','equivalent':False},
          {'task':'FEATURE_FRESHNESS','mechanism':'same335 features with ExtraTrees400, completed negative retention decision','equivalent':False}]
    return {'scope':'authorized local plans/completion evidence and previously fetched public history; not a claim about inaccessible machines','comparisons':rows,'evidence':[{'path':p.relative_to(T.parent).as_posix(),'sha256':sha(p)} for p in paths],
            'exact_two_stage_Ridge_HGB_sequence_residual_execution_found':False,'no_restart_of_old_search':True}

def prepare(args):
    bootstrap()
    import light_dual as d
    from synthetic_dual import run
    d.b.verify_source_lock();env=environment();assert env==json.loads((PREVIOUS/'ENVIRONMENT_LOCK.json').read_bytes()),'PAIRED_RUNTIME_CHANGED'
    tests=run()
    with d.b.offline_only():d,legacy,panels=inputs(args)
    control,feature,temporal,af,ff,metadata,audit=panels
    contract=json.loads((T/'source/base/DATA_CONTRACT.json').read_bytes())
    assert sha(args.data)==contract['raw_archive_sha256'] and sha(args.policy)==contract['private_policy_sha256']
    assert d.b.split_fingerprints(d.b.split_sets(control))==contract['split_fingerprints']
    time_identity=d.b.identity(temporal.assign(WELL_ID=control.WELL_ID,horizon=control.horizon,RCYL=control.RCYL),d.TEMPORAL)
    write(Path('execution/SYNTHETIC.json'),tests);write(Path('ENVIRONMENT_LOCK.json'),env)
    write(Path('USER_AUTHORIZATION.json'),{'role':'账户B执行与交付','verbatim':'换模型  模型不要太大 要兼顾特征获取和 时序 可以分为两个模型进行训练 继续',
          'scope':'one fixed small two-model candidate; validation, private research save and anonymous handoff; no platform submission or existing-model replacement','source':'direct human request, not a fabricated Claude instruction'})
    write(Path('HISTORY_CHECK.json'),history_check())
    pre={'control_identity':d.b.identity(control,af),'feature_identity':d.b.identity(feature,ff),'temporal_identity':time_identity,
         'split_fingerprints':contract['split_fingerprints'],'raw_archive_sha256':sha(args.data),'policy_sha256':sha(args.policy),
         'wells':81,'rows':972,'baseline_features':325,'feature_branch_columns':335,'temporal_branch_columns':195,'test_CSV_reads':0,'audit':audit,'historical_dtype':'UNKNOWN; unchanged old evidence gap'}
    write(Path('PRE_DATA_LOCK.json'),pre)
    plan={'task':'A2B-035/LIGHT_DUAL','role':'账户B执行与交付','spec':d.spec(),'hypothesis':'a regularized temporal trajectory plus shallow nonlinear feature correction may generalize with smaller artifacts than ExtraTrees; this is a single architecture trial, not a causal isolation of learner vs new time inputs',
          'evaluation':'fresh paired B0 fixed5 then five repeated grouped5 seeds1..5; same81 wells, not independent confirmation','success_model_cap':92,'success_CV_models':90,'success_full_candidate_models':2,'model_entry_cap':94,'fault_retry_cap':2,
          'preprocessors':'one top-level pipeline per model fit, independently counted; 92 on successful run','baseline_gate':{'fixed':73.71410733861434,'tolerance':1e-9,'all_six_R17_scores':'also matched before same-split candidate; mismatch stops'},
          'recommendation_all_required':{'fixed_delta_min':-.2,'repeat_mean_delta_min':.2,'positive_repeats_min':4,'worst_repeat_delta_min':-.2,'model_bytes_max':2097152,'all_hard_gates':'PASS'},
          'threshold_provenance':'B engineering criteria locked before scores; not user-quoted thresholds or significance evidence',
          'full_model_policy':'save exactly two branch artifacts after structurally valid CV, even if negative, as private research output requested by user; status explicitly research-only when screening fails',
          'temporal_only_scores':'descriptive ablation from same fitted Ridge, not an additional selectable candidate; no score-based path/weight/parameter changes',
          'stops':['actual leakage or target misalignment','well overlap or metric failure','baseline mismatch','fit entry budget exhausted','actual system-policy loading block'],
          'parallelism':'folds and branches sequential; OMP/BLAS1; B0 ExtraTrees n_jobs=-1; Ridge svd; HGB one OpenMP thread',
          'unchanged':['raw inputs and selected81 well queue','M-1 input and scale cutoff','M+1..M+12 targets','original325 lag/rolling/trend','original log1p(RCYL/s) and inverse','old environments, models, ZIPs and locks'],
          'OOF_persisted':False,'test_reads':0,'formal_packages':0,'platform_uploads':0,'no_score_based_early_stop':True}
    write(Path('PLAN.json'),plan)
    locked={p.relative_to(T).as_posix():sha(p) for p in T.rglob('*') if p.is_file() and (p.is_relative_to(T/'source') or p.name in ('run_research.py','PLAN.json','PRE_DATA_LOCK.json','ENVIRONMENT_LOCK.json','HISTORY_CHECK.json','USER_AUTHORIZATION.json')) and '__pycache__' not in p.parts}
    write(Path('IMPLEMENTATION_LOCK.json'),{'files':locked,'before_candidate_fit_or_score':True})
    print(json.dumps({'prepared':True,'synthetic':tests['passed'],'fit_entries':0,'model_cap':92,'two_model_size_budget':2097152}))

def validate(args):
    import light_dual as d
    for name,h in json.loads((T/'IMPLEMENTATION_LOCK.json').read_bytes())['files'].items():assert sha(T/name)==h,'SOURCE_CHANGED'
    assert environment()==json.loads((T/'ENVIRONMENT_LOCK.json').read_bytes()),'ENVIRONMENT_CHANGED'
    pre=json.loads((T/'PRE_DATA_LOCK.json').read_bytes());assert sha(args.data)==pre['raw_archive_sha256'] and sha(args.policy)==pre['policy_sha256']
    d.b.verify_source_lock();return d,pre

def train(args):
    d,pre=validate(args);b=d.b;np=d.np
    from ledger035 import Ledger
    from models035 import forbid_fits
    from sklearn.linear_model import Ridge
    from sklearn.ensemble import HistGradientBoostingRegressor
    tick=time.perf_counter();write(Path('execution/STARTED.json'),{'time':datetime.now(timezone(timedelta(hours=8))).isoformat(),'interpreter':sys.executable,'plan_sha256':sha(T/'PLAN.json'),'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json')})
    ledger=Ledger(T/'execution/FIT_EVENTS.json');ledger.value.update(local_success_model_cap=92,local_entry_cap=94,fault_retry_cap=2);ledger.save()
    original_run=ledger.run
    def capped(kind,stage,fn):
        assert ledger.value[kind+'s_entered']<94,'LOCAL_ENTRY_BUDGET'
        return original_run(kind,stage,fn)
    ledger.run=capped
    with b.offline_only():
        d,legacy,panels=inputs(args);control,feature,temporal,af,ff,metadata,audit=panels
        assert b.identity(control,af)==pre['control_identity'] and b.identity(feature,ff)==pre['feature_identity']
        assert b.identity(temporal.assign(WELL_ID=control.WELL_ID,horizon=control.horizon,RCYL=control.RCYL),d.TEMPORAL)==pre['temporal_identity']
        split_sets=b.split_sets(control);assert b.split_fingerprints(split_sets)==pre['split_fingerprints']
        reference=json.loads((T.parent/'A2B035_R17_20261020_v1/execution/CV_COMPLETE17.json').read_bytes())['results']['B0']
        results={};errors={};same_query=[]
        def summarize(oof,foldrows):
            summary=b.summary(control,oof);scores=[x['score'] for x in foldrows]
            return {'score':summary['official_score'],'weighted_losses':summary['weighted_losses'],'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(np.std(scores)),'folds':foldrows,'metric_cross_check_difference':summary['official_cross_check_difference']}
        def evaluate(folds,name,dual):
            pred=np.full(len(control),np.nan);temporal_oof=np.full(len(control),np.nan);coverage=np.zeros(len(control),int);rows=[];trows=[]
            for i,(tr,va) in enumerate(folds,1):
                assert not set(control.iloc[tr].WELL_ID)&set(control.iloc[va].WELL_ID),'WELL_OVERLAP'
                stage=f'{name}-'+('dual' if dual else 'B0')+f'-fold{i}'
                if dual:
                    artifact=d.fit_dual(feature.iloc[tr],temporal.iloc[tr],ff,ledger,stage)
                    with forbid_fits(extra_classes=(Ridge,HistGradientBoostingRegressor)):
                        p,tp=d.predict_dual(artifact,feature.iloc[va],temporal.iloc[va],return_temporal=True)
                        # Actual competition integration: changing other query rows cannot change first query.
                        if i==1:
                            first=d.predict_dual(artifact,feature.iloc[va[:1]],temporal.iloc[va[:1]])[0]
                            error=float(abs(first-p[0]));assert error<=1e-10,'CROSS_QUERY_DEPENDENCE';same_query.append({'split':name,'max_absolute_difference':error,'tolerance':1e-10,'fits_in_check':0})
                    temporal_oof[va]=tp
                else:
                    artifact=d.fit_control(control.iloc[tr],af,legacy,ledger,stage)
                    with forbid_fits():p=d.predict_control(artifact,control.iloc[va])
                pred[va]=p;coverage[va]+=1
                def row(values):
                    s=b.summary(control.iloc[va],values)
                    return {'fold':i,'score':s['official_score'],'weighted_losses':s['weighted_losses'],'train_wells':int(control.iloc[tr].WELL_ID.nunique()),'validation_wells':int(control.iloc[va].WELL_ID.nunique()),'well_overlap':0,'split_sha256':b.fold_hash(tr,va)}
                rows.append(row(p))
                if dual:trows.append(row(tp))
                (T/'execution/PROGRESS.json').write_bytes(enc({'stage':stage,'models_completed':ledger.value['models_completed'],'preprocessors_completed':ledger.value['preprocessors_completed']}))
                del artifact
            assert (coverage==1).all() and np.isfinite(pred).all()
            return summarize(pred,rows),pred,(summarize(temporal_oof,trows) if dual else None)
        for name,folds in split_sets.items():
            a,pa,_=evaluate(folds,name,False);assert abs(a['score']-reference[name]['score'])<=1e-9,'B0_REPRODUCTION_FAILED'
            z,pz,tz=evaluate(folds,name,True)
            results[name]={'B0':a,'candidate':z,'candidate_minus_B0':z['score']-a['score'],'temporal_only_descriptive':tz}
            import freshness
            errors[name]=freshness.error_groups(control,pa,pz,metadata,folds)
            write(Path('execution')/(name+'.json'),{'results':results[name],'error_groups':errors[name]})
            del pa,pz
        deltas=[results['repeat_'+str(i)]['candidate_minus_B0'] for i in range(1,6)]
        screen=results['fixed']['candidate_minus_B0']>=-.2 and np.mean(deltas)>=.2 and sum(x>0 for x in deltas)>=4 and min(deltas)>=-.2
        full=d.fit_dual(feature,temporal,ff,ledger,'dual-full')
        private=T/'private';private.mkdir();artifacts=[]
        for name in ('temporal','feature'):
            p=private/(name+'_model.joblib');b.joblib.dump(full[name],p,compress=3)
            artifacts.append({'branch':name,'file':p.name,'sha256':sha(p),'bytes':p.stat().st_size})
        total_bytes=sum(x['bytes'] for x in artifacts);size_pass=total_bytes<=2097152
        with forbid_fits(extra_classes=(Ridge,HistGradientBoostingRegressor)):
            expected=d.predict_dual(full,feature,temporal)
            loaded={'temporal':b.joblib.load(private/'temporal_model.joblib'),'feature':b.joblib.load(private/'feature_model.joblib')}
            actual=d.predict_dual(loaded,feature,temporal)
        assert np.array_equal(expected,actual),'RELOAD_MISMATCH';del expected,actual,loaded
        structure={'leakage':'PASS','target_alignment':'PASS','well_isolation':'PASS','official_metric':'PASS','six_B0_reproductions':'PASS','real_future_mutation_checks':audit['real_future_mutation_feature_checks'],'query_independence':same_query,'no_fit_in_predict':'PASS','model_size':'PASS' if size_pass else 'FAIL','independent_review':'PENDING'}
        if size_pass and screen:status='PENDING_INDEPENDENT_REVIEW'
        else:status='RESEARCH_ONLY_NOT_RECOMMENDED'
        params={'Ridge_coefficients':int(full['temporal']['model'].coef_.size+1),'HGB_iterations':int(full['feature']['model'].n_iter_),'HGB_total_nodes':sum(int(len(t.nodes)) for it in full['feature']['model']._predictors for t in it)}
        del full
        assert ledger.value['models_entered']==ledger.value['models_completed']==ledger.value['preprocessors_entered']==ledger.value['preprocessors_completed']==92
        validate(args)
        result={'task':'A2B-035/LIGHT_DUAL','role':'账户B执行与交付','spec':d.spec(),'results':results,'repeat_deltas':deltas,'repeat_mean_delta':float(np.mean(deltas)),'positive_repeats':sum(x>0 for x in deltas),'worst_repeat_delta':min(deltas),'screen_pass':bool(screen),'size_pass':size_pass,'status':status,'artifacts':artifacts,'combined_model_bytes':total_bytes,'learned_structure':params,'structure':structure,'models_fitted':92,'preprocessors_fitted':92,'model_failures':ledger.value['failures'],'retries':0,'artifact_reload_exact':True,'reload_on_training_not_validation':True,'OOF_persisted':False,'test_CSV_reads':0,'test_predictions':0,'formal_ZIP':0,'platform_uploads':0,'old_models_replaced':False,'plan_sha256':sha(T/'PLAN.json'),'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json'),'seconds':time.perf_counter()-tick}
        write(Path('private/MODEL_REGISTRY.json'),{'root':str(private),'artifacts':artifacts,'status':status,'not_deployed':True,'spec':d.spec(),'plan_sha256':sha(T/'PLAN.json')})
        write(Path('execution/ERROR_GROUPS.json'),errors);write(Path('execution/STRUCTURE.json'),structure);write(Path('execution/RESULT_LIGHT_DUAL.json'),result)
        print(json.dumps({k:result[k] for k in ('status','repeat_deltas','repeat_mean_delta','positive_repeats','combined_model_bytes','models_fitted','preprocessors_fitted','seconds')},indent=2))
        print(json.dumps({'fixed_B0':results['fixed']['B0']['score'],'fixed_candidate':results['fixed']['candidate']['score'],'fixed_delta':results['fixed']['candidate_minus_B0']},indent=2))

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','train']);ap.add_argument('--data',required=True);ap.add_argument('--policy',required=True);args=ap.parse_args()
    try:{'prepare':prepare,'train':train}[args.mode](args)
    except Exception as exc:
        p=T/'execution/FAILURE.json';p.parent.mkdir(parents=True,exist_ok=True)
        if not p.exists():p.write_bytes(enc({'type':type(exc).__name__,'message':str(exc) if isinstance(exc,(AssertionError,RuntimeError)) else 'technical failure; private stderr retained locally','budget_not_reset':True}))
        raise
