"""R15 W/HX research paths. No score or test-dependent route selection."""
import r14 as h
from r14 import np,pd,old,require,copy,fingerprint,encode,Path
from models035 import estimator_for
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import GroupKFold
import hashlib

def b0():return old.load_variant(old.HERE/'configs/B0.json')
def input_identity(panel,features):
    x=panel.copy()
    if 'HX_CSLB_counts' in features:x['HX_CSLB_counts']=x.HX_CSLB_counts.map(lambda v:__import__('json').dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')))
    return old.identity(x,features)
def route(name,base,W=False,HX=False,T=False):return {'schema':'A2B035-R15-v1','variant':name,'base':copy.deepcopy(base),'W':W,'HX':HX,'T':T}
def valid(c):
    require(set(c)=={'schema','variant','base','W','HX','T'} and c['schema']=='A2B035-R15-v1','R15_CONFIG_KEYS')
    require(all(type(c[k]) is bool for k in ('W','HX','T')) and not(c['T'] and c['HX']),'R15_FLAGS')
    b=c['base']
    if b.get('schema')==old.SCHEMA:
        old.validate_config(b);require(h.normalized(b) in (h.normalized(b0()),h.normalized(h.original_b0prime())),'R15_BASE_SCOPE')
    else:h.validate(b)
    return c

def raw_metadata(history,wid,t0,base,legacy):
    legal,end=old.legal_history(history,wid,t0,base['cutoff'],legacy);p=pd.to_datetime(legal.NY).dt.to_period('M');q=legal.assign(__period=p).sort_values('__period');v=pd.to_numeric(q.RCYL,errors='coerce').to_numpy(float);good=v[np.isfinite(v)&(v>=0)];raw=v[-1]
    if base['cutoff']=='T0_minus_1':_,_,meta=h.additions(history,wid,t0,legacy)
    else:meta={'M_ratio':np.nan,'M_SCTS_fraction':np.nan}
    meta.update(WELL_ID=wid,production_level=float(good.mean()) if len(good) else np.nan,scale_fallback=not(np.isfinite(raw) and raw>0));return meta

def hx_values(legal,end,legacy,include_ljcyl):
    date=legacy['anchors']['date_column'];months=pd.to_datetime(legal[date]).dt.to_period('M');q=legal.assign(__period=months).sort_values('__period');col='CSLB';types={};measure_months=[]
    if col in q:
        for value,month in zip(q[col],q.__period):
            if pd.notna(value) and str(value).strip():key=str(value).strip();types[key]=types.get(key,0)+1;measure_months.append(month)
    out={'HX_production_months':end.ordinal-q.__period.iloc[0].ordinal+1,'HX_measure_count':sum(types.values()),'HX_months_since_measure':end.ordinal-measure_months[-1].ordinal if measure_months else np.nan,'HX_CSLB_counts':types}
    if include_ljcyl:
        vals=pd.to_numeric(q.get('LJCYL',pd.Series(dtype=float)),errors='coerce');vals=vals[np.isfinite(vals)];out['HX_LJCYL_last']=float(vals.iloc[-1]) if len(vals) else np.nan
    return out

class HXPreprocessor:
    def __init__(self):self.base=None;self.counts=DictVectorizer(sparse=False,sort=True)
    def fit_transform(self,x,y):
        numeric=x.drop(columns=['HX_CSLB_counts']);self.base=old.training._preprocessor(numeric);a=self.base.fit_transform(numeric,y);b=self.counts.fit_transform(x.HX_CSLB_counts.tolist());return np.concatenate([a,b],axis=1)
    def transform(self,x):return np.concatenate([self.base.transform(x.drop(columns=['HX_CSLB_counts'])),self.counts.transform(x.HX_CSLB_counts.tolist())],axis=1)

class Provider:
    def __init__(self,history,policy,legacy,include_ljcyl=False):self.history=history;self.policy=policy;self.legacy=legacy;self.include_ljcyl=include_ljcyl;self.h_provider=h.Panels(history,policy,legacy);self.cache={}
    def get(self,c):
        valid(c);base=c['base'];key=fingerprint({'base':base,'HX':c['HX'],'include_ljcyl':self.include_ljcyl})
        if key in self.cache:return self.cache[key]
        if base.get('kind')=='H':panel,fs,audit,meta=self.h_provider.get(base)
        else:
            panel,fs,audit=old.build_variant_train(self.history,self.policy,self.legacy,base);meta=pd.DataFrame([raw_metadata(self.history,wid,pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1,base,self.legacy) for wid,g in panel.groupby('WELL_ID',sort=False)])
        panel=panel.copy();fs=list(fs)
        if c['HX']:
            added=[]
            for wid,g in panel.groupby('WELL_ID',sort=False):
                t0=pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1;legal,end=old.legal_history(self.history,wid,t0,base['cutoff'],self.legacy);vals=hx_values(legal,end,self.legacy,self.include_ljcyl)
                for k,v in vals.items():
                    if k not in panel:panel[k]=pd.Series([None]*len(panel),dtype=object) if isinstance(v,dict) else np.nan
                    for i in g.index:panel.at[i,k]=v
                added=list(vals)
            fs+=added;require(not any('NCYL' in name for name in added),'NCYL_FORBIDDEN')
        self.cache[key]=(panel,fs,audit,meta);return self.cache[key]

def fit_model(panel,fs,c,legacy,ledger,stage):
    valid(c);base=c['base'];x=panel[fs];proxy=h.proxy(base) if base.get('kind')=='H' else base;y=old.transform_target(panel,proxy);model=estimator_for(proxy,x.drop(columns=['HX_CSLB_counts'],errors='ignore'),legacy);prep=HXPreprocessor() if c['HX'] else old.training._preprocessor(x)
    xx=ledger.run('preprocessor',stage,lambda:prep.fit_transform(x,y));kwargs={'sample_weight':2.**(-panel.horizon.to_numpy(float))} if c['W'] else {}
    ledger.run('model',stage,lambda:model.fit(xx,y,**kwargs));return {'preprocessor':prep,'model':model,'features':fs,'config_fingerprint':fingerprint(c)}
def predict_model(artifact,panel,c):
    require(artifact['config_fingerprint']==fingerprint(c),'R15_MODEL_CONFIG');import joblib
    with joblib.parallel_backend('sequential'):z=artifact['model'].predict(artifact['preprocessor'].transform(panel[artifact['features']]))
    return old.inverse_target(z,panel)

def evaluate(c,provider,folds,ledger,stage,base_pred=None):
    p,fs,audit,meta=provider.get(c);out=np.full(len(p),np.nan);coverage=np.zeros(len(p),int);records=[]
    for no,(tr,va) in enumerate(folds,1):
        require(not set(p.iloc[tr].WELL_ID)&set(p.iloc[va].WELL_ID),'R15_WELL_OVERLAP');train=h.specialist_rows(p,tr) if c['T'] else tr
        artifact=fit_model(p.iloc[train],fs,c,provider.legacy,ledger,stage+'-fold'+str(no))
        if c['T']:
            require(base_pred is not None,'T_BASE_MEMORY_REQUIRED');early=h.specialist_rows(p,va);pred=h.splice(p.iloc[va],base_pred[va],predict_model(artifact,p.iloc[early],c))
        else:pred=predict_model(artifact,p.iloc[va],c)
        out[va]=pred;coverage[va]+=1;v=old.summary(p.iloc[va],pred);records.append({'fold':no,'score':v['official_score'],'weighted_losses':v['weighted_losses'],'train_wells':p.iloc[train].WELL_ID.nunique(),'effective_train_month_rows':len(train),'validation_wells':p.iloc[va].WELL_ID.nunique(),'well_overlap':0,'split_sha256':h.fold_hash(tr,va),'training_sample_weight':'2^-horizon unnormalized' if c['W'] else 'none','preprocessor_fit_count':1,'model_fit_count':1,'T_late_horizons_unchanged':True if c['T'] else None,'HX_measure_type_vocabulary_source':'training fold only' if c['HX'] else None})
    require((coverage==1).all() and np.isfinite(out).all(),'R15_OOF_COVERAGE');v=old.summary(p,out);scores=[r['score'] for r in records]
    return {'score':v['official_score'],'weighted_losses':v['weighted_losses'],'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(np.std(scores)),'folds':records},out
