"""Local anonymous-control RPC. Row matrices stay in process memory and pipes."""
import sys,struct,pickle,json,contextlib,os
from pathlib import Path
pipein=sys.stdin.buffer;pipeout=sys.stdout.buffer;sys.stdout=sys.stderr
sys.path.insert(0,str(Path(__file__).resolve().parent));import study16 as s
def read():
    raw=pipein.read(8)
    if not raw:return None
    n=struct.unpack('!Q',raw)[0];data=b''
    while len(data)<n:data+=pipein.read(n-len(data))
    return pickle.loads(data)
def write(x):
    b=pickle.dumps(x,protocol=5);pipeout.write(struct.pack('!Q',len(b))+b);pipeout.flush()
ledger=None
with s.old.offline_only():
    while True:
        q=read()
        if q is None or q.get('op')=='stop':break
        try:
            if q['op']=='runtime':write({'ok':True,'value':s.runtime()});continue
            if q['op']=='fit':
                if ledger is None:ledger=s.Ledger(q['ledger'])
                a=s.fit(q['c'],q['train'],q['features'],q['legacy'],ledger,q['stage'],q['weights']);pred=s.predict(a,q['valid']);e=s.integration(a,q['valid'],q['policy'],q['legacy'],q['history_columns']) if q.get('integration') else None
                write({'ok':True,'prediction':pred,'integration':e,'runtime':s.runtime(),'transformed_features':a['transformed_features']});del a;continue
            raise RuntimeError('UNKNOWN_LOCAL_RPC')
        except Exception as exc:
            import traceback;traceback.print_exc(file=sys.stderr);write({'ok':False,'type':type(exc).__name__,'message':str(exc)})
