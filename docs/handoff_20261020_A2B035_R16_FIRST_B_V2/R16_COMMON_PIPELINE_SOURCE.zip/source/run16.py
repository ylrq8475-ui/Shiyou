"""R16 locked finite research batch. All row OOF stays in memory."""
import sys,os,argparse,subprocess,struct,pickle,json,time,copy,hashlib,traceback,threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent));import study16 as s
from study16 import np,pd,old,h,require,encode,Ledger,budget
from error_budget import pairs
from sklearn.model_selection import GroupKFold
T=Path(__file__).resolve().parent.parent
STATE_LOCK=threading.RLock()
def save(p,x):
    with STATE_LOCK:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(encode(x))
def verify():
    lock=json.loads((T/'RESEARCH_LOCK16.json').read_bytes())
    for n,d in lock['files'].items():require(old.file_sha(T/n)==d,'R16_SOURCE_OR_CONFIG_CHANGED')
    old.verify_source_lock();require(s.runtime()==json.loads((T/'execution/ENV_NATIVE.json').read_bytes()),'NATIVE_RUNTIME_DRIFT')
class TabWorker:
    def __init__(self,exe):
        self.err=(T/'private/TAB_WORKER_STDERR.txt').open('wb');self.p=subprocess.Popen([str(exe),'-B',str(T/'source/tab_worker16.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err);self.runtime=self.call({'op':'runtime'})['value'];require(self.runtime==json.loads((T/'execution/ENV_TAB.json').read_bytes()),'TAB_RUNTIME_DRIFT')
    def call(self,q):
        b=pickle.dumps(q,protocol=5);self.p.stdin.write(struct.pack('!Q',len(b))+b);self.p.stdin.flush();raw=self.p.stdout.read(8);require(len(raw)==8,'LOCAL_TAB_WORKER_STOPPED');n=struct.unpack('!Q',raw)[0];b=b''
        while len(b)<n:
            part=self.p.stdout.read(n-len(b));require(bool(part),'LOCAL_TAB_WORKER_EOF');b+=part
        value=pickle.loads(b)
        if not value.get('ok'):
            save(T/'private/TAB_WORKER_LAST_ERROR.json',value);raise RuntimeError('TAB_WORKER_'+value['type'])
        return value
    def close(self):
        try:self.call_stop()
        finally:self.p.wait(timeout=30);self.err.close()
    def call_stop(self):
        b=pickle.dumps({'op':'stop'},protocol=5);self.p.stdin.write(struct.pack('!Q',len(b))+b);self.p.stdin.flush();self.p.stdin.close()
def main(a):
    require(not (T/'execution/STARTED16.json').exists(),'NO_RESTART_OF_SUCCESSFUL_FITS');verify();grid=json.loads((T/'configs/GRID16.json').read_bytes());started=time.perf_counter();save(T/'execution/STARTED16.json',{'lock_sha256':old.file_sha(T/'RESEARCH_LOCK16.json'),'before_first_real_fit':True,'fits_cap':None,'all_new_paths_upload_eligible':False});ledger=Ledger(T/'execution/NATIVE_FITS16.json');policy,legacy=old.load_locked_policy(a.policy);manifest=json.loads(Path(a.manifest).read_bytes());store=old.Inputs(a.data_archive)
    try:
        require(old.file_sha(a.data_archive)==json.loads((old.HERE/'DATA_CONTRACT.json').read_bytes())['raw_archive_sha256'],'RAW_ARCHIVE_CHANGED')
        for r in manifest['files']:require(old.sha(store.raw(r['relative_path']))==r['sha256'],'RAW_MEMBER_CHANGED')
        history=old.load_train(store,legacy)
    finally:store.close()
    provider=s.Provider(history,policy,legacy);panels={cut:provider.get({'cutoff':cut}) for cut in ('M_minus_1','T0_minus_1')};first=panels['M_minus_1'][0];require(first[['WELL_ID','horizon','RCYL']].equals(panels['T0_minus_1'][0][['WELL_ID','horizon','RCYL']]),'CROSS_CUTOFF_TARGET_ALIGNMENT');splits=h.split_sets(first);require(h.split_fingerprints(splits)==json.loads((old.HERE/'DATA_CONTRACT.json').read_bytes())['split_fingerprints'],'ORIGINAL_SPLITS_CHANGED');save(T/'execution/PRE_DATA16.json',{'data_sha256':old.file_sha(a.data_archive),'private_policy_sha256':old.file_sha(a.policy),'data_members_verified':100,'panels':{cut:{'features':len(v[1]),'identity':old.identity(v[0],v[1]),'boundary':v[2]} for cut,v in panels.items()},'before_real_fit':True,'test_files_parsed':0});worker=TabWorker(a.tab_python);cache={};records={};memory={};integrated=set();failures=[];blocked=set()
    def progress():
        save(T/'execution/PROGRESS16.json',{'successful_variants':len(records),'first_integrations':sorted(integrated),'failed_or_blocked':failures,'native_models':ledger.value['models_completed'],'native_preprocessors':ledger.value['preprocessors_completed'],'Tab_worker_counts':json.loads((T/'execution/TAB_FITS16.json').read_bytes()) if (T/'execution/TAB_FITS16.json').exists() else None,'elapsed_seconds':time.perf_counter()-started,'OOF_disk':False})
    def fold(c,env,sn,no,tr,va,stage_extra=''):
        key=(c['variant'],env,sn,no,stage_extra)
        if key in cache:return cache[key]
        verify();p,fs,audit,meta=panels[c['cutoff']];require(not set(p.iloc[tr].WELL_ID)&set(p.iloc[va].WELL_ID),'WELL_ISOLATION_FAILURE');stage=c['variant']+'-'+sn+'-'+str(no)+stage_extra;need=c['learner'] in ('LightGBM','CatBoost','TabPFN') and c['learner'] not in integrated;tick=time.perf_counter()
        if env=='TAB':
            response=worker.call({'op':'fit','c':c,'train':p.iloc[tr],'valid':p.iloc[va],'features':fs,'legacy':legacy,'weights':str(a.weights),'ledger':str(T/'execution/TAB_FITS16.json'),'stage':stage,'integration':need,'policy':policy,'history_columns':list(history.columns)});pred=response['prediction'];evidence=response['integration']
        else:
            fitted=s.fit(c,p.iloc[tr],fs,legacy,ledger,stage,a.weights);pred=s.predict(fitted,p.iloc[va]);evidence=s.integration(fitted,p.iloc[va],policy,legacy,list(history.columns)) if need else None;del fitted
        value=old.summary(p.iloc[va],pred);result={'score':value['official_score'],'weighted_losses':value['weighted_losses'],'fold':no,'training_wells':p.iloc[tr].WELL_ID.nunique(),'validation_wells':p.iloc[va].WELL_ID.nunique(),'well_overlap':0,'split_sha256':h.fold_hash(tr,va),'environment':env,'training_weights':'2^-horizon unnormalized' if c['W'] else 'none','model_fits':1,'preprocessor_fits':1,'seconds':time.perf_counter()-tick};cache[key]=(pred,result)
        if evidence:
            evidence.update(task='R16 first actual competition integration',config=c,environment=s.runtime() if env=='NATIVE' else worker.runtime,environment_hash=old.fingerprint(s.runtime() if env=='NATIVE' else worker.runtime),source_lock_sha256=old.file_sha(T/'RESEARCH_LOCK16.json'),resource_review_commit='929287843e30906144ca6caca4a4f5fdc6c2ec3d',actual_fold=result,new_path_upload_eligible=False)
            save(T/'execution'/('INTEGRATION_'+c['learner']+'.json'),evidence);integrated.add(c['learner']);progress();print('INTEGRATION_READY '+c['learner'],flush=True)
        return pred,result
    def evaluate(c,env):
        require(c['variant'] not in records,'COMPLETED_VARIANT_REUSE_REQUIRED');s.valid(c);p,fs,audit,meta=panels[c['cutoff']];folder=T/'execution'/c['variant'];folder.mkdir(exist_ok=True);save(folder/'PRESCORE.json',{'config':c,'environment':env,'runtime_hash':old.fingerprint(s.runtime() if env=='NATIVE' else worker.runtime),'panel_identity':old.identity(p,fs),'source_lock_sha256':old.file_sha(T/'RESEARCH_LOCK16.json'),'before_first_fit_or_prelocked_first_integration_fold':True});oofs={};values={};budgets={}
        print('BEGIN '+c['variant'],flush=True)
        for sn,folds in splits.items():
            out=np.full(len(p),np.nan);coverage=np.zeros(len(p),int);rs=[]
            for no,(tr,va) in enumerate(folds,1):pred,r=fold(c,env,sn,no,tr,va);out[va]=pred;coverage[va]+=1;rs.append(r)
            require((coverage==1).all() and np.isfinite(out).all(),'OOF_COVERAGE');v=old.summary(p,out);scores=[r['score'] for r in rs];values[sn]={'score':v['official_score'],'weighted_losses':v['weighted_losses'],'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(np.std(scores)),'folds':rs,'validation_rows_once':True};oofs[sn]=out;budgets[sn]=budget(p,out,meta,folds);save(folder/(sn+'.json'),{'evaluation':values[sn],'error_budget':budgets[sn]})
        values['repeated_summary']=h.repeated_summary([values['repeat_'+str(i)] for i in range(1,6)]);result={'config':c,'environment':env,'results':values,'error_budget':budgets,'new_path_upload_eligible':False};records[c['variant']]=result;memory[c['variant']]=oofs;save(folder/'RESULT.json',result);progress();print('DONE '+c['variant']+' '+str(values['repeated_summary']['mean']),flush=True)
    try:
        with old.offline_only():
            # Independent streams: slow Tab inference cannot block native models.
            def execute_item(item):
                c=item['config']
                if c['learner'] in blocked:return
                try:evaluate(c,item['environment'])
                except Exception as exc:
                    failures.append({'variant':c['variant'],'status':'FAILED_NOT_RETRAINED','type':type(exc).__name__,'code':str(exc) if isinstance(exc,RuntimeError) else 'PRIVATE_DETAIL'});(T/'private'/(c['variant']+'_TRACE.txt')).write_text(traceback.format_exc(),encoding='utf-8');progress()
                    if c['learner']=='TabPFN':blocked.add('TabPFN')
            def tab_study():
                c=next(x for x in grid['variants'] if x['config']['learner']=='TabPFN');tr,va=splits['fixed'][0]
                try:fold(c['config'],'TAB','fixed',1,tr,va)
                except Exception as exc:
                    failures.append({'learner':'TabPFN','status':'FIRST_ACTUAL_BATCH_BLOCKED','error_type':type(exc).__name__,'code':str(exc) if isinstance(exc,RuntimeError) else 'PRIVATE_DETAIL','scope':'no fallback or unsupported W'});blocked.add('TabPFN');progress()
                for item in grid['variants']:
                    if item['environment']=='TAB':execute_item(item)
            pool=ThreadPoolExecutor(max_workers=1);tab_future=pool.submit(tab_study)
            for learner in ('LightGBM','CatBoost'):
                item=next(x for x in grid['variants'] if x['config']['learner']==learner);tr,va=splits['fixed'][0];fold(item['config'],'NATIVE','fixed',1,tr,va)
            for item in grid['variants']:
                if item['environment']=='NATIVE':execute_item(item)
            save(T/'execution/NATIVE_MATRIX_COMPLETE.json',{'records':[r for r in records.values() if r['environment']=='NATIVE'],'row_OOF_persisted':False,'Tab_still_running':not tab_future.done()});print('NATIVE_MATRIX_COMPLETE',flush=True)
            tab_future.result();pool.shutdown(wait=True)
            for name,r in records.items():
                ctrl=('CTRL_TAB_' if r['environment']=='TAB' else 'CTRL_NATIVE_')+('B0' if r['config']['cutoff']=='M_minus_1' else 'B0P');b=records.get(ctrl)
                if b:r['same_environment_control']={'variant':ctrl,'fixed_delta':r['results']['fixed']['score']-b['results']['fixed']['score'],'repeated_delta':r['results']['repeated_summary']['mean']-b['results']['repeated_summary']['mean']}
            save(T/'execution/MATRIX_COMPLETE16.json',{'status':'MATRIX_COMPLETE_WITH_EXPLICIT_UNSUPPORTED_BRANCHES' if not failures else 'MATRIX_COMPLETED_WITH_RECORDED_BLOCKS','records':list(records.values()),'failures':failures,'TabPFN_W':'NOT_SUPPORTED_BY_PINNED_DEFAULT_FIT_API; no substitute','row_OOF_persisted':False,'platform_uploads':0});print('MATRIX_COMPLETE16',flush=True)
            # Winners chosen once by registered ranking; cross-validation is exploratory.
            rank=lambda r:(-r['results']['repeated_summary']['mean'],r['results']['repeated_summary']['standard_error'],-r['results']['fixed']['score'],r['config']['variant'])
            winners=[sorted([r for r in records.values() if r['config']['cutoff']==cut],key=rank)[0] for cut in ('M_minus_1','T0_minus_1')];save(T/'execution/WINNERS_BEFORE_FUSION.json',{'winners':[r['config'] for r in winners],'environments':[r['environment'] for r in winners],'basis':'repeat mean then SE then fixed then variant; exploratory same81wells'});combo={};correlation={}
            for sn,outer in splits.items():
                p=first;left=memory[winners[0]['config']['variant']][sn];right=memory[winners[1]['config']['variant']][sn];equal=(left+right)*.5;weighted=np.full(len(p),np.nan);weight_records=[]
                for no,(tr,va) in enumerate(outer,1):
                    train=p.iloc[tr];inner=list(GroupKFold(5,shuffle=True,random_state=20260916).split(train,groups=train.WELL_ID));member=[]
                    for j,r in enumerate(winners):
                        arr=np.full(len(tr),np.nan)
                        for k,(itr,iva) in enumerate(inner,1):
                            gtr=np.asarray(tr)[itr];gva=np.asarray(tr)[iva];require(not set(gtr)&set(va) and not set(gva)&set(va),'OUTER_VALIDATION_IN_WEIGHT_FIT');pred,_=fold(r['config'],r['environment'],sn+'-outer'+str(no)+'-inner',k,gtr,gva,'-fusion_member'+str(j));arr[iva]=pred
                        member.append(arr)
                    best=None
                    for units in range(11):
                        w=units/10.;score=old.summary(train,w*member[0]+(1-w)*member[1])['official_score']
                        if best is None or score>best[0]:best=(score,w)
                    w=best[1];weighted[va]=w*left[va]+(1-w)*right[va];weight_records.append({'outer_fold':no,'B0_weight':w,'B0prime_weight':1-w,'source':'outer training wells five inner GroupKFold OOF only','inner_seed':20260916,'outer_validation_rows_used':0,'weight_grid':'.0..1.0 step.1','inner_score':best[0]})
                ev={}
                for n,out in [('equal_50_50',equal),('training_inner_grid_0_1',weighted)]:
                    v=old.summary(p,out);fold_scores=[old.summary(p.iloc[va],out[va])['official_score'] for _,va in outer];ev[n]={'score':v['official_score'],'weighted_losses':v['weighted_losses'],'fold_scores':fold_scores,'worst_fold':min(fold_scores),'fold_std_population':float(np.std(fold_scores)),'error_budget':budget(p,out,panels['M_minus_1'][3],outer),'score_delta_to_best_member':v['official_score']-max(old.summary(p,left)['official_score'],old.summary(p,right)['official_score']),'first_two_month_loss_reduction_vs_best_member':min(old.summary(p,left)['weighted_losses']['m1_to_2'],old.summary(p,right)['weighted_losses']['m1_to_2'])-v['weighted_losses']['m1_to_2']}
                combo[sn]={'methods':ev,'training_inner_weight_records':weight_records};correlation[sn]=pairs(p,{'best_B0':left,'best_B0prime':right});save(T/'execution'/('FUSION_'+sn+'.json'),combo[sn])
            for method in ('equal_50_50','training_inner_grid_0_1'):combo[method+'_repeated_summary']=h.repeated_summary([combo['repeat_'+str(i)]['methods'][method] for i in range(1,6)])
            save(T/'execution/FINAL_RESEARCH16.json',{'status':'R16_CONTROLLED_RESEARCH_COMPLETE','records':list(records.values()),'winners':[r['config'] for r in winners],'fusion':combo,'paired_errors':correlation,'failures':failures,'TabPFN_W':'NOT_SUPPORTED; no unapproved approximation','actual_new_rows_persisted':False,'all_versions_upload_eligible':False,'S_v':'UNKNOWN','seconds':time.perf_counter()-started});print('R16_RESEARCH_COMPLETE',flush=True)
    finally:worker.close()
if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for n in ('data_archive','policy','manifest','tab_python','weights'):ap.add_argument('--'+n,required=True)
    main(ap.parse_args())
