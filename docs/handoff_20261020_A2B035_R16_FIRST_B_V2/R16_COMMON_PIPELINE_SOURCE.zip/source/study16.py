"""R16 learner adapters; original frozen boundary/metric remain unmodified."""
import os,sys,json,hashlib,platform,importlib.metadata as im,inspect,time,copy
from pathlib import Path
from datetime import datetime,timezone
NATIVE_THREADS=max(1,(os.cpu_count() or 2)-1)
for k in ('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_HUB_DISABLE_TELEMETRY','DO_NOT_TRACK','TABPFN_DISABLE_TELEMETRY'):os.environ[k]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import r14 as h
from r14 import old,np,pd,require,fingerprint,encode,Ledger
from models035 import forbid_fits
from error_budget import budget
import routes15
def runtime():return {'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({x.metadata['Name']:x.version for x in im.distributions()}.items()))}
def proxy(c):return old.load_variant(old.HERE/'configs'/('B0.json' if c['cutoff']=='M_minus_1' else 'B0_prime.json'))
def valid(c):
    require(set(c)=={'variant','cutoff','learner','params','W'} and c['cutoff'] in ('M_minus_1','T0_minus_1') and type(c['W']) is bool,'R16_CONFIG_SCOPE')
    p=c['params'];name=c['learner']
    if name=='LightGBM':require(set(p)=={'num_leaves','min_data_in_leaf','learning_rate','n_estimators'} and p['num_leaves'] in (7,15) and p['min_data_in_leaf'] in (10,20) and p['learning_rate']==.05 and p['n_estimators'] in (300,600),'R16_LGB_GRID')
    elif name=='CatBoost':require(set(p)=={'depth','iterations','learning_rate'} and p['depth'] in (4,6) and p['iterations']==800 and p['learning_rate']==.05,'R16_CAT_GRID')
    elif name=='TabPFN':require(p=={} and not c['W'],'TABPFN_221_NO_SAMPLE_WEIGHT_API')
    elif name=='ExtraTrees':require(p=={} and not c['W'],'R16_CONTROLS_ONLY')
    else:raise RuntimeError('R16_UNREGISTERED_LEARNER')
    return c
def estimator(c,x,legacy,weights):
    valid(c);name=c['learner'];p=c['params']
    if name=='LightGBM':
        require(im.version('LightGBM')=='4.6.0','LGB_VERSION');from lightgbm import LGBMRegressor
        return LGBMRegressor(**p,random_state=20260916,n_jobs=NATIVE_THREADS)
    if name=='CatBoost':
        require(im.version('CatBoost')=='1.2.8','CAT_VERSION');from catboost import CatBoostRegressor
        return CatBoostRegressor(**p,random_seed=20260916,thread_count=NATIVE_THREADS,verbose=False,allow_writing_files=False)
    if name=='TabPFN':
        require(im.version('tabpfn')=='2.2.1','TABPFN_VERSION');from tabpfn import TabPFNRegressor
        require('sample_weight' not in inspect.signature(TabPFNRegressor.fit).parameters,'REASSESS_CHANGED_TAB_API');require(old.file_sha(weights)=='2ab5a07d5c41dfe6db9aa7ae106fc6de898326c2765be66505a07e2868c10736','TAB_WEIGHT_IDENTITY')
        import torch;torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
        return TabPFNRegressor(model_path=Path(weights),device='cpu',random_state=20260916)
    return old.training._model_pipeline(old.safe.MODEL_NAME,x,legacy).named_steps['model'].set_params(n_jobs=NATIVE_THREADS)
def tab_deadline():
    if datetime.now(timezone.utc)<datetime(2026,10,22,16,0,tzinfo=timezone.utc):return
    root=HERE.parent;approval=root/'received/TAB_COMPETITION_APPROVAL.json'
    require(approval.exists(),'TAB_DEADLINE_NO_CODEX_INTEGRATION_APPROVAL')
    a=json.loads(approval.read_bytes());require(a.get('role')=='Codex' and a.get('can_search') is True and a.get('source_lock_sha256')==old.file_sha(root/'RESEARCH_LOCK16.json') and len(a.get('review_commit',''))==40,'TAB_APPROVAL_IDENTITY')
    require(datetime.fromisoformat(a['published_at'])<datetime(2026,10,22,16,0,tzinfo=timezone.utc),'TAB_APPROVAL_WAS_AFTER_DEADLINE')
def fit(c,p,fs,legacy,ledger,stage,weights):
    if c['learner']=='TabPFN':tab_deadline()

    valid(c);x=p[fs];y=old.transform_target(p,proxy(c));prep=old.training._preprocessor(x);xx=ledger.run('preprocessor',stage,lambda:prep.fit_transform(x,y));model=estimator(c,x,legacy,weights);kw={'sample_weight':2.**(-p.horizon.to_numpy(float))} if c['W'] else {}
    ledger.run('model',stage,lambda:model.fit(xx,y,**kw));return {'model':model,'prep':prep,'features':fs,'config':c,'transformed_features':xx.shape[1]}
def predict(a,p):
    model=a['model'];prep=a['prep'];fs=a['features']
    with forbid_fits((type(model),)),old.joblib.parallel_backend('sequential'):
        if a['config']['learner']=='TabPFN':
            z=[]
            for i in range(len(p)):
                tab_deadline();z.append(float(model.predict(prep.transform(p[fs].iloc[[i]]))[0]))
            z=np.asarray(z)
        else:z=np.asarray(model.predict(prep.transform(p[fs])))
    return old.inverse_target(z,p)
class Provider:
    def __init__(self,history,policy,legacy):self.history=history;self.policy=policy;self.legacy=legacy;self.cache={}
    def get(self,c):
        key=c['cutoff']
        if key not in self.cache:
            p,f,a=old.build_variant_train(self.history,self.policy,self.legacy,proxy(c));m=pd.DataFrame([routes15.raw_metadata(self.history,wid,pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1,proxy(c),self.legacy) for wid,g in p.groupby('WELL_ID',sort=False)]);self.cache[key]=(p,f,a,m)
        return self.cache[key]
def integration(a,validation,policy,legacy,history_columns):
    q=validation.iloc[:3];batch=predict(a,q);single=np.concatenate([predict(a,q.iloc[[i]]) for i in range(3)]);rev=predict(a,q.iloc[::-1])[::-1];extra=predict(a,pd.concat([q,q.assign(**{a['features'][0]:123456})],ignore_index=True))[:3]
    require(np.array_equal(batch,single) and np.array_equal(batch,rev) and np.array_equal(batch,extra),'R16_ACTUAL_QUERY_DEPENDENCE')
    months=pd.period_range('1990-01',periods=30,freq='M');names=legacy['data']['sources']['test']['history'];frames={};keys=[]
    for i,n in enumerate(names):
        f=pd.DataFrame({col:np.arange(30,dtype=float)+i+1 for col in history_columns});f['WELL_ID']='SYNTH_'+str(i);f['NY']=[str(p.to_timestamp().date()) for p in months];ec=legacy['anchors']['event_column'];f[ec]='SYNTH_NONE';f.loc[16:17,ec]=legacy['anchors']['eligible_event_values'][0];f['RCYL']=np.arange(30,dtype=float)+3;f['RCYL1']=f.RCYL*2;f['SCTS']=20.;frames[n]=f;keys+=list(f.iloc[18:][['WELL_ID','NY']].itertuples(index=False,name=None))
    pol=copy.deepcopy(policy);pol['template_key_sha256']=fingerprint(keys)
    class Store:
        def __init__(self,poison=(),invalid=False):self.poison=poison;self.invalid=invalid
        def raw(self,n):
            f=frames[n].copy()
            for col in self.poison:f[col]=f[col].astype(object);f.loc[18:,col]='POISON_DYNAMIC_CELL'
            b=f.to_csv(index=False,lineterminator='\n').encode('utf-8-sig');return b.replace(b'POISON_DYNAMIC_CELL',b'\xff\xfe\xfd') if self.invalid else b
    columns=[c for c in history_columns if c not in ('WELL_ID','NY')];cases=0
    for cut in ('M_minus_1','T0_minus_1'):
        c=copy.deepcopy(a['config']);c['cutoff']=cut;base=proxy(c);p,fs,audit=old.build_variant_test(Store(),pol,legacy,base)
        for col in columns:
            changed,ff,aa=old.build_variant_test(Store([col]),pol,legacy,base);pd.testing.assert_frame_equal(p[fs+['__scale035']],changed[fs+['__scale035']]);require(fs==ff,'WINDOW_FEATURE_ORDER');cases+=1
        poisoned,ff,aa=old.build_variant_test(Store(columns,True),pol,legacy,base);pd.testing.assert_frame_equal(p[fs+['__scale035']],poisoned[fs+['__scale035']]);require(np.array_equal(predict(a,p.iloc[:3]),predict(a,poisoned.iloc[:3])),'ACTUAL_WINDOW_MUTATION_PREDICTION')
    return {'status':'PASS','actual_learner':a['config']['learner'],'actual_competition_training_fold':True,'validation_rows_single_batch_reverse_extra_exact':True,'synthetic_window_column_cutoff_cases':cases,'both_cutoffs_covered':True,'all_dynamic_invalid_UTF8_window_cells_never_decoded':True,'actual_learner_poison_prediction_exact':True,'preprocessor_training_fold_only':True,'inference_fit_guard_active':True,'offline_socket_guard_active':True,'competition_test_files_parsed':0,'features_before_preprocessing':len(a['features']),'features_after_preprocessing':a['transformed_features'],'fit_models_for_integration_extra':0,'fit_preprocessors_for_integration_extra':0,'new_path_upload_eligible':False}
