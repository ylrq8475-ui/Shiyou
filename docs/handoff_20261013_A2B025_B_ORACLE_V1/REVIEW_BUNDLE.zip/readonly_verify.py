"""Anonymous review only: validate byte identities, arithmetic, counts and oracle tests.

Run from the extracted review bundle: python -B readonly_verify.py
No private data, training modules or model weights are loaded.
"""
from pathlib import Path
import hashlib
import json
import math
import sys
import unittest

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT/name).read_bytes())


def main():
    manifest = load('BUNDLE_MANIFEST.json')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert actual == set(manifest) | {'BUNDLE_MANIFEST.json'}
    for name, value in manifest.items():
        content = (ROOT/name).read_bytes()
        assert len(content) == value['bytes']
        assert hashlib.sha256(content).hexdigest() == value['sha256']
    plan = load('A1/PLAN_A2B025.json')
    a1manifest = load('A1/SHA256SUMS.json')
    for name, value in a1manifest.items():
        content = (ROOT/'A1'/name).read_bytes()
        assert hashlib.sha256(content).hexdigest() == value['sha256'] and len(content) == value['bytes']
    result = load('evidence/FINAL_RESULT.json')
    replay = load('evidence/STAGE1_REPLAY.json')
    oracle = load('evidence/STAGE2_ORACLE.json')
    assert result['status'] == 'COMPLETED'
    gate = plan['stage_1_fixed_B0_replay']['reproduction_gate']
    assert abs(replay['official_oof']-gate['official_oof']) <= gate['abs_tolerance']
    assert [round(x, 6) for x in replay['fold_scores']] == gate['fold_scores_6dp']
    mean = math.fsum(replay['fold_scores'])/5
    std = math.sqrt(math.fsum((x-mean)**2 for x in replay['fold_scores'])/5)
    assert abs(std-replay['fold_std_ddof0']) < 1e-10
    assert replay['worst_fold'] == min(replay['fold_scores'])
    assert abs(oracle['baseline_oof']-replay['official_oof']) < 1e-10
    decision = 'MAY_OPEN_NEW_PREREGISTRATION' if oracle['level_oracle_oof'] >= 90 else 'CEILING_BELOW_95_KEEP_CURRENT_MODEL'
    assert oracle['decision'] == decision and oracle['decision_threshold'] == 90
    budget = result['budget']
    assert budget['model_completed'] == budget['model_entered'] == 5
    assert budget['preprocessor_completed'] == budget['preprocessor_entered'] == 5
    assert budget['fault_retries'] == budget['C1_fits'] == budget['full_fits'] == budget['saved_models'] == 0
    for key in ('source_inputs_unchanged','environment_unchanged','frozen_artifacts_unchanged','raw_archive_and_manifest_unchanged'):
        assert result[key] is True
    counts = load('evidence/STAGE0_COUNTS.json')['cohorts']
    for key, expected in [('anchor_positive_train',(88,88,88,82)),('complete_12m_train',(81,81,81,75)),('test_template',(10,10,10,10))]:
        item = counts[key]
        assert tuple(item[k] for k in ('wells','record_present','finite','finite_positive')) == expected
    sys.path.insert(0, str(ROOT/'A1/reference'))
    tests = unittest.defaultTestLoader.loadTestsFromName('test_a2b025_oracle')
    outcome = unittest.TextTestRunner(verbosity=1).run(tests)
    assert outcome.wasSuccessful() and outcome.testsRun == 15
    print(json.dumps({'anonymous_files_verified':len(manifest),'aggregate_contracts_passed':True,
                      'synthetic_tests':outcome.testsRun,'real_fits':0,
                      'real_data_independent_reproduction':False,'decision':decision}))


if __name__ == '__main__':
    main()
