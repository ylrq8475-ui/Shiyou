"""Synthetic checks of replay stopping, row alignment and hard fit caps."""
import unittest
import numpy as np
import pandas as pd
from run_a2b025 import Budget, EXPECTED, FOLDS, replay_gate, well_pairs


class ExecutionContracts(unittest.TestCase):
    def test_exact_replay_passes(self):
        self.assertTrue(replay_gate(EXPECTED, FOLDS))

    def test_total_or_fold_drift_blocks(self):
        self.assertFalse(replay_gate(EXPECTED + 1e-7, FOLDS))
        self.assertFalse(replay_gate(EXPECTED, FOLDS[:-1]))
        self.assertFalse(replay_gate(EXPECTED, FOLDS[:-1] + [FOLDS[-1] + .000002]))

    def test_success_cap(self):
        budget = Budget()
        for _ in range(5):
            budget.enter_prep(); budget.preprocessor_completed += 1
            budget.enter_model(); budget.model_completed += 1
        with self.assertRaises(Exception): budget.enter_model()
        with self.assertRaises(Exception): budget.enter_prep()

    def test_entry_and_retry_caps(self):
        budget = Budget()
        for _ in range(6): budget.enter_model()
        with self.assertRaises(Exception): budget.enter_model()
        budget.retry()
        with self.assertRaises(Exception): budget.retry()

    def test_reordered_rows_are_paired_by_same_keys(self):
        frame = pd.DataFrame({'WELL_ID': ['synthetic'] * 12, 'horizon': list(range(12, 0, -1)), 'RCYL': list(range(12, 0, -1))})
        pairs = well_pairs(frame, np.arange(12, 0, -1, dtype=float))
        np.testing.assert_array_equal(pairs[0][0], np.arange(1, 13))
        np.testing.assert_array_equal(pairs[0][1], np.arange(1, 13))

    def test_duplicate_month_blocks(self):
        frame = pd.DataFrame({'WELL_ID': ['synthetic'] * 12, 'horizon': [1] * 12, 'RCYL': [1.] * 12})
        with self.assertRaises(Exception): well_pairs(frame, np.ones(12))

    def test_incomplete_and_nonfinite_block(self):
        frame = pd.DataFrame({'WELL_ID': ['synthetic'] * 11, 'horizon': list(range(1, 12)), 'RCYL': [1.] * 11})
        with self.assertRaises(Exception): well_pairs(frame, np.ones(11))
        with self.assertRaises(Exception): well_pairs(frame, np.full(11, np.nan))


if __name__ == '__main__':
    unittest.main()
