"""A2B-025 Phase 0: read-only anonymous counts at original segment-end M."""
from __future__ import annotations

import json
import sys
from pathlib import Path

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(Path(r"D:\codex\A2B023_20261010_v1")))

import bridge  # noqa: E402


def counts_for(anchors, history, config):
    pd, np, safe = bridge.pd, bridge.np, bridge.safe
    well_col = config["anchors"]["well_column"]
    date_col = config["anchors"]["date_column"]
    target_col = config["schema"]["mapping"]["target"]
    periods = safe._periods(history, date_col)
    local = history.loc[:, [well_col, target_col]].copy()
    local["__period"] = periods.to_numpy()
    by_key = {}
    for row in anchors.loc[:, [well_col, "anchor_period"]].itertuples(index=False, name=None):
        well, month = row
        matched = local.loc[(local[well_col] == well) & (local["__period"] == month), target_col]
        if len(matched) > 1:
            raise RuntimeError("duplicate well-month at the selected anchor")
        if len(matched) == 0:
            by_key[well] = None
        else:
            numeric = pd.to_numeric(matched, errors="coerce").iloc[0]
            by_key[well] = float(numeric) if not pd.isna(numeric) else float("nan")
    result = bridge.oracle.anchor_month_counts(list(by_key.values()))
    if result["wells"] != len(anchors):
        raise RuntimeError("anchor count mismatch")
    return result


def main():
    oracle_path = TASK / "reference" / "a2b025_oracle.py"
    bridge.sys.path.insert(0, str(oracle_path.parent))
    import a2b025_oracle as oracle
    bridge.oracle = oracle

    prior = bridge.prior
    config = bridge.safe.safe_config(bridge.config_module.load_config(prior.PRIVATE_CONFIG))
    store = prior.ArchiveStore(prior.RAW_ARCHIVE, prior.RAW_MANIFEST)
    try:
        train_tables, test_tables, reader = store.load_tables(config, bridge.multi.MultiSourceTables)
        train_anchor, _ = bridge.safe.segment_end_anchors(train_tables.history, config)
        complete_panel, _, complete_anchors = bridge.safe._build_train_panel(train_tables, config)
        test_panel, template_keys, _, test_anchors = bridge.safe._build_test_panel(test_tables, config)
        if len(train_anchor) != 88 or complete_panel.WELL_ID.nunique() != 81:
            raise RuntimeError("training cohort does not match the locked counts")
        if template_keys.WELL_ID.nunique() != 10 or len(test_panel) != 120:
            raise RuntimeError("test template cohort does not match the locked counts")

        output = {
            "task": "A2B-025",
            "phase": "stage_0_readonly_count",
            "anchor_rule": "A2B-013 segment_end_anchors; count raw RCYL at each original M",
            "fits": 0,
            "cohorts": {
                "anchor_positive_train": counts_for(train_anchor, train_tables.history, config),
                "complete_12m_train": counts_for(complete_anchors, train_tables.history, config),
                "test_template": counts_for(test_anchors, test_tables.history, config),
            },
            "reader": {
                "manifest_verified_files": reader["raw_files_verified"],
                "roles": reader["roles"],
                "archive_extracted_or_copied": reader["raw_extracted_or_copied"],
            },
            "raw_unchanged_after_read": store.unchanged(),
            "persisted_identifiers_months_or_values": False,
        }
        if not output["raw_unchanged_after_read"]:
            raise RuntimeError("raw archive or manifest changed during read")
        target = TASK / "STAGE0_COUNTS.json"
        with target.open("x", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write("\n")
        print(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False))
    finally:
        store.close()


if __name__ == "__main__":
    main()
