"""Locked A2B-025 B0 replay. No raw rows, predictions or fitted models are saved."""
from pathlib import Path
import argparse
import contextlib
import io
import json
import os
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.path.insert(0, 'D:/codex/A2B023_20261010_v1')
import bridge as b
sys.path.insert(0, str(HERE/'reference'))
import a2b025_oracle as oracle

np, pd, require = b.np, b.pd, b.require
A24 = Path('D:/codex/A2B024_20261012_v1')
PLAN_SHA = 'e3021e14a547da9d5278b3ebbe0d26b4bdc8d732e27e0c706ad2f3a3ae31fdf4'
EXPECTED = 73.71410733861434
FOLDS = [71.453314, 77.536429, 75.129241, 64.626864, 79.965989]
SPLIT = 'beadb191d075afdd138d6463f0b3a0e03999a76e07641f56ea24ec77e5e4d5f8'


def alias(path):
    path = Path(path)
    if path == b.prior.RAW_ARCHIVE:
        return 'AUTHORIZED_RAW_ARCHIVE'
    try:
        return path.relative_to(Path('D:/codex')).as_posix()
    except ValueError:
        return 'EXTERNAL_FILE/' + path.name


def sources():
    records = b.input_fingerprints()
    records[str(A24/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json')] = b.sha(A24/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json')
    records[str(A24/'execution/FIXED_REPLAY.json')] = b.sha(A24/'execution/FIXED_REPLAY.json')
    for name in ('run_a2b025.py', 'test_execution_contracts.py', 'AUTHORIZATION_AND_INTERPRETATION.md',
                 'PLAN_A2B025.json', 'PROMPT_FOR_ACCOUNT_B.md', 'SHA256SUMS.json',
                 'STAGE0_COUNTS.json', 'phase0_counts.py', 'reference/a2b025_oracle.py',
                 'reference/test_a2b025_oracle.py'):
        p = HERE/name
        records[str(p)] = b.sha(p)
    return {alias(p): h for p, h in sorted(records.items())}


def environment():
    env = b.public_environment()
    env['executable'] = alias(env['executable'])
    env['native_files'] = {alias(p): h for p, h in env['native_files'].items()}
    return env


def frozen_snapshot():
    records = b.old_snapshot()
    for root in (b.HERE, A24, Path('D:/codex/A2B024_DEPLOYMENT_PREP_20261012_v1'),
                 Path('D:/codex/A2B024_R1_PLATFORM_EXPLORE_20261012_v1')):
        for p in root.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts:
                records[str(p)] = b.sha(p)
    return {alias(p): h for p, h in sorted(records.items())}


def verify_reference():
    require(b.sha(HERE/'PLAN_A2B025.json') == PLAN_SHA, 'A1_PLAN_CHANGED')
    manifest = json.loads((HERE/'SHA256SUMS.json').read_bytes())
    for name, entry in manifest.items():
        p = HERE/name
        require(p.stat().st_size == entry['bytes'] and b.sha(p) == entry['sha256'], 'A1_REFERENCE_CHANGED')


def replay_gate(score, folds):
    return (len(folds) == 5 and abs(score-EXPECTED) <= 1e-9
            and [round(v, 6) for v in folds] == FOLDS)


def well_pairs(frame, predictions):
    require(len(frame) == len(predictions) and np.isfinite(predictions).all(), 'OOF_COVERAGE')
    require(not frame[['WELL_ID', 'horizon']].duplicated().any(), 'DUPLICATE_TARGET_KEY')
    work = frame[['WELL_ID', 'horizon', 'RCYL']].copy()
    work['prediction'] = predictions
    result = []
    for _, group in work.groupby('WELL_ID', sort=False):
        group = group.sort_values('horizon', kind='mergesort')
        require(group.horizon.tolist() == list(range(1, 13)), 'TARGET_HORIZON_ORDER')
        p = group.prediction.to_numpy(dtype=float)
        y = group.RCYL.to_numpy(dtype=float)
        require(np.isfinite(y).all() and (y >= 0).all() and (p >= 0).all(), 'SCORE_VALUES')
        result.append((p, y))
    return result


class Budget:
    def __init__(self):
        self.preprocessor_entered = self.preprocessor_completed = 0
        self.model_entered = self.model_completed = self.fault_retries = 0
    def enter_prep(self):
        require(self.preprocessor_entered < 6 and self.preprocessor_completed < 5, 'PREPROCESS_BUDGET')
        self.preprocessor_entered += 1
    def enter_model(self):
        require(self.model_entered < 6 and self.model_completed < 5, 'MODEL_BUDGET')
        self.model_entered += 1
    def retry(self):
        require(self.fault_retries < 1, 'RETRY_BUDGET')
        self.fault_retries += 1
    def snapshot(self):
        return dict(vars(self)) | {'C1_fits': 0, 'full_fits': 0, 'saved_models': 0}


def collect():
    verify_reference()
    config, panel, features, families, store, ready = b.prepare_data()
    try:
        require(families[0][0] is None and families[0][2] == SPLIT, 'FIXED_SPLIT_IDENTITY')
        old = json.loads((A24/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json').read_bytes())
        current = b.input_fingerprints()
        require(all(p in old['source_inputs'] and old['source_inputs'][p] == h for p, h in current.items()), 'A24_RUNTIME_INPUT_DRIFT')
        require(b.fingerprint(b.public_environment()) == b.fingerprint(old['environment']), 'A24_ENVIRONMENT_DRIFT')
        require(b.panel_identity(panel, features) == old['panel_identity'], 'A24_PANEL_IDENTITY_DRIFT')
        require(features == old['feature_order'], 'A24_FEATURE_ORDER_DRIFT')
        params = b.training._model_pipeline('extra_trees_log_ratio_last', panel[features], config).named_steps['model'].get_params()
        require(params == old['model_parameters'], 'A24_MODEL_PARAMETERS_DRIFT')
        require(ready['accepted_structure_result_unmodified']['status'] == 'structural_audit_passed', 'STRUCTURAL_GATE')
        require('RCYL' not in features and 'WELL_ID' not in features, 'LABEL_OR_KEY_FEATURE')
        train_tables, test_tables, reader = store.load_tables(config, b.multi.MultiSourceTables)
        _, _, train_anchors = b.safe._build_train_panel(train_tables, config)
        test, reference, _, test_anchors = b.safe._build_test_panel(test_tables, config)
        require(test[['WELL_ID', 'NY']].equals(reference), 'TEMPLATE_KEYS')
        require(not set(panel.WELL_ID) & set(test.WELL_ID), 'TRAIN_TEST_WELL_OVERLAP')
        cutoff = {
            'train': b.safe.audit_pre_anchor_cutoff(train_tables.history, train_anchors, config),
            'test': b.safe.audit_pre_anchor_cutoff(test_tables.history, test_anchors, config),
        }
        require(store.unchanged(), 'RAW_INTEGRITY')
        contract = {
            'environment': environment(), 'source_inputs': sources(),
            'panel_identity': b.panel_identity(panel, features), 'cohort_order_sha256': ready['cohort_order_sha256'],
            'feature_order': features, 'ordered_dtypes': list(zip(features, panel[features].dtypes.astype(str))),
            'execution_config_sha256': b.fingerprint(config), 'model_parameters': params,
            'fixed_split_sha256': families[0][2], 'wells': 81, 'rows': 972, 'features': 325,
            'boundary': 'V2: original last segment end M; all history and raw scale through M-1; target M+1..M+12',
            'historical_dtype': 'UNKNOWN', 'A24_current_identity_checks_passed': True,
            'structural_gate': 'PASS', 'accepted_audit_summary_sha256': b.fingerprint(ready['accepted_structure_result_unmodified']),
            'future_invariance_checks': cutoff, 'raw_members_verified': reader['raw_files_verified'],
            'original_data_copied_or_extracted': False,
        }
        return config, panel, features, families[0][1], store, contract
    except BaseException:
        store.close()
        raise


def prepare():
    config, panel, features, splits, store, contract = collect()
    try:
        suite = unittest.TestSuite()
        for module in ('test_a2b025_oracle', 'test_execution_contracts'):
            suite.addTests(unittest.defaultTestLoader.loadTestsFromName(module))
        output = io.StringIO()
        with b.forbid_fits():
            result = unittest.TextTestRunner(stream=output, verbosity=1).run(suite)
        require(result.wasSuccessful(), 'SYNTHETIC_TESTS_FAILED')
        b.dump_new(HERE/'SYNTHETIC_RESULTS.json', {'tests': result.testsRun, 'failures': len(result.failures),
            'errors': len(result.errors), 'all_passed': result.wasSuccessful(), 'real_fits': 0, 'time': b.prior.stamp()})
        old = frozen_snapshot()
        b.dump_new(HERE/'FROZEN_ARTIFACTS_PREFIT.json', old)
        b.dump_new(HERE/'PREFIT_LOCK.json', {
            'task': 'A2B-025', 'executor': 'Account B', 'time': b.prior.stamp(),
            'before_first_real_fit_and_new_score': True, 'contract': contract,
            'A1_source_commit': '1a385c08cc2229c9a44b58daa801602d242f77a2',
            'plan_sha256': PLAN_SHA, 'synthetic_sha256': b.sha(HERE/'SYNTHETIC_RESULTS.json'),
            'frozen_snapshot_sha256': b.sha(HERE/'FROZEN_ARTIFACTS_PREFIT.json'),
            'replay_gate': {'oof': EXPECTED, 'absolute_tolerance': 1e-9, 'folds_6dp': FOLDS},
            'decision_threshold': 90.0, 'parallelism': {'active_fits': 1, 'model_n_jobs': -1, 'BLAS_OpenMP_threads': 1},
            'budget': {'model_success_max': 5, 'model_entry_max': 6, 'preprocess_success_max': 5,
                'preprocess_entry_max': 6, 'fault_retry_max': 1},
            'retry_policy': 'One transient model-fit retry may reuse the already fitted fold preprocessor and identical transformed training matrix; no successful fit is repeated. Preprocessing errors stop.',
            'interpreter_launcher_warning': 'Failed to find real location warning observed; executable/base executable exist; imports pass; binary/version hashes equal A24 actual environment.',
        })
        print(json.dumps({'prepared': True, 'synthetic_tests': result.testsRun, 'source_files': len(contract['source_inputs']),
                          'frozen_files': len(old), 'A24_identity_match': True}), flush=True)
    finally:
        store.close()


def execute():
    require(not (HERE/'execution').exists(), 'EXECUTION_ALREADY_STARTED_NO_AUTOMATIC_RERUN')
    lock = json.loads((HERE/'PREFIT_LOCK.json').read_bytes())
    config, panel, features, splits, store, contract = collect()
    require(b.fingerprint(contract) == b.fingerprint(lock['contract']), 'PREFIT_CONTRACT_CHANGED')
    require(b.sha(HERE/'SYNTHETIC_RESULTS.json') == lock['synthetic_sha256'], 'SYNTHETIC_RECORD_CHANGED')
    old_before = json.loads((HERE/'FROZEN_ARTIFACTS_PREFIT.json').read_bytes())
    require(frozen_snapshot() == old_before, 'FROZEN_ARTIFACT_CHANGED_BEFORE_EXECUTION')
    out = HERE/'execution'
    out.mkdir()
    budget = Budget()
    events = []
    def event(kind, **details):
        record = {'sequence': len(events)+1, 'time': b.prior.stamp(), 'event': kind, **details, 'budget': budget.snapshot()}
        events.append(record)
        b.dump_new(out/f'event_{len(events):03d}.json', record)
    def identity_check():
        require(sources() == contract['source_inputs'], 'SOURCE_CHANGED_DURING_EXECUTION')
        require(environment() == contract['environment'], 'ENVIRONMENT_CHANGED_DURING_EXECUTION')
        require(b.fingerprint(config) == contract['execution_config_sha256'], 'CONFIG_CHANGED')
        require(b.panel_identity(panel, features) == contract['panel_identity'], 'PANEL_CHANGED')
        require(store.unchanged(), 'RAW_CHANGED')
    tick = time.perf_counter()
    result = {'task': 'A2B-025', 'status': 'STARTED', 'prefit_lock_sha256': b.sha(HERE/'PREFIT_LOCK.json'), 'started': b.prior.stamp()}
    fold_scores = []
    oof = np.full(len(panel), np.nan)
    event('execution_started', prefit_lock_sha256=result['prefit_lock_sha256'])
    try:
        for fold, (tr, va) in enumerate(splits, 1):
            identity_check()
            train, valid = panel.iloc[tr], panel.iloc[va]
            require(not set(train.WELL_ID) & set(valid.WELL_ID), 'FOLD_WELL_OVERLAP')
            x = train[features]
            raw = train['history__RCYL__last'].to_numpy(dtype=float)
            scale = np.where(np.isfinite(raw) & (raw > 0), raw, 1.0)
            expected = np.log1p(train.RCYL.to_numpy(dtype=float)/scale)
            require(np.array_equal(scale, b.training._target_scale(train, 'log_ratio_last')), 'RAW_SCALE_RULE')
            pipeline = b.training._model_pipeline('extra_trees_log_ratio_last', x, config)
            prep, model = pipeline.named_steps['preprocess'], pipeline.named_steps['model']
            params = model.get_params()
            require(params == contract['model_parameters'], 'MODEL_PARAMETER_CHANGED')
            op, om = prep.fit_transform, model.fit
            calls = [0, 0]
            def pf(xx, yy=None, **kw):
                require(isinstance(xx, pd.DataFrame) and xx.equals(x) and np.array_equal(yy, expected) and not kw, 'PREPROCESS_TRAIN_SCOPE')
                calls[0] += 1
                require(calls[0] == 1, 'EXTRA_PREPROCESS_FIT')
                budget.enter_prep()
                value = op(xx, yy)
                budget.preprocessor_completed += 1
                return value
            def mf(xx, yy, **kw):
                require(calls[0] == 1 and np.array_equal(yy, expected) and not kw, 'MODEL_TRAIN_SCOPE')
                require(np.array_equal(np.asarray(xx), np.asarray(prep.transform(x)), equal_nan=True), 'MODEL_TRAIN_FEATURES')
                fn = om
                while True:
                    budget.enter_model()
                    event('model_fit_entered', fold=fold, training_wells=int(train.WELL_ID.nunique()), validation_wells=int(valid.WELL_ID.nunique()))
                    try:
                        value = fn(xx, yy)
                    except Exception as exc:
                        retry = b.old.transient_fault(exc) and budget.fault_retries < 1
                        event('model_fit_failed', fold=fold, error_type=type(exc).__name__, retry_allowed=retry)
                        if not retry:
                            raise
                        budget.retry()
                        replacement = type(model)(**params)
                        pipeline.steps[-1] = ('model', replacement)
                        fn = replacement.fit
                        event('fault_retry_reserved_reuse_fold_preprocessor', fold=fold)
                        continue
                    budget.model_completed += 1
                    calls[1] += 1
                    return value
            prep.fit_transform, model.fit = pf, mf
            try:
                b.training._fit_pipeline(pipeline, 'extra_trees_log_ratio_last', x, train.RCYL, train.horizon, train)
                require(calls == [1, 1], 'FIT_CALL_COUNTS')
            finally:
                del prep.fit_transform
                del model.fit
            view = valid.drop(columns=['RCYL'])
            prediction = np.clip(b.training.predict_pipeline_output(pipeline, 'extra_trees_log_ratio_last', view[features], view), 0, None)
            identity_check()
            pairs = well_pairs(valid, prediction)
            score = b.training._score_prediction_array(valid, prediction)
            require(abs(score-oracle.official_score(pairs)) <= 1e-10, 'OFFICIAL_METRIC_DISAGREEMENT')
            oof[va] = prediction
            fold_scores.append(float(score))
            event('fold_completed', fold=fold, official_score=float(score))
            del pipeline
            require(round(score, 6) == FOLDS[fold-1], 'FOLD_REPRODUCTION_GATE_FAILED')
        identity_check()
        pairs = well_pairs(panel, oof)
        require(len(pairs) == 81, 'OOF_WELL_COUNT')
        score = b.training._score_prediction_array(panel, oof)
        require(abs(score-oracle.official_score(pairs)) <= 1e-10, 'OFFICIAL_METRIC_DISAGREEMENT')
        replay = {'official_oof': float(score), 'expected_oof': EXPECTED, 'absolute_difference': abs(score-EXPECTED),
                  'fold_scores': fold_scores, 'fold_std_ddof0': float(np.std(fold_scores)), 'worst_fold': min(fold_scores),
                  'split_sha256': SPLIT, 'reproduction_gate_passed': replay_gate(score, fold_scores)}
        b.dump_new(out/'STAGE1_REPLAY.json', replay)
        require(replay['reproduction_gate_passed'], 'OVERALL_REPRODUCTION_GATE_FAILED')
        event('reproduction_gate_passed')
        with b.forbid_fits():
            diagnostic = oracle.diagnose(pairs)
        require(abs(diagnostic['baseline_oof']-score) <= 1e-10, 'ORACLE_BASELINE_DISAGREEMENT')
        b.dump_new(out/'STAGE2_ORACLE.json', diagnostic)
        result.update(status='COMPLETED', stage1=replay, stage2=diagnostic)
        event('oracle_diagnosis_completed', decision=diagnostic['decision'])
    except Exception as exc:
        result.update(status='STOPPED_AT_ACTUAL_GATE', error_code=str(exc) if isinstance(exc, b.GateError) else type(exc).__name__, completed_fold_scores=fold_scores)
        event('execution_stopped', error_code=result['error_code'])
    finally:
        result.update(finished=b.prior.stamp(), seconds=time.perf_counter()-tick, budget=budget.snapshot(),
                      source_inputs_unchanged=sources() == contract['source_inputs'], environment_unchanged=environment() == contract['environment'],
                      frozen_artifacts_unchanged=frozen_snapshot() == old_before, frozen_files_checked=len(old_before),
                      raw_members_verified=len(store.members), raw_archive_and_manifest_unchanged=store.unchanged(),
                      persisted_row_oof_or_models=False)
        store.close()
        b.dump_new(out/'FINAL_RESULT.json', result)
        tokens = b.prior.train_test_wells_for_scan({'control': panel}, config)
        scan = b.prior.privacy_scan(out, tokens, config['anchors']['eligible_event_values'])
        b.dump_new(out/'PRIVACY_SCAN.json', scan)
        require(scan['passed'], 'EXECUTION_PRIVACY_SCAN_FAILED')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result['status'] == 'COMPLETED' else 1


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--prepare', action='store_true')
    g.add_argument('--execute', action='store_true')
    args = p.parse_args()
    if args.prepare:
        prepare()
    else:
        sys.exit(execute())
