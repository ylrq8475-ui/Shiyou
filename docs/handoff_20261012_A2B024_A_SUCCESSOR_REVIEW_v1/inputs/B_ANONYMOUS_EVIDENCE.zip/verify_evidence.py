"""Portable, read-only A2B-024 aggregate verification. Never imports training/data."""
import ast
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(name):return json.loads((ROOT/name).read_bytes())
def verify(root=ROOT):
    global ROOT
    ROOT=Path(root);checks=[]
    def check(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    def close(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=1e-9)
    manifest=read('BUNDLE_SHA256SUMS.json')
    for name,expected in manifest.items():
        path=ROOT/name;check('sha256:'+name,path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==expected)
    check('exact_bundle_inventory',set(manifest)|{'BUNDLE_SHA256SUMS.json'}=={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
    final=read('evidence/FINAL_RESULT.json');lock=read('evidence/IMPLEMENTATION_PRETRAIN_LOCK.json')
    events=[json.loads(p.read_bytes()) for p in sorted((ROOT/'evidence/events').glob('*.json'))]
    entries=[e for e in events if e['event']=='model_entered'];completed=[e for e in events if e['event']=='fit_completed']
    check('70_real_entries',len(entries)==70==len(completed)==final['budget']['model_completed']==final['budget']['model_entered'])
    check('70_separate_preprocessors',final['budget']['prep_entered']==final['budget']['prep_completed']==70)
    check('no_runtime_failures_or_retries',final['budget']['retries']==0 and not any(e['event']=='fit_failure' for e in events))
    check('stages_10_50_10_0',final['budget']['stage_successes']=={'fixed_replay':10,'five_later_splits':50,'conditional_confirmation':10,'conditional_private_full_fit':0})
    identities=[(e['stage'],e['seed'],e['fold'],e['arm']) for e in entries]
    check('unique_successful_fold_arm_identities',len(set(identities))==70)
    check('single_model_event_order',[e['event'] for e in events if e['event'] in ('model_entered','fit_completed')]==['model_entered','fit_completed']*70)
    check('prefit_time_before_first_entry',lock['time']<entries[0]['time'] and lock['before_first_fit_or_new_score'])
    for flag in ('source_inputs_unchanged','environment_unchanged','old_artifacts_unchanged'):check(flag,final[flag])
    check('raw100_readonly',final['raw_integrity']=={'verified_members':100,'unchanged':True,'copied_or_extracted':False})
    check('63_synthetic_no_real_fits',read('SYNTHETIC_RESULTS.json')['passed'] and read('SYNTHETIC_RESULTS.json')['tests_run']==63 and read('SYNTHETIC_RESULTS.json')['real_model_fits']==0)
    results=final['research']+[final['confirmation']]
    check('locked_seeds', [r['seed'] for r in results]==[None,20261012,20261013,20261014,20261015,20261016,20271012])
    check('locked_split_identity',[(r['seed'],r['split_sha256']) for r in results]==[(x['seed'],x['split_sha256']) for x in lock['families']])
    for i,r in enumerate(results):
        name=f'group{i}'
        check(name+':structure',r['structure_passed'] and len(r['routing_checks'])==5 and all(x['positive_exact_B0'] and x['fallback_exact_C1'] and x['independently_derived_arm_metadata'] for x in r['routing_checks']))
        arm_entries=[e for e in entries if e['seed']==r['seed'] and e['arm']=='B0']
        val_counts=[81-e['train_wells'] for e in arm_entries]
        check(name+':81_validation_wells',sum(val_counts)==81 and len(val_counts)==5)
        for a,v in r['arms'].items():
            prefix=v['official_weighted_prefix_loss'];monthly=v['monthly_official_weighted_loss']
            check(name+a+':official_from_loss',close(v['official_score'],100*(1-prefix['12'])))
            for n in (1,2,4,12):check(name+a+f':prefix{n}',close(prefix[str(n)],math.fsum(monthly[:n])))
            for t,(u,w) in enumerate(zip(v['monthly_unweighted_relative_error'],monthly),1):check(name+a+f':weight{t}',close(u*2**(-t),w))
            fs=v['fold_scores'];check(name+a+':worst',close(min(fs),v['worst_fold']))
            check(name+a+':std',close(statistics.pstdev(fs),v['fold_std_ddof0']))
            check(name+a+':OOF_well_weighted',close(math.fsum(s*n for s,n in zip(fs,val_counts))/81,v['official_score']))
            groups=v['diagnostics']['prediction_state_groups']
            check(name+a+':group_counts',sum(g['group_wells'] for g in groups.values())==81)
            for label,g in groups.items():
                check(name+a+label+':net_from_group',close(g['score_delta_vs_B0_in_group']*g['group_wells']/81,-100*g['net_loss_change_contribution_all_wells']))
        b0,r1=r['arms']['B0'],r['arms']['R1']
        check(name+':paired_total',close(r['delta_vs_B0'],r1['official_score']-b0['official_score']))
        check(name+':paired_first2',close(r['first2_score_delta'],100*(b0['official_weighted_prefix_loss']['2']-r1['official_weighted_prefix_loss']['2'])))
        ds=[c-b for b,c in zip(b0['fold_scores'],r1['fold_scores'])]
        check(name+':difference_of_minima',close(r['fold_risk']['difference_of_minima'],min(r1['fold_scores'])-min(b0['fold_scores'])))
        check(name+':minimum_paired_fold_delta',close(r['fold_risk']['minimum_paired_fold_delta'],min(ds)))
        ci=r['contribution_identity'];check(name+':monthly_contribution',close(math.fsum(ci['monthly_score_delta']),r['delta_vs_B0']) and ci['positive_complement_exact_zero'] and ci['all_months_equal_fallback_net_contribution'])
        for label,g in r1['diagnostics']['prediction_state_groups'].items():
            if label!='raw_scale_fallback':check(name+label+':zero_complement',g['net_loss_change_contribution_all_wells']==0 and g['early_net_loss_change_contribution_all_wells']==0)
        fallback=r1['diagnostics']['prediction_state_groups']['raw_scale_fallback']
        check(name+':fallback_only_annual',close(-100*fallback['net_loss_change_contribution_all_wells'],r['delta_vs_B0']))
        check(name+':fallback_only_first2',close(-100*fallback['early_net_loss_change_contribution_all_wells'],r['first2_score_delta']))
    later=final['research'][1:];dd=[x['delta_vs_B0'] for x in later];ee=[x['first2_score_delta'] for x in later]
    check('later_gate_recalculated',math.fsum(dd)/5>=.20 and sum(x>0 for x in dd)>=4 and min(dd)>=-.20 and math.fsum(ee)/5>=0 and sum(x>=0 for x in ee)>=4 and final['later_gate']['passed'])
    check('later_means',close(final['later_gate']['mean_delta'],math.fsum(dd)/5) and close(final['later_gate']['mean_first2_delta'],math.fsum(ee)/5))
    f=final['research'][0];check('fixed_gate_recalculated',f['delta_vs_B0']>=0 and f['first2_score_delta']>=-.02 and f['fold_risk']['difference_of_minima']>=-1 and final['fixed_gate']['passed'])
    c=final['confirmation'];check('confirmation_failure_recalculated',c['delta_vs_B0']<.20 and c['first2_score_delta']<0 and not final['confirmation_gate']['passed'])
    check('confirmation_fold_risks_pass',c['fold_risk']['difference_of_minima']>=-1 and c['fold_risk']['minimum_paired_fold_delta']>=-1)
    check('stopped_no_private_real_model',final['status']=='COMPLETED_STOPPED_AT_REGISTERED_GATE' and final['completed'] and not final['model_registry'])
    check('no_deployment',not final['deployment_approved'])
    for p in (ROOT/'runtime').glob('*.py'):
        ast.parse(p.read_text(encoding='utf-8'));check('source_AST:'+p.name,True)
    check('no_private_data_or_weight_files',not any(p.suffix.lower() in {'.csv','.yaml','.yml','.joblib','.pkl','.parquet','.npz','.npy'} for p in ROOT.rglob('*') if p.is_file()))
    return {'passed':True,'check_count':len(checks),'real_fits':0,'private_data_access':False,'scope':'original-byte manifest, aggregate arithmetic, journal counts, stage stop, source AST; no independent real training'}

if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
