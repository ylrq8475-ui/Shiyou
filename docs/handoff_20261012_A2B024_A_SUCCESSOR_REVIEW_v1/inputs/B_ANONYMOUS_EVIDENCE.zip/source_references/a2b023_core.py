"""A2B-023 target representation, identity selection and independently counted budget."""
import math
import numpy as np
from bridge import require,fingerprint

MODEL_NAMES={'B0':'extra_trees_log_ratio_last','C1':'explicit_absolute_log'}
def scales(raw):
    values=np.asarray(raw,dtype=float)
    positive=np.isfinite(values)&(values>0)
    return np.where(positive,values,1.0),~positive
def target(values,raw,arm):
    require(arm in MODEL_NAMES,'UNREGISTERED_TARGET_ARM')
    y=np.asarray(values,dtype=float)
    require(np.isfinite(y).all() and (y>=0).all(),'INVALID_TARGET')
    s,_=scales(raw)
    require(y.shape==s.shape,'TARGET_SCALE_SHAPE')
    return np.log1p(y/s) if arm=='B0' else np.log1p(y)
def inverse(values,raw,arm):
    require(arm in MODEL_NAMES,'UNREGISTERED_TARGET_ARM')
    z=np.asarray(values,dtype=float);s,_=scales(raw)
    require(z.shape==s.shape and np.isfinite(z).all(),'INVALID_TRANSFORMED_PREDICTION')
    with np.errstate(over='ignore'):
        result=np.expm1(z)*(s if arm=='B0' else 1.0)
    require(np.isfinite(result).all(),'NONFINITE_INVERSE_PREDICTION')
    return np.clip(result,0,None)
def select_features(train,features,mode):
    require('RCYL' not in train.columns and mode=='identity','LABEL_OR_UNAPPROVED_SELECTOR')
    require(len(features)==325 and 'RCYL' not in features and 'WELL_ID' not in features,'ORIGINAL_INPUT_REQUIRED')
    return list(features),{'mode':'identity','selected_count':325,'removed_count':0,'selected_feature_sha256':fingerprint(features)}

def fit_target_pipeline(pipeline,x,y,horizon,panel,arm,training_module):
    require(arm in MODEL_NAMES and 'RCYL' not in x and 'WELL_ID' not in x,'TRAINING_ARM_OR_FEATURE_CONTRACT')
    if arm=='B0':
        training_module._fit_pipeline(pipeline,MODEL_NAMES['B0'],x,y,horizon,panel)
    else:
        pipeline.fit(x,target(y,panel['history__RCYL__last'],arm))

def predict_target_pipeline(pipeline,x,panel,arm,training_module):
    require(arm in MODEL_NAMES and 'RCYL' not in x and 'WELL_ID' not in x,'PREDICTION_ARM_OR_FEATURE_CONTRACT')
    if arm=='B0':
        return training_module.predict_pipeline_output(pipeline,MODEL_NAMES['B0'],x,panel)
    return inverse(pipeline.predict(x),panel['history__RCYL__last'],arm)

class FitBudget:
    def __init__(self,cap=63):
        self.cap=cap
        self.pipeline_attempts=0
        self.selector_fit_calls=0
        self.preprocess_entered=0
        self.preprocess_completed=0
        self.model_entered=0
        self.model_completed=0
        self.runtime_retries=0
    def begin_pipeline(self):
        require(self.pipeline_attempts<self.cap,'PIPELINE_BUDGET_EXHAUSTED')
        require(self.model_entered<self.cap,'MODEL_BUDGET_EXHAUSTED')
        self.pipeline_attempts+=1
    def begin_selector(self):
        self.selector_fit_calls+=1
        require(self.selector_fit_calls<=self.pipeline_attempts,'SELECTOR_BUDGET')
    def begin_preprocess(self):
        self.preprocess_entered+=1
        require(self.preprocess_entered<=self.pipeline_attempts,'PREPROCESS_BUDGET')
    def complete_preprocess(self):
        self.preprocess_completed+=1
        require(self.preprocess_completed<=self.preprocess_entered,'PREPROCESS_WITHOUT_ENTRY')
    def begin_model(self):
        require(self.model_entered<self.cap and self.model_entered<self.preprocess_completed,'MODEL_BUDGET_OR_PREPROCESS')
        require(self.model_completed<61,'SUCCESSFUL_FIT_BUDGET_EXHAUSTED')
        self.model_entered+=1
    def complete_model(self):
        require(self.model_completed<61,'SUCCESSFUL_FIT_BUDGET_EXHAUSTED')
        self.model_completed+=1
        require(self.model_completed<=self.model_entered,'MODEL_WITHOUT_ENTRY')
    def snapshot(self):return dict(self.__dict__)

def retention_gate(fixed_delta,deltas,structure=True):
    require(len(deltas)==5 and all(math.isfinite(v) for v in [fixed_delta,*deltas]),'FINITE_PAIRED_SCORES')
    result={'fixed_delta':float(fixed_delta),'repeat_mean_delta':math.fsum(deltas)/5,
        'positive_repeats':sum(v>0 for v in deltas),'worst_repeat_delta':min(deltas),
        'structure_passed':bool(structure)}
    result['fixed_pass']=fixed_delta>=-.20
    result['repeat_mean_pass']=result['repeat_mean_delta']>=.20
    result['direction_pass']=result['positive_repeats']>=4
    result['worst_repeat_pass']=result['worst_repeat_delta']>=-.20
    result['passed']=all(result[k] for k in ('structure_passed','fixed_pass','repeat_mean_pass','direction_pass','worst_repeat_pass'))
    return result
