"""Run actual integration and frozen pure tests, without real model fits."""
import io
import json
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
suite=unittest.defaultTestLoader.discover(str(ROOT),pattern='test_*.py')
stream=io.StringIO();run=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
result={'task':'A2B-024 R2','passed':run.wasSuccessful(),'tests_run':run.testsRun,'failures':len(run.failures),'errors':len(run.errors),
        'real_model_fits':0,'real_preprocessor_fits':0,'scope':'45 frozen A-reviewed pure tests + actual-entry fake-estimator integration tests',
        'log':stream.getvalue()}
(ROOT/'SYNTHETIC_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(stream.getvalue());sys.exit(0 if run.wasSuccessful() else 1)
