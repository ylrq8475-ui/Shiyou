"""Integration tests of the actual entry using fake estimators only."""
import copy
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import pandas as pd
import a24_runner as r
from a24_control import Stages,fixed_gate,later_gate
from pretrain_contracts import ExecutionGuard,FitBudget,Arm,ContractFailure

class Prep:
    def fit_transform(self,x,y=None):return self.transform(x)
    def transform(self,x):return x.to_numpy(dtype=float)
class Model:
    def __init__(self,fail=False):self.fail=fail
    def get_params(self):return {'synthetic':True}
    def fit(self,x,y):
        if self.fail:raise MemoryError('synthetic runtime fault')
        self.value=float(np.mean(y));return self
    def predict(self,x):return np.full(len(x),self.value)
class Pipeline:
    def __init__(self,fail=False):self.named_steps={'preprocess':Prep(),'model':Model(fail)}
    def fit(self,x,y):
        z=self.named_steps['preprocess'].fit_transform(x,y);self.named_steps['model'].fit(z,y);return self
    def predict(self,x):return self.named_steps['model'].predict(self.named_steps['preprocess'].transform(x))
class Journal:
    def __init__(self):self.events=[]
    def add(self,event,**items):self.events.append((event,items))

def fixtures():
    features=['history__RCYL__last','horizon']+[f'synthetic_feature_{i}' for i in range(323)]
    p=pd.DataFrame(np.ones((24,325)),columns=features)
    p['WELL_ID']=np.repeat(['SYNTHETIC_A','SYNTHETIC_B'],12)
    p['horizon']=list(range(1,13))*2;p['anchor_time']=pd.Timestamp('2026-11-01');p['RCYL']=2.
    p.loc[12:,'history__RCYL__last']=0.
    c=SimpleNamespace(features=features,config={},guard=ExecutionGuard(),stages=Stages(),budget=FitBudget(),journal=Journal(),
        identity_check=lambda:None,model_params={'synthetic':True},lock_sha='synthetic_lock',fold_bindings={(None,1):'synthetic_fold'},current_sources=lambda:{'synthetic_source':'fixed'})
    return c,p

class EntryTests(unittest.TestCase):
    def test_actual_fit_B0_counts_and_target(self):
        c,p=fixtures()
        with patch.object(r.b.training,'_model_pipeline',lambda *a:Pipeline()):out=r.fit_one(c,p,'B0','fixed_replay',None,1)
        self.assertAlmostEqual(out.named_steps['model'].value,float(r.target(p.RCYL,p.history__RCYL__last,'B0').mean()))
        self.assertEqual((c.budget.prep_completed,c.budget.model_completed),(1,1))
    def test_actual_fit_C1_target(self):
        c,p=fixtures()
        with patch.object(r.b.training,'_model_pipeline',lambda *a:Pipeline()):out=r.fit_one(c,p,'C1','fixed_replay',None,1)
        self.assertAlmostEqual(out.named_steps['model'].value,np.log1p(2.))
    def test_actual_fit_retry_separate_counts(self):
        c,p=fixtures();calls=[]
        def factory(*a):calls.append(1);return Pipeline(fail=len(calls)==1)
        with patch.object(r.b.training,'_model_pipeline',factory):r.fit_one(c,p,'C1','fixed_replay',None,1)
        self.assertEqual((c.budget.retries,c.budget.attempts,c.budget.prep_completed,c.budget.model_entered,c.budget.model_completed),(1,2,2,2,1))
    def test_successful_identity_no_refit(self):
        c,p=fixtures()
        with patch.object(r.b.training,'_model_pipeline',lambda *a:Pipeline()):
            r.fit_one(c,p,'C1','fixed_replay',None,1)
            with self.assertRaises(ContractFailure):r.fit_one(c,p,'C1','fixed_replay',None,1)
        self.assertEqual(c.budget.model_completed,1)
    def test_confirmation_entry_forbidden_before_gates(self):
        c,p=fixtures()
        with self.assertRaises(ContractFailure):r.fit_one(c,p,'C1','conditional_confirmation',1,1)
        self.assertEqual(c.budget.attempts,0)
    def test_full_fit_forbidden_before_gates(self):
        c,p=fixtures()
        with self.assertRaises(ContractFailure):r.fit_one(c,p,'C1','conditional_private_full_fit',None,0)
    def test_stage_release_requires_full_quota(self):
        s=Stages()
        with self.assertRaises(ContractFailure):s.release('fixed_replay',True)
    def test_failed_gate_blocks_all_later_stages(self):
        s=Stages();s.completed['fixed_replay']=10;s.release('fixed_replay',False)
        for stage in s.caps:
            with self.assertRaises(ContractFailure):s.check(stage)
    def test_month_keys_cross_year(self):
        c,p=fixtures();self.assertEqual([m for w,m in r.keys(p)][:3],[202612,202701,202702])
    def test_actual_prediction_packet_uses_own_input(self):
        c,p=fixtures();pipe=Pipeline();pipe.named_steps['model'].value=1.;pipe._a24_fold_identity='synthetic_fold'
        v=p.drop(columns=['RCYL']);a=r.packet(c,pipe,v,'C1','synthetic_fold')
        rev=pd.concat([v.iloc[12:],v.iloc[:12]])
        bb=r.packet(c,pipe,rev,'C1','synthetic_fold')
        self.assertNotEqual(a.identity['cohort'],bb.identity['cohort']);self.assertNotEqual(a.keys,bb.keys)
    def test_actual_fitted_fold_identity_not_copied(self):
        c,p=fixtures();pipe=Pipeline();pipe.named_steps['model'].value=1.;pipe._a24_fold_identity='wrong_fold'
        with self.assertRaises(r.b.GateError):r.packet(c,pipe,p.drop(columns=['RCYL']),'C1','synthetic_fold')
    def test_four_real_adapter_faults_block_before_score(self):
        c,p=fixtures();v=p.drop(columns=['RCYL']);ei=r.actual_identity(c,v,'synthetic_fold');ks=r.keys(v)
        a=Arm(ks,tuple([1.]*24),ei);good=Arm(ks,tuple([2.]*24),dict(ei))
        bads=[Arm(ks[12:]+ks[:12],good.predictions,good.identity),Arm((ks[1],ks[0])+ks[2:],good.predictions,good.identity),
              Arm(ks,good.predictions,dict(ei,fold='wrong_fold')),Arm(ks,good.predictions,dict(ei,raw_state='wrong_raw'))]
        for bad in bads:
            c.guard=ExecutionGuard()
            with self.assertRaises(ContractFailure):r.routed_checked(c,p,{'B0':a,'C1':bad},ks,ei)
            with self.assertRaises(ContractFailure):r.summarize(c,p,np.ones(24))
    def test_target_perturbation_does_not_change_route(self):
        c,p=fixtures();v=p.drop(columns=['RCYL']);ei=r.actual_identity(c,v,'synthetic_fold');ks=r.keys(v)
        packs={'B0':Arm(ks,tuple([1.]*24),ei),'C1':Arm(ks,tuple([2.]*24),dict(ei))}
        out=r.routed_checked(c,p,packs,ks,ei);p['RCYL']=99999.
        self.assertTrue(np.array_equal(out,r.routed_checked(c,p,packs,ks,ei)))
        self.assertTrue(np.array_equal(out,np.repeat([1.,2.],12)))
    def test_positive_one_chooses_B0(self):
        c,p=fixtures();p['history__RCYL__last']=1.;v=p.drop(columns=['RCYL']);ei=r.actual_identity(c,v,'synthetic_fold');ks=r.keys(v)
        packs={'B0':Arm(ks,tuple([1.]*24),ei),'C1':Arm(ks,tuple([2.]*24),dict(ei))}
        self.assertTrue(np.array_equal(r.routed_checked(c,p,packs,ks,ei),np.ones(24)))
    def test_confirmation_paired_risk_distinct(self):
        rr={'structure_passed':True,'delta_vs_B0':1.,'first2_score_delta':1.,'fold_risk':{'difference_of_minima':1.,'minimum_paired_fold_delta':-5.}}
        self.assertTrue(fixed_gate(rr)['passed']);self.assertFalse(fixed_gate(rr,True)['passed'])
    def test_later_all_five_required_and_thresholds(self):
        rr={'structure_passed':True,'delta_vs_B0':.21,'first2_score_delta':0.}
        self.assertTrue(later_gate([rr]*5)['passed'])
        with self.assertRaises(ContractFailure):later_gate([rr]*4)
    def test_private_save_entry_blocked(self):
        c,p=fixtures()
        with self.assertRaises(ContractFailure):r.retain(c,p)
    def test_actual_private_save_both_arms_and_reload(self):
        c,p=fixtures();c.stages.allowed.add('conditional_private_full_fit')
        case=Path(__file__).resolve().parent/'synthetic_private_save_case'
        case.mkdir(exist_ok=True)
        with patch.object(r,'HERE',case),patch.object(r.b.training,'_model_pipeline',lambda *a:Pipeline()):
            result=r.retain(c,p)
        self.assertTrue(result['both_arms_saved'] and result['reload_exact_equality'])
        self.assertEqual((c.budget.model_completed,c.budget.prep_completed),(2,2))

if __name__=='__main__':unittest.main()
