"""Invented identifiers and numbers only. No fitted models, labels or data reads."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import unittest
from pretrain_contracts import Arm,COMMON_FIELDS,ContractFailure,ExecutionGuard,FitBudget,fold_risk,raw_digest

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.keys=tuple((w,202601+m) for w in ('SYNTHETIC_A','SYNTHETIC_B') for m in range(12))
        self.raw=(('SYNTHETIC_A',0.),('SYNTHETIC_B',1.))
        self.identity={k:hashlib.sha256(k.encode()).hexdigest() for k in COMMON_FIELDS}
        self.identity['raw_state']=raw_digest(self.raw)
        self.b=Arm(self.keys,tuple(range(24)),dict(self.identity))
        self.c=Arm(self.keys,tuple(range(100,124)),dict(self.identity))
    def route(self,b=None,c=None,raw=None,guard=None):
        return (guard or ExecutionGuard()).validate_and_route(b or self.b,c or self.c,self.raw if raw is None else raw,self.keys,self.identity)
    def assert_blocked(self,**kwargs):
        guard=ExecutionGuard()
        with self.assertRaises(ContractFailure):self.route(guard=guard,**kwargs)
        for stage in ('scoring','confirmation','full_fit','save'):
            with self.assertRaises(ContractFailure):guard.assert_stage_allowed(stage)
    def test_valid_aligned_whole_well_route(self):
        self.assertEqual(self.route(),self.c.predictions[:12]+self.b.predictions[12:])
    def test_only_c1_well_permutation_rejected(self):
        p=tuple(range(12,24))+tuple(range(12))
        self.assert_blocked(c=replace(self.c,keys=tuple(self.keys[i] for i in p),predictions=tuple(self.c.predictions[i] for i in p)))
    def test_only_c1_month_permutation_rejected(self):
        p=(1,0)+tuple(range(2,24))
        self.assert_blocked(c=replace(self.c,keys=tuple(self.keys[i] for i in p),predictions=tuple(self.c.predictions[i] for i in p)))
    def test_only_raw_permutation_rejected(self):self.assert_blocked(raw=self.raw[::-1])
    def test_same_shape_different_fold_rejected(self):
        meta=dict(self.identity);meta['fold']='different_fold';self.assert_blocked(c=replace(self.c,identity=meta))
    def test_raw_values_changed_without_keys_rejected(self):
        self.assert_blocked(raw=(('SYNTHETIC_A',1.),('SYNTHETIC_B',0.)))
    def test_common_source_mismatch_rejected(self):
        meta=dict(self.identity);meta['common_source']='different_source';self.assert_blocked(c=replace(self.c,identity=meta))
    def test_environment_mismatch_rejected(self):
        meta=dict(self.identity);meta['environment']='different_environment';self.assert_blocked(b=replace(self.b,identity=meta))
    def test_prediction_length_rejected(self):self.assert_blocked(c=replace(self.c,predictions=self.c.predictions[:-1]))
    def test_nonfinite_predictions_rejected(self):self.assert_blocked(c=replace(self.c,predictions=(float('nan'),)+self.c.predictions[1:]))
    def test_negative_predictions_rejected(self):self.assert_blocked(c=replace(self.c,predictions=(-1.,)+self.c.predictions[1:]))
    def test_positive_complement_exact(self):self.assertEqual(self.route()[12:],self.b.predictions[12:])
    def test_fold_counterexample(self):
        risk=fold_risk([60,80,75,72,74],[61,75,76,73,75])
        self.assertEqual(risk,{'difference_of_minima':1,'minimum_paired_fold_delta':-5})
    def test_fold_length_mismatch(self):
        with self.assertRaises(ContractFailure):fold_risk([60],[60,61])
    def test_fold_empty(self):
        with self.assertRaises(ContractFailure):fold_risk([],[])
    def test_fold_nonfinite(self):
        with self.assertRaises(ContractFailure):fold_risk([float('nan')],[60])
    @staticmethod
    def complete(b,key,retry=False):
        b.begin(key,retry);b.enter_preprocessor();b.complete_preprocessor();b.enter_model();b.complete_model()
    def test_budget_successful_identity_no_rerun(self):
        b=FitBudget();self.complete(b,'one')
        with self.assertRaises(ContractFailure):b.begin('one')
    def test_model_failure_keeps_successful_preprocessor_count(self):
        b=FitBudget();b.begin('one');b.enter_preprocessor();b.complete_preprocessor();b.enter_model();b.fail()
        self.complete(b,'one',retry=True)
        self.assertEqual((b.attempts,b.prep_entered,b.prep_completed,b.model_entered,b.model_completed,b.retries),(2,2,2,2,1,1))
    def test_preprocessor_failure_separate_entry_completion(self):
        b=FitBudget();b.begin('one');b.enter_preprocessor();b.fail();self.complete(b,'one',retry=True)
        self.assertEqual((b.prep_entered,b.prep_completed,b.model_entered,b.model_completed),(2,1,1,1))
    def test_false_retry_rejected(self):
        with self.assertRaises(ContractFailure):FitBudget().begin('one',retry=True)
    def test_failed_identity_requires_retry_flag(self):
        b=FitBudget();b.begin('one');b.fail()
        with self.assertRaises(ContractFailure):b.begin('one')
    def test_max_success_72(self):
        b=FitBudget()
        for i in range(72):self.complete(b,i)
        with self.assertRaises(ContractFailure):b.begin('extra')
    def test_max_attempts_and_preprocessing_74(self):
        b=FitBudget()
        for key in (0,1):
            b.begin(key);b.enter_preprocessor();b.complete_preprocessor();b.enter_model();b.fail();self.complete(b,key,retry=True)
        for i in range(2,72):self.complete(b,i)
        self.assertEqual((b.attempts,b.prep_entered,b.prep_completed,b.model_entered,b.model_completed,b.retries),(74,74,74,74,72,2))
        with self.assertRaises(ContractFailure):b.begin('extra')
    def test_third_retry_rejected(self):
        b=FitBudget()
        for i in range(2):b.begin(i);b.fail();self.complete(b,i,retry=True)
        b.begin(2);b.fail()
        with self.assertRaises(ContractFailure):b.begin(2,retry=True)
    def test_no_overlapping_pipeline_attempt(self):
        b=FitBudget();b.begin('one')
        with self.assertRaises(ContractFailure):b.begin('two')
    def test_cannot_complete_model_before_preprocessor(self):
        b=FitBudget();b.begin('one')
        with self.assertRaises(ContractFailure):b.enter_model()

if __name__=='__main__':
    r=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(ContractTests))
    out={'test_count':r.testsRun,'all_passed':r.wasSuccessful(),'failures':len(r.failures),'errors':len(r.errors),
         'actual_model_or_preprocessor_fits':0,'synthetic_budget_transitions_are_not_fits':True,
         'scope':'synthetic keyed adapter and budget only, not integrated real training or historical identity proof',
         'private_data_read':False}
    p=Path(__file__).with_name('PRETRAIN_SYNTHETIC_RESULTS.json')
    if p.exists():assert json.loads(p.read_bytes())==out
    else:p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    raise SystemExit(not r.wasSuccessful())
