"""A24 proposed inference/identity/budget contracts, no model or data loader."""
from dataclasses import dataclass
import hashlib
import json
import math

COMMON_FIELDS=('environment','common_source','config','cohort','feature_order',
               'fold','boundary','target_window','raw_state')

def raw_digest(raw):
    def token(x):
        x=float(x)
        if math.isnan(x):return 'NaN'
        if math.isinf(x):return '+Inf' if x>0 else '-Inf'
        return x.hex()
    encoded=json.dumps([(w,token(x)) for w,x in raw],ensure_ascii=True,separators=(',',':')).encode()
    return hashlib.sha256(encoded).hexdigest()

@dataclass(frozen=True)
class Arm:
    keys: tuple
    predictions: tuple
    identity: dict

class ContractFailure(ValueError):pass

class ExecutionGuard:
    def __init__(self):self.blocked=False
    def assert_stage_allowed(self,stage):
        if self.blocked:raise ContractFailure('identity gate failed; no scoring, confirmation, fitting or saving')
    def validate_and_route(self,b0,c1,raw,expected_keys,expected_identity):
        self.assert_stage_allowed('scoring')
        try:
            if set(expected_identity)!=set(COMMON_FIELDS) or not all(expected_identity.values()):
                raise ContractFailure('complete common identity required')
            if b0.identity!=expected_identity or c1.identity!=expected_identity:
                raise ContractFailure('paired source/fold/environment identity mismatch')
            if b0.keys!=expected_keys or c1.keys!=expected_keys:
                raise ContractFailure('well/month key or order mismatch')
            if not expected_keys or len(set(expected_keys))!=len(expected_keys):
                raise ContractFailure('empty or duplicate well/month keys')
            wells=[]
            for start in range(0,len(expected_keys),12):
                block=expected_keys[start:start+12]
                if len(block)!=12 or len({w for w,m in block})!=1:
                    raise ContractFailure('complete contiguous whole-well blocks required')
                well=block[0][0]
                if well in wells:raise ContractFailure('duplicated well block')
                months=[int(m) for w,m in block]
                if any(m//100<=0 or not 1<=m%100<=12 for m in months):
                    raise ContractFailure('invalid month')
                indices=[m//100*12+m%100-1 for m in months]
                if indices!=list(range(indices[0],indices[0]+12)):
                    raise ContractFailure('target months must be consecutive and ordered')
                wells.append(well)
            if [w for w,x in raw]!=wells or raw_digest(raw)!=expected_identity['raw_state']:
                raise ContractFailure('raw status key/order/value binding mismatch')
            if len(b0.predictions)!=len(expected_keys) or len(c1.predictions)!=len(expected_keys):
                raise ContractFailure('prediction length mismatch')
            if any(not math.isfinite(p) or p<0 for p in b0.predictions+c1.predictions):
                raise ContractFailure('nonfinite or negative inverse prediction')
            routed=[]
            for i,(well,x) in enumerate(raw):
                arm=b0 if math.isfinite(float(x)) and float(x)>0 else c1
                routed.extend(arm.predictions[i*12:(i+1)*12])
            return tuple(routed)
        except (ValueError,TypeError,OverflowError) as e:
            self.blocked=True
            if isinstance(e,ContractFailure):raise
            raise ContractFailure('invalid paired input') from e

def fold_risk(b0,r1):
    if len(b0)!=len(r1) or not b0 or not all(math.isfinite(x) for x in tuple(b0)+tuple(r1)):
        raise ContractFailure('paired finite fold scores required')
    return {'difference_of_minima':min(r1)-min(b0),
            'minimum_paired_fold_delta':min(c-b for b,c in zip(b0,r1))}

class FitBudget:
    """Only a counting state machine; never runs a fit. No successful-fold reruns."""
    def __init__(self):
        self.attempts=self.retries=self.prep_entered=self.prep_completed=0
        self.model_entered=self.model_completed=0
        self.active=None;self.successful=set();self.failed=set()
    def begin(self,key,retry=False):
        if self.active is not None:raise ContractFailure('only one pipeline attempt at a time')
        if key in self.successful:raise ContractFailure('successful identity cannot be rerun')
        if retry!=(key in self.failed):raise ContractFailure('retry needs recorded failure for this identity')
        if self.attempts>=74 or self.model_completed>=72 or (retry and self.retries>=2):
            raise ContractFailure('fit budget exhausted')
        self.attempts+=1;self.retries+=int(retry);self.active=[key,0]
    def enter_preprocessor(self):
        if self.active is None or self.active[1]!=0 or self.prep_entered>=74:raise ContractFailure('invalid preprocessing entry')
        self.prep_entered+=1;self.active[1]=1
    def complete_preprocessor(self):
        if self.active is None or self.active[1]!=1:raise ContractFailure('invalid preprocessing completion')
        self.prep_completed+=1;self.active[1]=2
    def enter_model(self):
        if self.active is None or self.active[1]!=2 or self.model_entered>=74:raise ContractFailure('invalid model entry')
        self.model_entered+=1;self.active[1]=3
    def complete_model(self):
        if self.active is None or self.active[1]!=3 or self.model_completed>=72:raise ContractFailure('invalid model completion')
        self.model_completed+=1;self.successful.add(self.active[0]);self.failed.discard(self.active[0]);self.active=None
    def fail(self):
        if self.active is None:raise ContractFailure('no active failure')
        self.failed.add(self.active[0]);self.active=None
