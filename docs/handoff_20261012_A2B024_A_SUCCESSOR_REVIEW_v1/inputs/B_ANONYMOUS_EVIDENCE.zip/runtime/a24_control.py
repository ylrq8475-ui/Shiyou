"""A2B-024 R2 stage permissions; pure, no data or estimator imports."""
import math
from pretrain_contracts import ContractFailure

class Stages:
    caps={'fixed_replay':10,'five_later_splits':50,'conditional_confirmation':10,'conditional_private_full_fit':2}
    def __init__(self):
        self.completed={k:0 for k in self.caps}
        self.allowed={'fixed_replay'}
        self.blocked=False
    def check(self,stage):
        if self.blocked or stage not in self.allowed or self.completed[stage]>=self.caps[stage]:
            raise ContractFailure('stage unauthorized, blocked or quota exhausted')
    def complete(self,stage):
        self.check(stage);self.completed[stage]+=1
    def release(self,stage,passed):
        sequence=list(self.caps);i=sequence.index(stage)
        if self.completed[stage]!=self.caps[stage]:raise ContractFailure('incomplete predecessor stage')
        if not passed:self.blocked=True;return
        if i+1<len(sequence):self.allowed.add(sequence[i+1])

def fixed_gate(r,confirmation=False):
    checks={'structure':r['structure_passed'],
            'total':r['delta_vs_B0']>=(.20 if confirmation else 0),
            'first2':r['first2_score_delta']>=(0 if confirmation else -.02),
            'difference_of_minima':r['fold_risk']['difference_of_minima']>=-1}
    if confirmation:checks['minimum_paired_fold_delta']=r['fold_risk']['minimum_paired_fold_delta']>=-1
    return {'checks':checks,'passed':all(checks.values())}

def later_gate(results):
    if len(results)!=5:raise ContractFailure('exactly five later groups required')
    d=[r['delta_vs_B0'] for r in results];e=[r['first2_score_delta'] for r in results]
    if not all(math.isfinite(x) for x in d+e):raise ContractFailure('nonfinite group result')
    summary={'mean_delta':math.fsum(d)/5,'strict_positive_count':sum(x>0 for x in d),'min_group_delta':min(d),
             'mean_first2_delta':math.fsum(e)/5,'nonnegative_first2_count':sum(x>=0 for x in e)}
    checks={'structure':all(r['structure_passed'] for r in results),'mean_delta':summary['mean_delta']>=.20,
            'strict_positive_count':summary['strict_positive_count']>=4,'min_group_delta':summary['min_group_delta']>=-.20,
            'mean_first2_delta':summary['mean_first2_delta']>=0,'nonnegative_first2_count':summary['nonnegative_first2_count']>=4}
    return {**summary,'checks':checks,'passed':all(checks.values())}
