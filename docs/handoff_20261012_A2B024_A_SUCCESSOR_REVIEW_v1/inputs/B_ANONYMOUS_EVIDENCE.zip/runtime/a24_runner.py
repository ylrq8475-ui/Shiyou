"""Authorized A2B-024 R2 execution. Importing this module performs no fit."""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
sys.path.insert(0,'D:/codex/A2B023_20261010_v1')
import bridge as b
from a2b023_core import target,fit_target_pipeline,predict_target_pipeline
from experiment_core import well_arrays
sys.path.insert(0,str(HERE))
from pretrain_contracts import Arm,ExecutionGuard,FitBudget,fold_risk,raw_digest,ContractFailure
from route_core import route_predictions
from a24_control import Stages,fixed_gate,later_gate

np,pd,require=b.np,b.pd,b.require
REPEATS=(20261012,20261013,20261014,20261015,20261016)
CONFIRM=20271012
PLAN_SHA='f77e2dd7e66697e428806c514cabdc4a780ab3b18aac85867b66606eead00804'
BOUNDARY='V2 last continuous event segment end M; history through M-1; targets M+1..M+12; template inherited'

def budget_dict(ctx):
    names=('attempts','retries','prep_entered','prep_completed','model_entered','model_completed')
    return {k:getattr(ctx.budget,k) for k in names}|{'stage_successes':dict(ctx.stages.completed)}

class Journal:
    def __init__(self,out):self.root=out/'events';self.root.mkdir();self.n=0
    def add(self,event,**items):
        self.n+=1;b.dump_new(self.root/f'{self.n:04d}.json',{'event':event,'time':b.prior.stamp(),**items})

def sources():
    return b.input_fingerprints()|{str(p):b.sha(p) for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.json','.md')}

def old_snapshot():
    return b.old_snapshot()|{str(p):b.sha(p) for p in b.HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts}

def keys(view):
    # The frozen training panel stores anchor_time + horizon, not a synthetic NY column.
    return tuple((str(w),int((pd.Period(a,freq='M')+int(h)).strftime('%Y%m')))
                 for w,a,h in view[['WELL_ID','anchor_time','horizon']].itertuples(index=False,name=None))
def raw(view):
    require(view.groupby('WELL_ID',sort=False)['history__RCYL__last'].nunique(dropna=False).le(1).all(),'RAW_STATE_NOT_WELL_CONSTANT')
    return tuple((str(w),float(x)) for w,x in view.drop_duplicates('WELL_ID')[['WELL_ID','history__RCYL__last']].itertuples(index=False,name=None))
def view_identity(view,features):
    return b.fingerprint({'keys':keys(view),'feature_frame':hashlib.sha256(pd.util.hash_pandas_object(view[features],index=True).values.tobytes()).hexdigest(),
                         'dtypes':list(zip(features,view[features].dtypes.astype(str)))})

def actual_identity(ctx,view,fold_id):
    # Each arm calls this with its OWN actual prediction frame, after inference.
    return {'environment':b.fingerprint(b.public_environment()),'common_source':b.fingerprint(ctx.current_sources()),
            'config':b.fingerprint(ctx.config),'cohort':view_identity(view,ctx.features),'feature_order':b.fingerprint(list(view[ctx.features].columns)),
            'fold':fold_id,'boundary':b.fingerprint(BOUNDARY),'target_window':b.fingerprint(keys(view)),'raw_state':raw_digest(raw(view))}

def packet(ctx,pipeline,view,arm,fold_id):
    require('RCYL' not in view.columns,'LABEL_PRESENT_AT_INFERENCE')
    require(pipeline.named_steps['model'].get_params()==ctx.model_params,'MODEL_PARAMETER_DRIFT')
    p=np.asarray(predict_target_pipeline(pipeline,view[ctx.features],view,arm,b.training),dtype=float)
    require(pipeline._a24_fold_identity==fold_id,'ACTUAL_FITTED_FOLD_MISMATCH')
    return Arm(keys(view),tuple(float(x) for x in p),actual_identity(ctx,view,pipeline._a24_fold_identity))

def fit_one(ctx,train,arm,stage,seed,fold):
    ctx.guard.assert_stage_allowed(stage);ctx.stages.check(stage)
    require('RCYL' not in ctx.features and 'WELL_ID' not in ctx.features,'LABEL_OR_ID_FEATURE')
    tag={'stage':stage,'seed':seed,'fold':fold,'arm':arm}
    identity=b.fingerprint(tag|{'train_view':view_identity(train.drop(columns=['RCYL']),ctx.features),'input_lock':ctx.lock_sha})
    retry=False
    while True:
        ctx.identity_check();ctx.stages.check(stage);ctx.budget.begin(identity,retry=retry)
        x=train[ctx.features];expected=target(train.RCYL,train['history__RCYL__last'],arm)
        pipeline=b.training._model_pipeline('extra_trees_log_ratio_last',x,ctx.config)
        prep,model=pipeline.named_steps['preprocess'],pipeline.named_steps['model']
        require(model.get_params()==ctx.model_params,'MODEL_PARAMETER_DRIFT')
        op,om=prep.fit_transform,model.fit;counts=[0,0,0,0];tick=time.perf_counter()
        def pf(xx,yy=None,**kw):
            require(isinstance(xx,pd.DataFrame) and xx.equals(x) and np.array_equal(np.asarray(yy),expected) and not kw,'PREPROCESS_TRAIN_SCOPE')
            counts[0]+=1;require(counts[0]==1,'REPEATED_PREPROCESS_FIT');ctx.budget.enter_preprocessor()
            value=op(xx,yy);counts[1]+=1;ctx.budget.complete_preprocessor();return value
        def mf(xx,yy,**kw):
            require(counts[1]==1 and not kw and np.array_equal(np.asarray(yy),expected),'MODEL_TRAIN_TARGET_SCOPE')
            require(np.array_equal(np.asarray(xx),np.asarray(prep.transform(x)),equal_nan=True),'MODEL_TRAIN_FEATURE_SCOPE')
            counts[2]+=1;require(counts[2]==1,'REPEATED_MODEL_FIT');ctx.budget.enter_model()
            ctx.journal.add('model_entered',**tag,train_rows=len(x),train_wells=int(train.WELL_ID.nunique()),budget=budget_dict(ctx))
            value=om(xx,yy);counts[3]+=1;ctx.budget.complete_model();ctx.stages.complete(stage);return value
        prep.fit_transform,model.fit=pf,mf
        try:
            fit_target_pipeline(pipeline,x,train.RCYL,train.horizon,train,arm,b.training)
            require(counts==[1,1,1,1],'FIT_CALL_COUNTS')
        except Exception as exc:
            completed=counts[3]>0
            if ctx.budget.active is not None:ctx.budget.fail()
            eligible=not completed and b.old.transient_fault(exc) and ctx.budget.retries<2 and ctx.budget.attempts<74
            ctx.journal.add('fit_failure',**tag,error_type=type(exc).__name__,entered_model=counts[2]>0,completed_model=completed,eligible_retry=eligible,budget=budget_dict(ctx))
            if not eligible:raise
            retry=True;continue
        finally:
            del prep.fit_transform;del model.fit
        ctx.identity_check()
        ctx.journal.add('fit_completed',**tag,seconds=time.perf_counter()-tick,budget=budget_dict(ctx))
        pipeline._a24_fold_identity=ctx.fold_bindings[(seed,fold)] if fold else 'full_save_roundtrip'
        return pipeline

def summarize(ctx,frame,p):
    ctx.guard.assert_stage_allowed('scoring');ctx.identity_check()
    result=b.score_summary(frame,p)
    check=frame[['WELL_ID','horizon','RCYL']].copy();check['prediction']=p
    value=b.official_twelve_month_score(check,truth_column='RCYL',prediction_column='prediction',epsilon=1e-6).total
    require(abs(value-result['official_score'])<1e-10,'OFFICIAL_METRIC_DISAGREEMENT')
    return result

def routed_checked(ctx,valid,packets,expected,expected_identity):
    rr=raw(valid.drop(columns=['RCYL']))
    routed=ctx.guard.validate_and_route(packets['B0'],packets['C1'],rr,expected,expected_identity)
    b0=np.asarray(packets['B0'].predictions).reshape(-1,12);c1=np.asarray(packets['C1'].predictions).reshape(-1,12)
    other=route_predictions([x for w,x in rr],b0,c1)
    require(np.array_equal(other.ravel(),np.asarray(routed)),'INDEPENDENT_ROUTE_DISAGREEMENT')
    mask=~(np.isfinite([x for w,x in rr])&(np.asarray([x for w,x in rr])>0))
    require(np.array_equal(other[~mask],b0[~mask]) and np.array_equal(other[mask],c1[mask]),'ROUTE_VALUE_INVARIANCE')
    return np.asarray(routed)

def run_family(ctx,panel,seed,splits,digest,stage):
    arrays={a:np.full(len(panel),np.nan) for a in ('B0','C1','R1')};folds={a:[] for a in arrays}
    states=np.full(len(panel),-1,dtype=int);tick=time.perf_counter();route_checks=[]
    for f,(tr,va) in enumerate(splits,1):
        ctx.guard.assert_stage_allowed(stage)
        train,valid=panel.iloc[tr].copy(),panel.iloc[va].copy()
        require(not set(train.WELL_ID)&set(valid.WELL_ID),'WELL_ISOLATION_FAILURE')
        fold_id=b.fingerprint({'split':digest,'fold':f,'train':b.prior.array_hash(np,tr),'valid':b.prior.array_hash(np,va)})
        expected_view=valid.drop(columns=['RCYL']);expected=keys(expected_view);ei=actual_identity(ctx,expected_view,fold_id)
        packets={}
        for arm in ('B0','C1'):
            pipeline=fit_one(ctx,train,arm,stage,seed,f)
            # Distinct copies through each actual arm prediction path; identity is not copied from B0.
            view=valid.drop(columns=['RCYL']).copy()
            packets[arm]=packet(ctx,pipeline,view,arm,fold_id)
            del pipeline,view
        routed=routed_checked(ctx,valid,packets,expected,ei)
        local,state_hash=b.old.prediction_states(train,valid);states[va]=local
        for arm in arrays:
            p=routed if arm=='R1' else np.asarray(packets[arm].predictions)
            arrays[arm][va]=p;folds[arm].append(summarize(ctx,valid,p)['official_score'])
        route_checks.append({'fold':f,'full_well_12_month_identity':True,'independently_derived_arm_metadata':True,'positive_exact_B0':True,'fallback_exact_C1':True,'train_threshold_sha256':state_hash})
        ctx.journal.add('fold_completed',stage=stage,seed=seed,fold=f,scores={a:folds[a][-1] for a in arrays},well_intersection=0,budget=budget_dict(ctx))
        print(json.dumps({'stage':stage,'seed':seed,'fold':f,'model_successes':ctx.budget.model_completed}),flush=True)
    result={'stage':stage,'seed':seed,'split_sha256':digest,'seconds':time.perf_counter()-tick,'structure_passed':True,'routing_checks':route_checks,'arms':{}}
    for arm in arrays:
        result['arms'][arm]={**summarize(ctx,panel,arrays[arm]),**b.fold_statistics(folds[arm]),
                            'diagnostics':b.diagnostic_summary(panel,arrays[arm],arrays['B0'],states)}
    bb,rr=result['arms']['B0'],result['arms']['R1']
    result['delta_vs_B0']=rr['official_score']-bb['official_score']
    result['first2_score_delta']=100*(bb['official_weighted_prefix_loss']['2']-rr['official_weighted_prefix_loss']['2'])
    result['fold_risk']=fold_risk(folds['B0'],folds['R1'])
    result['paired_fold_deltas']=[r-b0 for b0,r in zip(folds['B0'],folds['R1'])]
    _,_,_,_,_,wl0=well_arrays(panel,arrays['B0']);_,_,_,_,_,wlr=well_arrays(panel,arrays['R1'])
    fallback=states[::12]==0
    require(len(fallback)==81 and np.array_equal(states,np.repeat(states[::12],12)),'STATE_ROW_ORDER')
    net=(wl0-wlr).sum(axis=0)/81*100;fb=(wl0[fallback]-wlr[fallback]).sum(axis=0)/81*100
    require(np.array_equal(wl0[~fallback],wlr[~fallback]),'POSITIVE_COMPLEMENT_LOSS_CHANGED')
    require(np.allclose(net,fb,rtol=0,atol=1e-12) and abs(float(net.sum())-result['delta_vs_B0'])<1e-10,'FALLBACK_CONTRIBUTION_IDENTITY')
    result['contribution_identity']={'positive_complement_exact_zero':True,'all_months_equal_fallback_net_contribution':True,'monthly_score_delta':net.tolist(),
        'annual_score_delta':float(net.sum()),'fallback_well_count':int(fallback.sum())}
    ctx.identity_check()
    b.dump_new(ctx.out/('FIXED_REPLAY.json' if seed is None else f'SPLIT_{seed}.json'),result)
    return result

def retain(ctx,panel):
    import joblib
    ctx.guard.assert_stage_allowed('save');ctx.stages.check('conditional_private_full_fit')
    root=HERE/'private_models_PENDING_A';root.mkdir(exist_ok=False)
    arms={a:fit_one(ctx,panel,a,'conditional_private_full_fit',None,0) for a in ('B0','C1')}
    artifact={'task':'A2B-024 R2','status':'PENDING_A_REVIEW','pipelines':arms,'feature_columns':ctx.features,
        'target_transforms':{'B0':'log1p(RCYL/scale); expm1*scale','C1':'log1p(RCYL); expm1'},
        'route':'whole well C1 iff NOT (raw history__RCYL__last is finite AND strictly positive); otherwise B0',
        'boundary':BOUNDARY,'pretrain_lock_sha256':ctx.lock_sha,'environment':b.public_environment(),'model_parameters':ctx.model_params,
        'deployment_approved':False,'historical_dtype':'UNKNOWN'}
    view=panel.drop(columns=['RCYL']);eid=actual_identity(ctx,view,'full_save_roundtrip')
    before={a:packet(ctx,arms[a],view.copy(),a,'full_save_roundtrip') for a in arms}
    p0=routed_checked(ctx,panel,before,keys(view),eid)
    ctx.guard.assert_stage_allowed('save');path=root/'R1_complete_system.joblib';joblib.dump(artifact,path,compress=3)
    loaded=joblib.load(path);after={a:packet(ctx,loaded['pipelines'][a],view.copy(),a,'full_save_roundtrip') for a in arms}
    p1=routed_checked(ctx,panel,after,keys(view),eid)
    require(np.array_equal(p0,p1) and all(before[a].predictions==after[a].predictions for a in arms),'PRIVATE_SAVE_RELOAD_DRIFT')
    ctx.identity_check()
    meta={'status':'PENDING_A_REVIEW','private_relative_path':'private_models_PENDING_A/R1_complete_system.joblib','sha256':b.sha(path),
          'bytes':path.stat().st_size,'both_arms_saved':True,'reload_exact_equality':True,'feature_count':325,'pretrain_lock_sha256':ctx.lock_sha,'deployment_approved':False}
    b.dump_new(root/'MODEL_METADATA.json',meta);return meta

def execute():
    from threadpoolctl import threadpool_limits
    import sklearn.svm._libsvm
    require(b.sha(HERE/'PLAN_R2.json')==PLAN_SHA,'APPROVED_PLAN_HASH')
    require(json.loads((HERE/'SYNTHETIC_RESULTS.json').read_bytes())['passed'],'SYNTHETIC_FAILURE')
    out=HERE/'execution';out.mkdir(exist_ok=False);journal=Journal(out)
    source_before=sources();env=b.public_environment();old_before=old_snapshot()
    config,panel,features,old_families,store,ready=b.prepare_data()
    ctx=SimpleNamespace(out=out,journal=journal,budget=FitBudget(),stages=Stages(),guard=ExecutionGuard(),features=features,config=config,
                        current_sources=sources,lock_sha=None)
    def identity_check():
        require(sources()==source_before,'SOURCE_INPUT_CHANGED');require(b.public_environment()==env,'ENVIRONMENT_CHANGED')
        if ctx.lock_sha:require(b.sha(out/'IMPLEMENTATION_PRETRAIN_LOCK.json')==ctx.lock_sha,'PRETRAIN_LOCK_CHANGED')
    ctx.identity_check=identity_check
    result={'task':'A2B-024 R2','account':'账户B执行与交付','started':b.prior.stamp(),'research':[],'confirmation':None,'model_registry':{},
            'completed':False,'historical_dtype':'UNKNOWN','official_unique_boundary_not_blocking':True,'deployment_approved':False,'prior_scores_reused':False}
    try:
        pi=b.panel_identity(panel,features);require(pi==json.loads((b.HERE/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json').read_bytes())['panel_identity'],'ORIGINAL_INPUT_DRIFT')
        ctx.model_params=b.training._model_pipeline('extra_trees_log_ratio_last',panel[features],config).named_steps['model'].get_params()
        require(ctx.model_params==json.loads((b.OLD/'PLAN.json').read_bytes())['complete_model_get_params']['B0'],'LOCKED_MODEL_PARAMETER_DRIFT')
        families=[old_families[0]]
        for seed in (*REPEATS,CONFIRM):
            splitter=b.GroupKFold(n_splits=5,shuffle=True,random_state=seed)
            splits=list(splitter.split(panel,groups=panel.WELL_ID));b.prior.validate_splits(np,panel,splits)
            digest=b.fingerprint([(b.prior.array_hash(np,tr),b.prior.array_hash(np,va)) for tr,va in splits]);families.append((seed,splits,digest))
        ctx.fold_bindings={(s,f):b.fingerprint({'split':d,'fold':f,'train':b.prior.array_hash(np,tr),'valid':b.prior.array_hash(np,va)})
                           for s,sp,d in families for f,(tr,va) in enumerate(sp,1)}
        sg={'passed':True,'accepted_structure_result':ready,'all_seven_families_well_isolation':True,'original_A23_panel_identity_match':True,
            'independent_arm_metadata_adapter':True,'no_fits_before_lock':True,'original_feature_order':features,'ordered_dtypes':list(zip(features,panel[features].dtypes.astype(str)))}
        b.dump_new(out/'STRUCTURAL_GATES.json',sg)
        lock={'task':'A2B-024 R2','time':b.prior.stamp(),'before_first_fit_or_new_score':True,'plan_sha256':PLAN_SHA,
            'user_authorization_sha256':b.sha(HERE/'USER_AUTHORIZATION.md'),'source_inputs':source_before,'environment':env,'panel_identity':pi,
            'model_parameters':ctx.model_params,'feature_order':features,'ordered_dtypes':sg['ordered_dtypes'],
            'families':[{'seed':s,'split_sha256':h,'folds':5} for s,sp,h in families],
            'old_artifact_count':len(old_before),'old_artifact_snapshot_sha256':b.fingerprint(old_before),
            'boundary':BOUNDARY,'history_dtype':'UNKNOWN','old_scores_used_as_control':False,'budget_initial':budget_dict(ctx),'parallelism':{'active_models':1,'n_jobs':-1,'BLAS_OpenMP':1},
            'process_snapshot':json.loads((HERE/'PROCESS_CHECK.json').read_bytes()),'seed_history':json.loads((HERE/'SEED_HISTORY_REVIEW.json').read_bytes())}
        identity_check();b.dump_new(out/'IMPLEMENTATION_PRETRAIN_LOCK.json',lock);ctx.lock_sha=b.sha(out/'IMPLEMENTATION_PRETRAIN_LOCK.json')
        with threadpool_limits(limits=1):
            fixed=run_family(ctx,panel,*families[0],'fixed_replay');result['research'].append(fixed)
            old_fixed=json.loads((b.HERE/'execution/FINAL_RESULT.json').read_bytes())['research'][0]
            reproduce={a:abs(fixed['arms'][a]['official_score']-old_fixed['arms'][a]['official_score'])<1e-10 and np.allclose(fixed['arms'][a]['fold_scores'],old_fixed['arms'][a]['fold_scores'],rtol=0,atol=1e-10) for a in ('B0','C1')}
            require(all(reproduce.values()),'A23_REPLAY_AGGREGATE_MISMATCH')
            result['A23_fixed_reproduction']=reproduce;result['fixed_gate']=fixed_gate(fixed)
            ctx.stages.release('fixed_replay',result['fixed_gate']['passed'])
            if result['fixed_gate']['passed']:
                for fam in families[1:6]:result['research'].append(run_family(ctx,panel,*fam,'five_later_splits'))
                result['later_gate']=later_gate(result['research'][1:]);ctx.stages.release('five_later_splits',result['later_gate']['passed'])
                if result['later_gate']['passed']:
                    conf=run_family(ctx,panel,*families[6],'conditional_confirmation');result['confirmation']=conf
                    result['confirmation_gate']=fixed_gate(conf,confirmation=True);ctx.stages.release('conditional_confirmation',result['confirmation_gate']['passed'])
                    if result['confirmation_gate']['passed']:
                        require(old_snapshot()==old_before and store.unchanged(),'PRE_SAVE_INTEGRITY_FAILURE')
                        tokens=b.prior.train_test_wells_for_scan({'control':panel},config)
                        scan=b.prior.privacy_scan(out,tokens,config['anchors']['eligible_event_values']);require(scan['passed'],'PRE_SAVE_PRIVACY_FAILURE')
                        b.dump_new(out/'PRE_SAVE_PRIVACY_SCAN.json',scan);result['model_registry']=retain(ctx,panel)
            result['completed']=True
            result['status']='COMPLETED_PRIVATE_SYSTEM_PENDING_A' if result['model_registry'] else 'COMPLETED_STOPPED_AT_REGISTERED_GATE'
        identity_check()
    except Exception as exc:
        ctx.guard.blocked=True;ctx.stages.blocked=True
        code=str(exc) if isinstance(exc,(b.GateError,ContractFailure)) else type(exc).__name__
        result.update(status='STOPPED_ACTUAL_BLOCK',error_code=code);journal.add('stopped',error_code=code,budget=budget_dict(ctx))
    finally:
        result.update(finished=b.prior.stamp(),budget=budget_dict(ctx),source_inputs_unchanged=sources()==source_before,environment_unchanged=b.public_environment()==env,
            old_artifacts_unchanged=old_snapshot()==old_before,raw_integrity={'verified_members':len(store.members),'unchanged':store.unchanged(),'copied_or_extracted':False})
        store.close();b.dump_new(out/'FINAL_RESULT.json',result)
        tokens=b.prior.train_test_wells_for_scan({'control':panel},config)
        scan=b.prior.privacy_scan(out,tokens,config['anchors']['eligible_event_values']);b.dump_new(out/'PRIVACY_SCAN.json',scan)
        require(scan['passed'],'FINAL_PRIVACY_FAILURE')
        b.dump_new(out/'SHA256SUMS.json',{p.relative_to(out).as_posix():b.sha(p) for p in out.rglob('*') if p.is_file()})
    print(json.dumps({'status':result['status'],'budget':result['budget'],'later_gate':result.get('later_gate'),'confirmation_gate':result.get('confirmation_gate')}),flush=True)
    return 0 if result['completed'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true',required=True);parser.parse_args();sys.exit(execute())
