# A2B-035 R17 F70：固定双截止点ExtraTrees融合

账户B执行与交付。两个成员均为ExtraTrees400、min_samples_leaf=6、max_features=0.75、seed20260916，其余原配置。B0井史及原始last RCYL尺度截止M−1，B0′截止T0−1；目标窗口保持最后事件段末月次月起12月，325项输入与log1p(RCYL/s)及逆变换不改。原始最后观测RCYL有限且正时为尺度，否则1，不向前搜索正值。无层位、方案、扩样、校准、外部模型或第三方数据。

本版本固定B0/B0′权重为0.7/0.3。按相同井月键对各成员RCYL原值加权，最终裁非负。权重是用户R17在完整版本平台/CV比较后事先固定的两档对冲值，不从测试数据拟合，不对单井或月份路由；不把这次研究称为未见平台反馈的独立确认。两档之外不搜索权重。

环境Python3.13.7，全部依赖精确版本见requirements.txt。首次创建环境后，所有命令统一使用该虚拟环境解释器：
```
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe train.py --config variant.json --data_dir D:/official_data --output ./new_models
.venv\Scripts\python.exe predict.py --config variant.json --data_dir D:/official_data --model ./new_models/pair.joblib --output ./result.zip
```
Linux相同命令使用.venv/bin/python。data_dir接受官方原始目录或原ZIP，保持原相对结构；output分别为全新训练目录及新的结果ZIP，不需要改配置或手工写数据。只用包内已训模型时直接执行predict命令，省略--model默认models/pair.joblib。train.py始终从原始训练CSV重新拟合两个成员，不读取包内权重或测试标签；预处理按训练数据拟合。

source/base为原字节已审边界、特征、模型和指标核心；source/fusion17.py负责两成员训练、严格配置及模型身份验证、逐井推理和固定权重合成；variant.json锁定本版本；models/pair.joblib是私有正式包权重，runtime_policy.json是私有原始数据/特征/模板绑定。上述私有材料仅在本地正式包供赛事复现，不发布GitHub。

模板窗口内非键单元不解码、不进入特征；不对测试井拟合或做输入分布比较。输出result.zip根目录10份WELL_ID.csv、120行、WELL_ID/NY/RCYL三列；键、日期文本和顺序继承模板，CRC、重复键、有限非负及列数由程序检查。独立复现的结果ZIP必须逐字节一致。事件语义按版本化假设，分数不证明唯一官方解释。包待Codex判定可上传后才交用户手动上传，不自动最终指定或操作平台。
