"""Paired fixed/5x5 CV; F70 and F50 share the exact same in-memory member OOF."""
import argparse,json,time
from pathlib import Path
import fusion17 as f
from fusion17 import b,np,require,encode,Ledger
T=Path(__file__).resolve().parent.parent

def save(n,v):
    path=T/'execution'/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encode(v))

def main(a):
    require(not (T/'execution/CV_STARTED17.json').exists(),'R17_NO_RESTART')
    lock=json.loads((T/'SOURCE_LOCK17.json').read_bytes())
    for n,h in lock['files'].items():require(b.file_sha(T/n)==h,'R17_SOURCE_DRIFT')
    require(f.runtime()==json.loads((T/'execution/ENVIRONMENT17.json').read_bytes()),'R17_ENV_DRIFT');b.verify_source_lock();cs=f.members();policy,legacy=b.load_locked_policy(a.policy)
    save('CV_STARTED17.json',{'source_lock_sha256':b.file_sha(T/'SOURCE_LOCK17.json'),'weights_locked_before_fits':True,'member_CV_planned_fits':60,'OOF_persistence':False})
    store=b.Inputs(a.data_archive)
    try:
        require(b.file_sha(a.data_archive)==json.loads((f.HERE/'base/DATA_CONTRACT.json').read_bytes())['raw_archive_sha256'],'R17_RAW_ARCHIVE_IDENTITY')
        for row in json.loads(Path(a.manifest).read_bytes())['files']:require(b.sha(store.raw(row['relative_path']))==row['sha256'],'R17_RAW_MEMBER_IDENTITY')
        history=b.load_train(store,legacy)
    finally:store.close()
    provider=b.Panels(history,policy,legacy);panels=[provider.get(c)[0] for c in cs];first=panels[0];require(first[['WELL_ID','horizon','RCYL']].equals(panels[1][['WELL_ID','horizon','RCYL']]),'R17_MEMBER_TARGET_IDENTITY');splits=b.split_sets(first)
    require(b.split_fingerprints(splits)==json.loads((f.HERE/'base/DATA_CONTRACT.json').read_bytes())['split_fingerprints'],'R17_ORIGINAL_SPLITS')
    save('PRE_DATA17.json',{'members':[{'cutoff':c['cutoff'],'identity':b.identity(p,policy['feature_order']),'audit':provider.get(c)[2]} for c,p in zip(cs,panels)],'rows':972,'wells':81,'features':325,'split_fingerprints':b.split_fingerprints(splits),'data_members_verified':100,'test_CSVs_parsed':0,'before_first_real_fit':True})
    ledger=Ledger(T/'execution/CV_FITS17.json');results={name:{} for name in ('B0','B0_prime','F70','F50')};start=time.perf_counter()
    with b.offline_only():
        for sn,folds in splits.items():
            oofs=[]
            for name,c in zip(('B0','B0_prime'),cs):
                value,oof=b.evaluate_split(c,provider,folds,ledger,'R17-'+name+'-'+sn,folder=T/'execution/member_aggregate_folds');results[name][sn]=value;oofs.append(oof);print('MEMBER_DONE '+name+' '+sn,flush=True)
            if sn=='fixed':
                for name,expected in [('B0',73.71410733861434),('B0_prime',76.33261832127738)]:require(abs(results[name][sn]['score']-expected)<=1e-9,'R17_FIXED_REFERENCE_REPRODUCTION')
            for name in ('F70','F50'):
                out=f.mix(*oofs,f.spec(name));summary=b.summary(first,out);scores=[b.summary(first.iloc[va],out[va])['official_score'] for _,va in folds]
                results[name][sn]={'score':summary['official_score'],'weighted_losses':summary['weighted_losses'],'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(np.std(scores)),'fixed_weights':f.spec(name),'member_key_alignment':True,'well_overlap':0,'validation_rows_once':True,'weight_fits':0,'delta_to_B0':summary['official_score']-results['B0'][sn]['score'],'delta_to_B0_prime':summary['official_score']-results['B0_prime'][sn]['score']}
            save('CV_'+sn+'.json',{'members_and_fusions':{n:v[sn] for n,v in results.items()},'raw_error_correlation':float(np.corrcoef(first.RCYL.to_numpy()-oofs[0],first.RCYL.to_numpy()-oofs[1])[0,1]),'OOF_rows_persisted':False})
            save('CV_PROGRESS17.json',{'split_sets_completed':len(results['F70']),'models_completed':ledger.value['models_completed'],'preprocessors_completed':ledger.value['preprocessors_completed'],'seconds':time.perf_counter()-start,'OOF_disk':False});del oofs,out
        for name in results:results[name]['repeated_summary']=b.repeated_summary([results[name]['repeat_'+str(i)] for i in range(1,6)])
    require(ledger.value['models_completed']==ledger.value['preprocessors_completed']==60,'R17_CV_FIT_COUNTS')
    save('CV_COMPLETE17.json',{'status':'R17_FIXED_FUSIONS_CV_COMPLETE','results':results,'model_fits':60,'preprocessor_fits':60,'fit_failures':ledger.value['failures'],'OOF_rows_persisted':False,'weights_selected_on_test_or_OOF':False,'weights_source':'prespecified R17 fixed complete-version hedge values','seconds':time.perf_counter()-start});print('R17_CV_COMPLETE',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for n in ('data_archive','policy','manifest'):ap.add_argument('--'+n,required=True)
    main(ap.parse_args())
