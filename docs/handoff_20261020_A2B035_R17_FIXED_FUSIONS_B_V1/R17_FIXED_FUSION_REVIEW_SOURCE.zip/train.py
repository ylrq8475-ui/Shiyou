from source.fusion17 import main
if __name__=="__main__": main('train')
