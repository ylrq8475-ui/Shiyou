"""Zero-fit tests for the exact R17 combination and both frozen cutoffs."""
import copy
import fusion17 as f
from fusion17 import b,np,pd,require

def checks(policy,legacy,columns):
    passed=[];frames={};keys=[];months=pd.period_range('1990-01',periods=30,freq='M')
    for i,name in enumerate(legacy['data']['sources']['test']['history']):
        x=pd.DataFrame({c:np.arange(30,dtype=float)+i+1 for c in columns});x['WELL_ID']='SYNTH_'+str(i);x['NY']=[str(t.to_timestamp().date()) for t in months];ec=legacy['anchors']['event_column'];x[ec]='SYNTH_NONE';x.loc[16:17,ec]=legacy['anchors']['eligible_event_values'][0];x['RCYL']=np.arange(30,dtype=float)+3;x['RCYL1']=2*x.RCYL;x['SCTS']=20.;frames[name]=x;keys+=list(x.iloc[18:][['WELL_ID','NY']].itertuples(index=False,name=None))
    p=copy.deepcopy(policy);p['template_key_sha256']=b.fingerprint(keys)
    class Store:
        def __init__(self,poison=(),invalid=False):self.poison=poison;self.invalid=invalid
        def raw(self,n):
            x=frames[n].copy()
            for c in self.poison:x[c]=x[c].astype(object);x.loc[18:,c]='POISON_DYNAMIC_CELL'
            raw=x.to_csv(index=False,lineterminator='\n').encode('utf-8-sig');return raw.replace(b'POISON_DYNAMIC_CELL',b'\xff\xfe\xfd') if self.invalid else raw
    nonkeys=[c for c in columns if c not in ('WELL_ID','NY')];cases=0
    for c in f.members():
        ref,fs,au=b.build_variant_test(Store(),p,legacy,c)
        for col in nonkeys:
            mutated,ff,am=b.build_variant_test(Store([col]),p,legacy,c);pd.testing.assert_frame_equal(ref[fs+['__scale035']],mutated[fs+['__scale035']]);require(fs==ff and am['test_window_dynamic_values_decoded']==0,'R17_WINDOW_MUTATION');cases+=1
        mutated,ff,am=b.build_variant_test(Store(nonkeys,True),p,legacy,c);pd.testing.assert_frame_equal(ref[fs+['__scale035']],mutated[fs+['__scale035']]);require(am['test_window_RCYL_parsed']==0,'R17_WINDOW_LABEL_PARSED')
    passed.append({'name':'both cutoffs, every nonkey window column and all invalid UTF8 window cells','cases':cases,'status':'PASS'})
    left=np.array([2.,4.,-8.]);right=np.array([4.,8.,2.])
    for n in ('F70','F50'):
        c=f.spec(n);expected=np.maximum(c['B0_weight']*left+c['B0_prime_weight']*right,0);require(np.array_equal(f.mix(left,right,c),expected),'R17_FIXED_RAW_VALUE_FORMULA');require(np.array_equal(f.mix(left[::-1],right[::-1],c)[::-1],expected),'R17_BLEND_QUERY_ORDER');bad=dict(c);bad['B0_weight']=.6
        try:f.mix(left,right,bad)
        except RuntimeError:pass
        else:raise RuntimeError('R17_UNREGISTERED_WEIGHT_ACCEPTED')
    passed.append({'name':'F70/F50 exact raw-value fixed weighting, clipping and permutation; reject new weights','status':'PASS'})
    toy=pd.DataFrame({'WELL_ID':np.repeat(['TOY_'+str(i) for i in range(10)],12),'horizon':np.tile(np.arange(1,13),10),'RCYL':np.arange(120,dtype=float)+1})
    require(b.summary(toy,toy.RCYL.to_numpy())['official_score']==100.,'R17_PERFECT_METRIC')
    zero=b.summary(toy,np.zeros(120));truth=toy.RCYL.to_numpy().reshape(-1,12);expected=float((100*(1-(truth/(truth+1e-6)*2.**-np.arange(1,13)).sum(1))).mean());require(abs(zero['official_score']-expected)<1e-12,'R17_METRIC_FORMULA')
    splits=b.split_sets(toy);require(len(splits)==6 and all(len(v)==5 for v in splits.values()),'R17_GROUP_SPLITS')
    passed.append({'name':'official metric and fixed plus five repeated group folds','status':'PASS'})
    return {'status':'PASS','checks':passed,'model_fits':0,'preprocessor_fits':0,'test_dataset_rows_read':0,'all_values_synthetic':True}
