"""R17 fixed raw-RCYL blending of the unchanged B0 and B0-prime members."""
import os,sys,json,argparse,platform,importlib.metadata as im,copy
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'base'))
import cv035 as b
from cv035 import np,pd,require,encode
from ledger035 import Ledger
from models035 import forbid_fits
R17='7f44d70aa53410a2d072d69874003f3a8946adbb'

def spec(name):
    require(name in ('F70','F50'),'R17_FIXED_VERSION_ONLY')
    return {'schema':'A2B035-R17-fixed-v1','variant':name,'B0_weight':.7 if name=='F70' else .5,'B0_prime_weight':.3 if name=='F70' else .5,'instruction_commit':R17}

def members():
    cs=[b.load_variant(HERE/'base/configs'/name) for name in ('B0.json','B0_prime.json')]
    for c in cs:
        b.require_release(c,allow_benchmark=True)
        require(c['features']=='base325' and c['target']=={'transform':'log_ratio','scale':'last_legal'},'R17_MEMBER_REPRESENTATION')
        require(c['learner']=={'name':'ExtraTrees','n_estimators':400,'min_samples_leaf':6,'max_features':.75,'random_state':20260916,'n_jobs':-1},'R17_MEMBER_PARAMS')
    require([c['cutoff'] for c in cs]==['M_minus_1','T0_minus_1'],'R17_MEMBER_CUTOFFS')
    return cs

def runtime():
    v={'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({d.metadata['Name']:d.version for d in im.distributions()}.items()))}
    lock=json.loads((HERE/'base/ENVIRONMENT_LOCK.json').read_bytes());require(all(v[k]==lock[k] for k in v),'R17_RUNTIME_IDENTITY');return v

def mix(left,right,configuration):
    require(configuration==spec(configuration['variant']),'R17_NO_ALTERNATIVE_WEIGHTS')
    a=np.asarray(left,float);z=np.asarray(right,float);require(a.shape==z.shape and a.ndim==1 and np.isfinite(a).all() and np.isfinite(z).all(),'R17_MEMBER_PREDICTION_VALIDITY')
    return np.clip(configuration['B0_weight']*a+configuration['B0_prime_weight']*z,0,None)

def fit_pair(data,policy_path,dest):
    env=runtime();b.verify_source_lock();cs=members();policy,legacy=b.load_locked_policy(policy_path)
    dest=Path(dest);require(not dest.exists(),'R17_TRAIN_OUTPUT_EXISTS');dest.mkdir(parents=True)
    store=b.Inputs(data)
    try:history=b.load_train(store,legacy)
    finally:store.close()
    provider=b.Panels(history,policy,legacy);panels=[provider.get(c)[0] for c in cs]
    require(panels[0][['WELL_ID','horizon','RCYL']].equals(panels[1][['WELL_ID','horizon','RCYL']]),'R17_TRAIN_MEMBER_ALIGNMENT')
    ledger=Ledger(dest/'FIT_COUNTS.json');artifacts=[]
    for i,c in enumerate(cs):artifacts.append(b.fit_members_full(c,provider,np.arange(len(panels[0])),ledger,'R17-full-member'+str(i)))
    pair={'schema':'A2B035-R17-member-pair-v1','members':artifacts,'member_configs':cs,'policy_sha256':b.file_sha(policy_path),'pipeline_lock_sha256':b.file_sha(HERE/'base/PIPELINE_LOCK.json'),'runtime':env}
    b.joblib.dump(pair,dest/'pair.joblib',compress=3)
    receipt={'schema':pair['schema'],'member_configs':cs,'model_sha256':b.file_sha(dest/'pair.joblib'),'policy_sha256':pair['policy_sha256'],'pipeline_lock_sha256':pair['pipeline_lock_sha256'],'runtime':env,'instruction_commit':R17,'fit_counts':{k:v for k,v in ledger.value.items() if k!='events'},'panel_identities':[b.identity(p,policy['feature_order']) for p in panels],'cached_or_packaged_weights_loaded_for_training':False}
    require(ledger.value['models_completed']==ledger.value['preprocessors_completed']==2,'R17_FULL_PAIR_FIT_COUNT')
    (dest/'MODEL_RECEIPT.json').write_bytes(encode(receipt));return receipt

def load_pair(path,policy_path):
    path=Path(path);r=json.loads((path.parent/'MODEL_RECEIPT.json').read_bytes());require(b.file_sha(path)==r['model_sha256'],'R17_MODEL_BYTES')
    require(r['member_configs']==members() and r['runtime']==runtime() and r['policy_sha256']==b.file_sha(policy_path) and r['pipeline_lock_sha256']==b.file_sha(HERE/'base/PIPELINE_LOCK.json'),'R17_MODEL_SOURCE_POLICY_CONFIG_BINDING')
    pair=b.joblib.load(path);require(pair['member_configs']==members() and len(pair['members'])==2,'R17_PAIR_STRUCTURE');return pair

def predict_pair(data,policy_path,model):
    b.verify_source_lock();pair=load_pair(model,policy_path);policy,legacy=b.load_locked_policy(policy_path);store=b.Inputs(data)
    try:
        with forbid_fits():
            panels=[];audits=[];predictions=[]
            for c,artifact in zip(members(),pair['members']):
                p,fs,audit=b.build_variant_test(store,policy,legacy,c);out=np.full(len(p),np.nan)
                for wid in p.WELL_ID.drop_duplicates():
                    ix=np.flatnonzero((p.WELL_ID==wid).to_numpy());out[ix]=b.predict_fitted(artifact,lambda _:p.iloc[ix])
                require(np.isfinite(out).all(),'R17_NONFINITE_MEMBER_OUTPUT');panels.append(p);audits.append(audit);predictions.append(out)
            require(panels[0][['WELL_ID','NY','horizon']].equals(panels[1][['WELL_ID','NY','horizon']]),'R17_TEMPLATE_MEMBER_ALIGNMENT')
    finally:store.close()
    return panels[0],predictions,audits

def main(operation):
    root=HERE.parent;ap=argparse.ArgumentParser();ap.add_argument('--data_dir',required=True);ap.add_argument('--output',required=True);ap.add_argument('--config',default=str(root/'variant.json'));ap.add_argument('--policy',default=str(root/'runtime_policy.json'));ap.add_argument('--model',default=str(root/'models/pair.joblib'));a=ap.parse_args()
    expected=json.loads((root/'variant.json').read_bytes());require(expected==spec(expected['variant']) and json.loads(Path(a.config).read_bytes())==expected,'R17_CONFIG_MISMATCH')
    with b.offline_only():
        if operation=='train':fit_pair(a.data_dir,a.policy,a.output)
        else:
            p,preds,audits=predict_pair(a.data_dir,a.policy,a.model);out=mix(*preds,expected);lint=b.write_result(a.output,p,out);Path(str(a.output)+'.receipt.json').write_bytes(encode({'configuration':expected,'lint':lint,'member_boundary_audits':audits,'model_fits':0,'preprocessor_fits':0,'weight_selection':'R17 prespecified complete-version comparison; no test fitting or row routing'}))
    print(operation.upper()+'_R17_COMPLETE')
