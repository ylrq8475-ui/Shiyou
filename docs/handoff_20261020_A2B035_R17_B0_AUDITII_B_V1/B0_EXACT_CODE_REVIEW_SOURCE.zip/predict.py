from config_interface import prepare
from source.b0_entry import main
if __name__=="__main__":
    prepare()
    main('predict')
