"""Exact B0 rebuilding, explicitly authorized by R15; no platform upload."""
import os,sys,json,platform,importlib.metadata as im,argparse
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE/'base'))
from cv035 import *
from ledger035 import Ledger
from models035 import forbid_fits
ENTRY_DIR=Path(__file__).resolve().parent

def runtime():
    v={'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({d.metadata['Name']:d.version for d in im.distributions()}.items()))}
    lock=json.loads((ENTRY_DIR/'base/ENVIRONMENT_LOCK.json').read_bytes());require(all(v[k]==lock[k] for k in v),'B0_RUNTIME_IDENTITY');return v

def main(operation):
    root=ENTRY_DIR.parent;ap=argparse.ArgumentParser();ap.add_argument('--data_dir',required=True);ap.add_argument('--output',required=True);ap.add_argument('--policy',default=str(root/'runtime_policy.json'));ap.add_argument('--model',default=str(root/'models/model.joblib'));a=ap.parse_args();env=runtime();verify_source_lock();c=load_variant(ENTRY_DIR/'base/configs/B0.json');require_release(c,allow_benchmark=True);require(c['cutoff']=='M_minus_1' and c['features']=='base325','B0_EXACT_CONFIG');policy,legacy=load_locked_policy(a.policy);store=Inputs(a.data_dir)
    with offline_only():
        if operation=='train':
            dest=Path(a.output);require(not dest.exists(),'B0_OUTPUT_EXISTS');dest.mkdir(parents=True);ledger=Ledger(dest/'FIT_COUNTS.json')
            try:history=load_train(store,legacy)
            finally:store.close()
            provider=Panels(history,policy,legacy);p=provider.get(c)[0];bundle=fit_members_full(c,provider,np.arange(len(p)),ledger,'B0-full-R15');bundle.update(pipeline_lock_sha256=file_sha(ENTRY_DIR/'base/PIPELINE_LOCK.json'),policy_sha256=file_sha(a.policy));joblib.dump(bundle,dest/'model.joblib',compress=3);receipt={'model_sha256':file_sha(dest/'model.joblib'),'config':c,'runtime':env,'R15_instruction_commit':'9482ad9bb2a0bc64519e6a9effc8adbfee14173a','fits':{k:v for k,v in ledger.value.items() if k!='events'},'identity':identity(p,policy['feature_order'])};(dest/'MODEL_RECEIPT.json').write_bytes(encode(receipt))
        else:
            model=Path(a.model);receipt=json.loads((model.parent/'MODEL_RECEIPT.json').read_bytes());require(file_sha(model)==receipt['model_sha256'] and receipt['config']==c,'B0_MODEL_IDENTITY');bundle=joblib.load(model);require(bundle['policy_sha256']==file_sha(a.policy) and bundle['pipeline_lock_sha256']==file_sha(ENTRY_DIR/'base/PIPELINE_LOCK.json'),'B0_SOURCE_POLICY_BINDING')
            try:
                with forbid_fits():
                    p,features,audit=build_variant_test(store,policy,legacy,c);pred=np.full(len(p),np.nan)
                    for wid in p.WELL_ID.drop_duplicates():
                        inds=np.flatnonzero((p.WELL_ID==wid).to_numpy());pred[inds]=predict_fitted(bundle,lambda m:p.iloc[inds])
                    lint=write_result(a.output,p,pred);Path(str(a.output)+'.receipt.json').write_bytes(encode({'lint':lint,'boundary':audit,'model_fits':0,'preprocessor_fits':0}))
            finally:store.close()
    print(operation.upper()+'_B0_COMPLETE')
