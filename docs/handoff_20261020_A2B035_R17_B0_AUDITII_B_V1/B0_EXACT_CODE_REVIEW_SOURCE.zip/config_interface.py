import sys,json
from pathlib import Path
def prepare():
    root=Path(__file__).resolve().parent;arg=root/'variant.json'
    for i,v in enumerate(list(sys.argv)):
        if v=='--config':arg=Path(sys.argv[i+1]);del sys.argv[i:i+2];break
        if v.startswith('--config='):arg=Path(v.split('=',1)[1]);del sys.argv[i];break
    expected=json.loads((root/'variant.json').read_bytes());assert json.loads(arg.read_bytes())==expected,'FROZEN_VERSION_CONFIG_MISMATCH'
