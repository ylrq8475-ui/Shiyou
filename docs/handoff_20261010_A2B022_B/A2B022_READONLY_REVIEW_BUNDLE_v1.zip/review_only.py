"""Portable synthetic/aggregate review only. Does not import private data loading."""
import argparse
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import math
import os
import sys
import types
import unittest
from pathlib import Path

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module

def selected_definitions(module,path,names):
    source=path.read_text(encoding='utf-8')
    parsed=ast.parse(source)
    defs=[node for node in parsed.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in names]
    if {n.name for n in defs}!=set(names):raise AssertionError('Exact source function set missing')
    # Execute only allowlisted definitions from the original byte-verified source.
    # No data path declarations, project imports or execution entry are evaluated.
    exec(compile(ast.Module(body=defs,type_ignores=[]),str(path),'exec'),module.__dict__)

def main(root):
    manifest=json.loads((root/'BUNDLE_MANIFEST.json').read_bytes())
    for name,item in manifest['files'].items():
        data=(root/name).read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise AssertionError('Bundle byte identity mismatch')
    os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
    import numpy as np
    import pandas as pd
    core=load_module('experiment_core',root/'upstream/a2b021/experiment_core.py')
    bridge=types.ModuleType('bridge')
    bridge.__dict__.update(np=np,pd=pd,Path=Path,contextlib=contextlib,json=json,hashlib=hashlib,
        GateError=core.GateError,require=core.require,fingerprint=core.fingerprint,HERE=root/'runtime')
    selected_definitions(bridge,root/'runtime/bridge.py',['family','static_frame','dump_new','forbid_fits'])
    sys.modules['bridge']=bridge
    diagnostic=types.ModuleType('diagnose_inputs');diagnostic.__dict__.update(np=np,pd=pd)
    selected_definitions(diagnostic,root/'runtime/diagnose_inputs.py',['column_profile'])
    sys.modules['diagnose_inputs']=diagnostic
    sys.path.insert(0,str(root/'runtime'))
    tests=load_module('a2b022_test_contracts',root/'runtime/test_contracts.py')
    suite=unittest.defaultTestLoader.loadTestsFromModule(tests)
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    if not result.wasSuccessful():
        print(stream.getvalue());raise AssertionError('Synthetic checks failed')
    aggregate=load_module('a2b022_aggregate_check',root/'audit/aggregate_check.py').run(root)
    summary={'bundle_byte_files_checked':len(manifest['files']),'synthetic_cases':result.testsRun,
        'synthetic_passed':result.wasSuccessful(),'aggregate_check_count':aggregate['check_count'],
        'aggregate_checks_passed':aggregate['passed'],'real_model_fits':0,'real_preprocess_fits':0,
        'private_data_read':False,'algorithm_source':'exact selected original function AST definitions plus original selector/core source; no private import paths evaluated',
        'training_or_deployment_authorized_by_entry':False}
    print(json.dumps(summary,ensure_ascii=True))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-root',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args();main(args.bundle_root.resolve())
