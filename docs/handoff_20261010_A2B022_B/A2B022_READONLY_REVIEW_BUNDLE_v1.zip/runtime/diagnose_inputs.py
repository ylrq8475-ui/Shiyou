"""Finite outer-training-only input diagnostics. No estimator is fitted."""
import json
import math
import time
from collections import Counter,defaultdict
from pathlib import Path
from bridge import (HERE,OLD,prior,np,pd,require,fingerprint,dump_new,sha,forbid_fits,
                    prepare_data,old_snapshot,public_environment,input_fingerprints,
                    panel_identity,family,static_frame)

def column_profile(series):
    numeric = pd.api.types.is_numeric_dtype(series)
    observed = np.isfinite(series.to_numpy(dtype=float)) if numeric else series.notna().to_numpy()
    values = series.iloc[np.flatnonzero(observed)]
    n = len(values)
    counts = values.value_counts(dropna=False)
    unique = len(counts)
    return {'observed':observed,'n':n,'unique':unique,'numeric':numeric,
            'constant':n>0 and unique==1,'all_missing':n==0,
            'near_constant':n>=20 and unique>1 and counts.iloc[0]/n>=.95,
            'high_missing':1-n/len(series)>=.80}

def distribution(values):
    a = np.asarray(values,dtype=float)
    return {'min':float(a.min()),'median':float(np.median(a)),'max':float(a.max())}

def fold_diagnostic(train,features):
    frame = static_frame(train,features)
    profiles = {c:column_profile(frame[c]) for c in frame}
    families = defaultdict(list)
    for c in frame:families[family(c)].append(c)
    duplicate_pairs = mask_only_pairs = correlated = eligible_pairs = 0
    correlated_observed = []
    duplicate_columns = set()
    family_summaries = []
    for group,columns in families.items():
        duplicates = correlations = eligible = patterns = 0
        for i,a in enumerate(columns):
            pa = profiles[a]
            for b in columns[i+1:]:
                pb = profiles[b]
                same_mask = np.array_equal(pa['observed'],pb['observed'])
                patterns += same_mask
                if pa['all_missing'] or pb['all_missing'] or pa['constant'] or pb['constant']:continue
                joint = pa['observed'] & pb['observed']
                va = frame[a].iloc[np.flatnonzero(joint)]
                vb = frame[b].iloc[np.flatnonzero(joint)]
                if same_mask and pa['numeric']==pb['numeric'] and np.array_equal(va.to_numpy(),vb.to_numpy()):
                    duplicates += 1
                    duplicate_columns.add(b)
                if pa['numeric'] and pb['numeric'] and joint.sum()>=32 and va.nunique()>1 and vb.nunique()>1:
                    eligible += 1
                    corr = va.rank(method='average').corr(vb.rank(method='average'),method='pearson')
                    if math.isfinite(corr) and abs(corr)>=.98:
                        correlations += 1
                        correlated_observed.append(int(joint.sum()))
        duplicate_pairs += duplicates
        mask_only_pairs += patterns
        correlated += correlations
        eligible_pairs += eligible
        family_summaries.append({'family':group,'columns':len(columns),'exact_duplicate_nonconstant_pairs':duplicates,
                                 'same_observation_mask_pairs':patterns,'high_correlation_pairs':correlations,
                                 'eligible_numeric_pairs':eligible})
    raw = frame['history__RCYL__last'].to_numpy(dtype=float)
    reasons = {'nan':np.isnan(raw),'infinity':np.isinf(raw),'finite_zero':np.isfinite(raw)&(raw==0),
               'finite_negative':np.isfinite(raw)&(raw<0),'finite_positive':np.isfinite(raw)&(raw>0)}
    scale = {}
    for name,mask in reasons.items():
        n,c = int(mask.sum()),int((~mask).sum())
        scale[name] = {'status':'RELEASED','group_wells':n,'complement_wells':c} if min(n,c)>=5 else {'status':'SUPPRESSED'}
    fallback = ~np.isfinite(raw)|(raw<=0)
    scale['fallback_total'] = {'status':'RELEASED','group_wells':int(fallback.sum()),'complement_wells':int((~fallback).sum())} if min(int(fallback.sum()),int((~fallback).sum()))>=5 else {'status':'SUPPRESSED'}
    # Cardinality of complete static profiles, never hashes or singleton keys.
    distinct = len(frame.drop_duplicates())
    return {'training_wells':len(frame),'static_columns':len(frame.columns),'forecast_index_columns':2,
        'all_missing_columns':sum(v['all_missing'] for v in profiles.values()),
        'constant_observed_columns':sum(v['constant'] for v in profiles.values()),
        'near_constant_columns':sum(v['near_constant'] for v in profiles.values()),
        'high_missing_columns':sum(v['high_missing'] for v in profiles.values()),
        'observed_independent_wells_per_column':distribution([v['n'] for v in profiles.values()]),
        'observed_unique_values_per_column':distribution([v['unique'] for v in profiles.values()]),
        'exact_duplicate_nonconstant_pairs':duplicate_pairs,'duplicate_nonconstant_columns_greedy_upper_count':len(duplicate_columns),
        'identical_observation_mask_pairs':mask_only_pairs,'high_correlation_pairs':correlated,
        'eligible_numeric_pairs':eligible_pairs,
        'joint_wells_high_correlation_pairs':None if not correlated_observed else distribution(correlated_observed),
        'unique_complete_static_profile_count':distinct,'same_profile_extra_wells':len(frame)-distinct,
        'families':family_summaries,'raw_scale_reasons':scale}

def main():
    out = HERE/'diagnostic_v2'
    out.mkdir(exist_ok=False)
    tick = time.perf_counter()
    before,env = old_snapshot(),public_environment()
    import sklearn.svm._libsvm
    from sklearn.ensemble import ExtraTreesRegressor
    from threadpoolctl import threadpool_limits
    diagnostic_lock = {'request':'A2B-022','phase':'diagnostic','locked_at':prior.stamp(),
        'plan_sha256':sha(HERE/'DIAGNOSTIC_PLAN.json'),'authorization_sha256':sha(HERE/'USER_AUTHORIZATION.txt'),
        'environment':env,'inputs':input_fingerprints(),'model_or_preprocess_fits':0,
        'native_imports_passed':['numpy','pandas','sklearn.svm._libsvm','ExtraTreesRegressor','threadpoolctl']}
    dump_new(out/'DIAGNOSTIC_PRE_DATA_LOCK.json',diagnostic_lock)
    store = None
    try:
        config,panel,features,families,store,ready = prepare_data()
        schema = [{'column':c,'dtype':str(panel[c].dtype),'family':family(c),
                   'meaning':'forecast horizon 1..12' if family(c)=='forecast_indices' else 'history statistic computed at safe cutoff, repeated across horizons'} for c in features]
        require(np.array_equal(panel['horizon'].to_numpy(),panel['forecast_step'].to_numpy()),'FORECAST_INDICES_DIFFER')
        with forbid_fits(),threadpool_limits(limits=1):
            reports=[]
            for seed,splits,digest in families:
                for fold,(tr,va) in enumerate(splits,1):
                    # Deliberately never pass validation features or labels to statistics.
                    report=fold_diagnostic(panel.iloc[tr].drop(columns=['RCYL']),features)
                    reports.append({'seed':seed,'fold':fold,'split_sha256':digest,**report})
        summary={key:distribution([r[key] for r in reports]) for key in ['all_missing_columns','constant_observed_columns','near_constant_columns','high_missing_columns','exact_duplicate_nonconstant_pairs','duplicate_nonconstant_columns_greedy_upper_count','high_correlation_pairs','same_profile_extra_wells']}
        result={'request':'A2B-022','phase':'diagnostic','complete':True,'model_fits':0,'preprocess_fits':0,
            'candidate_scores_produced':False,'elapsed_seconds':time.perf_counter()-tick,
            'schema':schema,'schema_sha256':fingerprint(schema),'panel_identity':panel_identity(panel,features),
            'source_structure':ready,'fold_count':len(reports),'folds':reports,'cross_fold_summary':summary,
            'history_statistical_unit':'one independent training well; 12 rows are not independent',
            'test_distribution_or_validation_labels_used_for_diagnostics':False,
            'correlation_implies_deletion_or_causality':False,
            'scale_one_is_not_fallback_marker':True,'historical_dtype':'UNKNOWN','P0':'OPEN'}
        require(store.unchanged(),'RAW_CHANGED')
        require(old_snapshot()==before,'OLD_ARTIFACT_CHANGED')
        require(public_environment()==env,'ENVIRONMENT_CHANGED')
        dump_new(out/'INPUT_DIAGNOSTIC.json',result)
        tokens=prior.train_test_wells_for_scan({'control':panel},config)
        scan=prior.privacy_scan(out,tokens,config['anchors']['eligible_event_values'])
        dump_new(out/'PRIVACY_SCAN.json',scan)
        require(scan['passed'],'DIAGNOSTIC_PRIVACY_SCAN')
        dump_new(out/'INTEGRITY.json',{'old_files_checked':len(before),'old_files_unchanged':True,
            'old_manifest_snapshot_sha256':fingerprint(before),'raw_members_verified':len(store.members),
            'raw_archive_and_manifest_unchanged':True,'raw_extraction_or_copy':False,'environment_unchanged':True})
        dump_new(out/'SHA256SUMS.json',{p.name:sha(p) for p in out.iterdir() if p.is_file()})
        print(json.dumps({'diagnostic_complete':True,'cross_fold_summary':summary,'privacy_passed':scan['passed'],'fits':0},ensure_ascii=True),flush=True)
    finally:
        if store is not None:store.close()

if __name__=='__main__':main()
