"""Readonly bridge to the already accepted local data construction and metric code."""
import contextlib
import hashlib
import io
import json
import os
import sys
from pathlib import Path

os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
OLD = Path('D:/codex/A2B021_20261009_v1')
sys.path.insert(0,str(OLD))
import run_research as old
prior = old.prior
sys.path.insert(0,str(prior.PROJECT/'src'))
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from oil_uplift import training, a2b013_safe as safe, multistep as multi, config as config_module
from oil_uplift.scoring import official_twelve_month_score
from experiment_core import require, GateError, fingerprint, score_summary, fold_statistics, research_gate, support_distribution
from diagnostics import diagnostic_summary

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def dump_new(path,value):
    path = Path(path)
    # Encode before opening: a report error must not leave a truncated new artifact.
    encoded = json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,
                         default=lambda x: x.item() if isinstance(x,np.generic) else (_ for _ in ()).throw(TypeError(type(x).__name__)))+'\n'
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as out:
        out.write(encoded)

@contextlib.contextmanager
def forbid_fits():
    from sklearn.pipeline import Pipeline
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
    from sklearn.tree import DecisionTreeRegressor, ExtraTreeRegressor
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler, OneHotEncoder
    classes = [Pipeline,ColumnTransformer,ExtraTreesRegressor,HistGradientBoostingRegressor,
               DecisionTreeRegressor,ExtraTreeRegressor,SimpleImputer,StandardScaler,OneHotEncoder]
    patches = []
    def blocked(*args,**kwargs):
        raise GateError('FITTING_FORBIDDEN_DURING_DIAGNOSIS')
    for cls in classes:
        for name in ('fit','fit_transform','partial_fit'):
            if hasattr(cls,name):
                own = name in cls.__dict__
                patches.append((cls,name,getattr(cls,name),own))
                setattr(cls,name,blocked)
    try:
        yield
    finally:
        for cls,name,fn,own in reversed(patches):
            if own:setattr(cls,name,fn)
            else:delattr(cls,name)

def prepare_data():
    with forbid_fits(),contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
        config,panel,unused,features,families,store,ready = prior.data_prepare(
            old.ENTRY,np,pd,training,safe,multi,config_module,GroupKFold)
        del unused
    require(len(features)==325 and len(panel)==972 and panel.WELL_ID.nunique()==81,'ORIGINAL_COHORT_REQUIRED')
    require(features==list(panel[features].columns),'FEATURE_ORDER')
    return config,panel,features,families,store,ready

def old_snapshot():
    roots = [OLD,prior.HERE,prior.PROJECT]
    records = {}
    for root in roots:
        for p in sorted(root.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                records[str(p)] = sha(p)
    return records

def public_environment():
    result = prior.environment()
    result['logical_cpu_count'] = os.cpu_count()
    return result

def input_fingerprints():
    records = old.inputs()
    for p in HERE.glob('*.py'):
        records[str(p)] = sha(p)
    for name in ('USER_AUTHORIZATION.txt','DIAGNOSTIC_PLAN.json','PLAN.json','SYNTHETIC_TEST_RESULTS.json'):
        p = HERE/name
        if p.is_file():records[str(p)] = sha(p)
    return records

def panel_identity(panel,features):
    # Hashes only; private index, values, labels and well mappings never serialized.
    return {
        'feature_order_sha256':fingerprint(features),
        'feature_dtype_sha256':fingerprint(list(zip(features,panel[features].dtypes.astype(str)))),
        'feature_frame_sha256':hashlib.sha256(pd.util.hash_pandas_object(panel[features],index=True).values.tobytes()).hexdigest(),
        'label_key_frame_sha256':hashlib.sha256(pd.util.hash_pandas_object(panel[['WELL_ID','horizon','RCYL']],index=True).values.tobytes()).hexdigest(),
    }

def family(column):
    if column in ('horizon','forecast_step'):return 'forecast_indices'
    if column=='history_month_count':return 'history_coverage'
    if column.startswith('history__'):return '__'.join(column.split('__')[:2])
    return 'unresolved'

def static_frame(train,features):
    static = [c for c in features if family(c)!='forecast_indices']
    require(all(family(c)!='unresolved' for c in features),'UNRESOLVED_FEATURE_MEANING')
    require(train.groupby('WELL_ID',sort=False)[static].nunique(dropna=False).le(1).all().all(),'HISTORY_NOT_CONSTANT_WITHIN_WELL')
    return train.drop_duplicates('WELL_ID',keep='first')[static]
