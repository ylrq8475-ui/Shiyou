"""Seal synthetic checks and preparation identities, with no real fit."""
import json
import subprocess
import sys
from bridge import HERE,prior,sha,dump_new,public_environment,forbid_fits

if (HERE/'execution').exists():
    raise RuntimeError('Existing execution must not be resealed or rerun')
result=subprocess.run([sys.executable,'-E','-B','-m','unittest','test_contracts','-v'],cwd=HERE,capture_output=True,text=True)
transcript=result.stdout+result.stderr
tests=21
if result.returncode!=0 or f'Ran {tests} tests' not in transcript:
    print(transcript);raise RuntimeError('SYNTHETIC_FAILED')
from sklearn.ensemble import ExtraTreesRegressor
import sklearn.svm._libsvm
with forbid_fits():
    model=ExtraTreesRegressor(n_estimators=400,min_samples_leaf=6,max_features=.75,random_state=20260916,n_jobs=-1)
    model._validate_params()
dump_new(HERE/'SYNTHETIC_TEST_RESULTS.json',{'request':'A2B-022','sealed_at':prior.stamp(),
    'test_cases':tests,'passed':True,'real_model_fits':0,'real_preprocess_fits':0,'transcript':transcript,
    'source_sha256':{p.name:sha(p) for p in HERE.glob('*.py')},
    'diagnostic_plan_sha256':sha(HERE/'DIAGNOSTIC_PLAN.json'),'plan_sha256':sha(HERE/'PLAN.json'),
    'mechanism_decision_sha256':sha(HERE/'MECHANISM_DECISION.md'),'environment':public_environment(),
    'native_imports':'passed; no security policy changes'})
print(json.dumps({'synthetic_cases':tests,'passed':True,'model_fits':0,'preprocess_fits':0,'before_any_candidate_score':True},ensure_ascii=True))
