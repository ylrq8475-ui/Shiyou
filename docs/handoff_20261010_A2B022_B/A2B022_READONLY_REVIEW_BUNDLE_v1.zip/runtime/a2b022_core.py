"""A2B-022 finite, label-blind representation selectors and independent fit budget."""
import math
import numpy as np
import pandas as pd
from bridge import require,fingerprint,family,static_frame

PROTECTED = ('horizon','forecast_step','history__RCYL__last')

def select_features(train,features,mode):
    """Training-well-only rule, invoked as learning preprocessing during experiment."""
    require('RCYL' not in train.columns,'SELECTOR_MUST_NOT_RECEIVE_TARGET')
    frame = static_frame(train,features)
    if mode=='identity':return list(features),{'mode':mode,'selected_count':len(features),'removed_count':0,'selected_feature_sha256':fingerprint(features)}
    require(mode=='exact_redundancy','UNREGISTERED_SELECTOR')
    keep=[]
    removed_all_missing=removed_constant=removed_duplicate=0
    buckets={}
    for column in features:
        if column in PROTECTED:
            keep.append(column)
            if column in frame:
                values=frame[column]
                mask=np.isfinite(values.to_numpy(dtype=float)) if pd.api.types.is_numeric_dtype(values) else values.notna().to_numpy()
                buckets.setdefault(family(column),[]).append((column,mask,values.iloc[np.flatnonzero(mask)].to_numpy()))
            continue
        values=frame[column]
        numeric=pd.api.types.is_numeric_dtype(values)
        mask=np.isfinite(values.to_numpy(dtype=float)) if numeric else values.notna().to_numpy()
        observed=values.iloc[np.flatnonzero(mask)]
        if len(observed)==0:
            removed_all_missing+=1
            continue
        # Preserve constant-valued columns carrying an informative missing pattern.
        if mask.all() and observed.nunique(dropna=False)==1:
            removed_constant+=1
            continue
        duplicate=False
        for other,other_mask,other_values in buckets.get(family(column),[]):
            if np.array_equal(mask,other_mask) and np.array_equal(observed.to_numpy(),other_values):
                duplicate=True
                break
        if duplicate:
            removed_duplicate+=1
            continue
        keep.append(column)
        buckets.setdefault(family(column),[]).append((column,mask,observed.to_numpy()))
    require(all(c in keep for c in PROTECTED),'PROTECTED_FEATURE_DROPPED')
    require(len(keep)==len(set(keep)) and keep==[c for c in features if c in keep],'SELECTED_ORDER_CHANGED')
    return keep,{'mode':mode,'selected_count':len(keep),'removed_count':len(features)-len(keep),
        'removed_all_missing':removed_all_missing,'removed_fully_observed_constants':removed_constant,
        'removed_exact_duplicates_same_family':removed_duplicate,
        'selected_feature_sha256':fingerprint(keep),
        'missingness_only_information_preserved':True,'training_independent_wells':int(train.WELL_ID.nunique())}

class FitBudget:
    def __init__(self,cap=90):
        self.cap=cap
        self.pipeline_attempts=0
        self.selector_fit_calls=0
        self.preprocess_entered=0
        self.preprocess_completed=0
        self.model_entered=0
        self.model_completed=0
        self.runtime_retries=0
    def begin_pipeline(self):
        require(self.pipeline_attempts<self.cap,'PIPELINE_BUDGET_EXHAUSTED')
        require(self.model_entered<self.cap,'MODEL_BUDGET_EXHAUSTED')
        self.pipeline_attempts+=1
    def begin_selector(self):
        self.selector_fit_calls+=1
        require(self.selector_fit_calls<=self.pipeline_attempts,'SELECTOR_BUDGET')
    def begin_preprocess(self):
        self.preprocess_entered+=1
        require(self.preprocess_entered<=self.pipeline_attempts,'PREPROCESS_BUDGET')
    def complete_preprocess(self):
        self.preprocess_completed+=1
        require(self.preprocess_completed<=self.preprocess_entered,'PREPROCESS_WITHOUT_ENTRY')
    def begin_model(self):
        require(self.model_entered<self.cap and self.model_entered<self.preprocess_completed,'MODEL_BUDGET_OR_PREPROCESS')
        self.model_entered+=1
    def complete_model(self):
        self.model_completed+=1
        require(self.model_completed<=self.model_entered,'MODEL_WITHOUT_ENTRY')
    def snapshot(self):return dict(self.__dict__)

def retention_gate(fixed_delta,deltas,structure=True):
    require(len(deltas)==5 and all(math.isfinite(v) for v in [fixed_delta,*deltas]),'FINITE_PAIRED_SCORES')
    result={'fixed_delta':float(fixed_delta),'repeat_mean_delta':math.fsum(deltas)/5,
        'positive_repeats':sum(v>0 for v in deltas),'worst_repeat_delta':min(deltas),
        'structure_passed':bool(structure)}
    result['fixed_pass']=fixed_delta>=-.20
    result['repeat_mean_pass']=result['repeat_mean_delta']>=.20
    result['direction_pass']=result['positive_repeats']>=4
    result['worst_repeat_pass']=result['worst_repeat_delta']>=-.20
    result['passed']=all(result[k] for k in ('structure_passed','fixed_pass','repeat_mean_pass','direction_pass','worst_repeat_pass'))
    return result
