"""A2B-022 paired full-horizon CV and conditional private retention, <=90 entries."""
import argparse
import contextlib
import io
import json
import math
import os
import sys
import time
from types import SimpleNamespace
from pathlib import Path
from bridge import (HERE,OLD,old,prior,np,pd,training,require,GateError,fingerprint,dump_new,sha,
    prepare_data,old_snapshot,public_environment,input_fingerprints,panel_identity,
    official_twelve_month_score,score_summary,fold_statistics,support_distribution,diagnostic_summary)
from a2b022_core import FitBudget,select_features,retention_gate

class Journal:
    def __init__(self,root):
        self.root=root/'events';self.root.mkdir();self.sequence=0
    def add(self,event,**items):
        self.sequence+=1
        dump_new(self.root/f'{self.sequence:04d}.json',{'event':event,'time':prior.stamp(),**items})

def source_snapshot():
    result=input_fingerprints()
    for path in [HERE/'PRE_FIT_DEBUG_LOG.json',HERE/'MECHANISM_DECISION.md',HERE/'diagnostic_v2/INPUT_DIAGNOSTIC.json',
                 HERE/'diagnostic_v2/INTEGRITY.json',HERE/'diagnostic_v2/SHA256SUMS.json']:
        result[str(path)]=sha(path)
    return result

def predict(pipeline,valid,features):
    view=valid.drop(columns=['RCYL'])
    p=np.asarray(training.predict_pipeline_output(pipeline,'extra_trees_log_ratio_last',view[features],view),dtype=float)
    p=np.clip(p,0,None)
    require(len(p)==len(valid) and np.isfinite(p).all(),'INVALID_PREDICTION')
    return p

def fit_one(ctx,train,valid,arm,tag):
    require(valid is None or not set(train.WELL_ID)&set(valid.WELL_ID),'TRAIN_VALID_WELL_LEAKAGE')
    require('RCYL' not in ctx.features and 'WELL_ID' not in ctx.features,'LABEL_OR_ID_FEATURE')
    mode=ctx.plan['first_batch_candidates'][arm]['selector']
    while True:
        ctx.identity_check()
        ctx.budget.begin_pipeline()
        if arm!='B0':ctx.budget.begin_selector()
        selected,selection=select_features(train.drop(columns=['RCYL']),ctx.features,mode)
        x=train[selected]
        expected=np.log1p(train.RCYL.to_numpy(dtype=float)/training._target_scale(train,'log_ratio_last'))
        require(np.isfinite(expected).all(),'TRANSFORM_NONFINITE')
        pipeline=training._model_pipeline('extra_trees_log_ratio_last',x,ctx.config)
        prep,model=pipeline.named_steps['preprocess'],pipeline.named_steps['model']
        require(model.get_params()==ctx.model_params,'MODEL_PARAMETER_DRIFT')
        original_prep,original_model=prep.fit_transform,model.fit
        counts={'preprocess_entered':0,'preprocess_completed':0,'model_entered':0,'model_completed':0}
        completed_before=ctx.budget.model_completed
        tick=time.perf_counter()
        def prep_fit(xx,yy=None,**kwargs):
            require(isinstance(xx,pd.DataFrame) and xx.equals(x),'PREPROCESS_NOT_EXACT_TRAIN_X')
            require(np.array_equal(np.asarray(yy),expected),'PREPROCESS_NOT_EXACT_TRAIN_Y')
            require(not kwargs,'UNAUTHORIZED_PREPROCESS_ARGS')
            counts['preprocess_entered']+=1
            require(counts['preprocess_entered']==1,'MULTIPLE_PREPROCESS_FITS')
            ctx.budget.begin_preprocess()
            output=original_prep(xx,yy)
            counts['preprocess_completed']+=1;ctx.budget.complete_preprocess()
            return output
        def model_fit(xx,yy,**kwargs):
            require(counts['preprocess_completed']==1 and not kwargs,'MODEL_WITHOUT_PREPROCESS_OR_WEIGHTED')
            require(len(xx)==len(x) and np.array_equal(np.asarray(yy),expected),'MODEL_TRAIN_TARGET_SCOPE')
            # Verify transformed model input against the just-fitted training preprocessor.
            transformed=prep.transform(x)
            require(np.array_equal(np.asarray(xx),np.asarray(transformed),equal_nan=True),'MODEL_TRAIN_FEATURE_SCOPE')
            counts['model_entered']+=1
            require(counts['model_entered']==1,'MULTIPLE_MODEL_FITS')
            ctx.budget.begin_model()
            ctx.journal.add('model_fit_entered',tag=tag,training_rows=len(x),training_wells=int(train.WELL_ID.nunique()),
                            selection=selection,budget=ctx.budget.snapshot())
            value=original_model(xx,yy)
            counts['model_completed']+=1;ctx.budget.complete_model()
            return value
        prep.fit_transform,model.fit=prep_fit,model_fit
        try:
            training._fit_pipeline(pipeline,'extra_trees_log_ratio_last',x,train.RCYL,train.horizon,train)
            require(all(v==1 for v in counts.values()),'FIT_COUNT_MISMATCH')
        except Exception as exc:
            retry=old.transient_fault(exc) and ctx.budget.model_completed==completed_before and ctx.budget.runtime_retries<2 and ctx.budget.model_entered<90
            ctx.journal.add('fit_failed',tag=tag,error_code=str(exc) if isinstance(exc,GateError) else type(exc).__name__,
                            entered_model_fit=counts['model_entered']>0,eligible_retry=retry,budget=ctx.budget.snapshot())
            if not retry:raise
            ctx.budget.runtime_retries+=1
            ctx.journal.add('runtime_retry_reserved',tag=tag,budget=ctx.budget.snapshot())
            continue
        finally:
            del prep.fit_transform;del model.fit
        ctx.identity_check()
        p=None if valid is None else predict(pipeline,valid,selected)
        support=None
        if valid is not None:
            early=valid.loc[valid.horizon<=2]
            support=support_distribution(model.apply(prep.transform(x)),model.apply(prep.transform(early[selected])),train.WELL_ID.to_numpy())
        ctx.journal.add('fit_completed',tag=tag,elapsed_seconds=time.perf_counter()-tick,counts=counts,
                        selection=selection,budget=ctx.budget.snapshot())
        return pipeline,p,selection,support,selected

def summarize(frame,p):
    result=score_summary(frame,p)
    check=frame[['WELL_ID','horizon','RCYL']].copy();check['prediction']=p
    score=official_twelve_month_score(check,truth_column='RCYL',prediction_column='prediction',epsilon=1e-6).total
    require(abs(score-result['official_score'])<1e-10,'OFFICIAL_METRIC_DISAGREEMENT')
    return result

def run_family(ctx,panel,seed,splits,digest):
    arrays={arm:np.full(len(panel),np.nan) for arm in ('B0','C1')}
    states=np.full(len(panel),-1,dtype=int)
    folds={arm:[] for arm in arrays};supports={arm:[] for arm in arrays}
    selections={arm:[] for arm in arrays}
    tick=time.perf_counter()
    for fold,(tr,va) in enumerate(splits,1):
        train,valid=panel.iloc[tr],panel.iloc[va]
        local_states,statehash=old.prediction_states(train,valid);states[va]=local_states
        for arm in arrays:
            pipeline,p,selection,support,selected=fit_one(ctx,train,valid,arm,{'seed':seed,'fold':fold,'arm':arm,'phase':'CV'})
            ctx.identity_check()
            arrays[arm][va]=p
            folds[arm].append(summarize(valid,p)['official_score'])
            supports[arm].append({'fold':fold,**support})
            selections[arm].append({'fold':fold,**selection})
            del pipeline,p
        ctx.journal.add('fold_completed',seed=seed,fold=fold,scores={a:folds[a][-1] for a in arrays},
                        well_intersection=0,train_wells=int(train.WELL_ID.nunique()),valid_wells=int(valid.WELL_ID.nunique()),
                        training_state_threshold_sha256=statehash,budget=ctx.budget.snapshot())
        print(json.dumps({'seed':seed,'fold':fold,'model_fits':ctx.budget.model_completed},ensure_ascii=True),flush=True)
    ctx.identity_check()
    result={'seed':seed,'split_sha256':digest,'elapsed_seconds':time.perf_counter()-tick,
            'structure_passed':True,'arms':{},'leaf_support':supports,'feature_selection':selections}
    for arm in arrays:
        result['arms'][arm]={**summarize(panel,arrays[arm]),**fold_statistics(folds[arm]),
                            'diagnostics':diagnostic_summary(panel,arrays[arm],arrays['B0'],states)}
        result['arms'][arm]['delta_vs_B0']=result['arms'][arm]['official_score']-result['arms']['B0']['official_score']
        result['arms'][arm]['paired_fold_deltas']=[a-b for a,b in zip(folds[arm],folds['B0'],strict=True)]
    name='FIXED_FIVE_FOLD' if seed is None else f'REPEAT_{seed}'
    dump_new(ctx.out/(name+'.json'),result)
    return result

def retain(ctx,panel,gate):
    import joblib
    directory=HERE/'private_models_PENDING_A';directory.mkdir(exist_ok=False)
    pipeline,_,selection,_,selected=fit_one(ctx,panel,None,'C1',{'phase':'private_full_research_retention','arm':'C1'})
    before=predict(pipeline,panel,selected)
    path=directory/'C1.joblib'
    artifact={'pipeline':pipeline,'feature_columns':selected,'selector_mode':'exact_redundancy',
              'target_transform':'log1p(RCYL/raw_scale)','status':'PENDING_A_REVIEW','deployment_approved':False}
    joblib.dump(artifact,path,compress=3)
    loaded=joblib.load(path)
    after=predict(loaded['pipeline'],panel,loaded['feature_columns'])
    require(np.array_equal(before,after),'RETAINED_RELOAD_PREDICTION_DRIFT')
    ctx.identity_check()
    metadata={'candidate':'C1','status':'PENDING_A_REVIEW','deployment_or_replacement_approved':False,
        'private_relative_path':'private_models_PENDING_A/C1.joblib','sha256':sha(path),'bytes':path.stat().st_size,
        'selection':selection,'selected_feature_columns':selected,'target_transform':'log1p(RCYL/raw last RCYL finite positive else1)',
        'pretrain_lock_sha256':sha(ctx.out/'IMPLEMENTATION_PRETRAIN_LOCK.json'),
        'research_retention_gate':gate,'reload_exact_prediction_equality':True,
        'not_an_independent_confirmation':True,'historical_dtype':'UNKNOWN','P0':'OPEN'}
    dump_new(directory/'C1.metadata.json',metadata)
    return metadata

def execute():
    import sklearn.svm._libsvm
    from threadpoolctl import threadpool_limits
    plan=json.loads((HERE/'PLAN.json').read_bytes())
    tests=json.loads((HERE/'SYNTHETIC_TEST_RESULTS.json').read_bytes())
    require(plan['request']=='A2B-022' and plan['candidate_count']==1,'PLAN_AUTHORIZATION_ID')
    require(tests['passed'] and tests['real_model_fits']==0,'SYNTHETIC_NOT_PASSED')
    require(json.loads((HERE/'diagnostic_v2/INPUT_DIAGNOSTIC.json').read_bytes())['complete'],'DIAGNOSTIC_NOT_COMPLETE')
    out=HERE/'execution';out.mkdir(exist_ok=False)
    journal,budget=Journal(out),FitBudget(90)
    sources,env,old_before=source_snapshot(),public_environment(),old_snapshot()
    original_old_integrity=old.old_integrity()
    config,panel,features,families,store,ready=prepare_data()
    final={'request':'A2B-022','account':'B','started':prior.stamp(),'training_completed':False,
           'candidate_count':1,'historical_dtype':'UNKNOWN','P0':'OPEN','deployment_approved':False,
           'reused_prior_model_fits':0,'reused_prior_scores':False,'research':[],'artifacts':{}}
    lock_sha=None
    def identity_check():
        require(source_snapshot()==sources,'INPUT_OR_SOURCE_CHANGED_BEFORE_SCORING')
        require(public_environment()==env,'ENVIRONMENT_CHANGED_BEFORE_SCORING')
        if lock_sha is not None:require(sha(out/'IMPLEMENTATION_PRETRAIN_LOCK.json')==lock_sha,'PRETRAIN_LOCK_CHANGED')
    ctx=SimpleNamespace(out=out,journal=journal,budget=budget,config=config,features=features,plan=plan,identity_check=identity_check)
    try:
        identity=panel_identity(panel,features)
        require(identity==json.loads((HERE/'diagnostic_v2/INPUT_DIAGNOSTIC.json').read_bytes())['panel_identity'],'DATA_CHANGED_SINCE_DIAGNOSTIC')
        dummy=training._model_pipeline('extra_trees_log_ratio_last',panel[features],config)
        ctx.model_params=dummy.named_steps['model'].get_params()
        dummy.named_steps['model']._validate_params()
        require(ctx.model_params==json.loads((OLD/'PLAN.json').read_bytes())['complete_model_get_params']['B0'],'ORIGINAL_MODEL_PARAMS_DRIFT')
        selectors=[]
        for seed,splits,digest in families:
            prior.validate_splits(np,panel,splits)
            local=[]
            for fold,(tr,va) in enumerate(splits,1):
                cols,selection=select_features(panel.iloc[tr].drop(columns=['RCYL']),features,'exact_redundancy')
                local.append({'fold':fold,**selection})
            selectors.append({'seed':seed,'split_sha256':digest,'folds':local})
        identity_check()
        dump_new(out/'STRUCTURAL_GATES.json',{'request':'A2B-022','passed':True,'original_structure':ready,
            'diagnostic_current_panel_identity_match':True,'candidate_selector_precomputed_without_labels_or_validation':selectors,
            'training_well_intersections_all_zero':True,'test_distribution_selection':False,
            'historical_dtype':'UNKNOWN','P0':'OPEN','no_real_fits_before_lock':True})
        dump_new(out/'IMPLEMENTATION_PRETRAIN_LOCK.json',{'request':'A2B-022','locked_at':prior.stamp(),
            'locked_before_first_model_fit_or_candidate_score':True,'source_and_inputs':sources,'environment':env,
            'panel_identity':identity,'model_parameters':ctx.model_params,'baseline_feature_order':features,
            'baseline_ordered_dtype':list(zip(features,panel[features].dtypes.astype(str))),
            'candidate_feature_identities':selectors,'old_artifact_snapshot_sha256':fingerprint(old_before),
            'old_artifact_count':len(old_before),'original_T1_integrity':original_old_integrity,
            'budget':budget.snapshot(),'prior_scores_reused':False,'research_only':True,
            'private_config_contents_serialized':False,'historical_dtype':'UNKNOWN','P0':'OPEN'})
        lock_sha=sha(out/'IMPLEMENTATION_PRETRAIN_LOCK.json')
        with threadpool_limits(limits=1):
            for seed,splits,digest in families:
                final['research'].append(run_family(ctx,panel,seed,splits,digest))
            fixed=final['research'][0]['arms']['C1']['delta_vs_B0']
            deltas=[r['arms']['C1']['delta_vs_B0'] for r in final['research'][1:]]
            gate=retention_gate(fixed,deltas)
            final['retention_gate']=gate
            # Integrity/privacy gates precede any private model retention decision.
            require(old_snapshot()==old_before,'OLD_ARTIFACT_CHANGED')
            require(store.unchanged(),'RAW_DATA_CHANGED')
            tokens=prior.train_test_wells_for_scan({'control':panel},config)
            scan=prior.privacy_scan(out,tokens,config['anchors']['eligible_event_values'])
            dump_new(out/'PRE_RETENTION_PRIVACY_SCAN.json',scan)
            require(scan['passed'],'PRE_RETENTION_PRIVACY_FAILED')
            decision={'locked_at':prior.stamp(),'qualified':['C1'] if gate['passed'] else [],'gate':gate,
                      'private_full_fit_max':1,'confirmation_evaluated':False,'not_deployment_approval':True}
            dump_new(out/'RESEARCH_DECISION_LOCK.json',decision)
            if gate['passed']:final['artifacts']['C1']=retain(ctx,panel,gate)
            final['registry']={'B0':{'role':'fresh paired research control','artifact_saved':False},
                'C1':{'status':'RESEARCH_GATE_PASS_PENDING_A' if gate['passed'] else 'NO_UPGRADE_SIGNAL',
                      'research_gate_pass':gate['passed'],'artifact_saved':'C1' in final['artifacts'],'deployment_approved':False}}
            final.update(training_completed=True,status='COMPLETED_PENDING_A' if gate['passed'] else 'COMPLETED_NO_QUALIFIED_MODEL')
        identity_check()
    except Exception as exc:
        final.update(status='STOPPED_ACTUAL_BLOCK',error_code=str(exc) if isinstance(exc,GateError) else type(exc).__name__)
        journal.add('stopped',error_code=final['error_code'],budget=budget.snapshot())
    finally:
        final['budget']=budget.snapshot();final['finished']=prior.stamp()
        final['input_and_source_unchanged']=source_snapshot()==sources
        final['environment_unchanged']=public_environment()==env
        final['old_artifacts_unchanged']=old_snapshot()==old_before
        final['raw_data_after']={'members':len(store.members),'archive_and_manifest_unchanged':store.unchanged(),'raw_copied_or_extracted':False}
        store.close()
        dump_new(out/'FINAL_RESULT.json',final)
        tokens=prior.train_test_wells_for_scan({'control':panel},config)
        scan=prior.privacy_scan(out,tokens,config['anchors']['eligible_event_values'])
        dump_new(out/'PRIVACY_SCAN.json',scan)
        require(scan['passed'],'PRIVACY_SCAN_FAILED')
        dump_new(out/'SHA256SUMS.json',{p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()})
    print(json.dumps({'status':final['status'],'budget':budget.snapshot(),'gate':final.get('retention_gate'),
                      'error_code':final.get('error_code'),'private_model_saved':bool(final['artifacts'])},ensure_ascii=True),flush=True)
    return 0 if final['training_completed'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',action='store_true',required=True)
    parser.parse_args();sys.exit(execute())
