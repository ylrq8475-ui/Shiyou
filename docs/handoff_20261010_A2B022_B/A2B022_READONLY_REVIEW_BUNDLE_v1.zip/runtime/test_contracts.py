"""Synthetic contracts only; no real data or estimator fitting."""
import tempfile
import unittest
from pathlib import Path
from bridge import np,pd,GateError,dump_new,forbid_fits
from a2b022_core import select_features,FitBudget,retention_gate
from diagnose_inputs import column_profile

def frame():
    rows=[]
    for i in range(8):
        for step in range(1,13):
            rows.append({'WELL_ID':f'SYNTHETIC_{i}','horizon':step,'forecast_step':step,
                'history__RCYL__last':float(i+1),'history__X__last':float(i),
                'history__X__mean':float(i),'history__X__std':1.,
                'history__X__roll':np.nan if i%2 else 1.,
                'history__X__empty':np.nan,'history__Y__last':float(i)})
    return pd.DataFrame(rows)

class Contracts(unittest.TestCase):
    def setUp(self):
        self.x=frame();self.features=[c for c in self.x if c!='WELL_ID']
    def test_same_family_exact_duplicate_removed(self):
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertIn('history__X__last',selected);self.assertNotIn('history__X__mean',selected)
    def test_cross_family_duplicate_preserved(self):
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertIn('history__Y__last',selected)
    def test_fully_observed_constant_removed(self):
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertNotIn('history__X__std',selected)
    def test_constant_with_missingness_preserved(self):
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertIn('history__X__roll',selected)
    def test_all_missing_removed(self):
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertNotIn('history__X__empty',selected)
    def test_different_missing_masks_not_duplicates(self):
        self.x.loc[self.x.WELL_ID=='SYNTHETIC_0','history__X__last']=np.nan
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertIn('history__X__mean',selected)
    def test_horizon_and_scale_protected(self):
        selected,_=select_features(self.x,self.features,'exact_redundancy')
        self.assertTrue(all(c in selected for c in ['horizon','forecast_step','history__RCYL__last']))
    def test_scale_representative_keeps_target_transform_and_deduplicates(self):
        self.x['history__RCYL__lag1']=self.x['history__RCYL__last']
        selected,_=select_features(self.x,self.features+['history__RCYL__lag1'],'exact_redundancy')
        self.assertIn('history__RCYL__last',selected)
        self.assertNotIn('history__RCYL__lag1',selected)
    def test_selector_rejects_label(self):
        self.x['RCYL']=1
        with self.assertRaises(GateError):select_features(self.x,self.features,'exact_redundancy')
    def test_history_variation_blocked(self):
        self.x.loc[0,'history__X__last']=999
        with self.assertRaises(GateError):select_features(self.x,self.features,'exact_redundancy')
    def test_identity_exact_order(self):
        self.assertEqual(select_features(self.x,self.features,'identity')[0],self.features)
    def test_unknown_mode_blocked(self):
        with self.assertRaises(GateError):select_features(self.x,self.features,'tuned')
    def test_validation_data_cannot_affect_rule(self):
        train=self.x.iloc[:72]
        first=select_features(train,self.features,'exact_redundancy')
        unused_valid=self.x.iloc[72:].copy();unused_valid['history__X__mean']=123
        self.assertEqual(first,select_features(train,self.features,'exact_redundancy'))
    def test_budget_blocks_91st_entry(self):
        b=FitBudget();b.model_entered=90;b.preprocess_completed=91
        with self.assertRaises(GateError):b.begin_model()
    def test_model_needs_preprocess(self):
        with self.assertRaises(GateError):FitBudget().begin_model()
    def test_gate_negative_fixed_blocks(self):
        self.assertFalse(retention_gate(-.21,[.3]*5)['passed'])
    def test_gate_direction_and_worst(self):
        self.assertFalse(retention_gate(0,[1,1,1,-.3,-.3])['passed'])
    def test_gate_exact_minimum(self):
        self.assertTrue(retention_gate(-.2,[.3,.3,.3,.3,-.2])['passed'])
    def test_native_no_fit_guard(self):
        from sklearn.ensemble import ExtraTreesRegressor
        with forbid_fits(),self.assertRaises(GateError):ExtraTreesRegressor().fit([[1],[2]],[1,2])
    def test_serializer_numpy_and_no_partial_on_nan(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as d:
            p=Path(d)/'report.json';dump_new(p,{'n':np.int64(1),'b':np.bool_(True)})
            self.assertTrue(p.is_file())
            q=Path(d)/'invalid.json'
            with self.assertRaises(ValueError):dump_new(q,{'x':float('nan')})
            self.assertFalse(q.exists())
    def test_near_constant_only_at_predeclared_min_n(self):
        self.assertFalse(column_profile(pd.Series([1]*18+[2]))['near_constant'])
        self.assertTrue(column_profile(pd.Series([1]*19+[2]))['near_constant'])

if __name__=='__main__':unittest.main(verbosity=2)
