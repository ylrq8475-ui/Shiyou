"""Create explicit-allowlist anonymous review artifacts. Never copy raw inputs."""
import hashlib
import json
import math
import shutil
import statistics
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
OLD=Path('D:/codex/A2B021_20261009_v1')
T1=Path('D:/codex/A2B019_T1_20261009_v1')
PROJECT=Path('D:/codex/Shiyou_B_private_handoff_20261009_v1/payload/project')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
def dump(path,value):
    with Path(path).open('x',encoding='utf-8') as out:json.dump(value,out,ensure_ascii=False,indent=2,allow_nan=False);out.write('\n')
def text(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as out:out.write(value)
def mean(values):return math.fsum(values)/len(values)
def main():
    delivery=ROOT/'delivery_v2';delivery.mkdir(exist_ok=False)
    bundle=delivery/'bundle';bundle.mkdir()
    final=load(ROOT/'execution/FINAL_RESULT.json')
    diag=load(ROOT/'diagnostic_v2/INPUT_DIAGNOSTIC.json')
    check=load(ROOT/'post_run/AGGREGATE_CHECKS.json')
    lock=load(ROOT/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json')
    assert final['training_completed'] and check['passed']
    families=final['research'];fixed=families[0];repeats=families[1:]
    summary={}
    for arm in ['B0','C1']:
        summary[arm]={'fixed':{k:v for k,v in fixed['arms'][arm].items() if k!='diagnostics'},
            'repeat_scores':[r['arms'][arm]['official_score'] for r in repeats],
            'repeat_mean_score':mean([r['arms'][arm]['official_score'] for r in repeats]),
            'repeat_deltas':[r['arms'][arm]['delta_vs_B0'] for r in repeats],
            'repeat_mean_delta':mean([r['arms'][arm]['delta_vs_B0'] for r in repeats]),
            'repeat_mean_weighted_prefix_loss':{str(n):mean([r['arms'][arm]['official_weighted_prefix_loss'][str(n)] for r in repeats]) for n in [1,2,4,12]},
            'repeat_mean_monthly_weighted_loss':[mean([r['arms'][arm]['monthly_official_weighted_loss'][i] for r in repeats]) for i in range(12)]}
    attribution={'scope':'paired aggregate loss decomposition, not causal identification',
        'fixed_score_loss_contribution_first2':100*(fixed['arms']['B0']['official_weighted_prefix_loss']['2']-fixed['arms']['C1']['official_weighted_prefix_loss']['2']),
        'repeat_score_loss_contribution_first2':100*(summary['B0']['repeat_mean_weighted_prefix_loss']['2']-summary['C1']['repeat_mean_weighted_prefix_loss']['2']),
        'repeat_prediction_state_groups':{}}
    for group in ['raw_scale_fallback','positive_scale_training_q25_low','other_positive_scale']:
        base=[r['arms']['B0']['diagnostics']['prediction_state_groups'][group] for r in repeats]
        cand=[r['arms']['C1']['diagnostics']['prediction_state_groups'][group] for r in repeats]
        if all(v['status']=='RELEASED' for v in [*base,*cand]):
            attribution['repeat_prediction_state_groups'][group]={
                'mean_wells':mean([v['group_wells'] for v in base]),
                'mean_B0_group_loss':mean([v['full_mean_weighted_loss'] for v in base]),
                'mean_C1_group_loss':mean([v['full_mean_weighted_loss'] for v in cand]),
                'mean_net_score_contribution':-100*mean([v['net_loss_change_contribution_all_wells'] for v in cand])}
        else:attribution['repeat_prediction_state_groups'][group]={'status':'SUPPRESSED'}
    dump(delivery/'MODEL_COMPARISON.json',{'request':'A2B-022','models':summary,'gate':final['retention_gate'],
        'feature_selection_fold_count_range':[min(f['selected_count'] for r in families for f in r['feature_selection']['C1']),max(f['selected_count'] for r in families for f in r['feature_selection']['C1'])],
        'same_environment_paired_control':True,'historical_score_reused':False})
    dump(delivery/'ERROR_ATTRIBUTION.json',attribution)
    dump(delivery/'FIT_ACCOUNTING.json',{'request':'A2B-022','actual':final['budget'],
        'diagnostic_model_and_preprocess_fits':0,'pretrain_selector_identity_evaluations':30,
        'runtime_selector_rule_evaluations':30,'total_training_fold_selector_rule_evaluations':60,
        'conditional_full_research_fits':len(final['artifacts']),'confirmation_fits':0,
        'models_saved':len(final['artifacts']),'planned_model_entries':60,'unused_budget_not_used_for_search':True})
    dump(delivery/'MODEL_REGISTRY.json',{'request':'A2B-022','registry':final['registry'],
        'candidate_records_preserved':True,'retained_private_artifacts':{k:{f:v for f,v in item.items() if f!='selected_feature_columns'} for k,item in final['artifacts'].items()},
        'deployment_approved':False,'A_independent_review':'PENDING'})
    dump(delivery/'INTEGRITY_AFTER.json',{'request':'A2B-022','old_files_checked':lock['old_artifact_count'],
        'old_artifact_snapshot_sha256':lock['old_artifact_snapshot_sha256'],
        'old_artifacts_unchanged':final['old_artifacts_unchanged'],'source_and_input_unchanged':final['input_and_source_unchanged'],
        'environment_unchanged':final['environment_unchanged'],'raw_data_after':final['raw_data_after'],
        'privacy_scan':load(ROOT/'execution/PRIVACY_SCAN.json'),'private_model_files_uploaded':False})
    gate=final['retention_gate']
    lines=['# A2B-022 账户B匿名研究报告','','账户B执行与交付。账户A独立复核：PENDING。',
        '',f'结论：诊断证实输入存在精确冗余，但本次固定简化规则没有产生保留信号；结束该支线。完成60次新模型拟合及60次原学习型预处理拟合，失败/重试0；没有确认、全量保存、模型升级或赛事提交。',
        '', '## 诊断与候选', '',
        '沿用81井、972行、原始325列、相同历史截止与目标窗口。30个外层训练折按独立井统计；历史列井内恒定，horizon与forecast_step为月份索引。非恒定精确重复列每折24–41对，观测恒定列15–23项、近常量5–14项；没有全缺失或缺失80%以上的列。相关性仅作冗余迹象，没有自动删相关列。',
        '', '唯一候选C1：训练折内固定去重、移除全缺失及完全观测常量，保留带缺失模式的常量信息、两个月份索引及未经填补的RCYL尺度；每折保留277–288列。对照B0仍为325列。两者均为全年共享ExtraTrees，400树、叶最少6行、max_features=0.75、种子20260916，其余参数及预处理原样。',
        '', '## 固定五折与重复结果', '', '|切分|新对照B0|候选C1|配对增量|','|---|---:|---:|---:|']
    for r in families:
        b,c=r['arms']['B0'],r['arms']['C1']
        lines.append(f"|{'固定五折' if r['seed'] is None else r['seed']}|{b['official_score']:.9f}|{c['official_score']:.9f}|{c['delta_vs_B0']:+.9f}|")
    lines += ['',f"五组重复平均增量{gate['repeat_mean_delta']:+.9f}，严格正向{gate['positive_repeats']}/5，最差增量{gate['worst_repeat_delta']:+.9f}。分数前保留条件为固定增量≥-0.20、重复平均≥+0.20、至少4/5正向、最差≥-0.20及全部结构门禁；本批未通过，不追加第二候选。",'',
        '|固定五折统计|B0|C1|','|---|---:|---:|',
        f"|最差折|{fixed['arms']['B0']['worst_fold']:.9f}|{fixed['arms']['C1']['worst_fold']:.9f}|",
        f"|折间标准差ddof=0|{fixed['arms']['B0']['fold_std_ddof0']:.9f}|{fixed['arms']['C1']['fold_std_ddof0']:.9f}|",'',
        '五折分数（原顺序）：B0='+json.dumps(fixed['arms']['B0']['fold_scores'])+'；C1='+json.dumps(fixed['arms']['C1']['fold_scores'])+'。OOF按井等权，不简单平均五折。', '',
        '## 官方加权损失与归因', '', '|窗口|固定B0|固定C1|重复均B0|重复均C1|','|---|---:|---:|---:|---:|']
    for n in [1,2,4,12]:
        lines.append(f"|前{n}月|{summary['B0']['fixed']['official_weighted_prefix_loss'][str(n)]:.9f}|{summary['C1']['fixed']['official_weighted_prefix_loss'][str(n)]:.9f}|{summary['B0']['repeat_mean_weighted_prefix_loss'][str(n)]:.9f}|{summary['C1']['repeat_mean_weighted_prefix_loss'][str(n)]:.9f}|")
    lines += ['',f"固定总分增量中前两月贡献{attribution['fixed_score_loss_contribution_first2']:+.9f}分；五重复平均中前两月贡献{attribution['repeat_score_loss_contribution_first2']:+.9f}分。这是配对损失分解，不是因果归因。预测前状态组的井数分母和净分贡献见ERROR_ATTRIBUTION.json；不得按真实高损失井进行路由。",'',
        '发现结构冗余不等于发现可修复的主要误差源。删除等价列也改变随机抽样组成；本批负结果反对采用此固定规则，不能证明所有特征简化无效、冗余有益或树模型到达上限。', '',
        '## 运行、门禁与证据范围', '',
        f"实际研究执行窗口：{final['started']} 至 {final['finished']}；六组CV累计用时{sum(r['elapsed_seconds'] for r in families):.3f}秒。成功诊断约{diag['elapsed_seconds']:.3f}秒。一次序列化故障在零拟合阶段修复，失败目录/源码保留；不是训练重试。", '',
        f"21项合成契约通过；{check['check_count']}项匿名聚合算术、事件和字节核验通过。原100份赛事文件逐成员核验，原数据只读无解压复制；{lock['old_artifact_count']}项旧工件快照一致。实际解释器、完整依赖、原生模块及源码/配置摘要在新锁中，不宣称解决历史dtype身份链。", '',
        '原预处理拟合60次；选择规则另计分数前身份预计算30次、正式执行30次。所有选择和学习型预处理只使用相应训练井，验证与训练井交集均0；不使用测试分布或验证标签择列。', '',
        '历史73.71410733861434未作为本轮对照分数复用；新训练B0恰得到相同数值。86.2003仍只为用户报告的平台分数。事件语义和P0 OPEN、历史dtype UNKNOWN继续保留，官方补充不可得不作为启动条件。既有81井及切分已被多轮研究，不称独立新测试集或统计非劣效证明。', '',
        '## 下一步', '',
        '保持现有模型和冻结成果，结束本批精确去重支线，交A独立只读复核。不要从剩余额度追加相关性阈值或融合网格。若继续研究，应先提出与本批区别明确、可由预测前信息检验的机制，锁定有限对照与候选；本报告不另行授权下一批训练。最大可修复误差机制仍未识别。', '']
    text(delivery/'REPORT_B.md','\n'.join(lines))
    text(delivery/'MECHANISM_LEDGER.md','# A2B-022 误差机制台账\n\n账户B执行与交付。\n\n|事项|证据|结论边界|决策|\n|---|---|---|---|\n|精确冗余|30训练折均出现24–41对非恒定同家族精确重复|存在性明确；不证明删列收益|唯一固定简化候选已检验|\n|简化效果|固定-0.459497、重复均-0.140818、0/5正向|当前规则与配置负证据，不外推所有简化|停止，不保存或升级|\n|相关性与近常量|训练折统计124–152对高相关、5–14近常量列|相关与低方差不等于无用|未按相关性删列|\n|组损失预算|配对预测前状态组统计及井数分母|规模与因果可修复部分不同|不按真实标签路由|\n|选择偏差|相同81井、旧固定与重复切分再次研究|新种子也非新独立井|不宣称独立确认|\n|历史dtype/事件/P0|UNKNOWN/OPEN|新锁只约束本轮实际环境|保留，不回填旧证据|\n\n前两月与各状态组损失变化见ERROR_ATTRIBUTION.json，全部候选和五折记录在复测包中。\n')
    text(delivery/'B2A_022_REVIEW_REQUEST.md','# A2B-022 账户B请求账户A独立复核\n\n账户B执行与交付。由用户转交，不直接联系账户A。\n\n用户已明确批准有限输入诊断及首批至多两个候选、90次模型拟合绝对上限。本批依据30个训练折的精确冗余选择唯一候选，分数前锁定规则和保留条件，完成新对照与候选各30次，共60模型/60原预处理拟合；选择规则预计算30次、正式30次另计。固定与重复门槛均未通过，维持停止，无模型保存。\n\n请复核：授权和分数前锁定时序；325列原对照与独立候选特征身份；无标签/验证/测试信息择列；缺失模式及RCYL原始尺度保护；官方指标、分井切分与全部算术；拟合预算和失败记录；负结果及机制解释；匿名性与旧工件完整性。\n\n包内review_only.py仅做字节、21项合成及654项匿名聚合检查，不读取私有数据、不运行训练。首次诊断序列化失败已保留及解释；不要重跑已成功的60次模型训练。A的合成/算术复核与独立真实重训必须区分。P0及历史dtype未知保留。\n\n期待A给出有限范围审查结论及必要修订，不请求自动升级、部署、正式赛事打包或平台提交。\n')
    text(delivery/'README.md','# A2B-022 账户B匿名交接｜2026-10-10\n\n账户B执行与交付；账户A独立复核PENDING。\n\n输入诊断与唯一精确去重候选已完成。新对照60模型/60原预处理拟合（各30），候选未过门槛，停止，无保留模型、升级或正式提交。这里的60是两方案合计，不是每方案60。\n\n阅读顺序：REPORT_B.md、MECHANISM_LEDGER.md、MODEL_COMPARISON.json、ERROR_ATTRIBUTION.json、FIT_ACCOUNTING.json、B2A_022_REVIEW_REQUEST.md，最后下载匿名复测ZIP及其SHA256。复测ZIP不含原始CSV、私有配置内容、井号、逐井预测/标签、OOF、模型权重或凭据。代码和运行摘要中的路径/哈希为身份元数据。\n\n下载ZIP到新目录后，可使用隔离Python运行 `python -E -B review_only.py --bundle-root <解压目录>`；此入口只执行合成和匿名算术。普通源码中的run_experiment.py是审查对象，不能因收到本包再次执行--execute。\n\n本轮解释器和依赖不同于历史的可能性已按实际锁记录；本轮同环境配对，不宣称历史dtype或业务语义已确认。固定及重复切分已被多轮使用，不称新的独立测试集。\n')
    # Explicit allowlist: no raw/private config/model folders or historical binary payloads.
    source_map={}
    def copy(source,relative):
        target=bundle/relative;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target);assert sha(source)==sha(target)
        source_map[str(Path(source))]=relative
    for p in sorted(ROOT.glob('*.py')):copy(p,'runtime/'+p.name)
    for name in ['PLAN.json','DIAGNOSTIC_PLAN.json','USER_AUTHORIZATION.txt','MECHANISM_DECISION.md','SYNTHETIC_TEST_RESULTS.json','PRE_FIT_DEBUG_LOG.json']:
        copy(ROOT/name,'runtime/'+name)
    for directory in ['execution','diagnostic_v2']:
        for p in sorted((ROOT/directory).rglob('*')):
            if p.is_file() and p.suffix=='.json':copy(p,p.relative_to(ROOT).as_posix())
    for p in sorted((PROJECT/'src/oil_uplift').glob('*.py')):copy(p,'upstream/project/src/oil_uplift/'+p.name)
    for name in ['paired_experiment.py','archive_adapter.py','t1_core.py']:copy(T1/name,'upstream/t1/'+name)
    for name in ['run_research.py','experiment_core.py','diagnostics.py']:copy(OLD/name,'upstream/a2b021/'+name)
    entry=T1/'accepted_entry/received_20261009_v1/payload/audit_payload/migration_acceptance_20261009_r1/boundary_audit.py'
    copy(entry,'upstream/accepted/boundary_audit.py')
    for name in ['aggregate_check.py','AGGREGATE_CHECKS.json','build_delivery.py','DELIVERY_BUILD_LOG.json']:copy(ROOT/'post_run'/name,'audit/'+name)
    copy(ROOT/'post_run/review_only.py','review_only.py')
    for p in list(delivery.iterdir()):
        if p.is_file():copy(p,p.name)
    bound=[]
    for original,relative in source_map.items():
        expected=lock['source_and_inputs'].get(original)
        if expected is not None:
            assert sha(bundle/relative)==expected
            bound.append({'package_path':relative,'pretrain_source_sha256':expected})
    dump(bundle/'PROVIDED_PRETRAIN_BINDINGS.json',{'bindings':bound,'provided_bound_files':len(bound),
        'private_or_historical_unprovided_inputs_remain_unverified_by_recipient':True})
    manifest={p.relative_to(bundle).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in bundle.rglob('*') if p.is_file()}
    dump(bundle/'BUNDLE_MANIFEST.json',{'request':'A2B-022','account':'B','files':manifest,'manifest_excludes_itself':True})
    retest=subprocess.run([sys.executable,'-E','-B',str(bundle/'review_only.py'),'--bundle-root',str(bundle)],capture_output=True,text=True)
    if retest.returncode:
        print(retest.stdout+retest.stderr);raise RuntimeError('PACKAGED_RETEST_FAILED')
    summary_retest=json.loads(retest.stdout.strip().splitlines()[-1])
    dump(delivery/'PACKAGED_RETEST.json',summary_retest)
    # Scan archive candidate text with fresh private tokens in memory only.
    sys.path.insert(0,str(OLD))
    import run_research as old
    sys.path.insert(0,str(old.prior.PROJECT/'src'))
    from oil_uplift import config as config_module,a2b013_safe as safe
    config=safe.safe_config(config_module.load_config(old.prior.PRIVATE_CONFIG))
    tokens=old.prior.train_test_wells_for_scan({},config)
    scan=old.prior.privacy_scan(delivery,tokens,config['anchors']['eligible_event_values'])
    assert scan['passed']
    # Generic secrets and raw-file extension allowlist, including Python sources.
    import re
    for p in bundle.rglob('*'):
        if not p.is_file():continue
        assert p.suffix in ['.json','.md','.py','.txt']
        data=p.read_bytes()
        assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----',data)
        text_value=data.decode('utf-8-sig')
        private_tokens={str(t) for t in tokens if str(t)} | {str(t) for t in config['anchors']['eligible_event_values'] if isinstance(t,str) and len(t)>=2}
        for token in private_tokens:
            assert not re.search(r'(?<![\w])'+re.escape(token)+r'(?![\w])',text_value),'PRIVATE_TOKEN_FOUND'
    dump(delivery/'PUBLICATION_PRIVACY_CHECK.json',{**scan,'private_well_tokens_checked_in_memory':len(set(map(str,tokens))),
        'all_bundle_source_files_checked':True,'raw_files_or_private_configuration_contents_or_weights_included':False,
        'generic_credential_scan_passed':True,'scope':'explicit allowlist; fresh local well/event tokens plus structural checks, not proof against unknown identifiers'})
    archive=delivery/'A2B022_READONLY_REVIEW_BUNDLE_v1.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(bundle.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(bundle).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(manifest)+1
    text(delivery/(archive.name+'.sha256'),sha(archive)+'  '+archive.name+'\n')
    dump(delivery/'PUBLICATION_MANIFEST.json',{'account':'B execution and delivery','request':'A2B-022',
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in delivery.iterdir() if p.is_file()},
        'manifest_excludes_itself':True,'A_review':'PENDING','model_fit_count':60,'no_private_artifacts_included':True})
    print(json.dumps({'delivery_files':[p.name for p in delivery.iterdir() if p.is_file()],
        'bundle_files':len(manifest)+1,'pretrain_bindings':len(bound),'zip_sha256':sha(archive),
        'zip_bytes':archive.stat().st_size,'privacy_passed':True,'packaged_retest':summary_retest},ensure_ascii=True))

if __name__=='__main__':main()
