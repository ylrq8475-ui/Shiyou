"""Limited multi-mechanism research; anonymous outputs, RAM-only paired OOF."""
from pathlib import Path
import sys,json,hashlib,shutil,time,platform,importlib.metadata as im
from datetime import datetime,timezone,timedelta
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;PREVIOUS=T.parent/'A2B035_LIGHT_DUAL_20261021_v1'
sys.path.insert(0,str(T/'source'))
def enc(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,v):
    p=T/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),'OUTPUT_EXISTS:'+p.name;p.write_bytes(enc(v))
def environment():return {'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({x.metadata['Name']:x.version for x in im.distributions()}.items()))}
def bootstrap():
    for name in ('base','freshness.py','light_dual.py','synthetic_dual.py'):
        src=PREVIOUS/'source'/name;target=T/'source'/name
        for p in src.rglob('*') if src.is_dir() else [src]:
            if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
            dest=target/p.relative_to(src) if src.is_dir() else target;dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():assert sha(dest)==sha(p),'FROZEN_COPY_CHANGED'
            else:shutil.copyfile(p,dest)
def inputs(args):
    import stability as s
    b=s.b;policy,legacy=b.load_locked_policy(args.policy);allowed=set(legacy['data']['sources']['train']['history'])
    class TrainingOnly(b.Inputs):
        def raw(self,n):
            b.require(n in allowed,'NO_TEST_OR_OTHER_TABLE_ACCESS')
            return super().raw(n)
    st=TrainingOnly(args.data)
    try:hist=b.load_train(st,legacy)
    finally:st.close()
    return s,legacy,s.build(hist,policy,legacy)
def identity(s,control,state,temporal,af,sf):
    return {'B0_E0':s.b.identity(control,af),'E1':s.b.identity(state,sf),'T1':s.b.identity(temporal.assign(WELL_ID=control.WELL_ID,horizon=control.horizon,RCYL=control.RCYL),s.TEMPORAL)}
def prepare(args):
    bootstrap()
    import stability as s
    from common_errors import run_synthetic
    s.b.verify_source_lock();env=environment();assert env==json.loads((PREVIOUS/'ENVIRONMENT_LOCK.json').read_bytes()),'ENVIRONMENT_CHANGED'
    tests=s.synthetic();diagtests=run_synthetic()
    with s.b.offline_only():s,legacy,p=inputs(args)
    control,state,temporal,af,sf,metadata,audit=p
    contract=json.loads((T/'source/base/DATA_CONTRACT.json').read_bytes());splits=s.b.split_sets(control)
    assert s.b.split_fingerprints(splits)==contract['split_fingerprints']
    assert sha(args.data)==contract['raw_archive_sha256'] and sha(args.policy)==contract['private_policy_sha256']
    oldpre=json.loads((PREVIOUS/'PRE_DATA_LOCK.json').read_bytes());ids=identity(s,control,state,temporal,af,sf)
    assert ids['T1']==oldpre['temporal_identity'] and ids['B0_E0']==oldpre['control_identity'],'TEMPORAL_OR_CONTROL_NOT_IDENTICAL'
    from sklearn.model_selection import GroupKFold
    confirm=list(GroupKFold(5,shuffle=True,random_state=s.CONFIRM_SEED).split(control,groups=control.WELL_ID))
    confirmation=[s.b.fold_hash(tr,va) for tr,va in confirm]
    pre={'identities':ids,'split_fingerprints':contract['split_fingerprints'],'confirmation_split_fingerprints':confirmation,'confirmation_seed':s.CONFIRM_SEED,
      'seed_provenance':'new locally predeclared partition; no matching seed found in checked prior plans; not a claim of new wells or statistically independent data',
      'raw_archive_sha256':sha(args.data),'private_policy_sha256':sha(args.policy),'wells':81,'rows':972,'audit':audit,'historical_dtype':'UNKNOWN no backfill','test_CSV_reads':0}
    write(Path('PRE_DATA_LOCK.json'),pre);write(Path('ENVIRONMENT_LOCK.json'),env)
    write(Path('execution/SYNTHETIC.json'),{'feature_and_boundary':tests,'diagnostic':diagtests,'model_fits':0,'preprocessor_fits':0})
    write(Path('USER_AUTHORIZATION.json'),{'role':'账户B执行与交付','verbatim':'从数据的角度 和知识本身的较多 多方面尝试 让 模型更好 比 原本的好 同时注意稳定性 然后 对于不对的地方 要分析是不是有什么共同的原因','scope':'finite data/knowledge/stability research, paired training, common-error diagnosis, conditionally save qualified private model, anonymous handoff; no formal package/platform action','source':'direct user request, not a new Claude archive'})
    history={'scope':'available local plans, actual completion aggregates and previous public deliveries','equivalent_complete_config_found':False,
      'mechanisms':[{'name':'capacity','difference':'E0 ET200 plus max_depth8 joint capacity strategy; old grid400/800 without this depth; cannot separate effects of two capacity knobs'},
      {'name':'state','difference':'21 calendar six-month M-1 features; R13 R-block was related response family mainly atM;R15 HX was measure/history counts, not sameblock'},
      {'name':'temporal','difference':'previous Ridgealpha100 descriptive results reused without retraining; newalpha1000 only differs in shrinkage; temporal frame identity exactly matched'},
      {'name':'fusion','difference':'fixed global .75B0+.25T1, no grid/inner weight fitting/per-well routing'}],
      'prior_Ridge_result_sha256':sha(PREVIOUS/'execution/RESULT_LIGHT_DUAL.json'),
      'baseline_reference_sha256':sha(T.parent/'A2B035_R17_20261020_v1/execution/CV_COMPLETE17.json'),
      'B0_refits_reason':'same-run RAM-only OOF needed for new paired error recurrence, ablation and fixed fusion; no prior row OOF persisted, not a new claim of old B0 discovery',
      'notes_sha256':{p.name:sha(p) for p in sorted((T/'notes').glob('*.md'))}}
    write(Path('HISTORY_CHECK.json'),history)
    plan={'task':'A2B-035/STABILITY_20261022','role':'账户B执行与交付','spec':s.spec(),'eligible_candidates':list(s.CANDIDATES),
      'research_CV':'fixed5 and5repeated group5, seeds1..5; four actual learners x30=120 fits; F75 no extra fits',
      'successful_fit_budget':{'research':120,'conditional_confirmation_max':15,'conditional_full_max':2,'total_max':137},'entry_budget_with_fault_retries':139,'fault_retry_cap':2,
      'preprocessors':'one top-level train-fitted pipeline per actual learner; separately counted; no diagnostic preprocessing fit',
      'baseline_reproduction':'all6 exact B0 reference scores within1e-9; fail stops before same-split new candidate',
      'research_screen_all_required':{'fixed_delta_min':.2,'repeat_mean_delta_min':.2,'positive_repeat_min':4,'worst_repeat_delta_min':-.2,'min_paired_fixed_fold_delta_min':-1.,'all_structure_checks':'PASS'},
      'selection':'among passing candidates maximize repeat_mean_delta - sample_std(repeat_deltas); tie fixed_delta then stable candidate order E0,E1,T1,F75; choose only one',
      'confirmation':{'seed':s.CONFIRM_SEED,'folds':5,'only_if_research_pass':True,'delta_min':.2,'positive_fold_min':4,'min_paired_fold_delta_min':-1.,'no_parameter_or_weight_updates':True,'not_independent_wells':True},
      'saving':'only selected candidate after confirmation all pass; one full model or twoF75 components; max4MiB combined; pending independent review, never auto replace',
      'threshold_provenance':'B prespecified engineering stable-improvement criteria, not user-quoted values or significance claim',
      'error_analysis':'six-split same-well error recurrence and paired state losses; topquartile errors>=4/6 exploratory stable-hard group; raw labels only retrospective diagnosis; group/cell privacy suppression; fixedOOF pairedwell bootstrap2000 descriptive only',
      'stops':['actual leak/target misalignment/well overlap/metric failure','runtime environment/input/source drift','baseline mismatch','entry budget exhausted'],
      'no_score_based_research_early_stop':True,'no_test_access':True,'raw_read_only':True,'OOF_persistence':False,'old_artifacts_untouched':True,'platform_actions':0,
      'parallelism':'one model and fold at a time, ETn_jobs=-1, OMP/BLAS1, no new heavy dependencies or outside weights'}
    write(Path('PLAN.json'),plan)
    locked={p.relative_to(T).as_posix():sha(p) for p in T.rglob('*') if p.is_file() and (p.is_relative_to(T/'source') or p.is_relative_to(T/'notes') or p.name in ('run_research.py','PLAN.json','ENVIRONMENT_LOCK.json','PRE_DATA_LOCK.json','USER_AUTHORIZATION.json','HISTORY_CHECK.json')) and '__pycache__' not in p.parts}
    write(Path('IMPLEMENTATION_LOCK.json'),{'files':locked,'before_first_candidate_fit_or_score':True})
    print(json.dumps({'prepared':True,'models_fitted':0,'features':{'E0':325,'E1':346,'T1':195},'maximum_models':137,'feature_tests':tests['passed'],'rate_basis_diagnostic':audit['rate_basis_diagnostic']}))
def validate(args):
    import stability as s
    for n,h in json.loads((T/'IMPLEMENTATION_LOCK.json').read_bytes())['files'].items():assert sha(T/n)==h,'LOCK_CHANGED'
    assert environment()==json.loads((T/'ENVIRONMENT_LOCK.json').read_bytes()),'ENVIRONMENT_CHANGED'
    pre=json.loads((T/'PRE_DATA_LOCK.json').read_bytes());assert sha(args.data)==pre['raw_archive_sha256'] and sha(args.policy)==pre['private_policy_sha256']
    history=json.loads((T/'HISTORY_CHECK.json').read_bytes());assert sha(T.parent/'A2B035_R17_20261020_v1/execution/CV_COMPLETE17.json')==history['baseline_reference_sha256'],'BASELINE_REFERENCE_CHANGED'
    s.b.verify_source_lock();return s,pre
def train(args):
    s,pre=validate(args);b=s.b;np=s.np
    from ledger035 import Ledger
    from models035 import forbid_fits
    from sklearn.linear_model import Ridge
    from sklearn.model_selection import GroupKFold
    from common_errors import analyze
    tick=time.perf_counter();write(Path('execution/STARTED.json'),{'time':datetime.now(timezone(timedelta(hours=8))).isoformat(),'actual_interpreter':sys.executable,'plan_sha256':sha(T/'PLAN.json'),'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json')})
    ledger=Ledger(T/'execution/FIT_EVENTS.json');ledger.value.update(local_success_cap=137,local_entry_cap=139,fault_retry_cap=2);ledger.save();original=ledger.run
    def capped(kind,stage,fn):
        assert ledger.value[kind+'s_entered']<139,'FIT_ENTRY_CAP'
        return original(kind,stage,fn)
    ledger.run=capped
    with b.offline_only():
        s,legacy,p=inputs(args);control,state,temporal,af,sf,metadata,audit=p
        assert identity(s,control,state,temporal,af,sf)==pre['identities'];splits=b.split_sets(control)
        assert b.split_fingerprints(splits)==pre['split_fingerprints']
        reference=json.loads((T.parent/'A2B035_R17_20261020_v1/execution/CV_COMPLETE17.json').read_bytes())['results']['B0']
        results={};predictions={};errors={};query_checks=[]
        def summarize(pred,folds):
            rows=[]
            for i,(tr,va) in enumerate(folds,1):
                q=b.summary(control.iloc[va],pred[va]);rows.append({'fold':i,'score':q['official_score'],'weighted_losses':q['weighted_losses'],'training_wells':int(control.iloc[tr].WELL_ID.nunique()),'validation_wells':int(control.iloc[va].WELL_ID.nunique()),'well_overlap':0,'split_sha256':b.fold_hash(tr,va)})
            q=b.summary(control,pred);scores=[x['score'] for x in rows]
            return {'score':q['official_score'],'weighted_losses':q['weighted_losses'],'folds':rows,'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(np.std(scores)),'metric_crosscheck_difference':q['official_cross_check_difference']}
        def evaluate(name,folds,label):
            pred=np.full(len(control),np.nan);cover=np.zeros(len(control),int)
            for i,(tr,va) in enumerate(folds,1):
                assert not set(control.iloc[tr].WELL_ID)&set(control.iloc[va].WELL_ID),'WELL_OVERLAP'
                a=s.fit(name,control.iloc[tr],state.iloc[tr],temporal.iloc[tr],af,sf,legacy,ledger,f'{label}-{name}-fold{i}')
                with forbid_fits(extra_classes=(Ridge,)):
                    z=s.predict(a,control.iloc[va],state.iloc[va],temporal.iloc[va])
                    if i==1 and name!='B0':
                        one=s.predict(a,control.iloc[va[:1]],state.iloc[va[:1]],temporal.iloc[va[:1]])[0];difference=float(abs(one-z[0]));assert difference<=1e-10,'QUERY_DEPENDENCE'
                        query_checks.append({'split':label,'model':name,'difference':difference,'tolerance':1e-10})
                pred[va]=z;cover[va]+=1;del a
                (T/'execution/PROGRESS.json').write_bytes(enc({'stage':label,'model':name,'last_fold':i,'models_completed':ledger.value['models_completed'],'preprocessors_completed':ledger.value['preprocessors_completed']}))
            assert (cover==1).all() and np.isfinite(pred).all(),'OOF_COVERAGE'
            return summarize(pred,folds),pred
        import freshness
        for label,folds in splits.items():
            rs={};ps={}
            for name in s.ARMS:
                rs[name],ps[name]=evaluate(name,folds,label)
                if name=='B0':assert abs(rs[name]['score']-reference[label]['score'])<=1e-9,'BASELINE_REPRODUCTION_FAILED'
            ps['F75']=.75*ps['B0']+.25*ps['T1'];rs['F75']=summarize(ps['F75'],folds)
            for name in s.CANDIDATES:rs[name]['delta_vs_B0']=rs[name]['score']-rs['B0']['score']
            rs['E1']['delta_vs_capacity_E0']=rs['E1']['score']-rs['E0']['score']
            results[label]=rs;predictions[label]=ps
            errors[label]={name:freshness.error_groups(control,ps['B0'],ps[name],metadata,folds) for name in s.CANDIDATES}
            write(Path('execution')/(label+'.json'),{'results':rs,'error_groups':errors[label]})
        assert ledger.value['models_completed']==ledger.value['preprocessors_completed']==120
        common=analyze(control,predictions,metadata);write(Path('execution/COMMON_ERRORS.json'),common)
        screens={}
        for name in s.CANDIDATES:
            deltas=[results['repeat_'+str(i)][name]['delta_vs_B0'] for i in range(1,6)];fixed=results['fixed'][name]['delta_vs_B0'];fd=[z-a for z,a in zip(results['fixed'][name]['fold_scores'],results['fixed']['B0']['fold_scores'])]
            conditions={'fixed_gain':fixed>=.2,'mean_gain':np.mean(deltas)>=.2,'positive_direction':sum(x>0 for x in deltas)>=4,'worst_repeat':min(deltas)>=-.2,'worst_fixed_pair':min(fd)>=-1.}
            conditions={k:bool(v) for k,v in conditions.items()}
            screens[name]={'fixed_delta':fixed,'repeat_deltas':deltas,'repeat_mean_delta':float(np.mean(deltas)),'positive_repeats':sum(x>0 for x in deltas),'worst_repeat_delta':min(deltas),'paired_fixed_fold_deltas':fd,'stability_rank_score':float(np.mean(deltas)-np.std(deltas,ddof=1)),'conditions':conditions,'pass':all(conditions.values())}
        passed=[n for n in s.CANDIDATES if screens[n]['pass']]
        selected=max(passed,key=lambda n:(screens[n]['stability_rank_score'],screens[n]['fixed_delta'],-list(s.CANDIDATES).index(n))) if passed else None
        write(Path('execution/RESEARCH_COMPLETE.json'),{'screens':screens,'selected_before_confirmation':selected,'model_fits':120,'preprocessor_fits':120,'no_score_based_parameter_changes':True})
        del predictions
        confirm={'status':'NOT_RUN_NO_RESEARCH_PASS'};artifacts=[];registry=None
        if selected:
            folds=list(GroupKFold(5,shuffle=True,random_state=s.CONFIRM_SEED).split(control,groups=control.WELL_ID))
            assert [b.fold_hash(tr,va) for tr,va in folds]==pre['confirmation_split_fingerprints']
            models=['B0','T1'] if selected=='F75' else ['B0',selected];cr={};cp={}
            for n in models:cr[n],cp[n]=evaluate(n,folds,'confirmation')
            if selected=='F75':cp['F75']=.75*cp['B0']+.25*cp['T1'];cr['F75']=summarize(cp['F75'],folds)
            delta=cr[selected]['score']-cr['B0']['score'];fd=[z-a for z,a in zip(cr[selected]['fold_scores'],cr['B0']['fold_scores'])]
            confirmation_pass=delta>=.2 and sum(x>0 for x in fd)>=4 and min(fd)>=-1.
            confirm={'status':'PASS' if confirmation_pass else 'FAIL','seed':s.CONFIRM_SEED,'selected':selected,'results':cr,'delta':delta,'paired_fold_deltas':fd,'positive_folds':sum(x>0 for x in fd),'not_independent_wells':True};del cp
            write(Path('execution/CONFIRMATION.json'),confirm)
            if confirmation_pass:
                names=['B0','T1'] if selected=='F75' else [selected];full={};private=T/'private';private.mkdir()
                for name in names:
                    full[name]=s.fit(name,control,state,temporal,af,sf,legacy,ledger,'full-'+name)
                    path=private/(name+'.joblib');b.joblib.dump(full[name],path,compress=3);artifacts.append({'component':name,'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path)})
                with forbid_fits(extra_classes=(Ridge,)):
                    for name in names:
                        before=s.predict(full[name],control,state,temporal);after=s.predict(b.joblib.load(private/(name+'.joblib')),control,state,temporal);assert np.array_equal(before,after),'ARTIFACT_RELOAD_MISMATCH'
                del full,before,after
                size=sum(x['bytes'] for x in artifacts)
                registry={'candidate':selected,'components':artifacts,'combined_bytes':size,'size_cap':4194304,'size_pass':size<=4194304,'status':'PENDING_INDEPENDENT_REVIEW' if size<=4194304 else 'RESEARCH_ONLY_SIZE_FAIL','research_and_confirmation_pass':True,'not_deployed':True,'full_train_predictions_only_artifact_check':True}
                write(Path('private/MODEL_REGISTRY.json'),registry)
        validate(args)
        status='NO_STABLE_IMPROVEMENT_THIS_BATCH' if not selected else 'CONFIRMATION_FAILED' if confirm['status']=='FAIL' else registry['status']
        result={'task':'A2B-035/STABILITY_20261022','role':'账户B执行与交付','spec':s.spec(),'results':results,'screen':screens,'selected':selected,'confirmation':confirm,'model_registry_anonymous':registry,'status':status,
          'models_fitted':ledger.value['models_completed'],'preprocessors_fitted':ledger.value['preprocessors_completed'],'models_entered':ledger.value['models_entered'],'failures':ledger.value['failures'],'retries':0,
          'structure':{'leakage':'PASS','target_alignment':'PASS','well_isolation':'PASS','official_metric':'PASS','baseline_reproduction':'PASS','new_state_future_comparisons':audit['state_future_mutation_checks'],'time_future_comparisons':audit['real_future_mutation_feature_checks'],'query_independence':query_checks,'independent_review':'PENDING'},
          'raw_archive_and_policy_unchanged':True,'source_environment_unchanged':True,'OOF_persisted':False,'test_CSV_reads':0,'test_predictions':0,'formal_packages':0,'platform_uploads':0,'old_models_replaced':False,
          'plan_sha256':sha(T/'PLAN.json'),'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json'),'seconds':time.perf_counter()-tick}
        write(Path('execution/ERROR_GROUPS.json'),errors);write(Path('execution/RESULT_STABILITY.json'),result)
        print(json.dumps({'status':status,'screen':screens,'confirmation':{k:v for k,v in confirm.items() if k!='results'},'model_fits':ledger.value['models_completed'],'seconds':result['seconds']},ensure_ascii=False,indent=2))
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','train']);ap.add_argument('--data',required=True);ap.add_argument('--policy',required=True);a=ap.parse_args()
    try:{'prepare':prepare,'train':train}[a.mode](a)
    except Exception as exc:
        p=T/'execution/FAILURE.json';p.parent.mkdir(parents=True,exist_ok=True)
        if not p.exists():p.write_bytes(enc({'type':type(exc).__name__,'message':str(exc) if isinstance(exc,(AssertionError,RuntimeError)) else 'technical failure; see local stderr','budget_not_reset':True}))
        raise
