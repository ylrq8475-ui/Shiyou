"""Pure aggregate, zero-fit OOF error diagnostics.

No I/O or model fitting occurs in this module. Identifiers and per-well arrays
are temporary memory objects and are never part of the returned object.
"""

from __future__ import annotations

import json
import math
from collections.abc import Mapping

import numpy as np
import pandas as pd
from scipy.stats import rankdata


SPLITS = ("fixed", "repeat_1", "repeat_2", "repeat_3", "repeat_4", "repeat_5")
MODELS = ("B0", "E0", "E1", "T1", "F75")
AGE_FIELDS = ("CCJHWND", "CCYND", "LY", "CMD", "XXDL")
MIN_GROUP_SIZE = 5
EPSILON = 1e-6
BOOTSTRAP_DRAWS = 2000
BOOTSTRAP_SEED = 20261022

GROUP_LEVELS = {
    "scale_state": ("fallback", "positive"),
    "operating_fraction": ("below_0.8", "other", "unknown"),
    "recent_ratio": ("below_0.5", "0.5_to_2", "above_2", "unknown"),
    "BX_state": ("missing", "outside_0_100", "within_0_100"),
    **{
        f"age_{field}": (
            "observed_now", "missing_1_month", "missing_2plus_months"
        )
        for field in AGE_FIELDS
    },
}


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _finite_or_none(value: float) -> float | None:
    value = float(value)
    return value if math.isfinite(value) else None


def _validate(panel, predictions_by_split, metadata):
    _require(isinstance(panel, pd.DataFrame), "panel must be a DataFrame")
    _require(isinstance(metadata, pd.DataFrame), "metadata must be a DataFrame")
    required = {"WELL_ID", "horizon", "RCYL", "__scale035"}
    _require(required.issubset(panel.columns), "panel required columns are missing")
    _require(
        {"WELL_ID", *GROUP_LEVELS}.issubset(metadata.columns),
        "metadata required grouping columns are missing",
    )
    _require(panel.shape[0] == 81 * 12, "expected exactly 81 wells and 972 rows")
    _require(not panel["WELL_ID"].isna().any(), "panel well identity is missing")
    ids = panel["WELL_ID"].to_numpy().reshape(81, 12)
    _require(bool((ids == ids[:, :1]).all()), "well rows must be contiguous")
    wells = ids[:, 0]
    _require(pd.Index(wells).is_unique, "well blocks must be unique")
    horizon = pd.to_numeric(panel["horizon"], errors="raise").to_numpy(dtype=float)
    _require(
        bool(np.array_equal(horizon.reshape(81, 12), np.tile(np.arange(1, 13), (81, 1)))),
        "each well must have ordered horizons 1 through 12",
    )
    y = pd.to_numeric(panel["RCYL"], errors="raise").to_numpy(dtype=float).reshape(81, 12)
    scale = pd.to_numeric(panel["__scale035"], errors="raise").to_numpy(dtype=float).reshape(81, 12)
    _require(bool(np.isfinite(y).all() and (y >= 0).all()), "truth must be finite and nonnegative")
    _require(bool(np.isfinite(scale).all() and (scale > 0).all()), "scale must be finite and positive")
    _require(bool((scale == scale[:, :1]).all()), "scale must be constant within well")
    _require(not metadata["WELL_ID"].isna().any(), "metadata identity is missing")
    _require(metadata["WELL_ID"].is_unique and len(metadata) == 81, "metadata must have 81 unique wells")
    indexed = metadata.set_index("WELL_ID")
    _require(bool(pd.Index(wells).isin(indexed.index).all()), "metadata cohort mismatch")
    meta = indexed.reindex(wells)
    for name, levels in GROUP_LEVELS.items():
        _require(bool(meta[name].isin(levels).all()), f"unsupported or missing category in {name}")
    # A genuine positive raw value of one is not a fallback. The supplied raw
    # provenance category is the only source of fallback membership.
    fallback = meta["scale_state"].to_numpy() == "fallback"
    _require(bool((scale[fallback] == 1).all()), "fallback scale must equal one")
    _require(isinstance(predictions_by_split, Mapping), "predictions must be a mapping")
    _require(set(predictions_by_split) == set(SPLITS), "six prespecified splits are required")
    pred = {}
    for split in SPLITS:
        supplied = predictions_by_split[split]
        _require(isinstance(supplied, Mapping) and set(supplied) == set(MODELS), "five prespecified models are required")
        pred[split] = {}
        for model in MODELS:
            value = np.asarray(supplied[model], dtype=float)
            _require(value.ndim == 1 and value.shape == (972,), "prediction must be a 972-row vector")
            _require(bool(np.isfinite(value).all() and (value >= 0).all()), "predictions must be finite and nonnegative")
            pred[split][model] = value.reshape(81, 12)
    return y, scale[:, 0], meta, pred


def _loss_arrays(y, pred):
    weights = np.power(0.5, np.arange(1, 13, dtype=float))
    result = {}
    for split in SPLITS:
        result[split] = {}
        for model in MODELS:
            p = pred[split][model]
            signed = weights[None, :] * (p - y) / (np.abs(p) + np.abs(y) + EPSILON)
            over = np.maximum(signed, 0.0).sum(axis=1)
            under = np.maximum(-signed, 0.0).sum(axis=1)
            result[split][model] = {
                "loss": over + under,
                "over": over,
                "under": under,
            }
    return result


def _group_metrics(losses, mask, population):
    n = int(mask.sum())
    by_split = {}
    for split in SPLITS:
        baseline = losses[split]["B0"]["loss"][mask]
        by_split[split] = {}
        for model in MODELS:
            values = losses[split][model]
            group_loss = float(values["loss"][mask].mean())
            over = float(values["over"][mask].mean())
            under = float(values["under"][mask].mean())
            paired = float(100.0 * np.mean(baseline - values["loss"][mask]))
            by_split[split][model] = {
                "mean_official_weighted_loss": group_loss,
                "mean_score": float(100.0 * (1.0 - group_loss)),
                "overprediction_weighted_loss": over,
                "underprediction_weighted_loss": under,
                "signed_weighted_error": float(over - under),
                "overprediction_share_of_loss": float(over / group_loss) if group_loss > 0 else None,
                "loss_contribution_to_population": float(group_loss * n / population),
                "within_group_score_delta_vs_B0": paired,
                "net_score_delta_contribution_vs_B0": float(paired * n / population),
            }
    mean = {}
    for model in MODELS:
        mean[model] = {}
        for key in by_split["fixed"][model]:
            finite = [by_split[split][model][key] for split in SPLITS if by_split[split][model][key] is not None]
            mean[model][key] = float(np.mean(finite)) if finite else None
    return {"by_split": by_split, "arithmetic_mean_across_six_splits": mean}


def _partition(name, labels, levels, losses, persistent=None):
    population = len(labels)
    masks = [(level, np.asarray(labels) == level) for level in levels]
    # Empty categories are part of the declared partition. Suppressing the
    # whole dimension avoids publishing rare/empty counts by subtraction.
    private = any(int(mask.sum()) < MIN_GROUP_SIZE or population - int(mask.sum()) < MIN_GROUP_SIZE for _, mask in masks)
    if private:
        return {
            "dimension": name,
            "status": "SUPPRESSED",
            "reason": "at least one declared group or its complement is smaller than five",
        }
    cross_safe = persistent is not None and all(
        int((mask & persistent).sum()) >= MIN_GROUP_SIZE
        and int((mask & ~persistent).sum()) >= MIN_GROUP_SIZE
        for _, mask in masks
    )
    rows = []
    for level, mask in masks:
        row = {"group": level, "well_count": int(mask.sum()), **_group_metrics(losses, mask, population)}
        if cross_safe:
            count = int((mask & persistent).sum())
            row["persistent_hard_well_count"] = count
            row["persistent_hard_fraction_within_group"] = float(count / mask.sum())
        rows.append(row)
    return {
        "dimension": name,
        "status": "AVAILABLE",
        "groups": rows,
        "persistent_hard_cross_tab_status": "AVAILABLE" if cross_safe else "SUPPRESSED",
        "persistent_hard_cross_tab_note": (
            "all cross-tab cells have at least five wells" if cross_safe else
            "all persistent-hard counts and fractions for this dimension are suppressed because a cross-tab cell is smaller than five"
        ),
    }


def _rank_correlations(losses):
    matrices = {}
    values = np.full((len(SPLITS), len(MODELS), len(MODELS)), np.nan)
    for si, split in enumerate(SPLITS):
        ranked = {model: rankdata(losses[split][model]["loss"], method="average") for model in MODELS}
        for mi, first in enumerate(MODELS):
            for mj, second in enumerate(MODELS):
                if np.ptp(ranked[first]) > 0 and np.ptp(ranked[second]) > 0:
                    values[si, mi, mj] = float(np.corrcoef(ranked[first], ranked[second])[0, 1])
        matrices[split] = [[_finite_or_none(v) for v in row] for row in values[si]]
    mean = []
    counts = []
    for mi in range(len(MODELS)):
        mean.append([])
        counts.append([])
        for mj in range(len(MODELS)):
            valid = values[:, mi, mj][np.isfinite(values[:, mi, mj])]
            mean[mi].append(float(valid.mean()) if valid.size else None)
            counts[mi].append(int(valid.size))
    return {
        "method": "Spearman correlation of per-well official weighted losses; tied ranks averaged",
        "model_order": list(MODELS),
        "matrix_by_split": matrices,
        "arithmetic_mean_matrix": mean,
        "defined_split_count_matrix": counts,
        "undefined_policy": "null for a constant loss vector; mean uses only defined split correlations",
        "interpretation": "correlated errors indicate shared hard cases, not a causal mechanism",
    }


def _bootstrap(losses):
    n = len(losses["fixed"]["B0"]["loss"])
    draw = np.random.default_rng(BOOTSTRAP_SEED).integers(0, n, size=(BOOTSTRAP_DRAWS, n))
    candidates = {}
    for model in MODELS[1:]:
        delta = 100.0 * (losses["fixed"]["B0"]["loss"] - losses["fixed"][model]["loss"])
        means = delta[draw].mean(axis=1)
        limits = np.quantile(means, [0.025, 0.975], method="linear")
        candidates[model] = {
            "point_score_delta_vs_B0": float(delta.mean()),
            "percentile_2_5": float(limits[0]),
            "percentile_97_5": float(limits[1]),
        }
    return {
        "split": "fixed",
        "method": "paired well-level percentile bootstrap of existing fixed OOF losses",
        "resamples": BOOTSTRAP_DRAWS,
        "seed": BOOTSTRAP_SEED,
        "same_draws_used_for_all_candidates": True,
        "model_fits": 0,
        "preprocessing_fits": 0,
        "candidates": candidates,
        "limitations": [
            "descriptive interval only; excludes model-training and fold-construction uncertainty",
            "overlapping training folds induce dependence not modeled by this conditional bootstrap",
            "the same 81 wells are reused; neither the bootstrap nor repeat splits are independent new-data evidence",
            "not adjusted for comparing multiple candidates and not a model-retention or significance test",
        ],
    }


def analyze(panel, predictions_by_split, metadata):
    """Return anonymous JSON-safe aggregate diagnostics without any fitting.

    ``panel`` must have 81 contiguous well blocks, each ordered horizon 1..12.
    ``predictions_by_split`` contains all six SPLITS and all five MODELS, with
    one flat 972-row nonnegative prediction vector for every pair. ``metadata``
    has one row per well and the fixed categorical GROUP_LEVELS columns.
    Its numeric production_level is deliberately not grouped here: fold-only
    thresholds belong in the runner's existing independent aggregation path.
    """
    y, scale, meta, pred = _validate(panel, predictions_by_split, metadata)
    losses = _loss_arrays(y, pred)
    n = len(y)
    top_count = math.ceil(0.25 * n)
    frequency = np.zeros(n, dtype=int)
    for split in SPLITS:
        # No identifier is used for tie-breaking; source row order is fixed.
        top = np.argsort(-losses[split]["B0"]["loss"], kind="stable")[:top_count]
        frequency[top] += 1
    persistent = frequency >= 4
    persistent_partition = _partition(
        "persistent_B0_hard_cases", np.where(persistent, "persistent_hard", "other"),
        ("persistent_hard", "other"), losses,
    )
    persistent_partition.update({
        "selection": "B0 per-split largest ceil(0.25*N) well losses; present in at least four of six splits",
        "per_split_top_count": int(top_count),
        "minimum_split_frequency": 4,
        "tie_policy": "stable original well order at the top-quartile boundary",
        "diagnostic_only": True,
    })
    if persistent_partition["status"] == "AVAILABLE":
        persistent_partition["persistent_hard_well_count"] = int(persistent.sum())
    dimensions = [
        _partition(name, meta[name].to_numpy(), levels, losses, persistent)
        for name, levels in GROUP_LEVELS.items()
    ]
    fallback = meta["scale_state"].to_numpy() == "fallback"
    transition = np.full(n, "fallback", dtype=object)
    ratio = np.divide(y[:, 0], scale)
    positive = ~fallback
    transition[positive & (ratio < 0.5)] = "below_0.5"
    transition[positive & (ratio >= 0.5) & (ratio <= 2.0)] = "0.5_to_2"
    transition[positive & (ratio > 2.0)] = "above_2"
    posthoc = _partition(
        "posthoc_first_target_month_to_last_legal_positive_scale",
        transition, ("fallback", "below_0.5", "0.5_to_2", "above_2"), losses, persistent,
    )
    posthoc.update({
        "diagnostic_only": True,
        "uses_outcome_after_prediction": True,
        "may_be_used_as_model_input_or_routing": False,
        "definition": "first target-month true RCYL divided by original last legal positive RCYL; raw fallback provenance is a separate group",
        "fallback_source": "metadata.scale_state, never scale == 1",
        "positive_boundary_inclusion": "below 0.5; inclusive 0.5 to 2; above 2",
    })
    result = {
        "schema": "a2b035_common_errors_v1",
        "model_fits": 0,
        "preprocessing_fits": 0,
        "well_count": n,
        "row_count": int(y.size),
        "split_order": list(SPLITS),
        "model_order": list(MODELS),
        "official_loss": {
            "epsilon": EPSILON,
            "weights": "2**(-horizon), horizon 1..12, unnormalized",
            "formula": "sum_t weight_t * abs(pred-truth)/(abs(pred)+abs(truth)+epsilon); mean equally over wells; score=100*(1-loss)",
            "net_score_contribution": "group well fraction times paired within-group score delta against B0",
        },
        "privacy": {
            "minimum_group_and_complement_size": MIN_GROUP_SIZE,
            "all_declared_group_levels_checked_including_empty": True,
            "whole_dimension_suppression": True,
            "cross_tab_suppression": "all persistent-hard counts/fractions within a dimension suppressed if any group-by-hard-status cell is smaller than five",
            "persisted_well_identifiers_or_per_well_arrays": False,
        },
        "overall": _group_metrics(losses, np.ones(n, dtype=bool), n),
        "loss_rank_correlations": _rank_correlations(losses),
        "persistent_hard_cases": persistent_partition,
        "predefined_metadata_dimensions": dimensions,
        "posthoc_target_transition": posthoc,
        "fixed_oof_paired_bootstrap": _bootstrap(losses),
        "excluded_dimension": {
            "name": "production_level",
            "reason": "raw numeric field; this module must not create full-cohort quantile thresholds; training-fold-only groups remain the runner's responsibility",
        },
        "limitations": [
            "all group comparisons are descriptive posthoc error diagnostics, not proof of causal feature effects",
            "groups from different dimensions overlap and their score contributions must not be added",
            "persistent hard cases are selected using B0 outcomes; this selection favors apparent regression toward the mean for other models",
            "no label-based group may be used as a future input, gating variable, or model-routing rule",
            "six splits reuse the same wells and are not six independent datasets",
            "mean summaries average fixed plus five repeated splits, explicitly labeled; they are not the five-repeat selection metric",
        ],
    }
    # Fails closed if future modifications introduce NumPy scalars or NaN/Inf.
    json.dumps(result, ensure_ascii=False, allow_nan=False)
    return result


def run_synthetic():
    """Pure synthetic invariance/privacy checks; performs no fit and no I/O."""
    n = 81
    ids = np.array([f"SYNTHETIC_{i:03d}" for i in range(n)])
    y = np.ones((n, 12), dtype=float)
    scale = np.ones(n)
    panel = pd.DataFrame({
        "WELL_ID": np.repeat(ids, 12), "horizon": np.tile(np.arange(1, 13), n),
        "RCYL": y.ravel(), "__scale035": np.repeat(scale, 12),
    })
    meta = pd.DataFrame({"WELL_ID": ids})
    for field, levels in GROUP_LEVELS.items():
        meta[field] = [levels[i % len(levels)] for i in range(n)]
    meta["production_level"] = np.arange(n, dtype=float)
    base = 1.0 + np.arange(1, n + 1, dtype=float)[:, None] / n
    p = np.repeat(base, 12, axis=1).ravel()
    predictions = {
        split: {model: p.copy() for model in MODELS}
        for split in SPLITS
    }
    predictions["fixed"]["T1"] = y.ravel().copy()
    result = analyze(panel, predictions, meta)
    checks = []

    def check(name, condition):
        assert bool(condition), name
        checks.append({"check": name, "passed": True})

    weights = np.power(0.5, np.arange(1, 13, dtype=float))
    expected = (weights[None, :] * abs(p.reshape(n, 12) - y) / (p.reshape(n, 12) + y + EPSILON)).sum(axis=1).mean()
    check("official_formula_and_unnormalized_weights", np.isclose(result["overall"]["by_split"]["fixed"]["B0"]["mean_official_weighted_loss"], expected, rtol=0, atol=1e-15))
    check("identity_predictions_have_zero_paired_delta", result["fixed_oof_paired_bootstrap"]["candidates"]["E0"]["point_score_delta_vs_B0"] == 0)
    check("identity_bootstrap_interval_is_zero", result["fixed_oof_paired_bootstrap"]["candidates"]["E0"]["percentile_2_5"] == result["fixed_oof_paired_bootstrap"]["candidates"]["E0"]["percentile_97_5"] == 0)
    check("perfect_candidate_has_positive_delta", result["fixed_oof_paired_bootstrap"]["candidates"]["T1"]["point_score_delta_vs_B0"] > 0)
    check("constant_loss_rank_is_explicitly_undefined", result["loss_rank_correlations"]["matrix_by_split"]["fixed"][3][3] is None)
    check("persistent_hard_top_quartile_count", result["persistent_hard_cases"]["persistent_hard_well_count"] == 21)
    check("json_contains_no_synthetic_identifiers", "SYNTHETIC_" not in json.dumps(result))
    check("no_nonfinite_json", isinstance(json.dumps(result, allow_nan=False), str))
    check("no_fitting", result["model_fits"] == result["preprocessing_fits"] == 0)

    # Construct a fully publishable four-way target-transition partition.
    transition_panel = panel.copy()
    transition_meta = meta.copy()
    transition_meta["scale_state"] = "positive"
    transition_meta.loc[:19, "scale_state"] = "fallback"
    transition_y = y.copy()
    transition_y[20:40, 0] = 0.25
    transition_y[40:60, 0] = 1.0
    transition_y[60:, 0] = 3.0
    transition_panel["RCYL"] = transition_y.ravel()
    transition_result = analyze(transition_panel, predictions, transition_meta)
    transition_rows = transition_result["posthoc_target_transition"]["groups"]
    counts = {row["group"]: row["well_count"] for row in transition_rows}
    check("positive_raw_one_is_not_fallback", counts == {"fallback": 20, "below_0.5": 20, "0.5_to_2": 20, "above_2": 21})
    contributions = [row["by_split"]["fixed"]["T1"]["net_score_delta_contribution_vs_B0"] for row in transition_rows]
    total = transition_result["overall"]["by_split"]["fixed"]["T1"]["within_group_score_delta_vs_B0"]
    check("partition_contributions_sum_to_total", np.isclose(sum(contributions), total, atol=1e-12, rtol=0))

    rare_meta = meta.copy()
    rare_meta["BX_state"] = "within_0_100"
    rare_meta.loc[:3, "BX_state"] = "missing"
    rare_result = analyze(panel, predictions, rare_meta)
    rare_dimension = next(x for x in rare_result["predefined_metadata_dimensions"] if x["dimension"] == "BX_state")
    check("rare_or_empty_group_suppresses_entire_dimension", rare_dimension["status"] == "SUPPRESSED" and "groups" not in rare_dimension)

    def rejected(call):
        try:
            call()
        except ValueError:
            return True
        return False

    bad_panel = panel.copy()
    bad_panel.loc[0, "horizon"] = 2
    check("target_horizon_misalignment_rejected", rejected(lambda: analyze(bad_panel, predictions, meta)))
    bad_predictions = {split: {model: a.copy() for model, a in record.items()} for split, record in predictions.items()}
    bad_predictions["fixed"]["E0"][0] = np.nan
    check("nonfinite_prediction_rejected", rejected(lambda: analyze(panel, bad_predictions, meta)))
    shuffled = meta.sample(frac=1, random_state=7)
    shuffled_result = analyze(panel, predictions, shuffled)
    check("metadata_row_order_is_aligned_by_identity_in_memory", shuffled_result == result)
    return {"passed": True, "check_count": len(checks), "model_fits": 0, "preprocessing_fits": 0, "checks": checks}
