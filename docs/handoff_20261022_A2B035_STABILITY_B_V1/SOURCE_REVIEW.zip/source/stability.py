"""Finite prespecified capacity, production-state and temporal hypotheses."""
from light_dual import b,np,pd,TEMPORAL,sequence_values,expand_time
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from models035 import estimator_for

STATE_NAMES=['op_last','op_mean3','op_mean6','op_last_minus_previous3','op_zero_share6','op_slope6',
 'oil_liquid_last','oil_liquid_median3','oil_liquid_median6','oil_liquid_valid_count6',
 'oil_log_short_long_median_gap','oil_log_last_minus_median6','oil_log_adjacent_abs_median6','oil_log_slope6','oil_zero_share6','oil_valid_count6',
 'liquid_log_short_long_median_gap','liquid_log_slope6','liquid_valid_count6','op_valid_count6','oil_liquid_log_slope_difference6']
STATE=['state__'+n for n in STATE_NAMES]
ARMS=('B0','E0','E1','T1');CANDIDATES=('E0','E1','T1','F75')
CONFIRM_SEED=20261022

def small_tree():
    return ExtraTreesRegressor(n_estimators=200,max_depth=8,min_samples_leaf=6,max_features=.75,random_state=20260916,n_jobs=-1)
def temporal_model():return Ridge(alpha=1000.,fit_intercept=True,solver='svd')
def spec():
    return {'B0':'original frozen325 ExtraTrees400; contemporaneous paired OOF reference',
     'E0':{'purpose':'compact capacity control and eligible candidate','features':325,'model':small_tree().get_params()},
     'E1':{'purpose':'production-state representation, same estimator as E0','features':346,'new_features':STATE,'model':small_tree().get_params()},
     'T1':{'purpose':'stronger temporal shrinkage; only alpha changes100 to1000 from previous temporal-only branch','features':195,'model':temporal_model().get_params()},
     'F75':{'purpose':'fixed global complementarity, no per-well routing','members':['B0','T1'],'weights':[.75,.25],'space':'raw RCYL after individual inverse transforms','weight_selection':'none'},
     'cutoff':'M-1','target_window':'M+1..M+12','target':'log1p(RCYL/s); raw last legal RCYL finite>0 else1; no scale change',
     'state_scope':'6 calendar months up to cutoff; raw zeros valid; no RCYL/operating-fraction target correction; oil/liquid is an empirical ratio, not certified volumetric water cut',
     'minimum_valid':'3-month statistics require2;6-month statistics require4;slope requires3;latest requires actual latest; differences require both sides',
     'no_weights_calibration_geology_or_first_plan':True}

def state_values(frame,cutoff):
    periods=pd.to_datetime(frame.NY,errors='raise').dt.to_period('M')
    selected=(periods>=cutoff-5)&(periods<=cutoff)
    f=frame.loc[selected,['RCYL','RCYL1','SCTS']].copy();f['__p']=periods.loc[selected]
    b.require(not f.__p.duplicated().any(),'STATE_DUPLICATE_MONTH');f=f.set_index('__p')
    months=[cutoff-i for i in range(5,-1,-1)]
    def col(name):
        a=[]
        for m in months:
            v=pd.to_numeric(pd.Series([f.loc[m,name]]),errors='coerce').iloc[0] if m in f.index else np.nan
            a.append(float(v) if np.isfinite(v) else np.nan)
        return np.asarray(a,float)
    oil,liquid,days=col('RCYL'),col('RCYL1'),col('SCTS')
    b.require((oil[np.isfinite(oil)]>=0).all() and (liquid[np.isfinite(liquid)]>=0).all(),'NEGATIVE_STATE_PRODUCTION')
    calendar_days=np.asarray([m.days_in_month for m in months],float)
    good=np.isfinite(days);b.require(((days[good]>=0)&(days[good]<=calendar_days[good])).all(),'INVALID_STATE_DAYS')
    op=days/calendar_days;ratio=np.full(6,np.nan);valid=np.isfinite(oil)&np.isfinite(liquid)&(liquid>0)
    ratio[valid]=oil[valid]/liquid[valid]
    # Do not clip ratios or redefine the physical target from an assumed unit.
    lo,ll=np.log1p(oil),np.log1p(liquid)
    def stat(x,method='mean',minimum=4):
        x=np.asarray(x,float);x=x[np.isfinite(x)]
        return float(getattr(np,method)(x)) if len(x)>=minimum else np.nan
    def slope(x):
        x=np.asarray(x,float);ok=np.isfinite(x)
        return float(np.polyfit(np.arange(len(x))[ok],x[ok],1)[0]) if ok.sum()>=3 else np.nan
    def zeros(x):
        x=x[np.isfinite(x)];return float(np.mean(x==0)) if len(x)>=4 else np.nan
    def shift(x):return stat(x[-3:],'median',2)-stat(x[:3],'median',2)
    v=[op[-1],stat(op[-3:],minimum=2),stat(op),op[-1]-stat(op[-4:-1],minimum=2),zeros(days),slope(op),
       ratio[-1],stat(ratio[-3:],'median',2),stat(ratio,'median'),float(np.isfinite(ratio).sum()),
       shift(lo),lo[-1]-stat(lo,'median'),stat(np.abs(np.diff(lo)),'median',3),slope(lo),zeros(oil),float(np.isfinite(oil).sum()),
       shift(ll),slope(ll),float(np.isfinite(liquid).sum()),float(np.isfinite(op).sum()),slope(lo)-slope(ll)]
    return dict(zip(STATE,v))

def build(history,policy,legacy):
    import light_dual as ld
    control,unused_fresh,timeframe,af,unused_features,metadata,timeaudit=ld.build(history,policy,legacy)
    state=control.copy();blocks=[];comparisons=0;rate={'eligible_positive_pairs':0,'matches_onstream_within2pct':0,'matches_calendar_within2pct':0,'matches_both':0,'matches_neither':0}
    for wid,g in control.groupby('WELL_ID',sort=False):
        t0=pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1
        legal,cutoff=b.legal_history(history,wid,t0,'M_minus_1',legacy)
        values=state_values(legal,cutoff)
        local=history.loc[history.WELL_ID==wid].copy();local[['RCYL','RCYL1','SCTS']]=local[['RCYL','RCYL1','SCTS']].astype(object)
        p=pd.to_datetime(local.NY).dt.to_period('M');local.loc[p>cutoff,['RCYL','RCYL1','SCTS']]='FORBIDDEN_DYNAMIC_SENTINEL'
        again=state_values(local,cutoff)
        b.require(all(b.safe._same_feature_value(values[k],again[k]) for k in values),'STATE_FUTURE_SENSITIVE');comparisons+=len(values)
        blocks.extend([values]*len(g))
        # Rate-basis check is descriptive only. It never changes features/labels.
        q=pd.to_numeric(legal.RCYL,errors='coerce').to_numpy(float);d=pd.to_numeric(legal.SCTS,errors='coerce').to_numpy(float)
        m=pd.to_numeric(legal.YCYL,errors='coerce').to_numpy(float);cal=pd.to_datetime(legal.NY).dt.days_in_month.to_numpy(float)
        ok=np.isfinite(q)&np.isfinite(d)&np.isfinite(m)&(q>0)&(m>0)&(d>0)
        a=np.abs(q[ok]*d[ok]-m[ok])<=np.maximum(.5,.02*np.abs(m[ok]))
        z=np.abs(q[ok]*cal[ok]-m[ok])<=np.maximum(.5,.02*np.abs(m[ok]))
        rate['eligible_positive_pairs']+=int(ok.sum());rate['matches_onstream_within2pct']+=int(a.sum());rate['matches_calendar_within2pct']+=int(z.sum());rate['matches_both']+=int((a&z).sum());rate['matches_neither']+=int((~a&~z).sum())
    state=pd.concat([state,pd.DataFrame(blocks,index=state.index,columns=STATE)],axis=1)
    b.require(state[control.columns].equals(control) and len(af+STATE)==346,'ORIGINAL_325_CHANGED')
    audit={**timeaudit,'state_future_mutation_checks':comparisons,'state_features':21,'rate_basis_diagnostic':rate,'rate_basis_claim':'agreement counts only, not official unit confirmation; no RCYL correction performed','state_missing_counts':{k:int(state.loc[~state.WELL_ID.duplicated(),k].isna().sum()) for k in STATE}}
    return control,state,timeframe,af,af+STATE,metadata,audit

def fit(name,control,state,timeframe,af,sf,legacy,ledger,stage):
    c=b.load_variant(b.HERE/'configs/B0.json');y=b.transform_target(control,c)
    if name=='T1':
        x=timeframe[TEMPORAL];prep=Pipeline([('imputer',SimpleImputer(strategy='median',keep_empty_features=True)),('scale',StandardScaler())]);model=temporal_model();features=TEMPORAL
    else:
        features=sf if name=='E1' else af;x=(state if name=='E1' else control)[features];prep=b.training._preprocessor(x)
        model=estimator_for(c,x,legacy) if name=='B0' else small_tree()
    xx=ledger.run('preprocessor',stage,lambda:prep.fit_transform(x,y));ledger.run('model',stage,lambda:model.fit(xx,y))
    return {'name':name,'features':features,'preprocessor':prep,'model':model}

def predict(artifact,control,state,timeframe):
    name=artifact['name'];x=timeframe if name=='T1' else state if name=='E1' else control
    with b.joblib.parallel_backend('sequential'):z=artifact['model'].predict(artifact['preprocessor'].transform(x[artifact['features']]))
    return b.inverse_target(z,control)

def synthetic():
    from models035 import forbid_fits
    from synthetic_dual import run
    prior=run();tests=[];cut=pd.Period('2001-12','M')
    f=pd.DataFrame({'NY':[str(cut-i) for i in range(5,-1,-1)],'RCYL':[0.,1.,2.,3.,4.,5.],'RCYL1':[2.,2.,4.,6.,8.,10.],'SCTS':[0.,10.,10.,10.,10.,10.]})
    with forbid_fits(extra_classes=(Ridge,)):
        v=state_values(f,cut);assert len(v)==21 and list(v)==STATE;tests.append('exact21state columns')
        assert v['state__oil_liquid_last']==.5 and v['state__oil_zero_share6']==1/6;tests.append('zero valid and oil-liquid ratio unchanged')
        assert v['state__op_last']==10/31;tests.append('calendar operating fraction')
        future=f.iloc[[-1]].copy();future.NY=str(cut+1);future[['RCYL','RCYL1','SCTS']]='UNREADABLE'
        z=state_values(pd.concat([f,future]),cut);assert all(b.safe._same_feature_value(v[k],z[k]) for k in v);tests.append('future dynamic invalid strings excluded')
        z=state_values(f.iloc[::-1],cut);assert all(b.safe._same_feature_value(v[k],z[k]) for k in v);tests.append('order invariant calendar features')
        z=state_values(f.iloc[[-1]],cut);assert np.isnan(z['state__oil_log_slope6']) and np.isnan(z['state__op_mean3']);tests.append('insufficient histories remain missing')
        zero=f.copy();zero.RCYL1=0.;z=state_values(zero,cut);assert np.isnan(z['state__oil_liquid_last']) and z['state__oil_liquid_valid_count6']==0;tests.append('zero liquid no division')
        assert small_tree().get_params()['max_depth']==8 and temporal_model().alpha==1000.;tests.append('candidate factory fixed without fitting')
    return {'tests':prior['tests']+tests,'passed':prior['passed']+len(tests),'model_fits':0,'preprocessor_fits':0}
