"""Training-only, zero-fit explanation of the prelocked LJCYL exclusion."""
from pathlib import Path
import sys,argparse,json
TASK=Path(__file__).resolve().parent;sys.path.insert(0,str(TASK/'source'));import routes15 as r
def main(a):
    policy,legacy=r.old.load_locked_policy(a.policy);store=r.old.Inputs(a.data_dir)
    try:history=r.old.load_train(store,legacy)
    finally:store.close()
    p=r.Provider(history,policy,legacy).get(r.route('B0_U',r.b0()))[0];static_legal=0;static_whole=0;current_pairs=0;previous_pairs=0;comparable=0;bins={'none':0,'below_half':0,'half_to_90pct':0,'90pct_to_below_all':0,'all':0}
    for wid,g in p.groupby('WELL_ID',sort=False):
        t0=r.pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1;q,end=r.old.legal_history(history,wid,t0,'M_minus_1',legacy);q=q.assign(period=r.pd.to_datetime(q.NY).dt.to_period('M')).sort_values('period');cum=r.pd.to_numeric(q.LJCYL,errors='coerce').to_numpy(float);yc=r.pd.to_numeric(q.YCYL,errors='coerce').to_numpy(float);period=q.period.tolist();clean=cum[r.np.isfinite(cum)];static_legal+=int(len(clean)>1 and r.np.ptp(clean)<=.05);allv=r.pd.to_numeric(history.loc[history.WELL_ID==wid,'LJCYL'],errors='coerce').to_numpy(float);allv=allv[r.np.isfinite(allv)];static_whole+=int(len(allv)>1 and r.np.ptp(allv)<=.05);n=0;hits=0
        for i in range(1,len(q)):
            if period[i]!=period[i-1]+1 or not r.np.isfinite([cum[i],cum[i-1],yc[i],yc[i-1]]).all():continue
            tol=.05+1e-6*max(abs(cum[i]),abs(cum[i-1]),abs(yc[i]));delta=cum[i]-cum[i-1];n+=1;hits+=int(abs(delta-yc[i])<=tol);current_pairs+=int(abs(delta-yc[i])<=tol);previous_pairs+=int(abs(delta-yc[i-1])<=tol);comparable+=1
        f=hits/n if n else 0;key='none' if f==0 else 'below_half' if f<.5 else 'half_to_90pct' if f<.9 else '90pct_to_below_all' if f<1 else 'all';bins[key]+=1
    out={'scope':'training-only supplementary zero-fit audit, not a new candidate or threshold change','wells':81,'official_dictionary_units':{'LJCYL':'t','YCYL':'t'},'source_dictionary':'FIELD_DICTIONARY.json @ c30d44f7a61bff9afe4e1e6820f69821636f6700','legal_history_static_cumulative_wells':static_legal,'whole_training_history_static_cumulative_wells':static_whole,'comparable_adjacent_pairs':comparable,'same_month_YCYL_delta_agreement_pairs':current_pairs,'previous_month_YCYL_delta_agreement_pairs':previous_pairs,'within_well_current_month_agreement_fraction_bins':bins,'LJCYL_remains_disabled':True,'candidate_retrained':False,'interpretation':'counts describe a source/definition mismatch; no claim of verified future provenance or universal feature uselessness; original strict prereg exclusion unchanged','test_data_read':False,'NCYL_used':False,'model_fits':0,'preprocessor_fits':0};Path(a.output).write_bytes(r.encode(out));print(json.dumps(out))
if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for name in ('data_dir','policy','output'):ap.add_argument('--'+name,required=True)
    main(ap.parse_args())
