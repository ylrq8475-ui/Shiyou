# A2B-035 R15 B0+W，待Codex复核，禁止上传

账户B执行与交付。模型沿用A2B-013 B0的原325字段、截止M−1和目标log1p(RCYL/s)，原始最后观测RCYL有限且正则作尺度否则1，不回找更早正值。ExtraTrees400/leaf6/max_features0.75/seed20260916。唯一训练差异是每个月行使用2^-t样本权重，t1..12，不归一化。无层位、方案、扩样、校准、融合或外部数据。原lag/rolling/trend不变。

Python3.13.7，21项精确版本见requirements.txt。使用该版本创建环境后，统一用显式解释器：
```
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe train.py --data_dir D:/official_data --output ./new_model
.venv\Scripts\python.exe predict.py --data_dir D:/official_data --model ./new_model/model.joblib --output ./result.zip
```
只加载随包模型时执行最后一行并省略--model（默认models/model.joblib）。--data_dir为官方原目录或赛事原ZIP；--output为新目录或新结果ZIP，不覆盖旧文件。无需改私有配置或人工交互。runtime_policy.json保留原字节，读取数据使用命令行路径。

source/base是原字节共用方法；source/routes15.py是加权模型路径；source/w_entry.py和根train.py/predict.py提供独立命令。数值/分类预处理只在训练井拟合；预测逐井且禁止fit。模板窗口内非键动态值不解码、不作特征。结果10个CSV共120行，WELL_ID/NY/RCYL三列，原模板键和日期文本继承，自动linter检查CRC、唯一性、非负有限与行数。模型权重、私有策略及结果ZIP不上传GitHub。当前新路径审核未完成，upload_eligible=false，不可把包已生成当作获准上传或模型升级。

## 配置接口补充

train.py和predict.py均接受--config variant.json，默认读取随包variant.json；仅允许本完整版本的冻结配置，其他内容评分前即拒绝。此补充仅加入参数验证，不改变模型、私有策略、算法核心或result.zip，拟合0次；旧代码包保留。
