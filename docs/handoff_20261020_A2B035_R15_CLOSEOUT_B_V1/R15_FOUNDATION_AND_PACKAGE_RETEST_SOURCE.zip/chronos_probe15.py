"""Chronos-2 actual offline synthetic admission; no competition data or fits."""
import os,sys,socket,json,hashlib,time,platform,importlib.metadata as im
from pathlib import Path
ROOT=Path(__file__).resolve().parent;D=ROOT/'chronos_admission'
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HOME':str(D/'hf_cache'),'TORCH_HOME':str(D/'torch_cache'),'DO_NOT_TRACK':'1'}.items():os.environ[k]=v
sys.dont_write_bytecode=True
attempts=[];connect=socket.socket.connect
def denied(sock,address):
    if sock.family in (socket.AF_INET,socket.AF_INET6):attempts.append('blocked');raise RuntimeError('CHRONOS_ADMISSION_NETWORK_FORBIDDEN')
    return connect(sock,address)
socket.socket.connect=denied
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(v):(D/'ACTUAL_ADMISSION_RESULT.json').write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    started=time.perf_counter();receipt=json.loads((D/'RESOURCE_RECEIPT.json').read_bytes());weight=D/'model/model.safetensors';expected=next(x['actual_sha256'] for x in receipt['files'] if x['path']=='model.safetensors');assert sha(weight)==expected
    env={'python':platform.python_version(),'build':list(platform.python_build()),'dependencies':dict(sorted({x.metadata['Name']:x.version for x in im.distributions()}.items()))}
    try:
        import numpy as np,torch
        from chronos import Chronos2Pipeline
        torch.set_num_threads(1);torch.manual_seed(20260916);torch.use_deterministic_algorithms(True)
        pipeline=Chronos2Pipeline.from_pretrained(str(D/'model'),device_map='cpu',torch_dtype=torch.float32,local_files_only=True)
        series=[np.linspace(1,3,24,dtype=np.float32),np.linspace(4,1,31,dtype=np.float32),np.ones(19,dtype=np.float32)]
        # Each underlying call receives a single legal history, cross-learning disabled.
        def rows(items):return [pipeline.predict([torch.as_tensor(x)],prediction_length=12,batch_size=1,cross_learning=False)[0].detach().cpu().numpy() for x in items]
        a=rows(series);b=[rows([x])[0] for x in series];rev=rows(series[::-1])[::-1];extra=rows(series+[np.full(25,10000,dtype=np.float32)])[:3]
        assert all(np.array_equal(x,y) and np.array_equal(x,z) and np.array_equal(x,w) and np.isfinite(x).all() for x,y,z,w in zip(a,b,rev,extra))
        # Admission adapter slices before predictor; poisoning later positions has no effect.
        raw=np.r_[series[0],np.full(12,-9999,dtype=np.float32)];poison=raw.copy();poison[24:]=1e20
        assert np.array_equal(rows([raw[:24]])[0],rows([poison[:24]])[0]);assert sha(weight)==expected and not attempts
        save({'status':'PASS','task':'R15 conditional Chronos-2 synthetic admission','resource':receipt,'environment':env,'model_fits':0,'preprocessor_fits':0,'competition_data_read':False,'local_weights_only':True,'Python_network_guard_active':True,'network_attempts':len(attempts),'actual_single_series_group_order_extra_exact':True,'cutoff_slice_future_poison_exact':True,'adapter':'one history series per call; CPU float32; batch_size1; cross_learning=False; horizon12; no fine-tuning','weights_unchanged':True,'elapsed_seconds':time.perf_counter()-started,'upload_eligible':False,'Codex_admission':'PENDING'})
        print(json.dumps({'status':'PASS','model_fits':0,'preprocessor_fits':0,'seconds':time.perf_counter()-started}))
    except Exception as exc:
        save({'status':'BLOCKED_OR_FAILED','type':type(exc).__name__,'message':str(exc),'environment':env,'resource':receipt,'model_fits':0,'preprocessor_fits':0,'competition_data_read':False,'network_attempts':len(attempts),'upload_eligible':False});raise
if __name__=='__main__':main()
