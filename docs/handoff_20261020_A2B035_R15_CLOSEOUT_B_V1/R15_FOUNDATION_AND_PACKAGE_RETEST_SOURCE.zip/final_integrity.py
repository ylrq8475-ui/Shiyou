from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parent
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    previous=json.loads((ROOT.parent/'A2B035_20261019_v1/private/PROTECTED_BEFORE.json').read_bytes());checks=[]
    if 'files' in previous:
        for row in previous['files']:checks.append(h(row.get('path',row.get('absolute_path')))==row['sha256'])
    else:
        for p,sha in previous.items():
            if isinstance(sha,str) and len(sha)==64:checks.append(h(p)==sha)
    assert checks and all(checks);lock=json.loads((ROOT/'RESEARCH_LOCK.json').read_bytes());assert all(h(ROOT/n)==v for n,v in lock['files'].items());private=ROOT.parent/'Shiyou_B_private_handoff_20261009_v1/payload/project';expected={'frozen_private_config':('configs/private_data_inferred_v7_safe_plus_layer.yaml','89e60c301b1d553b1c7dab8e2f87d1d9a47b600abe4322f2e9895717201c0c72'),'raw_manifest':('private_logs/raw_manifest_20260916.json','efd81b2fa8226f3a610fefb272f20f6a1adb61a98d02ff6885732b7a1312266f')};assert all(h(private/p)==sha for p,sha in expected.values());v={'old_protected_files':len(checks),'old_protected_files_unchanged':True,'locked_research_files':len(lock['files']),'research_lock_files_original_bytes_unchanged':True,'private_config_and_raw_manifest_unchanged':True,'primary_environment_not_modified':True,'old_models_and_ZIPs_not_overwritten':True,'row_OOF_persisted':False,'platform_uploads':0};(ROOT/'execution/FINAL_PRESERVATION.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v))
if __name__=='__main__':main()
