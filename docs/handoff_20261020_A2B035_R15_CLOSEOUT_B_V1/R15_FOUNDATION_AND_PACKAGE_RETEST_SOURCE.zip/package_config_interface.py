"""Zero-fit CLI interface addition; retain existing models, results and ZIPs."""
from pathlib import Path
import sys,json,shutil,zipfile,subprocess,hashlib
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'source'));import routes15 as r
DATA=Path(__import__("os").environ["SHIYOU_AUTHORIZED_DATA_ARCHIVE"])
GUARD='''import sys,json
from pathlib import Path
def prepare():
    root=Path(__file__).resolve().parent;arg=root/'variant.json'
    for i,v in enumerate(list(sys.argv)):
        if v=='--config':arg=Path(sys.argv[i+1]);del sys.argv[i:i+2];break
        if v.startswith('--config='):arg=Path(v.split('=',1)[1]);del sys.argv[i];break
    expected=json.loads((root/'variant.json').read_bytes());assert json.loads(arg.read_bytes())==expected,'FROZEN_VERSION_CONFIG_MISMATCH'
'''
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    rows=[]
    for name,source,target,module,config in [('B0','B0_REPACK_PRIVATE_v2','B0_REPACK_PRIVATE_v3','b0_entry',r.b0()),('B0_W','W_CANDIDATE_PRIVATE','W_CANDIDATE_PRIVATE_v2','w_entry',r.route('B0_W',r.b0(),True))]:
        old=ROOT/source;dest=ROOT/target;assert not dest.exists();dest.mkdir();p=dest/'package';shutil.copytree(old/'package',p);shutil.copyfile(old/'result.zip',dest/'result.zip');oldmodel=h(old/'package/models/model.joblib');assert h(p/'models/model.joblib')==oldmodel
        (p/'variant.json').write_bytes(r.encode(config));(p/'config_interface.py').write_text(GUARD,encoding='utf-8',newline='\n')
        for op in ('train','predict'):(p/(op+'.py')).write_text('from config_interface import prepare\nfrom source.'+module+' import main\nif __name__=="__main__":\n    prepare()\n    main('+repr(op)+')\n',encoding='utf-8',newline='\n')
        with (p/'README.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\n## 配置接口补充\n\ntrain.py和predict.py均接受--config variant.json，默认读取随包variant.json；仅允许本完整版本的冻结配置，其他内容评分前即拒绝。此补充仅加入参数验证，不改变模型、私有策略、算法核心或result.zip，拟合0次；旧代码包保留。\n')
        code=dest/'submission_code.zip';members=[]
        with zipfile.ZipFile(code,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for file in sorted(p.rglob('*')):
                if not file.is_file() or '__pycache__' in file.parts:continue
                rel=file.relative_to(p).as_posix();i=zipfile.ZipInfo(rel,date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,file.read_bytes());members.append({'path':rel,'sha256':h(file),'bytes':file.stat().st_size})
        extracted=dest/'exact_ZIP_inference_check';extracted.mkdir()
        with zipfile.ZipFile(code) as z:assert z.testzip() is None;z.extractall(extracted)
        cli=[str(ROOT/'b0_clean_env/Scripts/python.exe'),'-B','predict.py','--config','variant.json','--data_dir',str(DATA),'--output',str(dest/'checked_result.zip')];proc=subprocess.run(cli,cwd=extracted,capture_output=True);(dest/'PRIVATE_STDERR.txt').write_bytes(proc.stderr);assert proc.returncode==0;assert (dest/'checked_result.zip').read_bytes()==(old/'result.zip').read_bytes();assert h(p/'models/model.joblib')==oldmodel and h(p/'runtime_policy.json')==h(old/'package/runtime_policy.json');unchanged=[f.relative_to(old/'package/source').as_posix() for f in (old/'package/source').rglob('*') if f.is_file() and '__pycache__' not in f.parts];assert all(h(old/'package/source'/rel)==h(p/'source'/rel) for rel in unchanged)
        # Invalid config rejects before the trainer receives an invocation.
        (extracted/'bad.json').write_text('{}',encoding='utf-8');bad=subprocess.run([str(ROOT/'b0_clean_env/Scripts/python.exe'),'-B','train.py','--config','bad.json','--data_dir',str(DATA),'--output',str(dest/'must_not_exist')],cwd=extracted,capture_output=True);assert bad.returncode!=0 and not (dest/'must_not_exist').exists()
        v={'version':name,'operation':'config interface only','model_fits':0,'preprocessor_fits':0,'models_result_private_policy_algorithm_sources_unchanged':True,'models_sha256':oldmodel,'result_zip_sha256':h(dest/'result.zip'),'submission_code_zip_sha256':h(code),'code_bytes':code.stat().st_size,'code_under5GB':code.stat().st_size<5_000_000_000,'members':members,'exact_ZIP_inference_result_bytes_equal':True,'invalid_config_rejects_before_train':True,'old_packages_retained':True,'upload_eligible':False};rows.append(v)
    (ROOT/'execution/CONFIG_INTERFACE_ZERO_FIT.json').write_bytes(r.encode({'versions':rows,'model_fits':0,'preprocessor_fits':0,'platform_uploaded':False}));print(json.dumps([{k:v[k] for k in ('version','model_fits','result_zip_sha256','submission_code_zip_sha256')} for v in rows]))
if __name__=='__main__':main()
