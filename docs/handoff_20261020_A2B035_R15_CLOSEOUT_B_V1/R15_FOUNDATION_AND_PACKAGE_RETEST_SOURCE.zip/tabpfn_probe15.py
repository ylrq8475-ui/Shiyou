"""Pinned TabPFN v2 admission only: synthetic data, local weights, no network."""
import os,sys,socket,json,hashlib,time,platform,importlib.metadata as im
from pathlib import Path
ROOT=Path(__file__).resolve().parent;D=ROOT/'tabpfn_admission'
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
for k,v in {'TABPFN_DISABLE_TELEMETRY':'1','TABPFN_STATE_DIR':str(D/'state'),'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HOME':str(D/'hf_cache'),'TORCH_HOME':str(D/'torch_cache'),'DO_NOT_TRACK':'1'}.items():os.environ[k]=v
sys.dont_write_bytecode=True
network_attempts=[];original_connect=socket.socket.connect
def denied(sock,address):
    if sock.family in (socket.AF_INET,socket.AF_INET6):network_attempts.append('blocked');raise RuntimeError('TABPFN_ADMISSION_NETWORK_FORBIDDEN')
    return original_connect(sock,address)
socket.socket.connect=denied
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(v):(D/'ACTUAL_ADMISSION_RESULT.json').write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    started=time.perf_counter();receipt=json.loads((D/'WEIGHT_RECEIPT.json').read_bytes());weight=D/'weights'/receipt['filename'];assert sha(weight)==receipt['actual_sha256'];environment={'python':platform.python_version(),'build':list(platform.python_build()),'dependencies':dict(sorted({x.metadata['Name']:x.version for x in im.distributions()}.items()))};fit_counts={'model_context_fit_entered':0,'model_context_fit_completed':0,'external_preprocessor_fit':0}
    try:
        import numpy as np,torch
        from tabpfn import TabPFNRegressor
        from sklearn.impute import SimpleImputer
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        torch.set_num_threads(1);torch.use_deterministic_algorithms(True);rng=np.random.default_rng(20260916);x=rng.normal(size=(24,3));x[::5,1]=np.nan;y=np.nan_to_num(x[:,0])*2+np.arange(24)/24;query=rng.normal(size=(3,3));prep=make_pipeline(SimpleImputer(strategy='median',add_indicator=True),StandardScaler());xx=prep.fit_transform(x);fit_counts['external_preprocessor_fit']=1
        model=TabPFNRegressor(model_path=weight,device='cpu',random_state=20260916);fit_counts['model_context_fit_entered']=1;model.fit(xx,y);fit_counts['model_context_fit_completed']=1
        # The admitted adapter deliberately never supplies multiple query rows.
        # Test grouping/order/unrelated queries through this actual per-row path.
        def rows(q):return np.asarray([float(model.predict(prep.transform(q[[i]]))[0]) for i in range(len(q))])
        a=rows(query);single=np.concatenate([rows(query[[i]]) for i in range(3)]);reverse=rows(query[::-1])[::-1];extended=rows(np.concatenate([query,query*100],axis=0))[:3];assert np.array_equal(a,single) and np.array_equal(a,reverse) and np.array_equal(a,extended);assert np.isfinite(a).all();assert sha(weight)==receipt['actual_sha256']
        save({'status':'PASS','task':'R15 TabPFN v2 actual admission probe','package_version':im.version('tabpfn'),'weight':receipt,'environment':environment,'fit_counts':fit_counts,'real_competition_data_read':False,'competition_model_fits':0,'weights_unchanged':True,'gradient_training_or_finetuning':False,'adapter':'TabPFNRegressor2.2.1 pinned v2 local model_path, CPU, seed20260916, defaultn_estimators8; every predict call one query row','actual_single_row_batch_reverse_and_extra_query_exact':True,'preprocessing_only_synthetic_training_rows':True,'network_connect_blocks':len(network_attempts),'Python_network_guard_active':True,'telemetry_disabled_before_import':True,'elapsed_seconds':time.perf_counter()-started,'upload_eligible':False,'Codex_admission':'PENDING','attribution_required':'Built with PriorLabs-TabPFN; include full license; distributed models derived from outputs must start with TabPFN if applicable'})
        print(json.dumps({'status':'PASS','fit_counts':fit_counts,'seconds':time.perf_counter()-started}))
    except Exception as exc:
        save({'status':'BLOCKED_OR_FAILED','type':type(exc).__name__,'message':str(exc),'environment':environment,'fit_counts':fit_counts,'competition_data_read':False,'network_connect_blocks':len(network_attempts),'weights_sha256':receipt['actual_sha256'],'stop_branch_until_evidence':True,'deadline':'2026-10-22T24:00:00+08:00'});raise
if __name__=='__main__':main()
