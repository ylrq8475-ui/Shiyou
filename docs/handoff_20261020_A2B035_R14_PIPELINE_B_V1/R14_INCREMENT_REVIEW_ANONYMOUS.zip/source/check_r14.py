"""Synthetic boundary and fit-routing checks; all fit calls are recording spies."""
from r14 import *
from error_budget import budget,group_labels,pairs
from unittest.mock import patch
import argparse,ast

def main(a):
    policy,legacy=old.load_locked_policy(a.policy);checks=[]
    c={'schema':SCHEMA,'variant':'SYNTH_H','kind':'H','cutoff':'T0_minus_1','target':{'transform':'log_ratio','scale':'calendar_T0_minus_2'},'features':'base325_M3_R','learner':original_b0prime()['learner'],'evaluation':original_b0prime()['evaluation']};validate(c)
    def passed(name,cases=1):checks.append({'name':name,'cases':cases,'PASS':True})
    cols=list(dict.fromkeys(['WELL_ID','NY',legacy['anchors']['event_column'],*legacy['features']['history_numeric_columns'],*legacy['features'].get('history_categorical_columns',[]),'RCYL','RCYL1','SCTS','CCJHWND']))
    months=pd.period_range('1980-01',periods=30,freq='M');t0=months[18];frames={};keys=[]
    for i,name in enumerate(legacy['data']['sources']['test']['history']):
        f=pd.DataFrame({col:np.arange(30,dtype=float)+2+i for col in cols});f['WELL_ID']='SYNTH_'+str(i);f['NY']=[str(p.to_timestamp().date()) for p in months];ec=legacy['anchors']['event_column'];f[ec]='SYNTH_NONE';f.loc[16:17,ec]=legacy['anchors']['eligible_event_values'][0];f['RCYL1']=2*f.RCYL;f['SCTS']=20.;frames[name]=f;keys+=list(f.iloc[18:][['WELL_ID','NY']].itertuples(index=False,name=None))
    p=copy.deepcopy(policy);p['template_key_sha256']=fingerprint(keys)
    class Store:
        def __init__(self,frames,poison=(),invalid=False):self.frames=frames;self.poison=poison;self.invalid=invalid
        def raw(self,name):
            f=self.frames[name].copy()
            for col in self.poison:f[col]=f[col].astype(object);f.loc[18:,col]='SYNTH_POISON'
            b=f.to_csv(index=False,lineterminator='\n').encode('utf-8-sig');return b.replace(b'SYNTH_POISON',b'\xff\xfe\xfd') if self.invalid else b
    panel,features,audit=test_panel(Store(frames),p,legacy,c);require(len(features)==333 and len(panel)==120,'SYNTH_H_SHAPE');passed('H exact333 feature order and120 template rows')
    dynamic=[col for col in cols if col not in ('WELL_ID','NY')]
    for col in dynamic:
        changed,ff,aa=test_panel(Store(frames,[col]),p,legacy,c);require(changed.equals(panel) and ff==features and aa['test_window_dynamic_values_decoded']==0,'H_WINDOW_POISON_CHANGED_FEATURES')
    changed,_,_=test_panel(Store(frames,dynamic,True),p,legacy,c);require(changed.equals(panel),'H_INVALID_WINDOW_BYTE_DECODED');passed('all dynamic window columns poisoned individually and invalid UTF8 together leave H unchanged',len(dynamic)+1)
    frame=next(iter(frames.values())).iloc[:18].copy();wid=frame.WELL_ID.iloc[0];v,scale,meta=additions(frame,wid,t0,legacy);require(scale==float(frame.RCYL.iloc[16]) and v['M_RCYL']==float(frame.RCYL.iloc[17]),'H_EXACT_CALENDAR');passed('H scale T0-2 differs from M raw feature T0-1')
    for raw in (0.,-1.,np.nan,np.inf,-np.inf,1.,6.):
        f=frame.copy();f.loc[16,'RCYL']=raw;v,s,_=additions(f,wid,t0,legacy);expected=old.training._target_scale(pd.DataFrame({'history__RCYL__last':[raw]}),'log_ratio_last')[0];require(s==expected,'H_FALLBACK_DIFFERS_FROM_B0');require(np.isfinite(v['M_RCYL_ratio'])==(np.isfinite(raw) and raw>0),'H_RATIO_DENOMINATOR')
    f=frame.drop(index=16);v,s,_=additions(f,wid,t0,legacy);require(s==1 and pd.isna(v['M_RCYL_ratio']),'H_MISSING_CALENDAR_USES_OTHER_MONTH');passed('fallback matches frozen training._target_scale incl missing calendar month',8)
    altered={k:v.copy() for k,v in frames.items()};first=next(iter(altered));altered[first].loc[:17,'RCYL']=1e8;other,_,_=test_panel(Store(altered),p,legacy,c);require(other.iloc[12:].equals(panel.iloc[12:]) and not other.iloc[:12].equals(panel.iloc[:12]),'H_CROSS_WELL');passed('H per-well legal prefix mutation affects only its well')
    for key in ('WELL_ID','NY'):
        changed={k:v.copy() for k,v in frames.items()};changed[first].loc[18,key]='SYNTH_CHANGED' if key=='WELL_ID' else '1995-01-01'
        try:test_panel(Store(changed),p,legacy,c)
        except RuntimeError:pass
        else:raise RuntimeError('H_CHANGED_KEY_ACCEPTED')
    passed('window keys fail before dynamic values enter feature flow',2)
    toy=pd.DataFrame({'WELL_ID':np.repeat(['TOY_'+str(i) for i in range(10)],12),'horizon':np.tile(np.arange(1,13),10),'RCYL':np.arange(120,dtype=float)+1,'__scale035':2.,'forecast_step':np.tile(np.arange(1,13),10),'f1':np.arange(120,dtype=float)})
    folds=split_sets(toy)['fixed'];t={'schema':SCHEMA,'variant':'SYNTH_T','kind':'T','base':c,'horizons':[1,2]};base=np.arange(120,dtype=float)+100;calls=[]
    class Provider:
        def __init__(self):self.legacy=legacy
        def get(self,_):return toy,['f1'],{'identity':{'synthetic':True}},None
    def fake_fit(q,fs,cfg,lc,ledger,stage):
        require(set(q.horizon)=={1,2},'T_TRAINED_LATE_ROWS');calls.append({'training_rows':len(q),'training_wells':q.WELL_ID.nunique(),'train_indices':q.index.tolist()});return None
    def fake_predict(model,q,cfg):require(set(q.horizon)=={1,2},'T_PREDICTED_LATE_HEAD');return np.ones(len(q))
    import r14 as module
    with patch.object(module,'fit',fake_fit),patch.object(module,'predict',fake_predict):result,pred=evaluate(t,Provider(),folds,None,'SPY',base)
    late=toy.horizon.to_numpy()>2;require(np.array_equal(pred[late],base[late]) and np.all(pred[~late]==1),'T_SPLICE_NOT_EXACT')
    for call,(tr,va) in zip(calls,folds):require(not set(call['train_indices'])&set(va) and call['training_rows']==2*call['training_wells'],'T_PREP_TRAINING_SCOPE')
    passed('actual T evaluate routing: only early train rows reach fit; same base late outputs retained; outer well isolation',5)
    # Exercise actual preprocessing and model factory via spies, without fitting either.
    preprocess_calls=[];model_calls=[]
    class Prep:
        def fit_transform(self,x,y):preprocess_calls.append(x.index.tolist());return np.ones((len(x),1))
    class Model:
        def fit(self,x,y):model_calls.append(len(y));return self
    class LedgerSpy:
        def run(self,kind,stage,fn):return fn()
    import models035
    with patch.object(old.training,'_preprocessor',lambda x:Prep()),patch.object(models035,'estimator_for',lambda *args:Model()):
        selected=specialist_rows(toy,folds[0][0]);fit(toy.iloc[selected],['f1'],t,legacy,LedgerSpy(),'SPY_ONLY')
    require(preprocess_calls==[selected.tolist()] and model_calls==[len(selected)],'T_PREPROCESSOR_OTHER_ROWS');passed('actual fit forwards only selected training month rows to both preprocessing and model recording spies')
    metadata=pd.DataFrame({'WELL_ID':toy.WELL_ID.drop_duplicates().tolist(),'production_level':np.arange(10,dtype=float),'M_ratio':[1.]*9+[4.],'M_SCTS_fraction':[.9]*10,'scale_fallback':[False]*9+[True]})
    captured=[];quantile=np.quantile
    def record_quantile(values,q):captured.append(np.asarray(values).copy());return quantile(values,q)
    with patch.object(np,'quantile',record_quantile):labels,rules=group_labels(toy,metadata,folds)
    before=captured[0];captured.clear();poison=metadata.copy();valid=set(toy.iloc[folds[0][1]].WELL_ID);poison.loc[poison.WELL_ID.isin(valid),'production_level']=1e30
    with patch.object(np,'quantile',record_quantile):ll,_=group_labels(toy,poison,folds)
    require(np.array_equal(before,captured[0]),'VALIDATION_MOVED_CUTPOINT_INPUTS')
    b=budget(toy,base,metadata,folds)
    for values in b['groups'].values():
        for g in values:require(('group_mean_weighted_loss' not in g and g['wells']=='<5') if g['status'].startswith('SUPPRESSED') else g['wells']>=5,'PRIVACY_MIN_GROUP')
    require(abs(sum(x['weighted_loss'] for x in b['horizon_buckets'].values())-b['total_weighted_loss'])<1e-12,'ERROR_BUCKET_SUM');require(abs(sum(b['direction_contributions']['full'].values())-b['total_weighted_loss'])<1e-12,'ERROR_DIRECTION_SUM');pp=pairs(toy,{'a':base,'b':toy.RCYL.to_numpy()});require(len(pp)==1 and pp[0]['equal_blend_gain_over_better_member']<=0,'ACTUAL_BLEND_LOSS');passed('training-fold cutpoints, <5 suppression, additive error budgets and actual blend/correlation aggregates',5)
    for change in ('cutoff','learner','target'):
        bad=copy.deepcopy(c)
        if change=='cutoff':bad[change]='T0_plus_1'
        elif change=='learner':bad[change]['name']='LightGBM'
        else:bad[change]['scale']='last_legal'
        try:validate(bad)
        except RuntimeError:pass
        else:raise RuntimeError('R14_OUTSIDE_SCOPE_ACCEPTED')
    bad=copy.deepcopy(t);bad['horizons']=[1,2,3]
    try:validate(bad)
    except RuntimeError:pass
    else:raise RuntimeError('T_HORIZON_EXPANDED')
    passed('unsafe boundary, unauthorized learner, scale override and T horizon change blocked',4)
    require(not (ROOT/'INCREMENT_APPROVAL.json').exists(),'UNEXPECTED_R14_RELEASE')
    # Until a real review is supplied, the runnable trainer must fail closed.
    try:require_increment_release(c)
    except RuntimeError as exc:require(str(exc)=='CODEX_R14_INCREMENT_REVIEW_REQUIRED','UNSIGNED_GATE_WRONG_FAILURE')
    else:raise RuntimeError('UNSIGNED_INCREMENT_SEARCH_ALLOWED')
    passed('increment search cannot proceed without actual Codex release')
    out={'status':'PASS','checks':checks,'assertion_case_count':sum(r['cases'] for r in checks),'model_fits':0,'preprocessor_fits':0,'fit_spies_only':True,'real_test_data_read':False,'synthetic_test_wells':10,'recording_spy_fit_routings':len(calls),'new_candidate_scores_produced':0,'external_models_checked':False}
    Path(a.output).write_bytes(encode(out));print(json.dumps({'status':'PASS','check_groups':len(checks),'cases':out['assertion_case_count'],'model_fits':0,'preprocessor_fits':0}))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--policy',required=True);ap.add_argument('--output',required=True);main(ap.parse_args())
