"""R14 additions. The reviewed R13 boundary, byte projector and metric stay intact."""
import os,sys,copy,json,re
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'base'))
import guard035 as old
from guard035 import np,pd,require,fingerprint,file_sha,encode
from cv035 import split_sets,split_fingerprints,fold_hash,repeated_summary
from models035 import predict_single
from ledger035 import Ledger

M3=['M_RCYL','M_RCYL_ratio','M_SCTS_fraction']
R5=['R1','R2','R3','R4','R5']
SCHEMA='A2B035-R14-v1'

def original_b0prime():return old.load_variant(old.HERE/'configs/B0_prime.json')
def normalized(c):
    x=copy.deepcopy(c);x.pop('variant',None);x.pop('purpose',None);x.pop('split_fingerprints',None);return x

def validate(c):
    if c.get('schema')==old.SCHEMA:
        old.validate_config(c)
        require(normalized(c)==normalized(original_b0prime()),'R14_ONLY_EXISTING_B0PRIME_AS_T_BASE')
        return copy.deepcopy(c)
    require(c.get('schema')==SCHEMA and bool(re.fullmatch('[A-Za-z0-9_-]{1,80}',c.get('variant',''))),'R14_SCHEMA_OR_VARIANT')
    if c.get('kind')=='T':
        require(set(c)=={'schema','variant','kind','base','horizons'} and c['horizons']==[1,2],'T_FIXED_HORIZONS')
        validate(c['base']);require(c['base'].get('kind')!='T','T_NOT_NESTED');return copy.deepcopy(c)
    require(set(c)=={'schema','variant','kind','cutoff','target','features','learner','evaluation'} and c['kind']=='H','H_KEYS')
    require(c['cutoff']=='T0_minus_1' and c['target']=={'transform':'log_ratio','scale':'calendar_T0_minus_2'},'H_FIXED_BOUNDARY_AND_SCALE')
    require(c['features'] in ('base325','base325_M3','base325_M3_R'),'H_FEATURES')
    p=c['learner'];a=original_b0prime()['learner'];b=copy.deepcopy(a);b.update(n_estimators=800,min_samples_leaf=10,max_features=1.)
    require(p in (a,b),'H_TWO_REGISTERED_ET_CONFIGS_ONLY')
    require(c['evaluation']==original_b0prime()['evaluation'],'H_SPLITS_CHANGED')
    return copy.deepcopy(c)

def base_config(c):return c['base'] if c.get('kind')=='T' else c
def proxy(c):
    c=validate(base_config(c))
    if c['schema']==old.SCHEMA:return c
    x=original_b0prime();x.update(variant=c['variant'],purpose='search',features='base325_R' if c['features'].endswith('_R') else 'base325',learner=c['learner']);return x

def verify_increment():
    old.verify_source_lock();p=ROOT/'INCREMENT_LOCK.json';require(p.exists(),'R14_LOCK_MISSING')
    lock=json.loads(p.read_bytes())
    for rel,h in lock['files'].items():
        f=(ROOT.parent/rel).resolve();require(f.is_relative_to(ROOT.parent.resolve()) and file_sha(f)==h,'R14_SOURCE_CHANGED')
    return lock

def require_increment_release(c):
    validate(c);verify_increment();p=ROOT/'INCREMENT_APPROVAL.json'
    require(p.exists(),'CODEX_R14_INCREMENT_REVIEW_REQUIRED')
    a=json.loads(p.read_bytes());require(a.get('role')=='Codex' and a.get('can_search') is True and a.get('increment_lock_sha256')==file_sha(ROOT/'INCREMENT_LOCK.json') and bool(re.fullmatch('[0-9a-f]{40}',a.get('review_commit',''))),'R14_RELEASE_IDENTITY')
    scope=a.get('allowed_scope',{});require(scope.get('H') is True and (c.get('kind')!='T' or scope.get('T') is True),'R14_RELEASE_SCOPE')

def additions(history,wid,t0,legacy):
    # Calendar lookup, no "last observed" substitution when T0-2 is absent.
    legal,end=old.legal_history(history,wid,t0,'T0_minus_1',legacy)
    previous=old.row_value(legal,t0-2,'RCYL',legacy);current=old.row_value(legal,t0-1,'RCYL',legacy);days=old.row_value(legal,t0-1,'SCTS',legacy)
    # Identical B0 fallback predicate: finite positive raw value, else 1.
    scale=previous if np.isfinite(previous) and previous>0 else 1.
    ratio=current/previous if np.isfinite(current) and np.isfinite(previous) and previous>0 else np.nan
    values={'M_RCYL':current,'M_RCYL_ratio':ratio,'M_SCTS_fraction':days/(t0-1).days_in_month}
    v=pd.to_numeric(legal.RCYL,errors='coerce').to_numpy(float);valid=v[np.isfinite(v)&(v>=0)]
    metadata={'production_level':float(valid.mean()) if len(valid) else np.nan,'M_ratio':ratio,'M_SCTS_fraction':values['M_SCTS_fraction'],'H_raw_scale':previous,'last_legal_raw_scale':float(pd.to_numeric(legal.sort_values(legacy['anchors']['date_column']).RCYL,errors='coerce').iloc[-1])}
    return values,float(scale),metadata

def augment(panel,features,history,legacy,c):
    b=base_config(validate(c));is_h=b.get('kind')=='H';out=panel.copy();meta=[]
    for wid,group in out.groupby('WELL_ID',sort=False):
        # Every forecast row shares a single pre-window history.
        t0=pd.Timestamp(group.anchor_time.iloc[0]).to_period('M')+1 if 'anchor_time' in group else pd.Timestamp(group.NY.iloc[0]).to_period('M')
        values,scale,m=additions(history,wid,t0,legacy)
        if is_h:
            out.loc[group.index,'__scale035']=scale
            if '_M3' in b['features']:
                for k,v in values.items():out.loc[group.index,k]=v
        raw=m['H_raw_scale'] if is_h else m['last_legal_raw_scale'];m['scale_fallback']=not (np.isfinite(raw) and raw>0);m.pop('H_raw_scale');m.pop('last_legal_raw_scale');m['WELL_ID']=wid;meta.append(m)
    f=list(features)
    if is_h and '_M3' in b['features']:
        f=[x for x in features if x not in R5]+M3+([x for x in R5] if b['features'].endswith('_R') else [])
    require(len(f)==len(set(f)) and len(out)==len(panel) and out[['WELL_ID','horizon']].equals(panel[['WELL_ID','horizon']]),'R14_ROW_OR_FEATURE_ORDER')
    if 'RCYL' in panel:require(out.RCYL.equals(panel.RCYL),'R14_TARGET_CHANGED')
    return out,f,pd.DataFrame(meta)

class Panels:
    def __init__(self,history,policy,legacy):self.history=history;self.policy=policy;self.legacy=legacy;self.cache={}
    def get(self,c):
        c=base_config(validate(c));k=fingerprint(c)
        if k not in self.cache:
            p,f,a=old.build_variant_train(self.history,self.policy,self.legacy,proxy(c));out,fs,meta=augment(p,f,self.history,self.legacy,c)
            a.update(features=len(fs),identity=old.identity(out,fs),R14_scale_calendar_exact=True,R14_future_rows_not_used=True)
            self.cache[k]=(out,fs,a,meta)
        return self.cache[k]

def test_panel(store,policy,legacy,c):
    c=base_config(validate(c));p,f,a=old.build_variant_test(store,policy,legacy,proxy(c))
    _,histories,_=old.test_keys_and_history(store,legacy,policy)
    out,fs,_=augment(p,f,pd.concat([x for x,t in histories],ignore_index=True),legacy,c)
    return out,fs,a

def fit(panel,features,c,legacy,ledger,stage):
    c=validate(base_config(c));x=panel[features];y=old.transform_target(panel,proxy(c))
    from models035 import estimator_for
    model=estimator_for(proxy(c),x,legacy);prep=old.training._preprocessor(x)
    xx=ledger.run('preprocessor',stage,lambda:prep.fit_transform(x,y));ledger.run('model',stage,lambda:model.fit(xx,y))
    return {'config_fingerprint':fingerprint(proxy(c)),'R14_config_fingerprint':fingerprint(c),'features':features,'preprocessor':prep,'model':model,'learner':'ExtraTrees','multioutput':False}

def predict(artifact,panel,c):
    b=base_config(c);require(artifact['R14_config_fingerprint']==fingerprint(b),'R14_ARTIFACT_CONFIG_IDENTITY')
    return predict_single(artifact,panel,proxy(b))
def specialist_rows(panel,indices):
    selected=np.asarray(indices)[panel.iloc[indices].horizon.isin([1,2]).to_numpy()]
    q=panel.iloc[selected];require(len(q)==2*q.WELL_ID.nunique() and (q.groupby('WELL_ID').horizon.agg(list).map(lambda v:v==[1,2])).all(),'SPECIALIST_ROW_ALIGNMENT')
    return selected

def splice(panel,base,early):
    base=np.asarray(base,float);early=np.asarray(early,float);mask=panel.horizon.isin([1,2]).to_numpy();require(len(base)==len(panel) and len(early)==int(mask.sum()),'T_SPLICE_SHAPE')
    out=base.copy();out[mask]=early;require(np.array_equal(out[~mask],base[~mask]) and np.isfinite(out).all(),'T_LATE_PREDICTIONS_CHANGED');return out

def evaluate(c,provider,folds,ledger,stage,base_oof=None):
    c=validate(c);p,f,a,meta=provider.get(c);oof=np.full(len(p),np.nan);coverage=np.zeros(len(p),int);records=[];is_t=c.get('kind')=='T'
    require(not is_t or base_oof is not None,'T_REQUIRES_MATCHING_SAME_RUN_BASE_OOF')
    if is_t:require(len(base_oof)==len(p) and np.isfinite(base_oof).all(),'T_BASE_OOF_SHAPE_FINITE')
    for n,(tr,va) in enumerate(folds,1):
        require(not set(p.iloc[tr].WELL_ID)&set(p.iloc[va].WELL_ID),'R14_OUTER_WELL_OVERLAP')
        selected=specialist_rows(p,tr) if is_t else tr;model=fit(p.iloc[selected],f,c,provider.legacy,ledger,f'{stage}-fold{n}')
        if is_t:
            v=specialist_rows(p,va);pred=splice(p.iloc[va],base_oof[va],predict(model,p.iloc[v],c))
        else:pred=predict(model,p.iloc[va],c)
        oof[va]=pred;coverage[va]+=1;v=old.summary(p.iloc[va],pred)
        records.append({'fold':n,'score':v['official_score'],'weighted_losses':v['weighted_losses'],'train_wells':int(p.iloc[selected].WELL_ID.nunique()),'effective_training_month_rows':len(selected),'validation_wells':int(p.iloc[va].WELL_ID.nunique()),'well_overlap':0,'row_split_sha256':fold_hash(tr,va),'leaf_parameter_unit':'month rows','late_horizons_unchanged':True if is_t else None})
    require((coverage==1).all() and np.isfinite(oof).all(),'R14_OOF_COVERAGE');v=old.summary(p,oof);scores=[r['score'] for r in records]
    return {'score':v['official_score'],'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(np.std(scores)),'weighted_losses':v['weighted_losses'],'official_formula_difference':v['official_cross_check_difference'],'folds':records,'identity':a['identity'],'validation_coverage_each_row_once':True},oof

def full_fit(c,provider,ledger,stage):
    c=validate(c);p,f,*_=provider.get(c)
    if c.get('kind')!='T':return {'base':fit(p,f,c,provider.legacy,ledger,stage),'specialist':None,'config':c}
    base=full_fit(c['base'],provider,ledger,stage+'-base');early=specialist_rows(p,np.arange(len(p)))
    return {'base':base['base'],'specialist':fit(p.iloc[early],f,c,provider.legacy,ledger,stage+'-first2'),'config':c}

def full_predict(bundle,panel,c):
    require(bundle['config']==c,'R14_MODEL_CONFIG_IDENTITY');b=predict(bundle['base'],panel,c)
    if bundle['specialist'] is None:return b
    mask=panel.horizon.isin([1,2]).to_numpy();return splice(panel,b,predict(bundle['specialist'],panel.loc[mask],c))
