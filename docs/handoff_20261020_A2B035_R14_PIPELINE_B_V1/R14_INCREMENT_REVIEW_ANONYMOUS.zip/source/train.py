"""R14 full-train entry. Private output only; requires Codex increment release."""
from r14 import *
from run_r14 import runtime,save
import argparse

def main(a):
    c=validate(json.loads(Path(a.config).read_bytes()));require_increment_release(c);env=runtime();root=Path(a.output);require(not root.exists(),'NEW_PRIVATE_MODEL_DIR_REQUIRED');root.mkdir(parents=True);policy,legacy=old.load_locked_policy(a.policy);contract=json.loads((old.HERE/'DATA_CONTRACT.json').read_bytes());data_path=Path(a.data_dir)
    if data_path.is_file():require(file_sha(data_path)==contract['raw_archive_sha256'],'TRAIN_ARCHIVE_IDENTITY')
    else:require(data_path.is_dir(),'TRAIN_DATA_DIRECTORY_MISSING')
    store=old.Inputs(data_path)
    try:history=old.load_train(store,legacy)
    finally:store.close()
    provider=Panels(history,policy,legacy);baseline=provider.get(original_b0prime())[0];require(old.identity(baseline,policy['feature_order'])==contract['B0_prime_identity'],'TRAIN_PROJECTED_DATA_IDENTITY');ledger=Ledger(root/'FIT_COUNTS.json')
    with old.offline_only():bundle=full_fit(c,provider,ledger,'full')
    bundle['private_policy_sha256']=file_sha(a.policy);bundle['increment_lock_sha256']=file_sha(ROOT/'INCREMENT_LOCK.json');bundle['runtime']=env;old.joblib.dump(bundle,root/'model.joblib');save(root/'MODEL_RECEIPT.json',{'model_sha256':file_sha(root/'model.joblib'),'config_fingerprint':fingerprint(c),'increment_lock_sha256':bundle['increment_lock_sha256'],'runtime':env,'status':'待独立复核','model_fits':ledger.value['models_completed'],'preprocessor_fits':ledger.value['preprocessors_completed']})
if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for k in ('config','data_dir','policy','output'):ap.add_argument('--'+k,required=True)
    main(ap.parse_args())
