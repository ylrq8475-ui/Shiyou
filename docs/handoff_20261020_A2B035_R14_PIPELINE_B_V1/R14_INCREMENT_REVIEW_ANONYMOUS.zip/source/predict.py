"""R14 inference: per-well, no fitting, immutable template keys, private result ZIP."""
from r14 import *
from run_r14 import runtime
from models035 import forbid_fits
import argparse

def main(a):
    c=validate(json.loads(Path(a.config).read_bytes()));require_increment_release(c);runtime();require(not Path(a.output).exists(),'EXISTING_RESULT_PRESERVED');policy,legacy=old.load_locked_policy(a.policy);receipt=json.loads((Path(a.model).parent/'MODEL_RECEIPT.json').read_bytes());require(file_sha(a.model)==receipt['model_sha256'],'MODEL_IDENTITY');bundle=old.joblib.load(a.model)
    require(bundle['increment_lock_sha256']==file_sha(ROOT/'INCREMENT_LOCK.json') and bundle['private_policy_sha256']==file_sha(a.policy),'MODEL_SOURCE_POLICY_IDENTITY');store=old.Inputs(a.data_dir)
    try:
        with old.offline_only(),forbid_fits():
            panel,features,audit=test_panel(store,policy,legacy,c);out=[]
            for _,group in panel.groupby('WELL_ID',sort=False):out.extend(full_predict(bundle,group,c))
            pred=np.asarray(out,float);old.write_result(a.output,panel,pred)
    finally:store.close()
    print(json.dumps({'rows':len(panel),'test_window_dynamic_values_decoded':audit['test_window_dynamic_values_decoded'],'result_sha256':file_sha(a.output),'model_fits':0,'preprocessor_fits':0}))
if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for k in ('config','data_dir','policy','model','output'):ap.add_argument('--'+k,required=True)
    main(ap.parse_args())
