"""Post-Codex-release runner; no fitting occurs before the signed increment gate."""
from r14 import *
from error_budget import budget,pairs
import argparse,platform,importlib.metadata as im,time

def runtime():
    v={'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'executable_sha256':file_sha(sys.executable),'dependencies':dict(sorted({d.metadata['Name']:d.version for d in im.distributions()}.items(),key=lambda x:x[0].lower())),'logical_CPU':os.cpu_count(),'n_jobs':-1,'outer_folds_parallel':1,'requested_native_threads':1}
    locked=json.loads((old.HERE/'ENVIRONMENT_LOCK.json').read_bytes())
    require(all(v[k]==locked[k] for k in ('python_version','python_build','python_compiler','dependencies')),'R14_RUNTIME_CHANGED')
    return v

def save(path,value):path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encode(value))
def rank(r):return (-r['results']['repeated_summary']['mean'],r['results']['repeated_summary']['standard_error'],-r['results']['fixed']['score'],r['config']['variant'])

def main(a):
    root=Path(a.output).resolve();require(not root.exists(),'NEW_OUTPUT_DIRECTORY_REQUIRED')
    plan=json.loads((ROOT.parent/'PLAN_R14.json').read_bytes());configs=[validate(json.loads((ROOT.parent/name).read_bytes())) for name in plan['H_configs']]
    for c in configs:require_increment_release(c)
    initial=runtime();root.mkdir(parents=True);ledger=Ledger(root/'FIT_COUNTS.json');save(root/'STARTED.json',{'runtime':initial,'increment_lock_sha256':file_sha(ROOT/'INCREMENT_LOCK.json'),'plan_sha256':file_sha(ROOT.parent/'PLAN_R14.json'),'R14_instruction_commit':plan['R14_instruction_commit'],'B0_standalone_rebuilt':False});tick=time.perf_counter()
    contract=json.loads((old.HERE/'DATA_CONTRACT.json').read_bytes());require(file_sha(a.data_dir)==contract['raw_archive_sha256'],'R14_DATA_CHANGED');policy,legacy=old.load_locked_policy(a.policy);store=old.Inputs(a.data_dir)
    try:history=old.load_train(store,legacy)
    finally:store.close()
    provider=Panels(history,policy,legacy);base=original_b0prime();p=provider.get(base)[0];splits=split_sets(p);require(split_fingerprints(splits)==contract['split_fingerprints'],'R14_SPLIT_IDENTITY');records={};memory={}
    def evaluate_all(c,prior=None):
        name=c['variant'];require(name not in records,'ALREADY_SUCCESSFUL_CONFIG_NOT_RERUN');require_increment_release(c);require(runtime()==initial,'R14_MIXED_RUNTIME');verify_increment();panel,fs,audit,metadata=provider.get(c)
        require(panel[['WELL_ID','horizon','RCYL']].equals(p[['WELL_ID','horizon','RCYL']]),'R14_PAIRWISE_LABEL_AND_ROW_ALIGNMENT')
        save(root/name/'PRESCORE.json',{'config':c,'config_fingerprint':fingerprint(c),'runtime':initial,'identity':old.identity(panel,fs),'split_fingerprints':split_fingerprints(splits),'increment_lock_sha256':file_sha(ROOT/'INCREMENT_LOCK.json'),'raw_archive_sha256':contract['raw_archive_sha256'],'private_policy_sha256':file_sha(a.policy),'before_variant_fits':True})
        result={};oofs={};diagnostics={}
        for sn,folds in splits.items():
            result[sn],oofs[sn]=evaluate(c,provider,folds,ledger,name+'-'+sn,base_oof=None if prior is None else prior[sn])
            diagnostics[sn]=budget(panel,oofs[sn],metadata,folds)
            save(root/name/(sn+'.json'),{'evaluation':result[sn],'training_error_budget':diagnostics[sn]})
        result['repeated_summary']=repeated_summary([result['repeat_'+str(i)] for i in range(1,6)]);row={'config':c,'results':result,'error_budgets':diagnostics};records[name]=row;memory[name]=oofs;save(root/name/'RESULT.json',row);print('COMPLETE '+name+' repeat='+str(result['repeated_summary']['mean']),flush=True);return row
    with old.offline_only():
        hs=[evaluate_all(c) for c in configs];best_h=sorted(hs,key=rank)[0]
        save(root/'H_CHOICE_BEFORE_T.json',{'selected':best_h['config']['variant'],'rule':'repeat mean descending, SE ascending, fixed score descending, variant lexical','before_any_T_fits':True})
        # This baseline is necessary for the authorized T/B0prime comparator,
        # not an extra fit to fill an old diagnostic table. B0 is never trained.
        b=evaluate_all(base);ts=[]
        for source in (b,best_h):
            c={'schema':SCHEMA,'variant':'T_'+source['config']['variant'],'kind':'T','base':source['config'],'horizons':[1,2]}
            require_increment_release(c);ts.append(evaluate_all(c,memory[source['config']['variant']]))
        best_t=sorted(ts,key=rank)[0];chosen=[base['variant'],best_h['config']['variant'],best_t['config']['variant']];correlations={}
        for sn in splits:correlations[sn]=pairs(p,{name:memory[name][sn] for name in chosen})
    ranking=sorted(records.values(),key=rank)
    save(root/'RESULT_R14_SEARCH.json',{'role':'账户B执行与交付','status':'CONTROLLED_SEARCH_COMPLETED','records':list(records.values()),'ranking':[r['config']['variant'] for r in ranking],'best_H':best_h['config']['variant'],'best_T':best_t['config']['variant'],'paired_error_and_equal_blends':correlations,'unavailable_budgets':{'B0':'UNKNOWN: old row OOF not persisted; zero diagnostic fit budget; standalone rebuild forbidden','prior_uploaded_candidate':'UNKNOWN: prior row OOF not persisted; no report-only refit'},'model_fits':ledger.value['models_completed'],'preprocessor_fits':ledger.value['preprocessors_completed'],'row_OOF_persisted':False,'test_input_distribution_comparisons':0,'B0_standalone_rebuilds':0,'B_platform_uploads':0,'S_v':'UNKNOWN until actual upload identity and score are bound','seconds':time.perf_counter()-tick,'runtime_unchanged':runtime()==initial,'candidate_selection':'rank complete H/T versions by actual S_v if bound, otherwise repeat mean as provisional; maximum 3 per day, package build separate; retain every accepted/rejected version with reason'})

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for name in ('data_dir','policy','output'):ap.add_argument('--'+name,required=True)
    main(ap.parse_args())
