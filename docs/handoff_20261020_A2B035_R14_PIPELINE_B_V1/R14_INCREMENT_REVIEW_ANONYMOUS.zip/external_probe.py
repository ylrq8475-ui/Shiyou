"""External adapter admission evidence: synthetic data only, two recorded fits."""
import os,sys,json,hashlib,importlib.metadata as im,platform,time,base64,csv
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
TASK=Path(__file__).resolve().parent;sys.path.insert(0,str(TASK/'source'))
from r14 import *
from models035 import fit_single,predict_single,forbid_fits
from unittest.mock import patch
import models035
def sha(p):return old.sha(Path(p).read_bytes())
def main():
    tick=time.perf_counter();base=original_b0prime();data=pd.DataFrame({'WELL_ID':np.repeat(['SYNTH_'+str(i) for i in range(10)],12),'horizon':np.tile(np.arange(1,13),10),'forecast_step':np.tile(np.arange(1,13),10),'RCYL':np.arange(120,dtype=float)%17+1,'__scale035':1.,'feature':np.arange(120,dtype=float),'missing':np.tile([1.,2.,np.nan,4.],30)})
    # The probe never loads a private policy or opens a competition data source.
    ledger=Ledger(TASK/'execution/EXTERNAL_SYNTHETIC_FITS.json');out=[]
    legacy={} # The LGB/Cat estimator branches do not read legacy model settings.
    for name,version,params in [('LightGBM','4.6.0',{'name':'LightGBM','num_leaves':7,'learning_rate':.03,'n_estimators':400,'min_child_samples':10,'random_state':20260916,'n_jobs':-1}),('CatBoost','1.2.8',{'name':'CatBoost','depth':4,'random_state':20260916,'thread_count':-1})]:
        require(im.version(name)==version,'EXTERNAL_PIN_CHANGED');c=copy.deepcopy(base);c.update(variant='SYNTH_'+name,purpose='search',learner=params);old.validate_config(c);gate_calls=[]
        def synthetic_gate(requested):require(requested==name,'UNEXPECTED_EXTERNAL_ADAPTER');gate_calls.append(requested);return {'synthetic_admission_probe_only':True}
        with old.offline_only(),patch.object(models035,'resource_gate',synthetic_gate):artifact=fit_single(data.iloc[:96],['feature','missing'],c,legacy,ledger,'synthetic-'+name)
        with old.offline_only(),forbid_fits((type(artifact['model']),)):
            batch=predict_single(artifact,data.iloc[96:],c);single=np.concatenate([predict_single(artifact,data.iloc[[i]],c) for i in range(96,120)]);reverse=predict_single(artifact,data.iloc[96:].iloc[::-1],c)[::-1]
        require(np.array_equal(batch,single) and np.array_equal(batch,reverse),'EXTERNAL_QUERY_DEPENDENCE')
        stats=artifact['preprocessor'].named_transformers_['numeric'].named_steps['impute'].statistics_;require(np.array_equal(stats,np.nanmedian(data.iloc[:96][['feature','missing']],axis=0)),'EXTERNAL_PREPROCESSOR_SCOPE')
        dist=im.distribution(name);native=[];checked=0
        for row in dist.files or []:
            path=Path(dist.locate_file(row))
            if row.hash and row.hash.mode=='sha256' and path.is_file():
                b=path.read_bytes();digest=base64.urlsafe_b64encode(__import__('hashlib').sha256(b).digest()).rstrip(b'=').decode();require(digest==row.hash.value,'INSTALLED_RECORD_HASH_MISMATCH');checked+=1
                if path.suffix.lower() in ('.pyd','.dll'):native.append({'package_relative_path':str(row).replace('\\','/'),'sha256':old.sha(b),'bytes':len(b)})
        license_files=[]
        for row in dist.files or []:
            if 'license' in str(row).lower() or Path(str(row)).name.lower()=='notice':
                path=Path(dist.locate_file(row))
                if path.is_file():license_files.append({'package_relative_path':str(row).replace('\\','/'),'sha256':sha(path),'bytes':path.stat().st_size})
        out.append({'learner':name,'version':version,'license':'MIT' if name=='LightGBM' else 'Apache-2.0','official_license_url':'https://github.com/lightgbm-org/LightGBM/blob/v4.6.0/LICENSE' if name=='LightGBM' else 'https://github.com/catboost/catboost/blob/v1.2.8/LICENSE','actual_common_adapter_exercised':True,'temporary_gate_override':'synthetic-only admission probe; old release file remains false, no competition data opened','resource_gate_calls':len(gate_calls),'synthetic_model_fits':1,'synthetic_preprocessor_fits':1,'single_row_batch_and_reordered_queries_exact':True,'imputation_training_rows_only':True,'inference_fit_guard_active':True,'network_connect_disabled_during_fit_and_inference':True,'pretrained_weights':False,'installed_RECORD_SHA256_entries_verified':checked,'native_modules':native,'installed_license_metadata':license_files,'admission':'PENDING_CODEX; not activated for competition search'})
    environment={'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({d.metadata['Name']:d.version for d in im.distributions()}.items(),key=lambda x:x[0].lower())),'system_site_packages':False,'new_isolated_environment':True,'old_environment_modified':False,'old_folds_reused':False}
    original=json.loads((old.HERE/'ENVIRONMENT_LOCK.json').read_bytes());environment['original21_dependency_versions_unchanged']=all(environment['dependencies'].get(k)==v for k,v in original['dependencies'].items());require(environment['original21_dependency_versions_unchanged'],'BASE21_VERSION_DRIFT')
    result={'status':'PASS','role':'账户B执行与交付','probe_type':'synthetic admission evidence only','environment':environment,'adapters':out,'competition_data_read':False,'competition_model_fits':0,'synthetic_model_fits':ledger.value['models_completed'],'synthetic_preprocessor_fits':ledger.value['preprocessors_completed'],'external_competition_release':False,'seconds':time.perf_counter()-tick};(TASK/'execution/EXTERNAL_ADMISSION_EVIDENCE.json').write_bytes(encode(result));print(json.dumps({'status':'PASS','synthetic_models':2,'synthetic_preprocessors':2,'competition_fits':0,'new_dependencies':len(environment['dependencies'])}))
if __name__=='__main__':main()
