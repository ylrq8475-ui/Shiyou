"""A2B-014 aggregate-only diagnostics for the frozen A2B-013 OOF.

Real well keys, row-level targets, predictions, and leaf memberships remain in
memory. Public functions return only aggregate-safe structures unless their
name explicitly says ``table`` for in-memory composition by the authorized
entry point.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from .a2b013_safe import SafeData, _safe_history_values, fit_and_predict
from .exceptions import DataContractError
from .scoring import official_twelve_month_score
from .training import _target_scale


EPSILON = 1e-6
PRIVACY_MIN_WELLS = 5
EXPECTED_OOF = 73.71410733861434
OOF_TOLERANCE = 1e-6
WINDOWS = (1, 3, 6, 12)
HORIZON_SETS = {
    "month_1": (1,),
    "months_1_2": (1, 2),
    "months_1_4": (1, 2, 3, 4),
    "months_1_12": tuple(range(1, 13)),
}


def _finite_number(value: Any) -> float:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return np.nan
    return numeric


def classify_last_rcyl(value: Any) -> str:
    """Classify the raw last-record RCYL without assigning field semantics."""
    if value is None or pd.isna(value):
        return "missing"
    numeric = _finite_number(value)
    if np.isnan(numeric):
        return "missing"
    if not np.isfinite(numeric):
        return "nonfinite"
    if numeric > 0:
        return "positive_finite"
    if numeric == 0:
        return "zero"
    return "negative_illegal"


def calendar_slope(values: Iterable[float]) -> float:
    """Fit a slope on fixed natural-month offsets while retaining gaps in x."""
    array = np.asarray(list(values), dtype=float)
    finite = np.isfinite(array)
    if int(finite.sum()) < 2:
        return np.nan
    x = np.arange(len(array), dtype=float)[finite]
    return float(np.polyfit(x, array[finite], 1)[0])


def _same_value(left: Any, right: Any, atol: float = 1e-12) -> bool:
    left_num, right_num = _finite_number(left), _finite_number(right)
    if np.isnan(left_num) and np.isnan(right_num):
        return True
    return bool(np.isclose(left_num, right_num, rtol=0.0, atol=atol, equal_nan=True))


def _month_age(cutoff: pd.Period, observed: pd.Period | None) -> int | None:
    if observed is None:
        return None
    return int(cutoff.ordinal - observed.ordinal)


def _numeric_value(row: pd.Series | None, column: str) -> float:
    if row is None or column not in row.index:
        return np.nan
    return _finite_number(row[column])


def calendar_state_table(
    history: pd.DataFrame,
    anchors: pd.DataFrame,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Build in-memory, pre-forecast state flags for complete-event wells."""
    well = config["anchors"]["well_column"]
    date = config["anchors"]["date_column"]
    numeric_fields = list(config["features"]["history_numeric_columns"])
    if "RCYL" not in numeric_fields:
        numeric_fields.insert(0, "RCYL")
    required = {well, date, *numeric_fields}
    missing = sorted(required - set(history.columns))
    if missing:
        raise DataContractError("A2B-014 history fields are missing: " + ", ".join(missing))
    work = history.copy()
    parsed = pd.to_datetime(work[date], errors="coerce")
    if parsed.isna().any():
        raise DataContractError("A2B-014 history contains an invalid date.")
    work["__period"] = parsed.dt.to_period("M")
    if work[[well, "__period"]].duplicated().any():
        raise DataContractError("A2B-014 requires at most one row per well-month.")
    rows: list[dict[str, Any]] = []
    aggregate_feature_differences = Counter()
    for item in anchors.to_dict("records"):
        well_value = item[well]
        anchor = item["anchor_period"]
        cutoff = anchor - 1
        local = work.loc[(work[well] == well_value) & (work["__period"] <= cutoff)].copy()
        local = local.sort_values("__period", kind="mergesort")
        if local.empty:
            raise DataContractError("A complete-event well lacks pre-cutoff history.")
        by_period = {period: row for period, (_, row) in zip(local["__period"], local.iterrows())}
        current = _safe_history_values(history, well_value, anchor, config)
        record: dict[str, Any] = {well: well_value}
        last_period = local["__period"].iloc[-1]
        rcyl_numeric = pd.to_numeric(local["RCYL"], errors="coerce").to_numpy(dtype=float)
        finite_rcyl = np.isfinite(rcyl_numeric)
        last_finite_period = local.loc[finite_rcyl, "__period"].iloc[-1] if finite_rcyl.any() else None
        record["last_record_age_months"] = _month_age(cutoff, last_period)
        record["last_finite_rcyl_age_months"] = _month_age(cutoff, last_finite_period)
        record["last_record_age_ge_1"] = bool(record["last_record_age_months"] >= 1)
        record["last_finite_rcyl_age_ge_1"] = bool(
            record["last_finite_rcyl_age_months"] is None
            or record["last_finite_rcyl_age_months"] >= 1
        )
        for window in WINDOWS:
            periods = [cutoff - offset for offset in range(window - 1, -1, -1)]
            month_missing = sum(period not in by_period for period in periods)
            field_missing = 0
            for period in periods:
                row = by_period.get(period)
                if row is None:
                    continue
                field_missing += sum(
                    not np.isfinite(_numeric_value(row, column)) for column in numeric_fields
                )
            record[f"calendar_missing_count_w{window}"] = int(month_missing)
            record[f"calendar_missing_any_w{window}"] = bool(month_missing)
            record[f"field_missing_count_w{window}"] = int(field_missing)
            record[f"field_missing_any_w{window}"] = bool(field_missing)
        last_rcyl = current.get("history__RCYL__last", np.nan)
        state = classify_last_rcyl(last_rcyl)
        record["last_rcyl_state"] = state
        record["scale_fallback"] = state != "positive_finite"
        for name in (
            "positive_finite", "zero", "missing", "nonfinite", "negative_illegal"
        ):
            record[f"last_rcyl_{name}"] = state == name

        lag_diff = rolling_diff = trend_diff = 0
        max_lag = max(map(int, config["features"].get("target_lags", [1, 2, 3, 6, 12])))
        max_window = max(
            [*map(int, config["features"].get("rolling_windows", [3, 6, 12])),
             *map(int, config["features"].get("trend_windows", [3, 6, 12]))]
        )
        grid_start = cutoff - max(max_lag, max_window) + 1
        grid_periods = list(pd.period_range(grid_start, cutoff, freq="M"))
        for column in numeric_fields:
            calendar_values = np.asarray(
                [_numeric_value(by_period.get(period), column) for period in grid_periods],
                dtype=float,
            )
            for lag in map(int, config["features"].get("target_lags", [1, 2, 3, 6, 12])):
                natural = calendar_values[-lag]
                existing = current.get(f"history__{column}__lag_{lag}", np.nan)
                if not _same_value(existing, natural):
                    lag_diff += 1
            for window in map(int, config["features"].get("rolling_windows", [3, 6, 12])):
                natural_tail = pd.Series(calendar_values[-window:])
                finite_tail = natural_tail.replace([np.inf, -np.inf], np.nan).dropna()
                values = {
                    "mean": finite_tail.mean() if not finite_tail.empty else np.nan,
                    "median": finite_tail.median() if not finite_tail.empty else np.nan,
                    "std": finite_tail.std(ddof=0) if not finite_tail.empty else np.nan,
                    "missing": int(window - len(finite_tail)),
                }
                for suffix, natural in values.items():
                    key = (
                        f"history__{column}__missing_{window}"
                        if suffix == "missing"
                        else f"history__{column}__roll_{window}_{suffix}"
                    )
                    existing = current.get(key, np.nan)
                    if not _same_value(existing, natural):
                        rolling_diff += 1
            for window in map(int, config["features"].get("trend_windows", [3, 6, 12])):
                natural = calendar_slope(calendar_values[-window:])
                existing = current.get(f"history__{column}__trend_{window}", np.nan)
                if not _same_value(existing, natural):
                    trend_diff += 1
        record["lag_difference_count"] = int(lag_diff)
        record["rolling_difference_count"] = int(rolling_diff)
        record["trend_difference_count"] = int(trend_diff)
        record["lag_diff_any"] = bool(lag_diff)
        record["rolling_diff_any"] = bool(rolling_diff)
        record["trend_diff_any"] = bool(trend_diff)
        record["any_history_feature_diff"] = bool(lag_diff or rolling_diff or trend_diff)
        aggregate_feature_differences.update(
            {"lag": lag_diff, "rolling": rolling_diff, "trend": trend_diff}
        )
        rows.append(record)
    table = pd.DataFrame(rows)
    aggregate = {
        "wells_checked": int(len(table)),
        "numeric_fields_checked": int(len(numeric_fields)),
        "feature_value_difference_counts": {
            name: int(aggregate_feature_differences[name]) for name in ("lag", "rolling", "trend")
        },
    }
    return table, aggregate


def independent_official_metrics(
    panel: pd.DataFrame,
    prediction: np.ndarray,
    epsilon: float = EPSILON,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Independently implement the unnormalized official metric."""
    required = {"WELL_ID", "horizon", "RCYL"}
    if not required.issubset(panel.columns):
        raise DataContractError("A2B-014 metric panel is missing required fields.")
    if len(panel) != len(prediction):
        raise DataContractError("A2B-014 metric input length mismatch.")
    truth = pd.to_numeric(panel["RCYL"], errors="coerce").to_numpy(dtype=float)
    pred = np.asarray(prediction, dtype=float)
    horizon = pd.to_numeric(panel["horizon"], errors="coerce").to_numpy(dtype=int)
    if not np.isfinite(truth).all() or not np.isfinite(pred).all() or (pred < 0).any():
        raise DataContractError("A2B-014 metric inputs are invalid.")
    weights = np.power(2.0, -horizon)
    denominator = np.abs(pred) + np.abs(truth) + epsilon
    relative = np.abs(pred - truth) / denominator
    signed = (pred - truth) / denominator
    work = pd.DataFrame({
        "WELL_ID": panel["WELL_ID"].to_numpy(),
        "horizon": horizon,
        "weighted_loss": weights * relative,
        "signed_relative_error": signed,
        "target_zero": truth == 0,
        "target_positive": truth > 0,
    })
    sizes = work.groupby("WELL_ID", sort=False).size()
    horizons = work.groupby("WELL_ID", sort=False)["horizon"].apply(lambda x: tuple(sorted(x.tolist())))
    if sizes.ne(12).any() or any(value != tuple(range(1, 13)) for value in horizons):
        raise DataContractError("A2B-014 metric requires one complete twelve-month window per well.")
    per_well_rows: list[dict[str, Any]] = []
    for well_value, group in work.groupby("WELL_ID", sort=False):
        row: dict[str, Any] = {"WELL_ID": well_value}
        for name, months in HORIZON_SETS.items():
            selected = group["horizon"].isin(months)
            row[f"{name}_loss"] = float(group.loc[selected, "weighted_loss"].sum())
            row[f"{name}_signed"] = float(group.loc[selected, "signed_relative_error"].mean())
        direction = row["months_1_12_signed"]
        row["direction"] = "over" if direction > 0 else "under" if direction < 0 else "tie"
        per_well_rows.append(row)
    per_well = pd.DataFrame(per_well_rows)
    monthly = [
        float(work.loc[work["horizon"] == month, "weighted_loss"].mean())
        for month in range(1, 13)
    ]
    total_loss = float(per_well["months_1_12_loss"].mean())
    metrics = {
        "official_oof": float(100.0 * (1.0 - total_loss)),
        "monthly_weighted_loss": monthly,
        "month_1_loss": float(monthly[0]),
        "months_1_2_loss": float(sum(monthly[:2])),
        "months_1_4_loss": float(sum(monthly[:4])),
        "months_1_12_loss": float(sum(monthly)),
        "well_count": int(len(per_well)),
        "epsilon": float(epsilon),
        "weights_normalized": False,
    }
    return metrics, per_well


def validate_fold_isolation(train_wells: Iterable[Any], valid_wells: Iterable[Any]) -> None:
    if set(train_wells) & set(valid_wells):
        raise DataContractError("A2B-014 detected a well crossing the validation boundary.")


@dataclass
class OOFRebuild:
    prediction: np.ndarray
    fold_id: np.ndarray
    support_rows: pd.DataFrame
    fold_scores: list[float]
    fold_counts: list[dict[str, int]]


def _tree_leaf_support(
    estimator: Any,
    train_x: pd.DataFrame,
    valid_x: pd.DataFrame,
    train_wells: np.ndarray,
) -> dict[str, np.ndarray]:
    preprocess = estimator.named_steps["preprocess"]
    model = estimator.named_steps["model"]
    transformed_train = np.asarray(preprocess.transform(train_x))
    transformed_valid = np.asarray(preprocess.transform(valid_x))
    trees = getattr(model, "estimators_", None)
    if trees is None or len(trees) != 400:
        raise DataContractError("A2B-014 expected the frozen 400-tree ExtraTrees model.")
    unique_support = np.empty((len(valid_x), len(trees)), dtype=float)
    effective_support = np.empty_like(unique_support)
    for tree_index, tree in enumerate(trees):
        train_leaf = tree.apply(transformed_train)
        valid_leaf = tree.apply(transformed_valid)
        leaf_stats: dict[int, tuple[int, float]] = {}
        for leaf in np.unique(train_leaf):
            mask = train_leaf == leaf
            counts = Counter(train_wells[mask].tolist())
            total = float(sum(counts.values()))
            shares = np.asarray(list(counts.values()), dtype=float) / total
            leaf_stats[int(leaf)] = (len(counts), float(1.0 / np.square(shares).sum()))
        for row_index, leaf in enumerate(valid_leaf):
            unique_support[row_index, tree_index], effective_support[row_index, tree_index] = leaf_stats[int(leaf)]
    return {
        "unique_wells_min": np.min(unique_support, axis=1),
        "unique_wells_p10": np.quantile(unique_support, 0.10, axis=1),
        "unique_wells_median": np.median(unique_support, axis=1),
        "effective_wells_median": np.median(effective_support, axis=1),
        "fraction_trees_unique_wells_le_1": np.mean(unique_support <= 1, axis=1),
        "fraction_trees_unique_wells_le_2": np.mean(unique_support <= 2, axis=1),
        "fraction_trees_unique_wells_le_3": np.mean(unique_support <= 3, axis=1),
        "fraction_trees_unique_wells_le_5": np.mean(unique_support <= 5, axis=1),
    }


def rebuild_frozen_oof(data: SafeData, config: dict[str, Any]) -> OOFRebuild:
    """Fit exactly the frozen five folds once and collect in-memory diagnostics."""
    panel = data.train
    splitter = GroupKFold(n_splits=5)
    groups = panel["WELL_ID"]
    prediction = np.full(len(panel), np.nan, dtype=float)
    fold_id = np.zeros(len(panel), dtype=int)
    support_parts: list[pd.DataFrame] = []
    fold_scores: list[float] = []
    fold_counts: list[dict[str, int]] = []
    for fold, (train_idx, valid_idx) in enumerate(
        splitter.split(panel, panel["RCYL"], groups), start=1
    ):
        train_wells = groups.iloc[train_idx].to_numpy()
        valid_wells = groups.iloc[valid_idx].to_numpy()
        validate_fold_isolation(train_wells, valid_wells)
        estimator, pred = fit_and_predict(
            panel.iloc[train_idx], panel.iloc[valid_idx], data.features, config
        )
        prediction[valid_idx] = pred
        fold_id[valid_idx] = fold
        support = _tree_leaf_support(
            estimator,
            panel.iloc[train_idx].loc[:, data.features],
            panel.iloc[valid_idx].loc[:, data.features],
            train_wells,
        )
        part = pd.DataFrame(support, index=valid_idx)
        part["WELL_ID"] = valid_wells
        part["fold"] = fold
        part["horizon"] = panel.iloc[valid_idx]["horizon"].to_numpy(dtype=int)
        support_parts.append(part)
        fold_panel = panel.iloc[valid_idx]
        official = official_twelve_month_score(
            fold_panel.assign(prediction=pred),
            truth_column="RCYL",
            prediction_column="prediction",
            epsilon=EPSILON,
        ).total
        fold_scores.append(float(official))
        fold_counts.append({
            "fold": fold,
            "training_wells": int(len(set(train_wells))),
            "validation_wells": int(len(set(valid_wells))),
            "well_overlap": 0,
        })
    if not np.isfinite(prediction).all() or (prediction < 0).any() or (fold_id == 0).any():
        raise DataContractError("A2B-014 OOF coverage failed.")
    support_rows = pd.concat(support_parts).sort_index(kind="mergesort")
    return OOFRebuild(prediction, fold_id, support_rows, fold_scores, fold_counts)


def _spearman(left: pd.Series, right: pd.Series) -> float | None:
    finite = np.isfinite(left.to_numpy(dtype=float)) & np.isfinite(right.to_numpy(dtype=float))
    if int(finite.sum()) < 3:
        return None
    lrank = left.loc[finite].rank(method="average").to_numpy(dtype=float)
    rrank = right.loc[finite].rank(method="average").to_numpy(dtype=float)
    if np.std(lrank) == 0 or np.std(rrank) == 0:
        return None
    return float(np.corrcoef(lrank, rrank)[0, 1])


def support_well_table(support_rows: pd.DataFrame) -> pd.DataFrame:
    columns = [column for column in support_rows if column not in {"WELL_ID", "fold", "horizon"}]
    result = support_rows.groupby("WELL_ID", sort=False)[columns].mean().reset_index()
    folds = support_rows.groupby("WELL_ID", sort=False)["fold"].first().reset_index()
    result = result.merge(folds, on="WELL_ID", validate="one_to_one")
    result["low_leaf_support"] = result["fraction_trees_unique_wells_le_3"] >= 0.25
    return result


def summarize_boolean_group(
    per_well: pd.DataFrame,
    flag: str,
    *,
    minimum: int = PRIVACY_MIN_WELLS,
) -> dict[str, Any]:
    selected = per_well[flag].astype(bool)
    group_count = int(selected.sum())
    complement_count = int((~selected).sum())
    if group_count < minimum or complement_count < minimum:
        return {"privacy_gate_passed": False, "status": "suppressed"}
    group = per_well.loc[selected]
    complement = per_well.loc[~selected]
    total_loss = float(per_well["months_1_12_loss"].sum())
    result: dict[str, Any] = {
        "privacy_gate_passed": True,
        "well_count": group_count,
        "complement_well_count": complement_count,
        "share_of_total_loss": float(group["months_1_12_loss"].sum() / total_loss),
        "mean_signed_relative_error": float(group["months_1_12_signed"].mean()),
        "overprediction_well_count": int((group["direction"] == "over").sum()),
        "underprediction_well_count": int((group["direction"] == "under").sum()),
        "exact_tie_well_count": int((group["direction"] == "tie").sum()),
    }
    for name in HORIZON_SETS:
        result[f"{name}_weighted_loss"] = float(group[f"{name}_loss"].mean())
    result["complement_months_1_12_weighted_loss"] = float(
        complement["months_1_12_loss"].mean()
    )
    eligible = positive = nonpositive = 0
    for _, fold_rows in per_well.groupby("fold", sort=True):
        fold_selected = fold_rows[flag].astype(bool)
        if int(fold_selected.sum()) < minimum or int((~fold_selected).sum()) < minimum:
            continue
        eligible += 1
        group_loss = float(fold_rows.loc[fold_selected, "months_1_12_loss"].mean())
        complement_loss = float(fold_rows.loc[~fold_selected, "months_1_12_loss"].mean())
        if group_loss > complement_loss:
            positive += 1
        else:
            nonpositive += 1
    result["eligible_fold_count"] = eligible
    result["folds_group_loss_above_complement"] = positive
    result["folds_group_loss_below_or_equal_complement"] = nonpositive
    overall_positive = (
        result["months_1_12_weighted_loss"] > result["complement_months_1_12_weighted_loss"]
    )
    consistent_needed = math.ceil(0.8 * eligible) if eligible else 0
    if eligible >= 3 and overall_positive and positive >= consistent_needed:
        conclusion = "observed_loss_concentration"
    elif eligible >= 3 and not overall_positive and nonpositive >= consistent_needed:
        conclusion = "not_observed"
    else:
        conclusion = "insufficient"
    result["conclusion"] = conclusion
    return result


def retrospective_target_summary(
    panel: pd.DataFrame,
    prediction: np.ndarray,
    minimum: int = PRIVACY_MIN_WELLS,
) -> dict[str, Any]:
    truth = pd.to_numeric(panel["RCYL"], errors="coerce").to_numpy(dtype=float)
    pred = np.asarray(prediction, dtype=float)
    horizon = panel["horizon"].to_numpy(dtype=int)
    weighted = np.power(2.0, -horizon) * np.abs(pred - truth) / (
        np.abs(pred) + np.abs(truth) + EPSILON
    )
    total = float(weighted.sum())
    result: dict[str, Any] = {"diagnostic_only": True}
    for name, mask in {"target_zero_rows": truth == 0, "target_positive_rows": truth > 0}.items():
        wells = int(panel.loc[mask, "WELL_ID"].nunique())
        complement_wells = int(panel.loc[~mask, "WELL_ID"].nunique())
        if wells < minimum or complement_wells < minimum:
            result[name] = {"privacy_gate_passed": False, "status": "suppressed"}
            continue
        result[name] = {
            "privacy_gate_passed": True,
            "row_count": int(mask.sum()),
            "well_count": wells,
            "weighted_loss_sum": float(weighted[mask].sum() / panel["WELL_ID"].nunique()),
            "share_of_total_loss": float(weighted[mask].sum() / total),
        }
    return result


def support_aggregate(
    support_wells: pd.DataFrame,
    per_well: pd.DataFrame,
) -> dict[str, Any]:
    if "unique_wells_median" in per_well.columns:
        merged = per_well.copy()
    else:
        merged = per_well.merge(support_wells, on=["WELL_ID", "fold"], validate="one_to_one")
    metrics = [
        "unique_wells_min", "unique_wells_p10", "unique_wells_median",
        "effective_wells_median", "fraction_trees_unique_wells_le_1",
        "fraction_trees_unique_wells_le_2", "fraction_trees_unique_wells_le_3",
        "fraction_trees_unique_wells_le_5",
    ]
    distribution = {
        name: {
            "min": float(merged[name].min()),
            "p10": float(merged[name].quantile(0.10)),
            "median": float(merged[name].median()),
            "p90": float(merged[name].quantile(0.90)),
            "max": float(merged[name].max()),
        }
        for name in metrics
    }
    correlations = {
        name: _spearman(merged[name], merged["months_1_12_loss"])
        for name in ("unique_wells_median", "effective_wells_median", "fraction_trees_unique_wells_le_3")
    }
    fold_correlations = []
    for fold, group in merged.groupby("fold", sort=True):
        fold_correlations.append({
            "fold": int(fold),
            "unique_wells_median_vs_loss_spearman": _spearman(
                group["unique_wells_median"], group["months_1_12_loss"]
            ),
            "fraction_le_3_vs_loss_spearman": _spearman(
                group["fraction_trees_unique_wells_le_3"], group["months_1_12_loss"]
            ),
        })
    return {
        "well_count": int(len(merged)),
        "distribution": distribution,
        "loss_association_spearman": correlations,
        "fold_loss_association_spearman": fold_correlations,
        "low_support_group": summarize_boolean_group(merged, "low_leaf_support"),
        "trees_treated_as_independent_samples": False,
    }


def safe_numeric_state_summary(
    states: pd.DataFrame,
    columns: list[str],
    minimum: int = PRIVACY_MIN_WELLS,
) -> dict[str, Any]:
    """Summarize state magnitudes without exposing small nonzero partitions."""
    result: dict[str, Any] = {}
    for column in columns:
        values = pd.to_numeric(states[column], errors="coerce")
        finite = values[np.isfinite(values)]
        nonzero = values.fillna(1).gt(0)
        entry: dict[str, Any] = {
            "finite_well_count": int(len(finite)),
            "mean": float(finite.mean()) if len(finite) else None,
            "median": float(finite.median()) if len(finite) else None,
            "maximum": float(finite.max()) if len(finite) else None,
        }
        if int(nonzero.sum()) >= minimum and int((~nonzero).sum()) >= minimum:
            entry["nonzero_well_count"] = int(nonzero.sum())
            entry["zero_well_count"] = int((~nonzero).sum())
        else:
            entry["partition_counts"] = "suppressed"
        result[column] = entry
    return result


def retrospective_target_fold_comparison(
    panel: pd.DataFrame,
    prediction: np.ndarray,
    fold_id: np.ndarray,
    worst_fold: int = 4,
    minimum: int = PRIVACY_MIN_WELLS,
) -> dict[str, Any]:
    """Compare zero-target prevalence in the worst fold without small cells."""
    truth = pd.to_numeric(panel["RCYL"], errors="coerce").to_numpy(dtype=float)
    pred = np.asarray(prediction, dtype=float)
    horizon = panel["horizon"].to_numpy(dtype=int)
    zero = truth == 0
    weighted = np.power(2.0, -horizon) * np.abs(pred - truth) / (
        np.abs(pred) + np.abs(truth) + EPSILON
    )
    output: dict[str, Any] = {"diagnostic_only": True}
    for name, mask in {
        "worst_fold": fold_id == worst_fold,
        "other_folds": fold_id != worst_fold,
    }.items():
        local = panel.loc[mask, ["WELL_ID"]].copy()
        local["zero"] = zero[mask]
        by_well = local.groupby("WELL_ID", sort=False)["zero"].any()
        zero_wells = int(by_well.sum())
        nonzero_only_wells = int((~by_well).sum())
        if zero_wells < minimum or nonzero_only_wells < minimum:
            output[name] = {"privacy_gate_passed": False, "status": "suppressed"}
            continue
        local_weighted = weighted[mask]
        local_zero = zero[mask]
        output[name] = {
            "privacy_gate_passed": True,
            "well_count": int(len(by_well)),
            "wells_with_any_zero_target": zero_wells,
            "zero_target_row_fraction": float(local_zero.mean()),
            "zero_target_share_of_loss": float(
                local_weighted[local_zero].sum() / local_weighted.sum()
            ),
        }
    return output


def worst_fold_summary(
    per_well: pd.DataFrame,
    state_flags: list[str],
    support_wells: pd.DataFrame,
    retrospective: dict[str, Any],
    worst_fold: int = 4,
) -> dict[str, Any]:
    support = support_wells.groupby("fold", sort=True).mean(numeric_only=True)
    result: dict[str, Any] = {
        "fold": worst_fold,
        "well_count": int((per_well["fold"] == worst_fold).sum()),
        "months_1_12_weighted_loss": float(
            per_well.loc[per_well["fold"] == worst_fold, "months_1_12_loss"].mean()
        ),
        "other_folds_months_1_12_weighted_loss": float(
            per_well.loc[per_well["fold"] != worst_fold, "months_1_12_loss"].mean()
        ),
        "state_prevalence": {},
        "leaf_support": {
            "unique_wells_median": float(support.loc[worst_fold, "unique_wells_median"]),
            "other_folds_unique_wells_median": float(
                support.loc[support.index != worst_fold, "unique_wells_median"].mean()
            ),
            "fraction_trees_unique_wells_le_3": float(
                support.loc[worst_fold, "fraction_trees_unique_wells_le_3"]
            ),
            "other_folds_fraction_trees_unique_wells_le_3": float(
                support.loc[support.index != worst_fold, "fraction_trees_unique_wells_le_3"].mean()
            ),
        },
        "retrospective_target_summary_reference": retrospective,
    }
    in_fold = per_well["fold"] == worst_fold
    for flag in state_flags:
        group = per_well.loc[in_fold, flag].astype(bool)
        complement = ~group
        other = per_well.loc[~in_fold, flag].astype(bool)
        other_complement = ~other
        if (
            int(group.sum()) < PRIVACY_MIN_WELLS
            or int(complement.sum()) < PRIVACY_MIN_WELLS
            or int(other.sum()) < PRIVACY_MIN_WELLS
            or int(other_complement.sum()) < PRIVACY_MIN_WELLS
        ):
            result["state_prevalence"][flag] = {"privacy_gate_passed": False, "status": "suppressed"}
            continue
        result["state_prevalence"][flag] = {
            "privacy_gate_passed": True,
            "worst_fold_fraction": float(group.mean()),
            "other_folds_fraction": float(other.mean()),
        }
    return result
