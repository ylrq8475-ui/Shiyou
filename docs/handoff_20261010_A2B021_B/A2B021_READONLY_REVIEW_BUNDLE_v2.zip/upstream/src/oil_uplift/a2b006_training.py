"""Isolated training helpers for the approved A2B-006 experiment.

This module intentionally does not change the frozen v7 training path.  It
separates the base estimator, target transform, sample-weight policy, and
target-scale policy so the experiment cannot rely on compound model-name
suffixes.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

from .exceptions import DataContractError
from .models import build_model
from .training import _preprocessor


@dataclass(frozen=True)
class ExplicitCandidateSpec:
    base_model: str
    target_transform: str
    sample_weight_policy: str
    scale_policy: str

    def validate(self) -> None:
        if self.base_model != "extra_trees":
            raise DataContractError("A2B-006 only authorizes the frozen ExtraTrees family.")
        if self.target_transform != "log_ratio":
            raise DataContractError("A2B-006 only authorizes the explicit log-ratio transform.")
        if self.sample_weight_policy not in {"none", "official_horizon"}:
            raise DataContractError("Unknown A2B-006 sample-weight policy.")
        if self.scale_policy not in {
            "legacy_anchor_last",
            "pre_anchor_last_q10",
            "pre_anchor_robust_q10",
        }:
            raise DataContractError("Unknown A2B-006 target-scale policy.")


def official_training_weights(horizon: pd.Series | np.ndarray) -> np.ndarray:
    """Return numerically rescaled 2^-t weights without changing ratios."""
    steps = np.asarray(pd.to_numeric(horizon, errors="coerce"), dtype=float)
    if not np.isfinite(steps).all() or (steps < 1).any() or (steps > 12).any():
        raise DataContractError("Official horizon proxy weights require horizons 1 through 12.")
    weights = np.power(2.0, -steps)
    return weights / float(weights.mean())


def _raw_scale(panel: pd.DataFrame, policy: str) -> np.ndarray:
    column = {
        "legacy_anchor_last": "history__RCYL__last",
        "pre_anchor_last_q10": "a2b006__rcyl_last_pre_anchor",
        "pre_anchor_robust_q10": "a2b006__rcyl_robust_pre_anchor",
    }[policy]
    if column not in panel:
        raise DataContractError(f"A2B-006 target scale requires {column}.")
    return pd.to_numeric(panel[column], errors="coerce").to_numpy(dtype=float)


def fit_scale_floor(panel: pd.DataFrame, policy: str) -> float | None:
    if policy == "legacy_anchor_last":
        return None
    required = {"WELL_ID"}
    if not required.issubset(panel.columns):
        raise DataContractError("Fold-local target scale requires WELL_ID.")
    one_per_well = panel.drop_duplicates("WELL_ID")
    values = _raw_scale(one_per_well, policy)
    positive = values[np.isfinite(values) & (values > 0)]
    if positive.size == 0:
        raise DataContractError("No positive training-well scale is available for the fold.")
    return float(np.quantile(positive, 0.10))


def resolve_scale(panel: pd.DataFrame, policy: str, floor: float | None) -> np.ndarray:
    raw = _raw_scale(panel, policy)
    if policy == "legacy_anchor_last":
        return np.where(np.isfinite(raw) & (raw > 0), raw, 1.0)
    if floor is None or not np.isfinite(floor) or floor <= 0:
        raise DataContractError("A positive fold-local scale floor is required.")
    clean = np.where(np.isfinite(raw) & (raw > 0), raw, floor)
    return np.maximum(clean, floor)


def transform_target(y: pd.Series | np.ndarray, scale: np.ndarray) -> np.ndarray:
    values = np.asarray(pd.to_numeric(y, errors="coerce"), dtype=float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise DataContractError("A2B-006 target values must be finite and non-negative.")
    if values.shape != scale.shape:
        raise DataContractError("Target and scale shapes differ.")
    return np.log1p(values / scale)


def inverse_target(transformed: np.ndarray, scale: np.ndarray) -> np.ndarray:
    values = np.asarray(transformed, dtype=float)
    if values.shape != scale.shape or not np.isfinite(values).all():
        raise DataContractError("Transformed predictions and scales must be finite and aligned.")
    return np.expm1(values) * scale


def fit_explicit_pipeline(
    x: pd.DataFrame,
    y: pd.Series,
    horizon: pd.Series,
    panel: pd.DataFrame,
    spec: ExplicitCandidateSpec,
    *,
    random_seed: int,
    model_params: dict[str, Any],
) -> Pipeline:
    spec.validate()
    estimator = Pipeline(
        [
            ("preprocess", _preprocessor(x)),
            ("model", build_model(spec.base_model, random_seed, model_params)),
        ]
    )
    floor = fit_scale_floor(panel, spec.scale_policy)
    scale = resolve_scale(panel, spec.scale_policy, floor)
    target = transform_target(y, scale)
    if spec.sample_weight_policy == "official_horizon":
        weights = official_training_weights(horizon)
        estimator.fit(x, target, model__sample_weight=weights)
    else:
        estimator.fit(x, target)
    estimator.a2b006_candidate_spec_ = asdict(spec)
    estimator.a2b006_scale_floor_ = floor
    estimator.a2b006_training_weight_rescaling_ = (
        "divide_by_training_mean" if spec.sample_weight_policy == "official_horizon" else "none"
    )
    return estimator


def predict_explicit_pipeline(
    estimator: Pipeline,
    x: pd.DataFrame,
    panel: pd.DataFrame,
    spec: ExplicitCandidateSpec,
) -> np.ndarray:
    stored = getattr(estimator, "a2b006_candidate_spec_", None)
    if stored != asdict(spec):
        raise DataContractError("A2B-006 estimator specification does not match inference request.")
    floor = getattr(estimator, "a2b006_scale_floor_", None)
    scale = resolve_scale(panel, spec.scale_policy, floor)
    transformed = np.asarray(estimator.predict(x), dtype=float)
    return inverse_target(transformed, scale)
