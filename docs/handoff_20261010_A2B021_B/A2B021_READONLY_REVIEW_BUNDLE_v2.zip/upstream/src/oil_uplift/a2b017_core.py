"""A2B-017 nested early-month calibration; row-level objects stay in memory."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np
import pandas as pd
from sklearn.exceptions import NotFittedError
from sklearn.model_selection import GroupKFold
from sklearn.utils.validation import check_is_fitted

from .a2b013_safe import MODEL_NAME, _official_score
from .a2b015_training import official_summary
from .a2b016_gate import canonical_sha256
from .exceptions import DataContractError
from .training import _fit_pipeline, _model_pipeline, _transform_target, predict_pipeline_output

GRID = (0.75, 0.90, 1.00, 1.10, 1.25)
SEEDS = (20260917, 20261031, 20261219, 20270107, 20270303)
CONFIRMATION_SEED = 20270421


def require(condition: bool, message: str) -> None:
    if not condition:
        raise DataContractError('A2B-017: ' + message)


def array_hash(values: np.ndarray) -> str:
    a = np.ascontiguousarray(values)
    return hashlib.sha256(a.dtype.str.encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


def row_hash(panel: pd.DataFrame) -> str:
    return canonical_sha256(panel[['WELL_ID', 'horizon']].astype(str).values.tolist())


def fallback_mask(panel: pd.DataFrame) -> np.ndarray:
    raw = pd.to_numeric(panel['history__RCYL__last'], errors='coerce').to_numpy(dtype=np.float64)
    result = ~np.isfinite(raw) | (raw <= 0)
    for _, positions in panel.groupby('WELL_ID', sort=False).indices.items():
        require(len(set(result[positions].tolist())) == 1, 'inconsistent pre-forecast state within a well')
    return result


def validate_panel(panel: pd.DataFrame) -> None:
    require(not panel[['WELL_ID', 'horizon']].duplicated().any(), 'duplicate well/horizon')
    for _, group in panel.groupby('WELL_ID', sort=False):
        require(sorted(group['horizon'].tolist()) == list(range(1, 13)), 'incomplete twelve-month well')


def grouped_splits(panel: pd.DataFrame, n: int = 5, seed: int | None = None):
    splitter = GroupKFold(n_splits=n, shuffle=seed is not None, random_state=seed)
    return [(a, b) for a, b in splitter.split(panel, groups=panel['WELL_ID'])]


def validate_splits(panel: pd.DataFrame, splits) -> None:
    coverage = np.zeros(len(panel), dtype=int)
    universe = set(range(len(panel)))
    for train, valid in splits:
        train, valid = np.asarray(train), np.asarray(valid)
        require(len(train) == len(set(train.tolist())) and len(valid) == len(set(valid.tolist())), 'duplicate split rows')
        require(set(train) | set(valid) == universe and not set(train) & set(valid), 'split row partition mismatch')
        require(not set(panel.iloc[train]['WELL_ID']) & set(panel.iloc[valid]['WELL_ID']), 'well crossed split')
        coverage[valid] += 1
    require(np.array_equal(coverage, np.ones(len(panel), dtype=int)), 'OOF coverage is not exactly once')


def prediction_view(panel: pd.DataFrame) -> pd.DataFrame:
    return panel.drop(columns=['RCYL'], errors='ignore')


@dataclass
class FitTrace:
    train_keys: pd.DataFrame
    valid_keys: pd.DataFrame
    fit_x_hash: str
    fit_y_hash: str
    prediction_hash: str
    actual_fit_calls: int
    actual_preprocess_fit_calls: int
    fresh_before_fit: bool


def audited_fit_predict(train: pd.DataFrame, valid: pd.DataFrame, features: list[str], config: dict,
                        allowed: set, forbidden: set) -> tuple[Any, np.ndarray, FitTrace]:
    tw, vw = set(train['WELL_ID']), set(valid['WELL_ID'])
    require(tw <= allowed and not tw & forbidden and not tw & vw, 'actual fitted well scope violation')
    require('RCYL' not in features, 'outcome is a model feature')
    x = train.loc[:, features]
    estimator = _model_pipeline(MODEL_NAME, x, config)
    try:
        check_is_fitted(estimator)
        fresh = False
    except NotFittedError:
        fresh = True
    require(fresh, 'estimator was already fitted')
    expected_y = _transform_target(train['RCYL'], train, 'log_ratio_last')
    calls = {'fit': 0, 'preprocess': 0}
    original_fit = estimator.fit
    prep = estimator.named_steps['preprocess']
    original_preprocess = prep.fit_transform

    def checked_preprocess(xx, yy=None, **kwargs):
        require(isinstance(xx, pd.DataFrame) and xx.equals(x), 'preprocessing saw data outside training frame')
        calls['preprocess'] += 1
        return original_preprocess(xx, yy, **kwargs)

    def checked_fit(xx, yy, **kwargs):
        require(isinstance(xx, pd.DataFrame) and xx.equals(x), 'pipeline fitted outside training frame')
        require(np.array_equal(np.asarray(yy), expected_y), 'pipeline fitted on wrong targets')
        calls['fit'] += 1
        return original_fit(xx, yy, **kwargs)

    estimator.fit = checked_fit
    prep.fit_transform = checked_preprocess
    try:
        _fit_pipeline(estimator, MODEL_NAME, x, train['RCYL'], train['horizon'], train)
    finally:
        del estimator.fit
        del prep.fit_transform
    require(calls == {'fit': 1, 'preprocess': 1}, 'actual fit or preprocessing call count changed')
    view = prediction_view(valid)
    p = np.clip(np.asarray(predict_pipeline_output(estimator, MODEL_NAME, view[features], view), dtype=np.float64), 0, None)
    require(len(p) == len(valid) and np.isfinite(p).all(), 'invalid model prediction')
    trace = FitTrace(train[['WELL_ID', 'horizon']].copy(), valid[['WELL_ID', 'horizon']].copy(),
                     canonical_sha256(pd.util.hash_pandas_object(x, index=True).tolist()),
                     array_hash(expected_y), array_hash(p), calls['fit'], calls['preprocess'], fresh)
    return estimator, p, trace


@dataclass
class TrainingOOF:
    panel: pd.DataFrame
    prediction: np.ndarray
    splits: list
    traces: list[FitTrace]
    allowed_wells: set
    forbidden_wells: set

    def audit(self) -> dict:
        validate_panel(self.panel)
        require(set(self.panel['WELL_ID']) == self.allowed_wells and not self.allowed_wells & self.forbidden_wells,
                'calibrator label scope violation')
        validate_splits(self.panel, self.splits)
        require(len(self.traces) == len(self.splits), 'missing inner fit trace')
        require(np.isfinite(self.prediction).all() and (self.prediction >= 0).all(), 'inner OOF is invalid')
        for (tr, va), trace in zip(self.splits, self.traces, strict=True):
            require(trace.train_keys.equals(self.panel.iloc[tr][['WELL_ID', 'horizon']]), 'inner fitted keys mismatch')
            require(trace.valid_keys.equals(self.panel.iloc[va][['WELL_ID', 'horizon']]), 'inner prediction keys mismatch')
            require(trace.prediction_hash == array_hash(self.prediction[va]), 'inner OOF prediction source mismatch')
            require(trace.fit_y_hash == array_hash(_transform_target(self.panel.iloc[tr]['RCYL'], self.panel.iloc[tr], 'log_ratio_last')),
                    'inner fit labels do not match training scope')
            require(trace.actual_fit_calls == trace.actual_preprocess_fit_calls == 1 and trace.fresh_before_fit,
                    'inner actual fit proof failed')
        return {'wells': len(self.allowed_wells), 'folds': len(self.splits), 'row_sha256': row_hash(self.panel),
                'prediction_sha256': array_hash(self.prediction), 'label_sha256': array_hash(self.panel['RCYL'].to_numpy(dtype=np.float64))}


def inner_oof(train: pd.DataFrame, features: list[str], config: dict, forbidden: set,
              fit: Callable = audited_fit_predict) -> TrainingOOF:
    splits = grouped_splits(train, 3)
    validate_splits(train, splits)
    oof = np.full(len(train), np.nan)
    traces = []
    allowed = set(train['WELL_ID'])
    for tr, va in splits:
        _, p, trace = fit(train.iloc[tr], prediction_view(train.iloc[va]), features, config, allowed, forbidden)
        oof[va] = p
        traces.append(trace)
    result = TrainingOOF(train, oof, splits, traces, allowed, forbidden)
    result.audit()
    return result


def pooled_loss(panel: pd.DataFrame, p: np.ndarray) -> float:
    y = panel['RCYL'].to_numpy(dtype=np.float64)
    h = panel['horizon'].to_numpy(dtype=int)
    require(len(p) == len(y) and np.isfinite(p).all() and np.isfinite(y).all(), 'nonfinite coefficient loss')
    terms = np.power(0.5, h) * np.abs(p-y) / (np.abs(p)+np.abs(y)+1e-6)
    work = pd.DataFrame({'well': panel['WELL_ID'].to_numpy(), 'loss': terms})
    return float(work.groupby('well', sort=False)['loss'].sum().mean())


def select_a(losses: dict[float, float]) -> float:
    require(set(losses) == set(GRID) and all(np.isfinite(v) for v in losses.values()), 'coefficient grid changed or nonfinite')
    return min(losses, key=lambda a: (losses[a], abs(a-1), a))


@dataclass
class Coefficients:
    candidate_id: str
    selected_a: tuple[float, ...]
    alpha: tuple[float, ...]
    training_provenance: dict
    fallback_wells: int
    grid_losses: list[list[float]]

    def aggregate(self) -> dict:
        return {'candidate_id': self.candidate_id, 'selected_a': list(self.selected_a), 'alpha': list(self.alpha),
                'training_provenance': self.training_provenance, 'fallback_independent_wells': self.fallback_wells,
                'unshrunk_grid_losses': self.grid_losses, 'deployment_or_outer_score_used': False}


def learn_coefficients(training: TrainingOOF, candidate_id: str) -> Coefficients:
    require(candidate_id in {'C1', 'C2'}, 'unregistered candidate')
    provenance = training.audit()
    panel, p = training.panel, training.prediction
    mask = fallback_mask(panel)
    n = int(panel.loc[mask, 'WELL_ID'].nunique())
    selected, grids = [], []
    scopes = [panel['horizon'].to_numpy() == h for h in (1, 2)] if candidate_id == 'C1' else [mask & (panel['horizon'].to_numpy() <= 2)]
    for scope in scopes:
        if candidate_id == 'C2' and n < 8:
            selected.append(1.0)
            grids.append([])
            continue
        losses = {a: pooled_loss(panel.loc[scope], a*p[scope]) for a in GRID}
        selected.append(select_a(losses))
        grids.append([losses[a] for a in GRID])
    return Coefficients(candidate_id, tuple(selected), tuple(1+0.5*(a-1) for a in selected), provenance, n, grids)


def apply_coefficients(base: np.ndarray, view: pd.DataFrame, coefficient: Coefficients) -> np.ndarray:
    require('RCYL' not in view.columns, 'outer validation labels passed to calibration application')
    require(all(np.isfinite(a) and a > 0 for a in coefficient.alpha), 'invalid coefficient')
    require(len(base) == len(view) and np.isfinite(base).all() and (base >= 0).all(), 'invalid base prediction')
    out = np.asarray(base, dtype=np.float64).copy()
    h = view['horizon'].to_numpy()
    if coefficient.candidate_id == 'C1':
        require(len(coefficient.alpha) == 2, 'C1 coefficient dimension changed')
        for month, alpha in zip((1, 2), coefficient.alpha):
            out[h == month] = np.maximum(0, alpha*base[h == month])
    else:
        require(coefficient.candidate_id == 'C2' and len(coefficient.alpha) == 1, 'C2 coefficient dimension changed')
        mask = fallback_mask(view) & (h <= 2)
        out[mask] = np.maximum(0, coefficient.alpha[0]*base[mask])
    audit_predictions(base, out, view, coefficient.candidate_id)
    return out


def audit_predictions(base, candidate, view, candidate_id) -> dict:
    require(np.isfinite(candidate).all() and (candidate >= 0).all(), 'candidate prediction validity failed')
    late = view['horizon'].to_numpy() >= 3
    require(np.array_equal(base[late], candidate[late]), 'months 3-12 changed')
    if candidate_id == 'C2':
        ordinary = ~fallback_mask(view)
        require(np.array_equal(base[ordinary], candidate[ordinary]), 'C2 ordinary predictions changed')
    return {'late_values_unchanged': True, 'ordinary_values_unchanged': candidate_id == 'C2'}


@dataclass
class FoldRun:
    train_index: np.ndarray
    valid_index: np.ndarray
    base_trace: FitTrace
    inner: TrainingOOF
    coefficients: dict[str, Coefficients]


@dataclass
class FamilyRun:
    panel: pd.DataFrame
    splits: list
    baseline: np.ndarray
    candidates: dict[str, np.ndarray]
    folds: np.ndarray
    runs: list[FoldRun]

    def audit(self, candidate_id: str) -> dict:
        validate_splits(self.panel, self.splits)
        require(len(self.runs) == len(self.splits), 'missing outer fold provenance')
        for (tr, va), run in zip(self.splits, self.runs, strict=True):
            require(np.array_equal(run.train_index, tr) and np.array_equal(run.valid_index, va), 'outer split mismatch')
            require(run.base_trace.train_keys.equals(self.panel.iloc[tr][['WELL_ID', 'horizon']]), 'outer fit scope mismatch')
            require(run.base_trace.valid_keys.equals(self.panel.iloc[va][['WELL_ID', 'horizon']]), 'outer prediction keys mismatch')
            require(run.base_trace.prediction_hash == array_hash(self.baseline[va]), 'outer base prediction source mismatch')
            require(run.base_trace.fit_y_hash == array_hash(_transform_target(self.panel.iloc[tr]['RCYL'], self.panel.iloc[tr], 'log_ratio_last')),
                    'outer fit labels do not match training scope')
            provenance = run.inner.audit()
            require(run.inner.panel.equals(self.panel.iloc[tr]), 'calibrator contains labels outside outer training set')
            require(run.inner.forbidden_wells == set(self.panel.iloc[va]['WELL_ID']), 'outer exclusion scope changed')
            coeff = run.coefficients[candidate_id]
            require(coeff.training_provenance == provenance, 'coefficient provenance mismatch')
            recomputed = learn_coefficients(run.inner, candidate_id)
            require(coeff.aggregate() == recomputed.aggregate(), 'coefficient rule or learning input mismatch')
            actual = apply_coefficients(self.baseline[va], prediction_view(self.panel.iloc[va]), coeff)
            require(np.array_equal(actual, self.candidates[candidate_id][va]), 'candidate application mask mismatch')
            require(run.base_trace.actual_fit_calls == run.base_trace.actual_preprocess_fit_calls == 1 and run.base_trace.fresh_before_fit,
                    'outer fit proof failed')
        return {'outer_folds': len(self.runs), 'inner_folds': sum(len(r.inner.traces) for r in self.runs),
                'cohort_sha256': row_hash(self.panel), 'outer_split_sha256': split_digest(self.splits),
                'inner_split_sha256': canonical_sha256([split_digest(r.inner.splits) for r in self.runs]),
                'actual_model_fit_calls': sum(1+len(r.inner.traces) for r in self.runs)}


def split_digest(splits) -> str:
    return canonical_sha256([(array_hash(np.asarray(a, dtype=np.int64)), array_hash(np.asarray(b, dtype=np.int64))) for a, b in splits])


def baseline_oof(panel, features, config, splits, fit=audited_fit_predict, progress=lambda _: None):
    validate_panel(panel)
    validate_splits(panel, splits)
    base, folds, traces = np.full(len(panel), np.nan), np.zeros(len(panel), dtype=int), []
    for i, (tr, va) in enumerate(splits, 1):
        _, p, trace = fit(panel.iloc[tr], prediction_view(panel.iloc[va]), features, config,
                          set(panel.iloc[tr]['WELL_ID']), set(panel.iloc[va]['WELL_ID']))
        base[va], folds[va] = p, i
        traces.append(trace)
        progress({'stage': 'baseline', 'fold': i})
    return base, folds, traces


def nested_from_baseline(panel, features, config, splits, base, folds, traces,
                         candidate_ids=('C1', 'C2'), fit=audited_fit_predict, progress=lambda _: None):
    output = {name: base.copy() for name in candidate_ids}
    runs = []
    for i, ((tr, va), base_trace) in enumerate(zip(splits, traces, strict=True), 1):
        train = panel.iloc[tr]
        inner = inner_oof(train, features, config, set(panel.iloc[va]['WELL_ID']), fit)
        coefficients = {name: learn_coefficients(inner, name) for name in candidate_ids}
        for name, c in coefficients.items():
            output[name][va] = apply_coefficients(base[va], prediction_view(panel.iloc[va]), c)
        runs.append(FoldRun(tr, va, base_trace, inner, coefficients))
        progress({'stage': 'nested_calibration', 'fold': i})
    result = FamilyRun(panel, splits, base, output, folds, runs)
    for name in candidate_ids:
        result.audit(name)
    return result


def summary(panel, prediction, folds) -> dict:
    validate_panel(panel)
    result = official_summary(panel, prediction, folds)
    independent = _official_score(panel, prediction)
    require(abs(result['official_oof']-independent) <= 1e-10, 'independent official metric disagreement')
    result['independent_metric_absolute_error'] = abs(result['official_oof']-independent)
    return result


def groups_summary(panel, prediction, folds) -> dict:
    mask = fallback_mask(panel)
    a, b = int(panel.loc[mask, 'WELL_ID'].nunique()), int(panel.loc[~mask, 'WELL_ID'].nunique())
    if min(a, b) < 5:
        return {'status': 'suppressed', 'fallback_wells': a, 'ordinary_wells': b}
    return {'status': 'published', 'fallback_wells': a, 'ordinary_wells': b,
            'fallback_score': summary(panel.loc[mask], prediction[mask], folds[mask])['official_oof'],
            'ordinary_score': summary(panel.loc[~mask], prediction[~mask], folds[~mask])['official_oof']}
