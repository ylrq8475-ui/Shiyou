"""Isolated, pre-registered A2B-009 R2 feature and training helpers."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

from .a2b006_training import inverse_target, resolve_scale, transform_target
from .exceptions import DataContractError
from .models import build_model
from .training import _preprocessor


RCYL_FEATURES = [
    "n1__rcyl__last_change_1",
    "n1__rcyl__cumulative_change_3",
    "n1__rcyl__median3_minus_median6",
    "n1__rcyl__trend3_minus_trend6",
    "n1__rcyl__last_over_median3",
    "n1__rcyl__last_over_median6",
]
PRODUCTION_FEATURES = [
    f"n1__{column.lower()}__{name}"
    for column in ("SCTS", "BJ", "CC")
    for name in ("mean3_minus_mean6", "trend3_minus_trend6", "last_over_median6")
]


def _stat(values: np.ndarray, minimum: int, kind: str) -> float:
    clean = values[np.isfinite(values)]
    if clean.size < minimum:
        return np.nan
    if kind == "median":
        return float(np.median(clean))
    if kind == "mean":
        return float(np.mean(clean))
    raise DataContractError("Unknown calendar statistic.")


def _calendar_slope(values: np.ndarray) -> float:
    finite = np.isfinite(values)
    if int(finite.sum()) < 2:
        return np.nan
    offsets = np.arange(len(values), dtype=float)
    return float(np.polyfit(offsets[finite], values[finite], 1)[0])


def _ratio(numerator: float, denominator: float) -> float:
    if not np.isfinite(numerator) or not np.isfinite(denominator) or abs(denominator) <= 1e-6:
        return np.nan
    return float(numerator / denominator)


def _difference(left: float, right: float) -> float:
    return float(left - right) if np.isfinite(left) and np.isfinite(right) else np.nan


def _features_from_six_months(months: dict[str, np.ndarray]) -> dict[str, float]:
    rcyl = months["RCYL"]
    median3 = _stat(rcyl[-3:], 2, "median")
    median6 = _stat(rcyl, 3, "median")
    result = dict(zip(RCYL_FEATURES, [
        _difference(rcyl[-1], rcyl[-2]),
        _difference(rcyl[-1], rcyl[-3]),
        _difference(median3, median6),
        _difference(_calendar_slope(rcyl[-3:]), _calendar_slope(rcyl)),
        _ratio(rcyl[-1], median3),
        _ratio(rcyl[-1], median6),
    ], strict=True))
    for column in ("SCTS", "BJ", "CC"):
        values = months[column]
        prefix = f"n1__{column.lower()}__"
        mean3 = _stat(values[-3:], 2, "mean")
        mean6 = _stat(values, 3, "mean")
        median6 = _stat(values, 3, "median")
        result[prefix + "mean3_minus_mean6"] = _difference(mean3, mean6)
        result[prefix + "trend3_minus_trend6"] = _difference(
            _calendar_slope(values[-3:]), _calendar_slope(values)
        )
        result[prefix + "last_over_median6"] = _ratio(values[-1], median6)
    return result


def calendar_feature_table(
    history: pd.DataFrame, anchors: pd.DataFrame, config: dict[str, Any]
) -> pd.DataFrame:
    """Build 15 features from exact natural months ending before each anchor."""
    well = config["anchors"]["well_column"]
    date = config["anchors"]["date_column"]
    required = {well, date, "RCYL", "SCTS", "BJ", "CC"}
    if not required.issubset(history.columns) or not {well, "anchor_time"}.issubset(anchors.columns):
        raise DataContractError("A2B-009 calendar features are missing required fields.")
    local = history[[well, date, "RCYL", "SCTS", "BJ", "CC"]].copy()
    local["__period"] = pd.to_datetime(local[date], errors="coerce").dt.to_period("M")
    if local["__period"].isna().any() or local.duplicated([well, "__period"]).any():
        raise DataContractError("Invalid or duplicate same-well calendar month in production history.")
    if anchors.duplicated([well, "anchor_time"]).any():
        raise DataContractError("Duplicate well/event anchor in A2B-009 feature request.")
    indexed = local.set_index([well, "__period"])
    rows: list[dict[str, Any]] = []
    for item in anchors[[well, "anchor_time"]].to_dict("records"):
        anchor = pd.Timestamp(item["anchor_time"])
        if pd.isna(anchor):
            raise DataContractError("Invalid A2B-009 anchor time.")
        periods = [anchor.to_period("M") - offset for offset in range(6, 0, -1)]
        months: dict[str, np.ndarray] = {}
        for column in ("RCYL", "SCTS", "BJ", "CC"):
            values = [
                indexed.at[(item[well], period), column]
                if (item[well], period) in indexed.index else np.nan
                for period in periods
            ]
            months[column] = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=float)
        rows.append({well: item[well], "anchor_time": anchor, **_features_from_six_months(months)})
    return pd.DataFrame(rows, columns=[well, "anchor_time", *RCYL_FEATURES, *PRODUCTION_FEATURES])


def event_balanced_training_weights(frame: pd.DataFrame) -> np.ndarray:
    """Give each included event equal mass within a well, then mean-normalize."""
    counts = frame.groupby(["WELL_ID", "anchor_time"], sort=False).size()
    if counts.empty or counts.ne(12).any():
        raise DataContractError("Every included event must have exactly 12 training rows.")
    events_per_well = frame[["WELL_ID", "anchor_time"]].drop_duplicates().groupby("WELL_ID").size()
    raw = frame["WELL_ID"].map(1.0 / events_per_well).to_numpy(dtype=float)
    if not np.isfinite(raw).all() or (raw <= 0).any():
        raise DataContractError("Invalid event-balanced training weights.")
    return raw / float(raw.mean())


def fit_event_model(
    train: pd.DataFrame, features: list[str], *, seed: int, params: dict[str, Any]
) -> tuple[Pipeline, dict[str, float]]:
    x = train[features]
    scale = resolve_scale(train, "legacy_anchor_last", None)
    target = transform_target(train["RCYL"], scale)
    weights = event_balanced_training_weights(train)
    pipeline = Pipeline([
        ("preprocess", _preprocessor(x)),
        ("model", build_model("extra_trees", seed, params)),
    ])
    pipeline.fit(x, target, model__sample_weight=weights)
    return pipeline, {
        "min": float(weights.min()),
        "max": float(weights.max()),
        "mean": float(weights.mean()),
    }


def predict_event_model(model: Pipeline, valid: pd.DataFrame, features: list[str]) -> np.ndarray:
    scale = resolve_scale(valid, "legacy_anchor_last", None)
    transformed = np.asarray(model.predict(valid[features]), dtype=float)
    return inverse_target(transformed, scale)
