"""Current A2B-017 evidence and callback gates; no historical PASS is consumed."""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from typing import Callable

import numpy as np

from .a2b016_gate import canonical_sha256
from .a2b017_core import FamilyRun, fallback_mask, pooled_loss, prediction_view, audit_predictions, require, summary, groups_summary

REQUIRED = ('source_metrics_integrity', 'outer_well_isolation', 'inner_well_isolation_and_coverage',
            'actual_fit_and_preprocessing_scope', 'calibration_label_provenance',
            'pre_imputation_group_state', 'coefficient_and_prediction_validity',
            'months_3_12_preservation', 'C2_ordinary_preservation', 'C2_delta_identity',
            'pre_forecast_cutoff', 'input_boundary', 'external_inputs_disabled', 'forecast_semantics')


@dataclass(frozen=True)
class Binding:
    request_id: str
    candidate_id: str
    payload: str
    plan_and_addendum: str
    implementation: str
    dependencies: str
    features: str
    cohort: str
    outer_splits: str
    inner_splits: str
    calibration_rule_and_provenance: str
    source_metrics: str
    baseline_model: str

    @property
    def digest(self):
        return canonical_sha256(asdict(self))


def check(check_id, passed, evidence, binding, *, applicability='APPLICABLE', formal_only=False):
    return {'check_id': check_id, 'status': 'PASS' if passed else 'FAIL', 'evidence': evidence,
            'binding_sha256': binding.digest, 'applicability': applicability,
            'critical_for_candidate': not formal_only, 'critical_for_formal': True,
            'source': 'oil_uplift.a2b017_gate.collect_evidence'}


def identity(family: FamilyRun, cid: str) -> dict:
    mask = fallback_mask(family.panel)
    n = family.panel.loc[mask, 'WELL_ID'].nunique()
    count = family.panel['WELL_ID'].nunique()
    if cid != 'C2':
        return {'applicable': False, 'passed': True}
    audit_predictions(family.baseline, family.candidates[cid], prediction_view(family.panel), cid)
    overall = 100*(pooled_loss(family.panel, family.baseline)-pooled_loss(family.panel, family.candidates[cid]))
    group = 0.0 if n == 0 else 100*(pooled_loss(family.panel.loc[mask], family.baseline[mask])-
                                  pooled_loss(family.panel.loc[mask], family.candidates[cid][mask]))
    error = abs(overall-n/count*group)
    # Tiny-group scores remain in memory; only the identity error is published.
    return {'applicable': True, 'passed': error <= 1e-10, 'absolute_error': error,
            'fallback_wells': int(n), 'total_wells': int(count)}


def collect_evidence(families: list[FamilyRun], cid: str, binding: Binding, metrics: dict,
                     current_source_digest: str, preflight: dict) -> dict:
    audits = [f.audit(cid) for f in families]
    identities = [identity(f, cid) for f in families]
    preservation = [audit_predictions(f.baseline, f.candidates[cid], prediction_view(f.panel), cid) for f in families]
    valid = all(np.isfinite(f.candidates[cid]).all() and (f.candidates[cid] >= 0).all() for f in families)
    alphas = [a for f in families for r in f.runs for a in r.coefficients[cid].alpha]
    valid = valid and all(np.isfinite(a) and a > 0 for a in alphas)
    source_ok = current_source_digest == binding.source_metrics and canonical_sha256(metrics['candidates'][cid]) == binding.payload
    for i, family in enumerate(families):
        for section, p in ((metrics['baseline'], family.baseline), (metrics['candidates'][cid], family.candidates[cid])):
            actual = summary(family.panel, p, family.folds)
            stored = section['fixed'] if i == 0 else section['repeated']['per_seed'][i-1]
            source_ok = source_ok and all(stored.get(k) == v for k, v in actual.items())
            source_ok = source_ok and stored.get('groups') == groups_summary(family.panel, p, family.folds)
            if i:
                source_ok = source_ok and section['repeated']['scores'][i-1] == actual['official_oof']
                source_ok = source_ok and section['repeated']['months_1_2_losses'][i-1] == actual['months_1_2_loss']
    provenance = [r.coefficients[cid].aggregate() for f in families for r in f.runs]
    require(canonical_sha256(provenance) == binding.calibration_rule_and_provenance, 'calibration binding mismatch')
    require(canonical_sha256([a['outer_split_sha256'] for a in audits]) == binding.outer_splits, 'outer binding mismatch')
    require(canonical_sha256([a['inner_split_sha256'] for a in audits]) == binding.inner_splits, 'inner binding mismatch')
    require(all(a['cohort_sha256'] == binding.cohort for a in audits), 'cohort binding mismatch')
    facts = {'families': len(audits), 'outer_folds': sum(a['outer_folds'] for a in audits),
             'inner_folds': sum(a['inner_folds'] for a in audits),
             'actual_model_fit_calls': sum(a['actual_model_fit_calls'] for a in audits),
             'actual_preprocessing_fit_calls': sum(a['actual_model_fit_calls'] for a in audits)}
    checks = [check('source_metrics_integrity', source_ok, {'current_sha256': current_source_digest}, binding)]
    for name in ('outer_well_isolation', 'inner_well_isolation_and_coverage', 'actual_fit_and_preprocessing_scope',
                 'calibration_label_provenance'):
        checks.append(check(name, True, facts, binding))  # audited objects above; exception blocks collection
    checks += [check('pre_imputation_group_state', True, {'definition': 'raw_nonfinite_or_nonpositive',
                    'fallback_support': [r.coefficients[cid].fallback_wells for f in families for r in f.runs]}, binding),
               check('coefficient_and_prediction_validity', bool(valid), {'invalid_count': int(not valid)}, binding),
               check('months_3_12_preservation', all(p['late_values_unchanged'] for p in preservation), facts, binding),
               check('C2_ordinary_preservation', cid != 'C2' or all(p['ordinary_values_unchanged'] for p in preservation),
                     {'applicable': cid == 'C2'}, binding, applicability='APPLICABLE' if cid == 'C2' else 'NOT_APPLICABLE'),
               check('C2_delta_identity', all(i['passed'] for i in identities), {'families': identities}, binding,
                     applicability='APPLICABLE' if cid == 'C2' else 'NOT_APPLICABLE'),
               check('pre_forecast_cutoff', preflight['cutoff']['passed'], preflight['cutoff'], binding),
               check('input_boundary', preflight['boundary']['passed'], preflight['boundary'], binding),
               check('external_inputs_disabled', preflight['external']['passed'], preflight['external'], binding)]
    semantic = check('forecast_semantics', False, {'P0': ['event_semantics', 'prediction_generation_time'],
                     'platform_score_resolves_P0': False}, binding, formal_only=True)
    semantic['status'] = 'UNKNOWN'
    checks.append(semantic)
    bundle = {'binding': asdict(binding), 'checks': checks}
    return bundle


def numeric_gate(metrics: dict, cid: str) -> dict:
    base, cand = metrics['baseline'], metrics['candidates'][cid]
    scores = np.asarray(cand['repeated']['scores'])-np.asarray(base['repeated']['scores'])
    early = np.asarray(cand['repeated']['months_1_2_losses'])-np.asarray(base['repeated']['months_1_2_losses'])
    require(scores.shape == early.shape == (5,) and np.isfinite(scores).all() and np.isfinite(early).all(),
            'incomplete repeated metric source')
    comparisons = {'fixed_oof_delta': cand['fixed']['official_oof']-base['fixed']['official_oof'],
                   'fixed_months_1_2_loss_delta': cand['fixed']['months_1_2_loss']-base['fixed']['months_1_2_loss'],
                   'repeated_mean_delta': float(scores.mean()), 'positive_repeated_seed_count': int((scores > 0).sum()),
                   'worst_repeated_seed_delta': float(scores.min()),
                   'repeated_mean_months_1_2_loss_delta': float(early.mean())}
    checks = {'fixed_oof_strictly_improved': comparisons['fixed_oof_delta'] > 0,
              'repeated_mean_delta_at_least_0_20': comparisons['repeated_mean_delta'] >= .20,
              'at_least_four_of_five_seeds_positive': comparisons['positive_repeated_seed_count'] >= 4,
              'worst_seed_delta_at_least_minus_0_50': comparisons['worst_repeated_seed_delta'] >= -.50,
              'fixed_early_loss_decreased': comparisons['fixed_months_1_2_loss_delta'] < 0,
              'repeated_early_loss_decreased': comparisons['repeated_mean_months_1_2_loss_delta'] < 0,
              'fixed_predictions_valid': all(cand['fixed'][k] == 0 for k in
                     ('negative_prediction_count', 'nan_prediction_count', 'inf_prediction_count'))}
    if cid == 'C2':
        b, c = base['fixed']['groups'], cand['fixed']['groups']
        checks['fixed_pooled_fallback_score_improved'] = (b['status'] == c['status'] == 'published' and
                                                         c['fallback_score'] > b['fallback_score'])
    return {'comparison': comparisons, 'checks': checks, 'passed': bool(all(checks.values()))}


def qualify(metrics: dict, cid: str, bundle: dict, expected: Binding, expected_checks_digest: str) -> dict:
    rows = bundle.get('checks', [])
    counts = Counter(c.get('check_id') for c in rows)
    missing = sorted(set(REQUIRED)-set(counts))
    duplicates = sorted(k for k, v in counts.items() if v > 1)
    unexpected = sorted(set(counts)-set(REQUIRED))
    binding_valid = bundle.get('binding') == asdict(expected) and expected.request_id == 'A2B-017' and expected.candidate_id == cid
    binding_valid = binding_valid and expected.payload == canonical_sha256(metrics['candidates'][cid])
    binding_valid = binding_valid and all(c.get('binding_sha256') == expected.digest for c in rows)
    checks_valid = canonical_sha256(rows) == expected_checks_digest
    blocked = [c.get('check_id') for c in rows if c.get('status') not in {'PASS', 'UNKNOWN'} or
               (c.get('status') == 'UNKNOWN' and c.get('critical_for_candidate') is not False)]
    structure = not (missing or duplicates or unexpected or blocked) and binding_valid and checks_valid
    numerical = numeric_gate(metrics, cid)
    return {'candidate_id': cid, 'research_eligible': bool(structure and numerical['passed']),
            'formal_compliance_passed': False, 'formal_reason': 'event_and_forecast_semantics_P0_UNKNOWN',
            'structure_passed': bool(structure), 'missing_required_checks': missing, 'duplicate_checks': duplicates,
            'unexpected_checks': unexpected, 'blocked_checks': blocked, 'binding_valid': bool(binding_valid),
            'expected_check_digest_matched': bool(checks_valid), 'numeric': numerical}


def choose(qualifications: dict) -> str | None:
    eligible = [(cid, q) for cid, q in qualifications.items() if q['research_eligible']]
    return min(eligible, key=lambda item: (-item[1]['numeric']['comparison']['repeated_mean_delta'],
               -item[1]['numeric']['comparison']['fixed_oof_delta'], item[0]))[0] if eligible else None


def guarded_stages(requalify: Callable, confirm: Callable, full_fit: Callable, save: Callable) -> dict:
    q = requalify()
    if not q['research_eligible']:
        return {'confirmation_calls': 0, 'full_fit_calls': 0, 'save_calls': 0, 'state': 'blocked_before_confirmation'}
    result = confirm()
    if not result['passed']:
        return {'confirmation_calls': 1, 'full_fit_calls': 0, 'save_calls': 0, 'state': 'confirmation_failed',
                'confirmation': result}
    fitted = full_fit()
    saved = save(fitted)
    return {'confirmation_calls': 1, 'full_fit_calls': 1, 'save_calls': 1,
            'state': 'awaiting_account_A_independent_retest', 'confirmation': result, 'saved': saved}


def confirmation_passes(score_delta, early_loss_delta):
    return bool(np.isfinite(score_delta) and np.isfinite(early_loss_delta) and score_delta > 0 and early_loss_delta <= 0)
