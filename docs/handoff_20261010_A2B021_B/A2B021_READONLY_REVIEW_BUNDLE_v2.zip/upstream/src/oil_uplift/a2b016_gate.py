"""A2B-016 evidence-bound candidate qualification gate.

This module intentionally does not alter the frozen A2B-015 implementation.
It rebuilds candidate qualification from aggregate metrics and checks that are
executed against the candidate data path.  Passing this gate permits only the
research-candidate confirmation stage; it is not formal compliance approval.
"""

from __future__ import annotations

import ast
import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from sklearn.exceptions import NotFittedError
from sklearn.utils.validation import check_is_fitted

from .a2b013_safe import MODEL_NAME, SafeData, audit_pre_anchor_cutoff
from .a2b015_training import build_candidate_data, trend_feature_columns
from .exceptions import DataContractError
from .training import _model_pipeline


STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
STATUS_UNKNOWN = "UNKNOWN"

APPLICABLE = "APPLICABLE"
NOT_APPLICABLE = "NOT_APPLICABLE"
GLOBAL_ASSUMPTION = "GLOBAL_ASSUMPTION"

REQUIRED_CHECK_IDS = (
    "source_metrics_integrity",
    "well_id_fold_isolation",
    "pre_anchor_history_cutoff",
    "nontrend_and_labels_unchanged",
    "no_layer_or_first_plan_inputs",
    "fold_local_fit",
    "prediction_validity",
    "external_inputs_disabled",
    "historical_layer_availability",
    "forecast_time_and_event_semantics",
)


def canonical_sha256(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def implementation_fingerprint(root: Path, paths: Sequence[Path]) -> tuple[str, dict[str, str]]:
    components: dict[str, str] = {}
    for path in paths:
        resolved = path.resolve()
        if not resolved.is_file():
            raise DataContractError("A2B-016 implementation fingerprint source is missing.")
        try:
            relative = resolved.relative_to(root.resolve()).as_posix()
        except ValueError as exc:
            raise DataContractError("A2B-016 implementation source is outside the project root.") from exc
        components[relative] = file_sha256(resolved)
    return canonical_sha256(components), components


def feature_fingerprint(features: Sequence[str], registered_definition_sha256: str) -> str:
    return canonical_sha256({
        "ordered_features": list(features),
        "registered_definition_sha256": registered_definition_sha256,
    })


def split_fingerprint(split_families: Mapping[str, Sequence[tuple[np.ndarray, np.ndarray]]]) -> str:
    payload: dict[str, list[dict[str, Any]]] = {}
    for family, splits in sorted(split_families.items()):
        payload[family] = []
        for train_index, valid_index in splits:
            train = np.asarray(train_index, dtype=np.int64)
            valid = np.asarray(valid_index, dtype=np.int64)
            payload[family].append({
                "train_count": int(len(train)),
                "validation_count": int(len(valid)),
                "train_index_sha256": hashlib.sha256(train.tobytes()).hexdigest(),
                "validation_index_sha256": hashlib.sha256(valid.tobytes()).hexdigest(),
            })
    return canonical_sha256(payload)


@dataclass(frozen=True)
class EvidenceBinding:
    request_id: str
    source_request_id: str
    candidate_id: str
    source_metrics_sha256: str
    candidate_payload_sha256: str
    implementation_sha256: str
    feature_definition_sha256: str
    split_sha256: str

    def as_dict(self) -> dict[str, str]:
        return asdict(self)

    @property
    def sha256(self) -> str:
        return canonical_sha256(self.as_dict())


@dataclass(frozen=True)
class GateCheck:
    check_id: str
    status: str
    evidence: dict[str, Any]
    source: str
    binding_sha256: str
    applicability: str = APPLICABLE
    critical_for_candidate: bool = True
    critical_for_formal: bool = True

    def __post_init__(self) -> None:
        if self.status not in {STATUS_PASS, STATUS_FAIL, STATUS_UNKNOWN}:
            raise DataContractError("A2B-016 status must be PASS, FAIL, or UNKNOWN.")
        if self.applicability not in {APPLICABLE, NOT_APPLICABLE, GLOBAL_ASSUMPTION}:
            raise DataContractError("A2B-016 applicability is invalid.")

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EvidenceBundle:
    binding: EvidenceBinding
    checks: tuple[GateCheck, ...]
    implementation_components: dict[str, str]

    def as_dict(self) -> dict[str, Any]:
        return {
            "binding": {**self.binding.as_dict(), "binding_sha256": self.binding.sha256},
            "checks": [check.as_dict() for check in self.checks],
            "implementation_components": dict(self.implementation_components),
        }


def build_binding(
    *,
    candidate_id: str,
    source_metrics: Mapping[str, Any],
    source_metrics_sha256: str,
    implementation_sha256: str,
    feature_definition_sha256: str,
    split_sha256: str,
) -> EvidenceBinding:
    candidates = source_metrics.get("candidates", {})
    if candidate_id not in candidates:
        raise DataContractError("A2B-016 candidate is absent from the source metrics.")
    return EvidenceBinding(
        request_id="A2B-016",
        source_request_id=str(source_metrics.get("request_id", "")),
        candidate_id=candidate_id,
        source_metrics_sha256=source_metrics_sha256,
        candidate_payload_sha256=canonical_sha256(candidates[candidate_id]),
        implementation_sha256=implementation_sha256,
        feature_definition_sha256=feature_definition_sha256,
        split_sha256=split_sha256,
    )


def source_metrics_integrity_check(
    actual_sha256: str,
    expected_sha256: str,
    binding: EvidenceBinding,
) -> GateCheck:
    matched = actual_sha256 == expected_sha256 == binding.source_metrics_sha256
    return GateCheck(
        "source_metrics_integrity",
        STATUS_PASS if matched else STATUS_FAIL,
        {
            "expected_hash_present": bool(expected_sha256),
            "actual_matches_expected": matched,
            "legacy_main_gate_consumed": False,
            "legacy_leakage_audit_consumed": False,
        },
        "oil_uplift.a2b016_gate.source_metrics_integrity_check",
        binding.sha256,
    )


def audit_well_isolation(
    panel: pd.DataFrame,
    split_families: Mapping[str, Sequence[tuple[np.ndarray, np.ndarray]]],
    binding: EvidenceBinding,
) -> GateCheck:
    failures = 0
    folds_checked = 0
    coverage_failures = 0
    minimum_train_wells: int | None = None
    minimum_valid_wells: int | None = None
    row_count = len(panel)
    if "WELL_ID" not in panel or row_count == 0 or not split_families:
        failures += 1
    else:
        for splits in split_families.values():
            coverage = np.zeros(row_count, dtype=np.int16)
            if not splits:
                coverage_failures += 1
                continue
            for train_index, valid_index in splits:
                folds_checked += 1
                train = np.asarray(train_index, dtype=int)
                valid = np.asarray(valid_index, dtype=int)
                invalid_indices = (
                    train.ndim != 1
                    or valid.ndim != 1
                    or len(np.unique(train)) != len(train)
                    or len(np.unique(valid)) != len(valid)
                    or (len(train) and (train.min() < 0 or train.max() >= row_count))
                    or (len(valid) and (valid.min() < 0 or valid.max() >= row_count))
                    or bool(set(train.tolist()) & set(valid.tolist()))
                )
                if invalid_indices or not len(train) or not len(valid):
                    failures += 1
                    continue
                train_wells = set(panel.iloc[train]["WELL_ID"])
                valid_wells = set(panel.iloc[valid]["WELL_ID"])
                failures += int(bool(train_wells & valid_wells))
                coverage[valid] += 1
                minimum_train_wells = len(train_wells) if minimum_train_wells is None else min(minimum_train_wells, len(train_wells))
                minimum_valid_wells = len(valid_wells) if minimum_valid_wells is None else min(minimum_valid_wells, len(valid_wells))
            coverage_failures += int(not np.array_equal(coverage, np.ones(row_count, dtype=np.int16)))
    failures += coverage_failures
    return GateCheck(
        "well_id_fold_isolation",
        STATUS_FAIL if failures else STATUS_PASS,
        {
            "split_families_checked": len(split_families),
            "folds_checked": folds_checked,
            "overlap_or_index_failures": failures - coverage_failures,
            "coverage_failures": coverage_failures,
            "minimum_training_wells": minimum_train_wells or 0,
            "minimum_validation_wells": minimum_valid_wells or 0,
        },
        "oil_uplift.a2b016_gate.audit_well_isolation",
        binding.sha256,
    )


def _anchor_periods(panel: pd.DataFrame, config: Mapping[str, Any]) -> pd.DataFrame:
    well = config["anchors"]["well_column"]
    anchors = panel.loc[:, [well, "anchor_time"]].drop_duplicates().copy()
    anchors["anchor_period"] = pd.to_datetime(anchors.pop("anchor_time"), errors="coerce").dt.to_period("M")
    return anchors


def _perturb_at_or_after_anchor(
    history: pd.DataFrame,
    panel: pd.DataFrame,
    config: Mapping[str, Any],
) -> tuple[pd.DataFrame, int, int]:
    well = config["anchors"]["well_column"]
    date = config["anchors"]["date_column"]
    local = history.copy()
    periods = pd.to_datetime(local[date], errors="coerce").dt.to_period("M")
    anchors = _anchor_periods(panel, config).set_index(well)["anchor_period"]
    row_anchors = local[well].map(anchors)
    mask = row_anchors.notna() & periods.notna() & (periods >= row_anchors)
    changed_values = 0
    for column in config["features"]["history_numeric_columns"]:
        if column not in local:
            continue
        numeric = pd.to_numeric(local[column], errors="coerce")
        changed = mask & np.isfinite(numeric.to_numpy(dtype=float))
        local.loc[changed, column] = numeric.loc[changed] + 1000003.25
        changed_values += int(changed.sum())
    return local, int(mask.sum()), changed_values


def audit_pre_anchor_history(
    baseline: SafeData,
    candidate: SafeData,
    train_history: pd.DataFrame,
    test_history: pd.DataFrame,
    config: dict[str, Any],
    binding: EvidenceBinding,
) -> GateCheck:
    failure = False
    evidence: dict[str, Any] = {
        "train_events_checked": 0,
        "test_events_checked": 0,
        "feature_values_checked": 0,
        "future_sensitive_feature_count": 0,
        "future_rows_perturbed": 0,
        "future_numeric_values_perturbed": 0,
        "candidate_features_unchanged_after_future_perturbation": False,
    }
    try:
        train_cutoff = audit_pre_anchor_cutoff(train_history, _anchor_periods(baseline.train, config), config)
        test_cutoff = audit_pre_anchor_cutoff(test_history, _anchor_periods(baseline.test, config), config)
        perturbed_train, train_rows, train_values = _perturb_at_or_after_anchor(train_history, baseline.train, config)
        perturbed_test, test_rows, test_values = _perturb_at_or_after_anchor(test_history, baseline.test, config)
        perturbed_candidate, _, _ = build_candidate_data(
            baseline, perturbed_train, perturbed_test, config
        )
        invariant = (
            candidate.train.loc[:, candidate.features].equals(
                perturbed_candidate.train.loc[:, perturbed_candidate.features]
            )
            and candidate.test.loc[:, candidate.features].equals(
                perturbed_candidate.test.loc[:, perturbed_candidate.features]
            )
        )
        future_sensitive = int(train_cutoff["future_sensitive_feature_count"]) + int(
            test_cutoff["future_sensitive_feature_count"]
        )
        failure = not invariant or future_sensitive != 0 or train_rows + test_rows == 0
        evidence.update({
            "train_events_checked": int(train_cutoff["events_checked"]),
            "test_events_checked": int(test_cutoff["events_checked"]),
            "feature_values_checked": int(train_cutoff["feature_values_checked"] + test_cutoff["feature_values_checked"]),
            "future_sensitive_feature_count": future_sensitive,
            "future_rows_perturbed": train_rows + test_rows,
            "future_numeric_values_perturbed": train_values + test_values,
            "candidate_features_unchanged_after_future_perturbation": invariant,
        })
    except (DataContractError, KeyError, TypeError, ValueError):
        failure = True
        evidence["check_exception"] = True
    return GateCheck(
        "pre_anchor_history_cutoff",
        STATUS_FAIL if failure else STATUS_PASS,
        evidence,
        "oil_uplift.a2b016_gate.audit_pre_anchor_history",
        binding.sha256,
    )


def audit_nontrend_and_labels(
    baseline: SafeData,
    candidate: SafeData,
    config: Mapping[str, Any],
    binding: EvidenceBinding,
) -> GateCheck:
    trends = set(trend_feature_columns(dict(config)))
    train_nontrend = [column for column in baseline.train.columns if column not in trends]
    test_nontrend = [column for column in baseline.test.columns if column not in trends]
    feature_order_match = baseline.features == candidate.features
    train_match = baseline.train.loc[:, train_nontrend].equals(candidate.train.loc[:, train_nontrend])
    test_match = baseline.test.loc[:, test_nontrend].equals(candidate.test.loc[:, test_nontrend])
    reference_match = baseline.reference.equals(candidate.reference)
    target_match = baseline.train["RCYL"].equals(candidate.train["RCYL"])
    passed = feature_order_match and train_match and test_match and reference_match and target_match
    return GateCheck(
        "nontrend_and_labels_unchanged",
        STATUS_PASS if passed else STATUS_FAIL,
        {
            "feature_order_match": feature_order_match,
            "train_nontrend_columns_checked": len(train_nontrend),
            "test_nontrend_columns_checked": len(test_nontrend),
            "train_nontrend_match": train_match,
            "test_nontrend_match": test_match,
            "labels_unchanged": target_match,
            "test_template_reference_unchanged": reference_match,
        },
        "oil_uplift.a2b016_gate.audit_nontrend_and_labels",
        binding.sha256,
    )


def audit_input_boundary(candidate: SafeData, binding: EvidenceBinding) -> GateCheck:
    layer = [name for name in candidate.features if name.startswith("layer__")]
    first_plan = [name for name in candidate.features if name.startswith("plan_first__")]
    target_or_future = [
        name for name in candidate.features
        if name == "RCYL" or name.startswith(("target__", "label__", "prediction_window__"))
    ]
    audit = candidate.audit
    declared_layer = int(audit.get("layer_feature_count", -1))
    declared_plan = int(audit.get("first_plan_feature_count", -1))
    passed = not layer and not first_plan and not target_or_future and declared_layer == 0 and declared_plan == 0
    return GateCheck(
        "no_layer_or_first_plan_inputs",
        STATUS_PASS if passed else STATUS_FAIL,
        {
            "feature_count": len(candidate.features),
            "layer_feature_count": len(layer),
            "first_plan_feature_count": len(first_plan),
            "target_or_prediction_window_feature_count": len(target_or_future),
            "builder_declared_layer_feature_count": declared_layer,
            "builder_declared_first_plan_feature_count": declared_plan,
        },
        "oil_uplift.a2b016_gate.audit_input_boundary",
        binding.sha256,
    )


def _function_call_lines(path: Path, function_name: str) -> dict[str, int]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    function = next(
        (node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name),
        None,
    )
    if function is None:
        return {}
    lines: dict[str, int] = {}
    for node in ast.walk(function):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Name):
            name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            name = node.func.attr
        else:
            continue
        lines.setdefault(name, int(node.lineno))
    return lines


def audit_fold_local_fit(
    panel: pd.DataFrame,
    features: Sequence[str],
    config: dict[str, Any],
    split_families: Mapping[str, Sequence[tuple[np.ndarray, np.ndarray]]],
    fit_source_path: Path,
    binding: EvidenceBinding,
) -> GateCheck:
    checked = 0
    prefitted = 0
    estimators: list[Any] = []
    failure = False
    try:
        for splits in split_families.values():
            for train_index, valid_index in splits:
                train = panel.iloc[np.asarray(train_index, dtype=int)]
                valid = panel.iloc[np.asarray(valid_index, dtype=int)]
                if train.empty or valid.empty:
                    failure = True
                    continue
                estimator = _model_pipeline(MODEL_NAME, train.loc[:, list(features)], config)
                try:
                    check_is_fitted(estimator)
                    prefitted += 1
                except NotFittedError:
                    pass
                estimators.append(estimator)
                checked += 1
        unique_instances = len({id(item) for item in estimators})
        calls = _function_call_lines(fit_source_path, "fit_and_predict")
        required_calls = ("_model_pipeline", "_fit_pipeline", "predict_pipeline_output")
        ordered = all(name in calls for name in required_calls) and (
            calls["_model_pipeline"] < calls["_fit_pipeline"] < calls["predict_pipeline_output"]
        )
        failure = failure or checked == 0 or prefitted != 0 or unique_instances != checked or not ordered
    except (DataContractError, KeyError, TypeError, ValueError):
        calls = {}
        unique_instances = 0
        ordered = False
        failure = True
    return GateCheck(
        "fold_local_fit",
        STATUS_FAIL if failure else STATUS_PASS,
        {
            "fold_factories_executed": checked,
            "fresh_estimator_instances": unique_instances,
            "prefitted_estimator_count": prefitted,
            "fit_path_factory_before_fit_before_predict": ordered,
            "fit_path_required_call_count": sum(name in calls for name in ("_model_pipeline", "_fit_pipeline", "predict_pipeline_output")),
        },
        "oil_uplift.a2b016_gate.audit_fold_local_fit",
        binding.sha256,
    )


def audit_prediction_validity(candidate_metrics: Mapping[str, Any], binding: EvidenceBinding) -> GateCheck:
    fixed = candidate_metrics.get("fixed", {})
    repeated = candidate_metrics.get("repeated", {})
    required = ("negative_prediction_count", "nan_prediction_count", "inf_prediction_count")
    missing = [name for name in required if name not in fixed]
    invalid_count = sum(int(fixed.get(name, 1)) for name in required)
    repeated_scores = np.asarray(repeated.get("scores", []), dtype=float)
    repeated_early = np.asarray(repeated.get("months_1_2_losses", []), dtype=float)
    aggregate_finite = (
        repeated_scores.shape == (5,)
        and repeated_early.shape == (5,)
        and np.isfinite(repeated_scores).all()
        and np.isfinite(repeated_early).all()
        and np.isfinite(float(fixed.get("official_oof", np.nan)))
    )
    passed = not missing and invalid_count == 0 and bool(aggregate_finite)
    return GateCheck(
        "prediction_validity",
        STATUS_PASS if passed else STATUS_FAIL,
        {
            "missing_validity_fields": len(missing),
            "negative_nan_or_inf_count": invalid_count,
            "fixed_and_repeated_aggregates_finite": bool(aggregate_finite),
            "row_level_predictions_consumed": False,
            "source": "frozen_aggregate_metrics_bound_by_sha256",
        },
        "oil_uplift.a2b016_gate.audit_prediction_validity",
        binding.sha256,
    )


def audit_external_inputs(
    config: Mapping[str, Any],
    source_paths: Sequence[Path],
    binding: EvidenceBinding,
) -> GateCheck:
    denied_modules = {"requests", "urllib", "http", "socket", "boto3", "huggingface_hub", "datasets"}
    network_imports = remote_literals = pretrained_loads = missing_sources = 0
    for path in source_paths:
        if not path.is_file():
            missing_sources += 1
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                network_imports += sum(alias.name.split(".")[0] in denied_modules for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                network_imports += int(node.module.split(".")[0] in denied_modules)
            elif isinstance(node, ast.Constant) and isinstance(node.value, str):
                remote_literals += int(node.value.startswith(("http://", "https://", "s3://", "hf://")))
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                pretrained_loads += int(node.func.attr in {"load_model", "load_pretrained", "from_pretrained"})
    project = config.get("project", {})
    policy_ok = project.get("allow_external_data") is False and project.get("allow_pretrained_weights") is False
    failures = network_imports + remote_literals + pretrained_loads + missing_sources + int(not policy_ok)
    return GateCheck(
        "external_inputs_disabled",
        STATUS_FAIL if failures else STATUS_PASS,
        {
            "policy_disables_external_data_and_pretrained_weights": policy_ok,
            "source_files_checked": len(source_paths),
            "network_imports": network_imports,
            "remote_literals": remote_literals,
            "pretrained_load_calls": pretrained_loads,
            "missing_source_files": missing_sources,
        },
        "oil_uplift.a2b016_gate.audit_external_inputs",
        binding.sha256,
    )


def historical_layer_availability_check(features: Sequence[str], binding: EvidenceBinding) -> GateCheck:
    used = sum(name.startswith("layer__") for name in features)
    return GateCheck(
        "historical_layer_availability",
        STATUS_UNKNOWN,
        {
            "layer_feature_count_used": used,
            "timestamp_proof_available": False,
            "disposition": "not_applicable_because_candidate_uses_no_layer_fields" if not used else "candidate_relevant_unknown",
        },
        "oil_uplift.a2b016_gate.historical_layer_availability_check",
        binding.sha256,
        applicability=NOT_APPLICABLE if not used else APPLICABLE,
        critical_for_candidate=bool(used),
        critical_for_formal=bool(used),
    )


def forecast_semantics_check(binding: EvidenceBinding) -> GateCheck:
    return GateCheck(
        "forecast_time_and_event_semantics",
        STATUS_UNKNOWN,
        {
            "same_assumption_research_authorized": True,
            "organizer_confirmation_available": False,
            "formal_compliance_confirmed": False,
            "disposition": "research_allowed_formal_compliance_blocked",
        },
        "oil_uplift.a2b016_gate.forecast_semantics_check",
        binding.sha256,
        applicability=GLOBAL_ASSUMPTION,
        critical_for_candidate=False,
        critical_for_formal=True,
    )


def collect_candidate_evidence(
    *,
    root: Path,
    candidate_id: str,
    source_metrics: Mapping[str, Any],
    source_metrics_sha256: str,
    expected_source_metrics_sha256: str,
    registered_feature_definition_sha256: str,
    baseline: SafeData,
    candidate: SafeData,
    train_history: pd.DataFrame,
    test_history: pd.DataFrame,
    config: dict[str, Any],
    split_families: Mapping[str, Sequence[tuple[np.ndarray, np.ndarray]]],
    implementation_paths: Sequence[Path],
    external_audit_paths: Sequence[Path],
    fit_source_path: Path,
) -> EvidenceBundle:
    implementation_hash, components = implementation_fingerprint(root, implementation_paths)
    binding = build_binding(
        candidate_id=candidate_id,
        source_metrics=source_metrics,
        source_metrics_sha256=source_metrics_sha256,
        implementation_sha256=implementation_hash,
        feature_definition_sha256=feature_fingerprint(candidate.features, registered_feature_definition_sha256),
        split_sha256=split_fingerprint(split_families),
    )
    candidate_metrics = source_metrics["candidates"][candidate_id]
    checks = (
        source_metrics_integrity_check(source_metrics_sha256, expected_source_metrics_sha256, binding),
        audit_well_isolation(candidate.train, split_families, binding),
        audit_pre_anchor_history(baseline, candidate, train_history, test_history, config, binding),
        audit_nontrend_and_labels(baseline, candidate, config, binding),
        audit_input_boundary(candidate, binding),
        audit_fold_local_fit(candidate.train, candidate.features, config, split_families, fit_source_path, binding),
        audit_prediction_validity(candidate_metrics, binding),
        audit_external_inputs(config, external_audit_paths, binding),
        historical_layer_availability_check(candidate.features, binding),
        forecast_semantics_check(binding),
    )
    return EvidenceBundle(binding=binding, checks=checks, implementation_components=components)


def _close(left: Any, right: Any) -> bool:
    try:
        return bool(np.isclose(float(left), float(right), rtol=1e-12, atol=1e-12))
    except (TypeError, ValueError):
        return False


def recompute_numeric_gate(source_metrics: Mapping[str, Any], candidate_id: str) -> dict[str, Any]:
    baseline = source_metrics["baseline"]
    candidate = source_metrics["candidates"][candidate_id]
    baseline_fixed = baseline["fixed"]
    candidate_fixed = candidate["fixed"]
    baseline_scores = np.asarray(baseline["repeated"]["scores"], dtype=float)
    candidate_scores = np.asarray(candidate["repeated"]["scores"], dtype=float)
    baseline_early = np.asarray(baseline["repeated"]["months_1_2_losses"], dtype=float)
    candidate_early = np.asarray(candidate["repeated"]["months_1_2_losses"], dtype=float)
    if any(values.shape != (5,) or not np.isfinite(values).all() for values in (
        baseline_scores, candidate_scores, baseline_early, candidate_early
    )):
        raise DataContractError("A2B-016 frozen repeated aggregates are incomplete or invalid.")
    score_deltas = candidate_scores - baseline_scores
    early_deltas = candidate_early - baseline_early
    comparison = {
        "fixed_oof_delta": float(candidate_fixed["official_oof"] - baseline_fixed["official_oof"]),
        "repeated_mean_delta": float(np.mean(score_deltas)),
        "positive_repeated_seed_count": int(np.sum(score_deltas > 0)),
        "worst_repeated_seed_delta": float(np.min(score_deltas)),
        "fixed_months_1_2_loss_delta": float(candidate_fixed["months_1_2_loss"] - baseline_fixed["months_1_2_loss"]),
        "repeated_mean_months_1_2_loss_delta": float(np.mean(early_deltas)),
    }
    stored = candidate.get("comparison", {})
    stored_consistent = all(_close(comparison[name], stored.get(name)) for name in comparison)
    checks = {
        "stored_comparison_matches_recomputation": stored_consistent,
        "fixed_oof_strictly_improved": comparison["fixed_oof_delta"] > 0,
        "repeated_mean_delta_at_least_0_20": comparison["repeated_mean_delta"] >= 0.20,
        "at_least_four_of_five_seeds_positive": comparison["positive_repeated_seed_count"] >= 4,
        "worst_seed_delta_at_least_minus_0_50": comparison["worst_repeated_seed_delta"] >= -0.50,
        "fixed_months_1_2_loss_decreased": comparison["fixed_months_1_2_loss_delta"] < 0,
        "repeated_mean_months_1_2_loss_decreased": comparison["repeated_mean_months_1_2_loss_delta"] < 0,
    }
    return {
        "comparison": comparison,
        "checks": checks,
        "passed": bool(all(checks.values())),
        "legacy_main_gates_consumed": False,
    }


def evaluate_candidate_qualification(
    source_metrics: Mapping[str, Any],
    candidate_id: str,
    bundle: EvidenceBundle,
    expected_binding: EvidenceBinding,
) -> dict[str, Any]:
    numeric = recompute_numeric_gate(source_metrics, candidate_id)
    check_ids = [check.check_id for check in bundle.checks]
    duplicates = sorted({check_id for check_id in check_ids if check_ids.count(check_id) > 1})
    missing = sorted(set(REQUIRED_CHECK_IDS) - set(check_ids))
    unexpected = sorted(set(check_ids) - set(REQUIRED_CHECK_IDS))
    binding_match = bundle.binding == expected_binding and all(
        check.binding_sha256 == expected_binding.sha256 for check in bundle.checks
    )
    identity_match = (
        bundle.binding.candidate_id == candidate_id
        and bundle.binding.source_request_id == str(source_metrics.get("request_id", ""))
        and bundle.binding.candidate_payload_sha256 == canonical_sha256(source_metrics["candidates"].get(candidate_id))
    )
    fail_ids = sorted(check.check_id for check in bundle.checks if check.status == STATUS_FAIL)
    candidate_unknown_ids = sorted(
        check.check_id for check in bundle.checks
        if check.status == STATUS_UNKNOWN and check.critical_for_candidate
    )
    formal_unknown_ids = sorted(
        check.check_id for check in bundle.checks
        if check.status == STATUS_UNKNOWN and check.critical_for_formal
    )
    evidence_passed = not (
        missing or duplicates or unexpected or not binding_match or not identity_match or fail_ids or candidate_unknown_ids
    )
    formal_compliance_passed = evidence_passed and not formal_unknown_ids
    eligible = bool(numeric["passed"] and evidence_passed)
    return {
        "candidate_id": candidate_id,
        "status": "eligible_for_confirmation_pending_independent_review" if eligible else "blocked_before_confirmation",
        "eligible_for_research_candidate_confirmation": eligible,
        "formal_compliance_passed": formal_compliance_passed,
        "formal_compliance_status": "confirmed" if formal_compliance_passed else "unconfirmed_or_blocked",
        "numeric_gate": numeric,
        "evidence_gate": {
            "passed": evidence_passed,
            "missing_required_checks": missing,
            "duplicate_checks": duplicates,
            "unexpected_checks": unexpected,
            "fail_checks": fail_ids,
            "candidate_critical_unknown_checks": candidate_unknown_ids,
            "formal_critical_unknown_checks": formal_unknown_ids,
            "binding_match": binding_match,
            "candidate_identity_match": identity_match,
        },
        "binding_sha256": expected_binding.sha256,
    }


def _confirmation_passed(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, Mapping):
        return bool(value.get("passed", False))
    return False


def execute_candidate_upgrade(
    *,
    source_metrics: Mapping[str, Any],
    candidate_id: str,
    bundle: EvidenceBundle,
    expected_binding: EvidenceBinding,
    confirmation_runner: Callable[[str], Any],
    full_fit_runner: Callable[[str], Any],
    artifact_saver: Callable[[str, Any], Any],
) -> dict[str, Any]:
    """Guard the real promotion callbacks; all checks precede any callback."""
    decision = evaluate_candidate_qualification(source_metrics, candidate_id, bundle, expected_binding)
    if not decision["eligible_for_research_candidate_confirmation"]:
        return {**decision, "confirmation_called": False, "full_fit_called": False, "save_called": False}
    confirmation = confirmation_runner(candidate_id)
    if not _confirmation_passed(confirmation):
        return {
            **decision,
            "status": "confirmation_failed_no_full_fit_or_save",
            "confirmation_called": True,
            "full_fit_called": False,
            "save_called": False,
        }
    fitted = full_fit_runner(candidate_id)
    saved = artifact_saver(candidate_id, fitted)
    return {
        **decision,
        "status": "candidate_artifact_saved_pending_independent_review",
        "confirmation_called": True,
        "full_fit_called": True,
        "save_called": True,
        "save_result": saved,
    }


def status_counts(checks: Iterable[GateCheck]) -> dict[str, int]:
    items = list(checks)
    return {
        status: sum(check.status == status for check in items)
        for status in (STATUS_PASS, STATUS_FAIL, STATUS_UNKNOWN)
    }
