"""A2B-011 isolated leakage gates and guarded only11 training helpers."""

from __future__ import annotations

import ast
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
from sklearn.exceptions import NotFittedError
from sklearn.pipeline import Pipeline
from sklearn.utils.validation import check_is_fitted

from .a2b006_training import inverse_target, resolve_scale, transform_target
from .a2b009_training import event_balanced_training_weights
from .exceptions import DataContractError
from .models import build_model
from .multistep import _history_features
from .training import _preprocessor


STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
STATUS_UNKNOWN = "UNKNOWN"
ALLOWED_SHARED = {"horizon", "forecast_step", "history_month_count"}


@dataclass(frozen=True)
class AuditCheck:
    check_id: str
    status: str
    evidence: dict[str, int | float | str | bool]
    location: str
    critical_for_training: bool = True
    critical_for_upgrade: bool = True

    def __post_init__(self) -> None:
        if self.status not in {STATUS_PASS, STATUS_FAIL, STATUS_UNKNOWN}:
            raise DataContractError("A2B-011 audit status must be PASS, FAIL, or UNKNOWN.")

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def training_gate(checks: Iterable[AuditCheck]) -> bool:
    """Any FAIL is a hard stop; critical UNKNOWN also stops strict training."""
    return all(
        check.status != STATUS_FAIL
        and not (check.critical_for_training and check.status == STATUS_UNKNOWN)
        for check in checks
    )


def upgrade_gate(checks: Iterable[AuditCheck]) -> bool:
    """No critical UNKNOWN may be interpreted as a safety PASS."""
    return all(
        check.status != STATUS_FAIL
        and not (check.critical_for_upgrade and check.status == STATUS_UNKNOWN)
        for check in checks
    )


def _same_value(left: Any, right: Any) -> bool:
    if pd.isna(left) and pd.isna(right):
        return True
    try:
        a, b = float(left), float(right)
        return bool(np.isclose(a, b, rtol=1e-12, atol=1e-12, equal_nan=True))
    except (TypeError, ValueError):
        return str(left) == str(right)


def audit_feature_boundary(features: list[str]) -> list[AuditCheck]:
    """Allow only the preregistered no-layer history and shared horizon fields."""
    bad_future = sum(
        name.startswith(("target__", "future__", "prediction_window__"))
        or name in {"RCYL", "NY", "anchor_time", "WELL_ID"}
        for name in features
    )
    bad_late = sum(name.startswith(("plan_first__", "layer__")) for name in features)
    bad_other = sum(
        not (name.startswith("history__") or name in ALLOWED_SHARED)
        for name in features
    )
    duplicate_count = len(features) - len(set(features))
    return [
        AuditCheck(
            "target_or_future_feature",
            STATUS_FAIL if bad_future or bad_other or duplicate_count else STATUS_PASS,
            {"feature_count": len(features), "future_or_target_count": bad_future,
             "unregistered_count": bad_other, "duplicate_count": duplicate_count},
            "oil_uplift.a2b011_training.audit_feature_boundary",
        ),
        AuditCheck(
            "late_plan_or_layer_excluded",
            STATUS_FAIL if bad_late else STATUS_PASS,
            {"late_or_layer_feature_count": bad_late},
            "oil_uplift.a2b011_training.audit_feature_boundary",
        ),
    ]


def audit_history_cutoff(
    panel: pd.DataFrame,
    history: pd.DataFrame,
    config: dict[str, Any],
    features: list[str],
) -> AuditCheck:
    """Recompute each event from pre-anchor rows and compare all selected history fields."""
    well = config["anchors"]["well_column"]
    date = config["anchors"]["date_column"]
    required = {well, "anchor_time", "horizon", "RCYL", *features}
    if not required.issubset(panel.columns) or not {well, date}.issubset(history.columns):
        return AuditCheck("history_pre_anchor_cutoff", STATUS_FAIL,
                          {"missing_required_columns": True},
                          "oil_uplift.a2b011_training.audit_history_cutoff")
    local = history.copy()
    local["__audit_period"] = pd.to_datetime(local[date], errors="coerce").dt.to_period("M")
    duplicates = int(local.duplicated([well, "__audit_period"]).sum())
    invalid_dates = int(local["__audit_period"].isna().sum())
    historical = [name for name in features if name.startswith("history__")]
    keys = [*historical, "history_month_count"]
    mismatch_count = 0
    event_count = 0
    for (well_value, anchor_value), event in panel.groupby([well, "anchor_time"], sort=False):
        event_count += 1
        anchor_period = pd.Timestamp(anchor_value).to_period("M")
        prior_month = (anchor_period - 1).to_timestamp()
        if len(event) != 12 or sorted(event["horizon"].tolist()) != list(range(1, 13)):
            mismatch_count += 1
            continue
        trimmed = local.loc[(local[well] == well_value) & (local["__audit_period"] < anchor_period)]
        full_values = _history_features(local, well_value, prior_month, config)
        trimmed_values = _history_features(trimmed, well_value, prior_month, config)
        first = event.iloc[0]
        for name in keys:
            if name not in full_values or name not in first or not _same_value(full_values[name], trimmed_values[name]) or not _same_value(first[name], trimmed_values[name]):
                mismatch_count += 1
            if any(not _same_value(value, first[name]) for value in event[name].iloc[1:]):
                mismatch_count += 1
    status = STATUS_FAIL if mismatch_count or duplicates or invalid_dates or not event_count else STATUS_PASS
    return AuditCheck(
        "history_pre_anchor_cutoff", status,
        {"events_checked": event_count, "history_fields_checked_per_event": len(keys),
         "value_or_horizon_mismatches": mismatch_count, "duplicate_well_months": duplicates,
         "invalid_history_dates": invalid_dates},
        "oil_uplift.a2b011_training.audit_history_cutoff",
    )


def audit_fold_isolation(
    train_wells: set[Any], valid_wells: set[Any], auxiliary_wells: set[Any]
) -> list[AuditCheck]:
    overlap = len(train_wells & valid_wells)
    auxiliary_overlap = len(auxiliary_wells & valid_wells)
    return [
        AuditCheck("train_validation_well_isolation",
                   STATUS_FAIL if overlap else STATUS_PASS,
                   {"train_unique_wells": len(train_wells), "validation_unique_wells": len(valid_wells),
                    "overlap_count": overlap},
                   "oil_uplift.a2b011_training.audit_fold_isolation"),
        AuditCheck("validation_history_excluded_from_auxiliary",
                   STATUS_FAIL if auxiliary_overlap else STATUS_PASS,
                   {"auxiliary_unique_wells": len(auxiliary_wells),
                    "validation_auxiliary_overlap_count": auxiliary_overlap},
                   "oil_uplift.a2b011_training.audit_fold_isolation"),
    ]


def audit_preprocessor_scope(preprocessor: Any, train_rows: int, validation_rows: int) -> AuditCheck:
    """Reject an already fitted transformer before every outer-fold fit."""
    try:
        check_is_fitted(preprocessor)
        already_fitted = True
    except NotFittedError:
        already_fitted = False
    invalid_size = train_rows <= 0 or validation_rows <= 0
    return AuditCheck(
        "fold_local_preprocessing",
        STATUS_FAIL if already_fitted or invalid_size else STATUS_PASS,
        {"pre_fitted_transformer": already_fitted, "train_rows": train_rows,
         "validation_rows": validation_rows},
        "oil_uplift.a2b011_training.audit_preprocessor_scope",
    )


def audit_layer_availability(features: list[str], has_timestamp_proof: bool = False) -> AuditCheck:
    """Unknown provenance remains UNKNOWN even when no layer feature is selected."""
    used = sum(name.startswith("layer__") for name in features)
    status = STATUS_PASS if has_timestamp_proof else STATUS_UNKNOWN
    return AuditCheck(
        "historical_layer_availability", status,
        {"layer_feature_count_used": used, "timestamp_proof": has_timestamp_proof},
        "oil_uplift.a2b011_training.audit_layer_availability",
        critical_for_training=bool(used), critical_for_upgrade=bool(used),
    )


def audit_external_dependencies(source_paths: list[Path]) -> AuditCheck:
    """Inspect executed source for network imports, remote literals, and model loads."""
    denied_modules = {"requests", "urllib", "http", "socket", "boto3", "huggingface_hub", "datasets"}
    denied_imports = 0
    remote_literals = 0
    model_load_calls = 0
    missing_files = 0
    for path in source_paths:
        if not path.is_file():
            missing_files += 1
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                denied_imports += sum(alias.name.split(".")[0] in denied_modules for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                denied_imports += int(node.module.split(".")[0] in denied_modules)
            elif isinstance(node, ast.Constant) and isinstance(node.value, str):
                remote_literals += int(
                    len(node.value) > 12
                    and node.value.startswith(("http://", "https://", "s3://", "hf://"))
                )
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                model_load_calls += int(node.func.attr in {"load_model", "load_pretrained", "from_pretrained"})
    failures = denied_imports + remote_literals + model_load_calls + missing_files
    return AuditCheck(
        "no_external_data_or_pretrained_artifacts",
        STATUS_FAIL if failures else STATUS_PASS,
        {"source_files_checked": len(source_paths), "network_imports": denied_imports,
         "remote_literals": remote_literals, "pretrained_load_calls": model_load_calls,
         "missing_source_files": missing_files},
        "oil_uplift.a2b011_training.audit_external_dependencies",
    )


def fit_guarded_event_model(
    train: pd.DataFrame,
    valid: pd.DataFrame,
    features: list[str],
    *,
    seed: int,
    params: dict[str, Any],
    preprocessor: Any | None = None,
) -> Pipeline:
    """The B2 fit path: all fold and transformer checks precede fitting."""
    checks = [
        *audit_feature_boundary(features),
        *audit_fold_isolation(set(train["WELL_ID"]), set(valid["WELL_ID"]), set()),
    ]
    transformer = preprocessor if preprocessor is not None else _preprocessor(train[features])
    checks.append(audit_preprocessor_scope(transformer, len(train), len(valid)))
    if not training_gate(checks):
        raise DataContractError("A2B-011 fold leakage gate blocked model fitting.")
    scale = resolve_scale(train, "legacy_anchor_last", None)
    target = transform_target(train["RCYL"], scale)
    weights = event_balanced_training_weights(train)
    model = Pipeline([
        ("preprocess", transformer),
        ("model", build_model("extra_trees", seed, params)),
    ])
    model.fit(train[features], target, model__sample_weight=weights)
    return model


def predict_guarded_event_model(model: Pipeline, valid: pd.DataFrame, features: list[str]) -> np.ndarray:
    scale = resolve_scale(valid, "legacy_anchor_last", None)
    return inverse_target(np.asarray(model.predict(valid[features]), dtype=float), scale)
