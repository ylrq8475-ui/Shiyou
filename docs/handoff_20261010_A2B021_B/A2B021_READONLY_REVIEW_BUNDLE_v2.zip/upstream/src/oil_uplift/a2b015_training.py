"""A2B-015 same-boundary calendar-trend experiment helpers.

Well identifiers and row-level targets or predictions are returned only to the
authorized in-memory runner. Persisted outputs must use the aggregate helpers.
"""

from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from .a2b013_safe import SafeData, fit_and_predict
from .exceptions import DataContractError


MODEL_SEED = 20260916
STABILITY_SEEDS = [20260917, 20261031, 20261219, 20270107, 20270303]
CONFIRMATION_SEED = 20270421
EXPECTED_FEATURE_COUNT = 325
EXPECTED_TREND_COLUMNS = 51
PRIVACY_MIN_WELLS = 5


@dataclass
class PairedOOF:
    baseline: np.ndarray
    candidate: np.ndarray
    fold_ids: np.ndarray
    fold_counts: list[dict[str, int]]


def calendar_slope(values: Iterable[float]) -> float:
    """Fit a slope on fixed natural-month offsets, retaining missing x gaps."""
    array = np.asarray(list(values), dtype=float)
    if np.isinf(array).any():
        raise DataContractError("A2B-015 trend input contains infinity.")
    finite = np.isfinite(array)
    if int(finite.sum()) < 2:
        return np.nan
    offsets = np.arange(len(array), dtype=float)[finite]
    return float(np.polyfit(offsets, array[finite], 1)[0])


def trend_feature_columns(config: dict[str, Any]) -> list[str]:
    fields = list(config["features"]["history_numeric_columns"])
    target = config.get("schema", {}).get("mapping", {}).get("target", "RCYL")
    if target not in fields:
        fields.insert(0, target)
    windows = sorted(set(map(int, config["features"].get("trend_windows", [3, 6, 12]))))
    columns = [f"history__{field}__trend_{window}" for field in fields for window in windows]
    if len(fields) != 17 or windows != [3, 6, 12] or len(columns) != EXPECTED_TREND_COLUMNS:
        raise DataContractError("A2B-015 frozen 17-field, 3/6/12 trend definition changed.")
    return columns


def feature_definition_sha256(config: dict[str, Any]) -> str:
    payload = {
        "columns": trend_feature_columns(config),
        "cutoff": "anchor_previous_complete_natural_month",
        "grid": "continuous_natural_months",
        "x": "original_integer_month_offsets",
        "missing_y": "remove_y_keep_x",
        "minimum_finite": 2,
        "zero": "retained",
        "infinity": "contract_failure",
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def calendar_trend_table(
    history: pd.DataFrame,
    anchors: pd.DataFrame,
    config: dict[str, Any],
    *,
    require_complete_last12: bool = True,
) -> tuple[pd.DataFrame, dict[str, int]]:
    """Recompute the 51 existing trend columns on fixed calendar windows."""
    well = config["anchors"]["well_column"]
    date = config["anchors"]["date_column"]
    fields = list(config["features"]["history_numeric_columns"])
    target = config.get("schema", {}).get("mapping", {}).get("target", "RCYL")
    if target not in fields:
        fields.insert(0, target)
    required = {well, date, *fields}
    if not required.issubset(history.columns) or not {well, "anchor_time"}.issubset(anchors.columns):
        raise DataContractError("A2B-015 trend input is missing required fields.")
    if anchors[well].duplicated().any():
        raise DataContractError("A2B-015 requires one anchor per well.")

    local = history.loc[:, [well, date, *fields]].copy()
    parsed = pd.to_datetime(local[date], errors="coerce")
    if parsed.isna().any():
        raise DataContractError("A2B-015 history contains an invalid date.")
    local["__period"] = parsed.dt.to_period("M")
    if local[[well, "__period"]].duplicated().any():
        raise DataContractError("A2B-015 found duplicate rows for a well-month.")
    for field in fields:
        converted = pd.to_numeric(local[field], errors="coerce")
        if np.isinf(converted.to_numpy(dtype=float)).any():
            raise DataContractError("A2B-015 numeric history contains infinity.")
        local[field] = converted
    indexed = local.set_index([well, "__period"])

    rows: list[dict[str, Any]] = []
    missing_months = 0
    for item in anchors.loc[:, [well, "anchor_time"]].to_dict("records"):
        anchor = pd.Timestamp(item["anchor_time"])
        if pd.isna(anchor):
            raise DataContractError("A2B-015 contains an invalid anchor.")
        cutoff = anchor.to_period("M") - 1
        periods12 = [cutoff - offset for offset in range(11, -1, -1)]
        absent = sum((item[well], period) not in indexed.index for period in periods12)
        missing_months += absent
        if require_complete_last12 and absent:
            raise DataContractError("A2B-015 recent 12-month complete-grid precondition failed.")
        row: dict[str, Any] = {well: item[well], "anchor_time": anchor}
        for field in fields:
            values12 = np.asarray([
                indexed.at[(item[well], period), field]
                if (item[well], period) in indexed.index else np.nan
                for period in periods12
            ], dtype=float)
            for window in (3, 6, 12):
                row[f"history__{field}__trend_{window}"] = calendar_slope(values12[-window:])
        rows.append(row)
    table = pd.DataFrame(rows, columns=[well, "anchor_time", *trend_feature_columns(config)])
    return table, {
        "wells_checked": int(len(table)),
        "recent_12_month_missing_whole_months": int(missing_months),
        "trend_columns": EXPECTED_TREND_COLUMNS,
    }


def _same_series(left: pd.Series, right: pd.Series) -> np.ndarray:
    left_num = pd.to_numeric(left, errors="coerce").to_numpy(dtype=float)
    right_num = pd.to_numeric(right, errors="coerce").to_numpy(dtype=float)
    return np.isclose(left_num, right_num, rtol=0.0, atol=1e-12, equal_nan=True)


def replace_calendar_trends(
    panel: pd.DataFrame,
    history: pd.DataFrame,
    features: list[str],
    config: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, int]]:
    """Return a row-order-preserving panel with only the 51 trends replaced."""
    if len(features) != EXPECTED_FEATURE_COUNT:
        raise DataContractError("A2B-015 input feature count changed.")
    trend_columns = trend_feature_columns(config)
    if not set(trend_columns).issubset(panel.columns):
        raise DataContractError("A2B-015 input panel lacks a frozen trend column.")
    well = config["anchors"]["well_column"]
    anchors = panel.loc[:, [well, "anchor_time"]].drop_duplicates()
    if anchors[well].duplicated().any():
        raise DataContractError("A2B-015 panel has multiple anchors for one well.")
    table, audit = calendar_trend_table(history, anchors, config)
    keyed = table.set_index([well, "anchor_time"])
    output = panel.copy()
    active_trends = [column for column in trend_columns if column in features]
    inactive_trends = [column for column in trend_columns if column not in features]
    if any(not panel[column].isna().all() for column in inactive_trends):
        raise DataContractError("A2B-015 found a finite excluded baseline trend column.")
    if any(not table[column].isna().all() for column in inactive_trends):
        raise DataContractError("A2B-015 calendar recomputation activated an excluded trend column.")
    changed = np.zeros(len(output), dtype=int)
    for column in trend_columns:
        replacement = pd.Series(
            [keyed.at[(row[well], pd.Timestamp(row["anchor_time"])), column]
             for row in output.loc[:, [well, "anchor_time"]].to_dict("records")],
            index=output.index,
        )
        same = _same_series(output[column], replacement)
        changed += (~same).astype(int)
        output[column] = replacement
    if list(output.columns) != list(panel.columns) or len(output) != len(panel):
        raise DataContractError("A2B-015 trend replacement changed panel shape or column order.")
    nontrend = [column for column in panel.columns if column not in trend_columns]
    if not output.loc[:, nontrend].equals(panel.loc[:, nontrend]):
        raise DataContractError("A2B-015 changed a non-trend panel value.")
    per_well = pd.DataFrame({well: output[well], "changed": changed}).groupby(well, sort=False)["changed"].first()
    audit.update({
        "changed_wells": int((per_well > 0).sum()),
        "unchanged_wells": int((per_well == 0).sum()),
        "changed_feature_values_per_event": int(per_well.sum()),
        "total_features": int(len(features)),
        "panel_trend_columns_recomputed": int(len(trend_columns)),
        "active_trend_features": int(len(active_trends)),
        "inactive_all_missing_trend_columns": int(len(inactive_trends)),
        "nontrend_columns_unchanged": True,
    })
    flags = per_well.gt(0).rename("trend_changed").reset_index()
    return output, flags, audit


def build_candidate_data(
    baseline: SafeData,
    train_history: pd.DataFrame,
    test_history: pd.DataFrame,
    config: dict[str, Any],
) -> tuple[SafeData, pd.DataFrame, dict[str, Any]]:
    train, flags, train_audit = replace_calendar_trends(
        baseline.train, train_history, baseline.features, config
    )
    test, _, test_audit = replace_calendar_trends(
        baseline.test, test_history, baseline.features, config
    )
    candidate = SafeData(
        train=train,
        test=test,
        reference=baseline.reference.copy(),
        features=list(baseline.features),
        audit=copy.deepcopy(baseline.audit),
    )
    return candidate, flags, {"train": train_audit, "test": test_audit}


def deterministic_splits(panel: pd.DataFrame) -> list[tuple[np.ndarray, np.ndarray]]:
    groups = panel["WELL_ID"]
    splitter = GroupKFold(n_splits=5)
    return [(train, valid) for train, valid in splitter.split(panel, panel["RCYL"], groups)]


def shuffled_splits(panel: pd.DataFrame, seed: int) -> list[tuple[np.ndarray, np.ndarray]]:
    groups = panel["WELL_ID"]
    splitter = GroupKFold(n_splits=5, shuffle=True, random_state=seed)
    return [(train, valid) for train, valid in splitter.split(panel, panel["RCYL"], groups)]


def validate_splits(panel: pd.DataFrame, splits: list[tuple[np.ndarray, np.ndarray]]) -> list[dict[str, int]]:
    coverage = np.zeros(len(panel), dtype=int)
    rows: list[dict[str, int]] = []
    for fold, (train_idx, valid_idx) in enumerate(splits, start=1):
        train_wells = set(panel.iloc[train_idx]["WELL_ID"])
        valid_wells = set(panel.iloc[valid_idx]["WELL_ID"])
        overlap = len(train_wells & valid_wells)
        if overlap:
            raise DataContractError("A2B-015 WELL_ID crossed a validation fold.")
        coverage[valid_idx] += 1
        rows.append({
            "fold": fold,
            "training_wells": len(train_wells),
            "validation_wells": len(valid_wells),
            "well_overlap": overlap,
        })
    if not np.array_equal(coverage, np.ones(len(panel), dtype=int)):
        raise DataContractError("A2B-015 validation rows are not covered exactly once.")
    return rows


def run_paired_oof(
    baseline: SafeData,
    candidate: SafeData,
    config: dict[str, Any],
    splits: list[tuple[np.ndarray, np.ndarray]],
) -> PairedOOF:
    if baseline.features != candidate.features or len(baseline.train) != len(candidate.train):
        raise DataContractError("A2B-015 paired panels are not aligned.")
    keys = ["WELL_ID", "anchor_time", "horizon"]
    if not baseline.train.loc[:, keys].equals(candidate.train.loc[:, keys]):
        raise DataContractError("A2B-015 paired OOF keys differ.")
    fold_counts = validate_splits(baseline.train, splits)
    base_oof = np.full(len(baseline.train), np.nan, dtype=float)
    t1_oof = np.full(len(candidate.train), np.nan, dtype=float)
    fold_ids = np.zeros(len(baseline.train), dtype=int)
    for fold, (train_idx, valid_idx) in enumerate(splits, start=1):
        _, base_pred = fit_and_predict(
            baseline.train.iloc[train_idx], baseline.train.iloc[valid_idx], baseline.features, config
        )
        _, t1_pred = fit_and_predict(
            candidate.train.iloc[train_idx], candidate.train.iloc[valid_idx], candidate.features, config
        )
        base_oof[valid_idx] = base_pred
        t1_oof[valid_idx] = t1_pred
        fold_ids[valid_idx] = fold
    for prediction in (base_oof, t1_oof):
        if not np.isfinite(prediction).all() or (prediction < 0).any():
            raise DataContractError("A2B-015 produced invalid OOF predictions.")
    return PairedOOF(base_oof, t1_oof, fold_ids, fold_counts)


def fixed_half_blend(
    baseline_prediction: np.ndarray,
    candidate_prediction: np.ndarray,
    baseline_keys: pd.DataFrame,
    candidate_keys: pd.DataFrame,
    baseline_folds: np.ndarray,
    candidate_folds: np.ndarray,
) -> np.ndarray:
    if not baseline_keys.reset_index(drop=True).equals(candidate_keys.reset_index(drop=True)):
        raise DataContractError("A2B-015 blend keys differ.")
    if not np.array_equal(baseline_folds, candidate_folds):
        raise DataContractError("A2B-015 blend fold assignments differ.")
    left = np.asarray(baseline_prediction, dtype=float)
    right = np.asarray(candidate_prediction, dtype=float)
    if left.shape != right.shape or left.shape[0] != len(baseline_keys):
        raise DataContractError("A2B-015 blend prediction lengths differ.")
    result = 0.5 * left + 0.5 * right
    if not np.isfinite(result).all() or (result < 0).any():
        raise DataContractError("A2B-015 blend prediction is invalid.")
    return result


def official_summary(panel: pd.DataFrame, prediction: np.ndarray, fold_ids: np.ndarray) -> dict[str, Any]:
    pred = np.asarray(prediction, dtype=float)
    truth = panel["RCYL"].to_numpy(dtype=float)
    horizon = panel["horizon"].to_numpy(dtype=int)
    folds = np.asarray(fold_ids, dtype=int)
    if len(pred) != len(panel) or not np.isfinite(pred).all() or (pred < 0).any():
        raise DataContractError("A2B-015 metric input predictions are invalid.")
    relative = np.abs(pred - truth) / (np.abs(pred) + np.abs(truth) + 1e-6)
    weighted = np.power(0.5, horizon) * relative
    work = pd.DataFrame({"well": panel["WELL_ID"].to_numpy(), "loss": weighted})
    score = 100.0 * (1.0 - float(work.groupby("well", sort=False)["loss"].sum().mean()))
    monthly = [float(weighted[horizon == month].mean()) for month in range(1, 13)]
    fold_scores = []
    for fold in sorted(set(folds.tolist())):
        mask = folds == fold
        fold_work = pd.DataFrame({"well": panel.loc[mask, "WELL_ID"].to_numpy(), "loss": weighted[mask]})
        fold_scores.append(100.0 * (1.0 - float(fold_work.groupby("well", sort=False)["loss"].sum().mean())))
    return {
        "official_oof": float(score),
        "fold_scores": [float(value) for value in fold_scores],
        "worst_fold_score": float(min(fold_scores)),
        "worst_fold_number": int(1 + int(np.argmin(fold_scores))),
        "fold_score_std": float(np.std(fold_scores)),
        "monthly_weighted_loss": monthly,
        "month_1_loss": monthly[0],
        "months_1_2_loss": float(sum(monthly[:2])),
        "months_1_4_loss": float(sum(monthly[:4])),
        "months_1_12_loss": float(sum(monthly)),
        "negative_prediction_count": int((pred < 0).sum()),
        "nan_prediction_count": int(np.isnan(pred).sum()),
        "inf_prediction_count": int(np.isinf(pred).sum()),
    }


def candidate_comparison(
    baseline_fixed: dict[str, Any],
    candidate_fixed: dict[str, Any],
    baseline_repeated: list[dict[str, Any]],
    candidate_repeated: list[dict[str, Any]],
) -> dict[str, Any]:
    score_deltas = [
        float(candidate["official_oof"] - baseline["official_oof"])
        for baseline, candidate in zip(baseline_repeated, candidate_repeated, strict=True)
    ]
    early_deltas = [
        float(candidate["months_1_2_loss"] - baseline["months_1_2_loss"])
        for baseline, candidate in zip(baseline_repeated, candidate_repeated, strict=True)
    ]
    return {
        "fixed_oof_delta": float(candidate_fixed["official_oof"] - baseline_fixed["official_oof"]),
        "fixed_months_1_2_loss_delta": float(
            candidate_fixed["months_1_2_loss"] - baseline_fixed["months_1_2_loss"]
        ),
        "fixed_worst_fold_delta": float(
            candidate_fixed["worst_fold_score"] - baseline_fixed["worst_fold_score"]
        ),
        "repeated_seed_deltas": score_deltas,
        "repeated_mean_delta": float(np.mean(score_deltas)),
        "positive_repeated_seed_count": int(sum(value > 0 for value in score_deltas)),
        "worst_repeated_seed_delta": float(min(score_deltas)),
        "repeated_months_1_2_loss_deltas": early_deltas,
        "repeated_mean_months_1_2_loss_delta": float(np.mean(early_deltas)),
    }


def evaluate_main_gates(comparison: dict[str, Any], candidate_fixed: dict[str, Any]) -> dict[str, Any]:
    checks = {
        "fixed_oof_strictly_improved": comparison["fixed_oof_delta"] > 0,
        "repeated_mean_delta_at_least_0_20": comparison["repeated_mean_delta"] >= 0.20,
        "at_least_four_of_five_seeds_positive": comparison["positive_repeated_seed_count"] >= 4,
        "worst_seed_delta_at_least_minus_0_50": comparison["worst_repeated_seed_delta"] >= -0.50,
        "fixed_months_1_2_loss_decreased": comparison["fixed_months_1_2_loss_delta"] < 0,
        "repeated_mean_months_1_2_loss_decreased": comparison["repeated_mean_months_1_2_loss_delta"] < 0,
        "predictions_finite_and_nonnegative": (
            candidate_fixed["negative_prediction_count"] == 0
            and candidate_fixed["nan_prediction_count"] == 0
            and candidate_fixed["inf_prediction_count"] == 0
        ),
        "no_new_leakage": True,
    }
    return {"checks": checks, "passed": bool(all(checks.values()))}


def ranking_key(item: tuple[str, dict[str, Any]]) -> tuple[float, float, float, str]:
    candidate_id, result = item
    comparison = result["comparison"]
    return (
        -float(comparison["repeated_mean_delta"]),
        -float(comparison["fixed_oof_delta"]),
        float(result["fixed"]["months_1_2_loss"]),
        candidate_id,
    )


def confirmation_passes(score_delta: float, months_1_2_loss_delta: float) -> bool:
    """Apply the locked one-shot confirmation rule without tolerance tuning."""
    return bool(score_delta > 0 and months_1_2_loss_delta <= 0)


def anonymous_trend_group_summary(
    panel: pd.DataFrame,
    prediction: np.ndarray,
    flags: pd.DataFrame,
) -> dict[str, Any]:
    per_well_flag = flags.set_index("WELL_ID")["trend_changed"]
    marker = panel["WELL_ID"].map(per_well_flag).astype(bool).to_numpy()
    group_wells = int(panel.loc[marker, "WELL_ID"].nunique())
    complement_wells = int(panel.loc[~marker, "WELL_ID"].nunique())
    if group_wells < PRIVACY_MIN_WELLS or complement_wells < PRIVACY_MIN_WELLS:
        return {"status": "suppressed", "privacy_gate_passed": False}
    fold_ids = np.ones(len(panel), dtype=int)
    group = official_summary(panel.loc[marker].reset_index(drop=True), np.asarray(prediction)[marker], fold_ids[marker])
    complement = official_summary(panel.loc[~marker].reset_index(drop=True), np.asarray(prediction)[~marker], fold_ids[~marker])
    return {
        "privacy_gate_passed": True,
        "changed_well_count": group_wells,
        "unchanged_well_count": complement_wells,
        "changed_group_score": group["official_oof"],
        "unchanged_group_score": complement["official_oof"],
        "changed_group_months_1_2_loss": group["months_1_2_loss"],
        "unchanged_group_months_1_2_loss": complement["months_1_2_loss"],
        "diagnostic_only": True,
    }
