"""Read-only, no-fit all-field information-cutoff audit. Output aggregates only."""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent
PRIVATE_CONFIG_HASH = '89e60c301b1d553b1c7dab8e2f87d1d9a47b600abe4322f2e9895717201c0c72'

class GateError(Exception):
    pass

def require(condition, code):
    if not condition:
        raise GateError(code)

def digest(value):
    return hashlib.sha256(value).hexdigest()

def fingerprint(value):
    return digest(json.dumps(value, ensure_ascii=True, separators=(',', ':'), sort_keys=True).encode())

def file_hash(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()

def preflight(root, config=None):
    expected = json.loads((HERE / 'SOURCE_LOCK.json').read_text(encoding='utf-8'))
    source_ok = all((root / name).is_file() and digest((root / name).read_bytes().replace(b'\r\n', b'\n')) == sha for name, sha in expected['files'].items())
    versions = {}
    for name, version in expected['dependencies'].items():
        try:
            actual = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual = None
        versions[name] = {'required': version, 'actual': actual, 'match': actual == version}
    lock = HERE / 'PRE_DATA_LOCK.json'
    package_ok = False
    if lock.is_file():
        package_ok = all(file_hash(HERE / p) == h for p, h in json.loads(lock.read_text(encoding='utf-8'))['files'].items())
    config_ok = config is not None and config.is_file() and file_hash(config) == PRIVATE_CONFIG_HASH
    runtime_ok = platform.python_version() == '3.13.7' and all(v['match'] for v in versions.values())
    return {'source_identity_passed': source_ok, 'package_lock_passed': package_ok, 'python': platform.python_version(), 'required_python': '3.13.7', 'dependencies': versions, 'runtime_passed': runtime_ok, 'private_config_supplied': config is not None, 'private_config_identity_passed': config_ok, 'ready_for_real_audit': source_ok and package_ok and runtime_ok and config_ok, 'real_data_read': False, 'model_fit_calls': 0, 'preprocess_fit_calls': 0, 'training_allowed': False}

def bind(root):
    global np, pd, safe, multi, training, GroupKFold, config_module
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / 'src'))
    import numpy as np
    import pandas as pd
    from sklearn.model_selection import GroupKFold
    from sklearn.pipeline import Pipeline
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import ExtraTreesRegressor
    def forbidden(*args, **kwargs):
        raise GateError('FIT_FORBIDDEN_IN_AUDIT')
    Pipeline.fit = forbidden
    Pipeline.fit_transform = forbidden
    ColumnTransformer.fit = forbidden
    ColumnTransformer.fit_transform = forbidden
    ExtraTreesRegressor.fit = forbidden
    from oil_uplift import a2b013_safe as safe, multistep as multi, training, config as config_module
    require(Path(safe.__file__).resolve().is_relative_to(root.resolve()), 'IMPORT_ROOT_MISMATCH')

def same(left, right):
    if pd.isna(left) and pd.isna(right):
        return True
    return bool(left == right)

def equal_dict(left, right):
    return left.keys() == right.keys() and all(same(left[k], right[k]) for k in left)

def values_at(history, well, first_excluded, config):
    # Target anchor is deliberately absent from this function.
    v = multi._history_features(history, well, (first_excluded - 1).to_timestamp(), config)
    return {'history_month_count': v['history_month_count'], **{k: x for k, x in v.items() if k.startswith('history__')}}

def independent_segments(history, config):
    a = config['anchors']; well, date, event = (a[k] for k in ['well_column', 'date_column', 'event_column'])
    result = {}
    periods = pd.to_datetime(history[date], errors='coerce').dt.to_period('M')
    require(not periods.isna().any(), 'INVALID_MONTH')
    require(not pd.DataFrame({'w': history[well], 'm': periods}).duplicated().any(), 'DUPLICATE_MONTH')
    for value, group in history.groupby(well, sort=False):
        months = sorted(periods.loc[group.index[group[event].isin(a['eligible_event_values'])]].tolist())
        require(bool(months), 'NO_EVENT')
        start = end = months[-1]
        for month in reversed(months[:-1]):
            if month != start - 1:
                break
            start = month
        result[value] = (start, end)
    return result

def raw_scale(value):
    number = pd.to_numeric(pd.Series([value]), errors='coerce').iloc[0]
    return float(number) if np.isfinite(number) and number > 0 else 1.0

def raw_fallback(value):
    number = pd.to_numeric(pd.Series([value]), errors='coerce').iloc[0]
    return not (np.isfinite(number) and number > 0)

def compare_split(history, panel, anchors, config, features):
    well, date = (config['anchors'][k] for k in ['well_column', 'date_column'])
    segments = independent_segments(history, config)
    candidate = panel.copy(deep=True)
    history_columns = [c for c in features if c.startswith('history__') or c == 'history_month_count']
    stats = dict(wells=0, changed_cutoff_wells=0, removed_records=0, changed_feature_values=0, changed_scale_wells=0, fallback_to_ordinary=0, ordinary_to_fallback=0, stale_last_month_control=0, stale_last_month_candidate=0, calendar_gap_wells_control=0, calendar_gap_wells_candidate=0, mutation_and_trim_checks=0)
    for anchor in anchors.to_dict('records'):
        value, end = anchor[well], anchor['anchor_period']
        start, independent_end = segments[value]
        require(end == independent_end, 'ANCHOR_DISAGREEMENT')
        local = history.loc[history[well] == value].copy()
        months = pd.to_datetime(local[date]).dt.to_period('M')
        require(bool((months < start).any()), 'EMPTY_EARLY_HISTORY')
        control = values_at(local, value, end, config)
        earlier = values_at(local, value, start, config)
        mask = panel[well] == value
        for c in history_columns:
            require(c in control and c in earlier, 'MISSING_FEATURE')
            require(all(same(x, control[c]) for x in panel.loc[mask, c]), 'CONTROL_REBUILD_MISMATCH')
            candidate.loc[mask, c] = earlier[c]
        if start == end:
            require(equal_dict(control, earlier), 'UNAFFECTED_WELL_CHANGED')
        stats['wells'] += 1
        stats['changed_cutoff_wells'] += int(start != end)
        stats['removed_records'] += int(((months >= start) & (months < end)).sum())
        stats['changed_feature_values'] += sum(not same(control[c], earlier[c]) for c in history_columns)
        stats['changed_scale_wells'] += int(raw_scale(control['history__RCYL__last']) != raw_scale(earlier['history__RCYL__last']))
        bf, cf = raw_fallback(control['history__RCYL__last']), raw_fallback(earlier['history__RCYL__last'])
        stats['fallback_to_ordinary'] += int(bf and not cf)
        stats['ordinary_to_fallback'] += int(not bf and cf)
        for first_excluded, expected, suffix in [(end, control, 'control'), (start, earlier, 'candidate')]:
            included = months.loc[months < first_excluded]
            stats['stale_last_month_' + suffix] += int(included.max() != first_excluded - 1)
            stats['calendar_gap_wells_' + suffix] += int(included.max().ordinal - included.min().ordinal + 1 != len(included))
            trimmed = local.loc[months < first_excluded].copy()
            require(equal_dict(expected, values_at(trimmed, value, first_excluded, config)), 'TRIM_SENSITIVE_FEATURE')
            numeric = list(dict.fromkeys(['RCYL', *config.get('features', {}).get('history_numeric_columns', [])]))
            categorical = config.get('features', {}).get('history_categorical_columns', [])
            for missing in [False, True]:
                mutated = local.copy()
                for c in numeric:
                    if c in mutated:
                        mutated[c] = pd.to_numeric(mutated[c], errors='coerce').astype(float)
                        mutated.loc[months >= first_excluded, c] = np.nan if missing else 987654321.
                for c in categorical:
                    if c in mutated and c not in [well, date]:
                        mutated[c] = mutated[c].astype(object)
                        mutated.loc[months >= first_excluded, c] = None if missing else '__SYNTHETIC_FUTURE_MUTATION__'
                require(equal_dict(expected, values_at(mutated, value, first_excluded, config)), 'MUTATION_SENSITIVE_FEATURE')
            stats['mutation_and_trim_checks'] += 3
    invariant = [c for c in panel.columns if c not in history_columns]
    require(panel[invariant].equals(candidate[invariant]), 'TARGET_OR_KEY_DRIFT')
    require(list(panel[features].dtypes.astype(str)) == list(candidate[features].dtypes.astype(str)), 'DTYPE_DRIFT')
    expected_scale = np.array([raw_scale(x) for x in candidate['history__RCYL__last']])
    require(np.array_equal(training._target_scale(candidate, 'log_ratio_last'), expected_scale), 'SCALE_MISMATCH')
    for frame in [panel, candidate]:
        numeric = frame[features].select_dtypes(include='number')
        require(not np.isinf(numeric.to_numpy(dtype=float)).any(), 'NONFINITE_FEATURE')
    return candidate, stats

def schema_gate(control, candidate, config, features):
    require(training.configured_feature_columns(control, config) == features, 'CONTROL_SCHEMA_DRIFT')
    require(training.configured_feature_columns(candidate, config) == features, 'CANDIDATE_SCHEMA_DRIFT')

def fold_gate(control, candidate, features):
    splitter = GroupKFold(n_splits=5)
    original = list(splitter.split(control, control['RCYL'], control['WELL_ID']))
    changed = list(splitter.split(candidate, candidate['RCYL'], candidate['WELL_ID']))
    mappings = []
    for number, ((tr, va), (ctr, cva)) in enumerate(zip(original, changed), 1):
        require(np.array_equal(tr, ctr) and np.array_equal(va, cva), 'FOLD_DRIFT')
        require(not set(control.iloc[tr]['WELL_ID']) & set(control.iloc[va]['WELL_ID']), 'WELL_FOLD_OVERLAP')
        bmiss = control.iloc[tr][features].isna().all()
        cmiss = candidate.iloc[tr][features].isna().all()
        require(not bool((cmiss & ~bmiss).any()), 'NEW_FOLD_ALL_MISSING_COLUMN')
        mappings.extend((str(v), number) for v in control.iloc[va]['WELL_ID'].drop_duplicates())
    return fingerprint(sorted(mappings))

def execute_audit(config, train_tables, test_tables, expected=None):
    train, _, train_anchors = safe._build_train_panel(train_tables, config)
    test, reference, _, test_anchors = safe._build_test_panel(test_tables, config)
    features = training.configured_feature_columns(train, config)
    require(not any(c.startswith(('layer__', 'plan_first__')) for c in features), 'FORBIDDEN_FEATURE')
    require(not set(train.WELL_ID) & set(test.WELL_ID), 'TRAIN_TEST_OVERLAP')
    counts = {'train_history_wells': int(train_tables.history.WELL_ID.nunique()), 'train_wells': int(train.WELL_ID.nunique()), 'train_rows': len(train), 'test_wells': int(test.WELL_ID.nunique()), 'test_rows': len(test), 'feature_columns': len(features)}
    if expected:
        require(counts == expected['cohort'], 'COHORT_DRIFT')
    candidate_train, train_stats = compare_split(train_tables.history, train, train_anchors, config, features)
    candidate_test, test_stats = compare_split(test_tables.history, test, test_anchors, config, features)
    schema_gate(train, candidate_train, config, features)
    split_hash = fold_gate(train, candidate_train, features)
    require(test[['WELL_ID', 'NY']].equals(reference), 'CONTROL_TEMPLATE_DRIFT')
    require(candidate_test[['WELL_ID', 'NY']].equals(reference), 'CANDIDATE_TEMPLATE_DRIFT')
    if expected:
        got = {'train_changed_wells': train_stats['changed_cutoff_wells'], 'train_removed_records': train_stats['removed_records'], 'test_changed_wells': test_stats['changed_cutoff_wells'], 'test_removed_records': test_stats['removed_records']}
        require(got == expected['expected_boundary_counts'], 'BOUNDARY_COUNTS_DRIFT')
    return {'status': 'structural_audit_passed', 'cohort': counts, 'train': train_stats, 'test': test_stats, 'feature_schema_sha256': fingerprint(list(zip(features, train[features].dtypes.astype(str)))), 'fixed_well_fold_mapping_sha256': split_hash, 'exact_template_preserved': True, 'target_rows_labels_preserved': True, 'model_fit_calls': 0, 'preprocess_fit_calls': 0, 'baseline_reuse_verified': False, 'training_allowed': False, 'remaining_gate': 'historical_data_schema_split_and_runtime_identity_for_baseline_reuse', 'event_semantics': 'UNKNOWN', 'forecast_time': 'UNKNOWN'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', required=True, type=Path)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--input-dir', type=Path)
    parser.add_argument('--mode', choices=['preflight', 'audit'], default='preflight')
    parser.add_argument('--authorized', action='store_true')
    args = parser.parse_args()
    raw_read = False
    try:
        pre = preflight(args.source_root, args.config)
        if args.mode == 'preflight':
            print(json.dumps(pre, indent=2, ensure_ascii=True))
            return 0
        require(args.authorized and os.environ.get('COMPETITION_DATA_ACCESS_ACK') == 'I_AM_AUTHORIZED', 'LOCAL_ACCESS_ACK_REQUIRED')
        require(pre['ready_for_real_audit'], 'PREFLIGHT_FAILED')
        # Suppress third-party warnings/tracebacks which might contain private values.
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            bind(args.source_root)
            original = config_module.load_config(args.config)
            config = safe.safe_config(original, str(args.input_dir) if args.input_dir else None)
            role_paths = {}
            for split, roles in [('train', ['history']), ('test', ['history', 'template'])]:
                for role in roles:
                    paths = multi._declared_role_paths(config, split, role)
                    require(len(paths) == len(set(paths)), 'DUPLICATE_FILE_WITHIN_ROLE')
                    role_paths[(split, role)] = paths
            train_paths = set(role_paths[('train', 'history')])
            test_paths = set(role_paths[('test', 'history')] + role_paths[('test', 'template')])
            require(not train_paths & test_paths, 'TRAIN_TEST_SOURCE_OVERLAP')
            require(args.config.resolve() not in train_paths | test_paths, 'CONFIG_SOURCE_OVERLAP')
            # The same test CSV may supply both history and template roles.
            files = list(dict.fromkeys([args.config.resolve(), *(p for paths in role_paths.values() for p in paths)]))
            raw_read = True
            before = [file_hash(p) for p in files]
            try:
                train = multi.load_multisource_split(config, 'train')
                test = multi.load_multisource_split(config, 'test')
                result = execute_audit(config, train, test, json.loads((HERE / 'PLAN.json').read_text(encoding='utf-8')))
            finally:
                require([file_hash(p) for p in files] == before, 'SOURCE_FILES_CHANGED_DURING_AUDIT')
            result.update({'real_data_read': True, 'declared_files_checked': len(files), 'declared_content_sha256': fingerprint(before), 'declared_files_unchanged': True, 'source_commit': '4464061826607b40acdeac2e0ff4700641dd4272'})
        print(json.dumps(result, indent=2, ensure_ascii=True))
        return 0
    except Exception as exc:
        print(json.dumps({'status': 'stopped', 'error_code': str(exc) if isinstance(exc, GateError) else type(exc).__name__, 'real_data_read': raw_read, 'training_allowed': False, 'model_fit_calls': 0, 'preprocess_fit_calls': 0}, ensure_ascii=True))
        return 1

if __name__ == '__main__':
    sys.exit(main())
