"""A2B-019 T1: paired CV only; no saved model or row-level result.

Imports of model modules are lazy so pre-runtime preparation remains possible.
The reviewed boundary artifact must be supplied with its exact approved hash.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import contextlib
import copy
import errno
import hashlib
import importlib.util
import io
import json
import os
import platform
import sys
import time
from t1_core import (ENTRY_SHA256, SEEDS, FitBudget, GateError, fingerprint,
                     fixed_gate, official_summary, repeated_gate, require, raw_scale)
from archive_adapter import ArchiveStore, sha

HERE = Path(__file__).resolve().parent
ACTIVE_LOCK_NAME = 'PREPARATION_LOCK_v2.json'
PROJECT = Path(r'D:\codex\Shiyou_B_private_handoff_20261009_v1\payload\project')
PRIVATE_CONFIG = PROJECT/'configs/private_data_inferred_v7_safe_plus_layer.yaml'
RAW_MANIFEST = PROJECT/'private_logs/raw_manifest_20260916.json'
RAW_ARCHIVE = Path(r'D:\weichat\xwechat_files\wxid_0icxdm6epwnr22_a5ae\msg\file\2026-10\data (1).zip')
PRIOR_PLAN = Path(r'D:\codex\shiyou-boundary-20261009\PLAN.json')
SOURCE_LOCK = Path(r'D:\codex\shiyou-boundary-20261009\SOURCE_LOCK.json')
RAW_HASH = '813f0ebe71f6dddf64e8fbc6f365e15058c9952de16304f2f46392e96eca09c7'
CONFIG_HASH = '89e60c301b1d553b1c7dab8e2f87d1d9a47b600abe4322f2e9895717201c0c72'


def stamp():
    return datetime.now(timezone(timedelta(hours=8))).isoformat()


def dump_new(path, payload):
    with path.open('x', encoding='utf-8') as out:
        json.dump(payload, out, ensure_ascii=False, indent=2, allow_nan=False)


def module_load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def environment():
    import importlib.metadata
    base = Path(sys.base_prefix)
    return {'executable':sys.executable,'python':platform.python_version(),
            'build':platform.python_build(),'compiler':platform.python_compiler(),
            'versions':dict(sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions())),
            'native_files':{str(p):sha(p.read_bytes()) for p in
                            [Path(sys.executable),base/'python.exe',base/'python313.dll',
                             Path(sys.prefix)/'Lib/site-packages/sklearn/svm/_libsvm.cp313-win_amd64.pyd'] if p.is_file()}}


def input_identity(entry):
    sources = [p for p in PROJECT.rglob('*.py') if p.is_file()]
    sources += [PRIVATE_CONFIG,RAW_MANIFEST,RAW_MANIFEST.with_suffix('.json.sha256'),
                PRIOR_PLAN,SOURCE_LOCK,PROJECT/'requirements-lock.txt',
                PROJECT/'experiments/a2b017/IMPLEMENTATION_PRETRAIN_LOCK.json']
    sources += sorted(HERE.glob('*.py')) + [HERE/'T1_SUPPLEMENT_PLAN.json',HERE/'PREPARATION_LOCK.json',entry]
    active_lock = HERE/ACTIVE_LOCK_NAME
    if active_lock.is_file():
        sources += [active_lock]
        sources += [Path(name) for name in json.loads(active_lock.read_bytes())['upstream_readonly_files']]
    return {str(p):sha(p.read_bytes()) for p in sources} | {str(RAW_ARCHIVE):sha(RAW_ARCHIVE.read_bytes())}


def array_hash(np, value):
    a = np.ascontiguousarray(value, dtype=np.int64)
    return sha(a.dtype.str.encode()+str(a.shape).encode()+a.tobytes())


def validate_splits(np, panel, splits):
    coverage = np.zeros(len(panel),dtype=int)
    universe = set(range(len(panel)))
    for tr,va in splits:
        require(len(tr)==len(set(tr)) and len(va)==len(set(va)), 'DUPLICATE_SPLIT_ROW')
        require(set(tr)|set(va)==universe and not set(tr)&set(va), 'SPLIT_PARTITION')
        require(not set(panel.iloc[tr].WELL_ID)&set(panel.iloc[va].WELL_ID), 'WELL_ISOLATION')
        coverage[va] += 1
    require(np.array_equal(coverage,np.ones(len(panel),dtype=int)), 'OOF_COVERAGE')


def data_prepare(entry, np, pd, training, safe, multi, config_module, GroupKFold):
    require(sha(entry.read_bytes()) == ENTRY_SHA256, 'ACCEPTED_ENTRY_HASH_MISMATCH')
    require(sha(PRIVATE_CONFIG.read_bytes()) == CONFIG_HASH, 'CONFIG_IDENTITY_CHANGED')
    require(sha(RAW_ARCHIVE.read_bytes()) == RAW_HASH, 'RAW_ARCHIVE_IDENTITY_CHANGED')
    config = safe.safe_config(config_module.load_config(PRIVATE_CONFIG))
    store = ArchiveStore(RAW_ARCHIVE,RAW_MANIFEST)
    # No frozen paths are edited; data reader explicitly maps declared members in memory.
    train_tables,test_tables,reader = store.load_tables(config,multi.MultiSourceTables)
    audit = module_load(entry,'t1_accepted_boundary_audit')
    expected = json.loads(PRIOR_PLAN.read_bytes())
    # bind() installs no-fit guards. Restore only those known class methods after audit.
    from sklearn.pipeline import Pipeline
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import ExtraTreesRegressor
    originals = [(Pipeline,'fit',Pipeline.fit),(Pipeline,'fit_transform',Pipeline.fit_transform),
                 (ColumnTransformer,'fit',ColumnTransformer.fit),
                 (ColumnTransformer,'fit_transform',ColumnTransformer.fit_transform),
                 (ExtraTreesRegressor,'fit',ExtraTreesRegressor.fit)]
    try:
        audit.bind(PROJECT)
        structure = audit.execute_audit(config,train_tables,test_tables,expected)
        require(structure['status']=='structural_audit_passed', 'ACCEPTED_STRUCTURE_FAILED')
        control,_,anchors = safe._build_train_panel(train_tables,config)
        test,reference,_,test_anchors = safe._build_test_panel(test_tables,config)
        features = training.configured_feature_columns(control,config)
        control_schema = list(zip(features,control[features].dtypes.astype(str)))
        require(len(features)==325, 'FEATURE_COUNT')
        # Preserve new control dtype before constructing the candidate, without old dtype claims.
        candidate,_ = audit.compare_split(train_tables.history,control,anchors,config,features)
        candidate_test,_ = audit.compare_split(test_tables.history,test,test_anchors,config,features)
        audit.schema_gate(control,candidate,config,features)
        require(control_schema == list(zip(features,candidate[features].dtypes.astype(str))), 'NEW_RUN_DTYPE_DRIFT')
        require(test[['WELL_ID','NY']].equals(reference) and candidate_test[['WELL_ID','NY']].equals(reference), 'TEMPLATE_DRIFT')
    finally:
        for owner,name,fn in originals:
            setattr(owner,name,fn)
    old = json.loads((PROJECT/'experiments/a2b017/IMPLEMENTATION_PRETRAIN_LOCK.json').read_bytes())
    row_digest = fingerprint(control[['WELL_ID','horizon']].astype(str).values.tolist())
    require(row_digest == old['cohort_order_sha256'], 'APPROVED_COHORT_ROW_ORDER_DRIFT')
    require(fingerprint(features) == old['feature_order_sha256'], 'APPROVED_FEATURE_ORDER_DRIFT')
    require(control.drop(columns=features).equals(candidate.drop(columns=features)), 'TARGET_OR_ROW_DRIFT')
    require(control.groupby('WELL_ID').size().eq(12).all(), 'TARGET_HORIZON_COUNT')
    for frame in [control,candidate]:
        require(np.isfinite(frame.RCYL).all() and (frame.RCYL>=0).all(), 'TARGET_VALUES')
        independently_scaled = np.asarray([raw_scale(x) for x in frame['history__RCYL__last']])
        require(np.array_equal(independently_scaled,training._target_scale(frame,'log_ratio_last')),'RAW_SCALE_FALLBACK_DRIFT')
    families = []
    for index,seed in enumerate([None,*SEEDS]):
        splitter = GroupKFold(n_splits=5,shuffle=seed is not None,random_state=seed)
        splits = list(splitter.split(control,groups=control.WELL_ID))
        candidate_splits = list(splitter.split(candidate,groups=candidate.WELL_ID))
        validate_splits(np,control,splits)
        for (tr,va),(ctr,cva) in zip(splits,candidate_splits,strict=True):
            require(np.array_equal(tr,ctr) and np.array_equal(va,cva), 'PAIRED_SPLIT_DRIFT')
            b = control.iloc[tr][features].isna().all()
            c = candidate.iloc[tr][features].isna().all()
            require(not (c & ~b).any(), 'NEW_TRAIN_FOLD_ALL_MISSING')
        split_hash = fingerprint([(array_hash(np,a),array_hash(np,b)) for a,b in splits])
        require(split_hash == old['outer_split_sha256'][index], 'APPROVED_SPLIT_DRIFT')
        families.append((seed,splits,split_hash))
    require(store.unchanged(), 'RAW_CHANGED_DURING_STRUCTURE')
    runtime_config = {'private_config_sha256':CONFIG_HASH,
                      'execution_config_sha256':fingerprint(config),
                      'runtime_mapping':'in-memory archive adapter; no frozen config edits',
                      'calibration':'none','blend':'none','model_seed':20260916,
                      'parallelism':{'active_fits':1,'model_n_jobs':-1,'BLAS_OpenMP_threads':1},
                      'reader':reader}
    # Return private frames only in memory. Expose only column schema and hashes.
    ready = {'accepted_structure_result_unmodified':structure,'new_control_ordered_schema':control_schema,
             'new_control_schema_sha256':fingerprint(control_schema), 'cohort_order_sha256':row_digest,
             'split_families':[{'seed':s,'split_digest':h,'fold_well_intersections':[0]*5}
                               for s,_,h in families], 'runtime_settings':runtime_config,
             'historical_dtype_identity':'UNKNOWN','old_baseline_score_reused':False,
             'T1_amendment':'new paired control replaces old-score reuse requirement; old structure result not relabeled'}
    return config,control,candidate,features,families,store,ready


class Journal:
    def __init__(self,output):
        self.directory = output/'events'
        self.directory.mkdir(exist_ok=False)
        self.sequence = 0

    def add(self,event,**payload):
        self.sequence += 1
        dump_new(self.directory/f'{self.sequence:04d}.json',
                 {'event':event,'time_Asia_Shanghai':stamp(),**payload})


def transient_fault(exc):
    # Only identifiable memory/resource failures qualify. No generic ValueError retry.
    return isinstance(exc,MemoryError) or (isinstance(exc,OSError) and exc.errno in {errno.ENOMEM,errno.EAGAIN})


def fit_one(np, training, frame, features, config, tr,va,budget,journal,tag):
    train,valid = frame.iloc[tr],frame.iloc[va]
    require(not set(train.WELL_ID)&set(valid.WELL_ID),'FIT_WELL_OVERLAP')
    require('RCYL' not in features,'LABEL_IN_FEATURES')
    x = train[features]
    expected = np.log1p(train.RCYL.to_numpy(dtype=float)/training._target_scale(train,'log_ratio_last'))
    require(np.isfinite(expected).all(),'TRANSFORM_NONFINITE')
    while True:
        model = training._model_pipeline('extra_trees_log_ratio_last',x,config)
        prep = model.named_steps['preprocess']
        estimator = model.named_steps['model']
        original_prep,original_model_fit = prep.fit_transform,estimator.fit
        counts = {'preprocess':0,'model':0}
        entered = False
        completed_before = budget.model_completed
        def fit_preprocess(xx,yy=None,**kwargs):
            require(isinstance(xx,type(x)) and xx.equals(x),'PREPROCESS_TRAIN_SCOPE')
            require(np.array_equal(np.asarray(yy),expected),'PREPROCESS_TARGET')
            counts['preprocess'] += 1
            budget.preprocess_started += 1
            require(counts['preprocess']==1,'MULTIPLE_PREPROCESS_FITS')
            return original_prep(xx,yy,**kwargs)
        def fit_model(xx,yy,**kwargs):
            nonlocal entered
            require(len(xx)==len(x) and np.array_equal(np.asarray(yy),expected),'MODEL_TRAIN_SCOPE')
            require(counts['preprocess']==1,'MODEL_WITHOUT_TRAIN_PREPROCESS')
            budget.begin_model(); entered=True; counts['model'] += 1
            require(counts['model']==1,'MULTIPLE_MODEL_FITS')
            journal.add('model_fit_entered',tag=tag,budget=budget.snapshot())
            answer = original_model_fit(xx,yy,**kwargs)
            budget.complete_model()
            return answer
        prep.fit_transform,estimator.fit = fit_preprocess,fit_model
        try:
            training._fit_pipeline(model,'extra_trees_log_ratio_last',x,train.RCYL,train.horizon,train)
            require(counts=={'preprocess':1,'model':1},'FIT_COUNT_MISMATCH')
        except Exception as exc:
            journal.add('fit_failed',tag=tag,error_code=str(exc) if isinstance(exc,GateError) else type(exc).__name__,
                        entered_model_fit=entered,eligible_runtime_retry=transient_fault(exc),budget=budget.snapshot())
            if not transient_fault(exc) or budget.model_completed != completed_before:
                raise
            budget.retry()
            journal.add('runtime_retry_reserved',tag=tag,budget=budget.snapshot())
            continue
        finally:
            del prep.fit_transform
            del estimator.fit
        # Prediction failures do not repeat a successfully fitted model.
        view = valid.drop(columns=['RCYL'])
        prediction = np.clip(training.predict_pipeline_output(model,'extra_trees_log_ratio_last',view[features],view),0,None)
        require(len(prediction)==len(valid) and np.isfinite(prediction).all(),'INVALID_PREDICTION')
        journal.add('fit_and_prediction_completed',tag=tag,budget=budget.snapshot())
        del model
        return prediction


def summary_for(np,pd,official,frame,prediction):
    require(np.isfinite(prediction).all(),'OOF_NOT_COMPLETE')
    result = official_summary(frame.WELL_ID.tolist(),frame.horizon.tolist(),frame.RCYL.tolist(),prediction.tolist())
    check = frame[['WELL_ID','horizon','RCYL']].copy()
    check['prediction'] = prediction
    source_score = official(check,truth_column='RCYL',prediction_column='prediction',epsilon=1e-6).total
    require(abs(source_score-result['official_score'])<1e-10,'OFFICIAL_SCORE_IMPLEMENTATION_DISAGREEMENT')
    return result


def run_family(np,pd,training,official,frames,features,config,splits,seed,budget,journal,identity_check,output):
    predictions = {arm:np.full(len(frame),np.nan) for arm,frame in frames.items()}
    folds = {arm:[] for arm in frames}
    for index,(tr,va) in enumerate(splits,1):
        for arm,frame in frames.items():
            identity_check()
            tag = {'seed':seed,'fold':index,'arm':arm}
            tick = time.perf_counter()
            p = fit_one(np,training,frame,features,config,tr,va,budget,journal,tag)
            identity_check()  # A mid-fit environment/source change stops before any scoring.
            predictions[arm][va] = p
            score = summary_for(np,pd,official,frame.iloc[va],p)
            folds[arm].append(score['official_score'])
            journal.add('fold_scored',tag=tag,aggregate=score,elapsed_seconds=time.perf_counter()-tick,
                        train_wells=int(frame.iloc[tr].WELL_ID.nunique()),validation_wells=int(frame.iloc[va].WELL_ID.nunique()),
                        budget=budget.snapshot())
    identity_check()
    result = {'seed':seed,'arms':{arm:{**summary_for(np,pd,official,frames[arm],predictions[arm]),
                                      'fold_scores':folds[arm]} for arm in frames}}
    result['delta'] = result['arms']['candidate']['official_score']-result['arms']['control']['official_score']
    dump_new(output/('FIXED_FIVE_FOLD.json' if seed is None else f'REPEAT_{seed}.json'),result)
    # OOF arrays and all row keys cease to be reachable on return; aggregates only leave.
    return result


def privacy_scan(output,well_tokens,event_values):
    import re
    hits = 0
    checked = 0
    tokens = {str(t) for t in well_tokens if str(t)} | {str(t) for t in event_values if isinstance(t,str) and len(t)>=2}
    for file in output.rglob('*'):
        if not file.is_file() or file.suffix not in {'.json','.md'}:
            continue
        text = file.read_text(encoding='utf-8-sig')
        checked += 1
        for token in tokens:
            hits += bool(re.search(r'(?<![\w])'+re.escape(token)+r'(?![\w])',text))
        hits += bool(re.search(r'"(?:eligible_event_values|raw_value|y_true|y_pred|predictions|row_keys)"\s*:',text))
    return {'checked_report_files':checked,'private_token_hits':hits,'passed':hits==0,
            'numeric_candidate_value_check':'raw candidate fields never serialized; numeric constants alone are not identifier evidence'}


def execute(args):
    require(args.execute,'EXPLICIT_EXECUTE_FLAG_REQUIRED')
    prep = json.loads((HERE/ACTIVE_LOCK_NAME).read_bytes())
    for name,digest in prep['implementation_files'].items():
        require(sha((HERE/name).read_bytes())==digest,'IMPLEMENTATION_CHANGED_SINCE_PREPARATION')
    for name,digest in prep['upstream_readonly_files'].items():
        require(sha(Path(name).read_bytes())==digest,'UPSTREAM_CHANGED_SINCE_PREPARATION')
    plan = json.loads((HERE/'T1_SUPPLEMENT_PLAN.json').read_bytes())
    require(plan['approved_request']=='A2B-019' and plan['phase']=='T1','AUTHORIZATION_ID')
    require(args.accepted_entry.is_file(),'ACCEPTED_ENTRY_NOT_AVAILABLE')
    require(sha(args.accepted_entry.read_bytes())==ENTRY_SHA256,'ACCEPTED_ENTRY_HASH_MISMATCH')
    # No data read, project import, or execution marker before mandatory imports pass.
    import numpy as np
    import pandas as pd
    import sklearn.svm._libsvm
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import ExtraTreesRegressor
    from sklearn.model_selection import GroupKFold
    from threadpoolctl import threadpool_limits
    output = HERE/'execution'
    output.mkdir(exist_ok=False)  # Existing successful folds must never be silently rerun.
    journal = Journal(output)
    budget = FitBudget()
    sys.dont_write_bytecode = True
    sys.path.insert(0,str(PROJECT/'src'))
    from oil_uplift import training, a2b013_safe as safe, multistep as multi, config as config_module
    from oil_uplift.scoring import official_twelve_month_score
    require(Path(training.__file__).resolve().is_relative_to(PROJECT),'SOURCE_IMPORT_ROOT')
    source_before = input_identity(args.accepted_entry)
    env_before = environment()
    frames = store = config = None
    final = {'request':'A2B-019','phase':'T1','started':stamp(),'historical_dtype_identity':'UNKNOWN',
             'training_authorized':True,'training_completed':False,'scores_available':False,
             'deployment_authorized':False,'candidate_model_saved':False}
    def identities():
        require(input_identity(args.accepted_entry)==source_before,'INPUT_OR_IMPLEMENTATION_CHANGED')
        require(environment()==env_before,'PAIRED_ENVIRONMENT_CHANGED')
    try:
        with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
            config,control,candidate,features,families,store,ready = data_prepare(
                args.accepted_entry,np,pd,training,safe,multi,config_module,GroupKFold)
            identities()
            dummy = training._model_pipeline('extra_trees_log_ratio_last',control[features],config)
            require(dummy.named_steps['model'].get_params()['n_estimators']==400,'MODEL_PARAMS')
            lock = {'request':'A2B-019','phase':'T1','locked_before_first_fit_or_score':stamp(),
                    'environment':env_before,'source_and_input_files':source_before,
                    'model_parameters':dummy.named_steps['model'].get_params(),
                    'data_structure':ready,'training_authorized':True,
                    'historical_environment_identity_required':False,'historical_dtype_identity':'UNKNOWN',
                    'new_paired_baseline_authorized':True,'old_score_reused':False,
                    'new_control_and_candidate_same_environment_required':True}
            del dummy
            dump_new(output/'IMPLEMENTATION_PRETRAIN_LOCK.json',lock)
            dump_new(output/'STRUCTURAL_GATES.json',ready)
            frames = {'control':control,'candidate':candidate}
            # One active fold/arm; estimator n_jobs=-1 remains frozen; nested BLAS is limited.
            with threadpool_limits(limits=1):
                fixed = run_family(np,pd,training,official_twelve_month_score,frames,features,config,
                                   families[0][1],None,budget,journal,identities,output)
                b,c = fixed['arms']['control'],fixed['arms']['candidate']
                gate = fixed_gate(b['official_score'],c['official_score'],b['fold_scores'],c['fold_scores'],True)
                final.update({'fixed':fixed,'fixed_gate':gate,'scores_available':True})
                if not gate['passed']:
                    final.update({'status':'COMPLETED_STOP_PRIMARY_GATE_FAILED','training_completed':True})
                else:
                    repeats=[]
                    for seed,splits,_ in families[1:]:
                        repeats.append(run_family(np,pd,training,official_twelve_month_score,frames,features,config,
                                                  splits,seed,budget,journal,identities,output))
                    confirm = repeated_gate([x['delta'] for x in repeats])
                    final.update({'repeats':repeats,'repeat_gate':confirm,'training_completed':True,
                                  'status':'COMPLETED_PASSED_RESEARCH_GATES' if confirm['passed'] else 'COMPLETED_STOP_REPEAT_GATE_FAILED'})
            identities()
    except Exception as exc:
        final.update({'status':'STOPPED_STRUCTURE_OR_RUNTIME','error_code':str(exc) if isinstance(exc,GateError) else type(exc).__name__})
    finally:
        final['budget']=budget.snapshot()
        final['finished']=stamp()
        final['original_inputs_unchanged']=input_identity(args.accepted_entry)==source_before
        final['paired_environment_unchanged']=environment()==env_before
        if store is not None:
            final['raw_archive_and_manifest_unchanged']=store.unchanged()
            store.close()
        dump_new(output/'FINAL_RESULT.json',final)
        well_tokens = [] if frames is None else frames['control'].WELL_ID.tolist()
        if frames is not None:
            well_tokens += train_test_wells_for_scan(frames,config)
        scan = privacy_scan(output,well_tokens,[] if config is None else config['anchors']['eligible_event_values'])
        dump_new(output/'PRIVACY_SCAN.json',scan)
        hashes = {p.relative_to(output).as_posix():sha(p.read_bytes()) for p in output.rglob('*') if p.is_file()}
        dump_new(output/'SHA256SUMS.json',hashes)
        require(scan['passed'],'PRIVACY_SCAN_FAILED')
    print(json.dumps({'status':final['status'],'budget':budget.snapshot(),'training_completed':final['training_completed']},ensure_ascii=True))


def train_test_wells_for_scan(frames,config):
    # All original history well identifiers are included, not just eligible training wells.
    store = ArchiveStore(RAW_ARCHIVE,RAW_MANIFEST)
    try:
        import pandas as pd
        tokens = []
        for key,names in store.role_members(config).items():
            if key[1] != 'history':
                continue
            for name in names:
                frame=pd.read_csv(io.BytesIO(store.zip.read(store.members[name])),
                                  encoding=config['data']['csv']['encoding'],sep=config['data']['csv']['delimiter'])
                tokens.extend(frame.WELL_ID.tolist())
        return tokens
    finally:
        store.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accepted-entry',type=Path,required=True)
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    try:
        execute(args)
        return 0
    except Exception as exc:
        print(json.dumps({'status':'STOPPED','error_code':str(exc) if isinstance(exc,GateError) else type(exc).__name__,
                          'training_authorized':True,'no_automatic_restart':True},ensure_ascii=True))
        return 1


if __name__=='__main__':
    sys.exit(main())
