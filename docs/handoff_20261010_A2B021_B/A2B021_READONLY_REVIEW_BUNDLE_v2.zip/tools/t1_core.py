"""Pure, independently testable scoring, decision and fit-budget contracts."""
from collections import defaultdict
import hashlib
import json
import math
import statistics

SEEDS = [20260917, 20261031, 20261219, 20270107, 20270303]
ENTRY_SHA256 = '753762da9a7e0a7c7f734587a458b961dbdd00d9eb4e4f489d1cbb0a659ddf67'


class GateError(Exception):
    pass


def require(condition, code):
    if not condition:
        raise GateError(code)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def raw_scale(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 1.0
    return number if math.isfinite(number) and number > 0 else 1.0


def official_summary(wells, horizons, truth, prediction):
    require(len(wells) == len(horizons) == len(truth) == len(prediction) > 0, 'SCORE_LENGTH')
    grouped = defaultdict(list)
    for well, step, y, p in zip(wells, horizons, truth, prediction, strict=True):
        require(float(step).is_integer() and 1 <= step <= 12, 'INVALID_HORIZON')
        y, p = float(y), float(p)
        require(math.isfinite(y) and math.isfinite(p) and y >= 0 and p >= 0, 'INVALID_SCORE_VALUE')
        grouped[well].append((int(step), y, p))
    losses = {n: [] for n in (1, 2, 4, 12)}
    for rows in grouped.values():
        require(sorted(x[0] for x in rows) == list(range(1, 13)), 'INCOMPLETE_OR_DUPLICATE_HORIZON')
        # No leading two, no weight normalization, no truncation renormalization.
        for n in losses:
            losses[n].append(math.fsum(2.0**(-t) * abs(p-y)/(abs(p)+abs(y)+1e-6)
                                       for t,y,p in rows if t <= n))
    mean_losses = {str(n): math.fsum(items)/len(items) for n,items in losses.items()}
    return {'official_score': 100.0*(1.0-mean_losses['12']),
            'official_weighted_loss': mean_losses,
            'loss_units': 'dimensionless; unnormalized 2^-t; equal mean over complete wells',
            'well_count': len(grouped)}


def fixed_gate(control, candidate, control_folds, candidate_folds, structural):
    require(len(control_folds) == len(candidate_folds) == 5, 'FIVE_FOLDS_REQUIRED')
    require(all(math.isfinite(float(x)) for x in [control, candidate, *control_folds, *candidate_folds]), 'NONFINITE_GATE_SCORE')
    delta = candidate-control
    worst_delta = min(candidate_folds)-min(control_folds)
    return {'delta':delta, 'control_worst_fold':min(control_folds),
            'candidate_worst_fold':min(candidate_folds), 'worst_fold_delta':worst_delta,
            'control_fold_std_ddof0':statistics.pstdev(control_folds),
            'candidate_fold_std_ddof0':statistics.pstdev(candidate_folds),
            'overall_delta_passed':delta >= -0.20, 'worst_fold_delta_passed':worst_delta >= -1.00,
            'structural_passed':bool(structural),
            'passed':bool(structural) and delta >= -0.20 and worst_delta >= -1.00}


def repeated_gate(deltas):
    require(len(deltas) == 5 and all(math.isfinite(float(x)) for x in deltas), 'FIVE_REPEAT_DELTAS_REQUIRED')
    mean = math.fsum(deltas)/5
    qualified = sum(x >= -0.20 for x in deltas)
    return {'mean_delta':mean,'count_delta_at_least_minus_0_20':qualified,
            'positive':sum(x > 0 for x in deltas),'zero':sum(x == 0 for x in deltas),
            'negative':sum(x < 0 for x in deltas),
            'passed':mean >= -0.20 and qualified >= 4,
            'interpretation':'engineering loss budget; not semantic evidence or statistical noninferiority'}


class FitBudget:
    """Attempts are counted at the actual model.fit boundary, including failures."""
    def __init__(self):
        self.model_started = 0
        self.model_completed = 0
        self.preprocess_started = 0
        self.retries_used = 0

    def begin_model(self):
        require(self.model_started < 62 and self.model_completed < 60, 'MODEL_FIT_BUDGET_EXHAUSTED')
        self.model_started += 1

    def complete_model(self):
        require(self.model_completed < self.model_started, 'FIT_COMPLETION_WITHOUT_START')
        self.model_completed += 1

    def retry(self):
        require(self.retries_used < 2, 'RETRY_BUDGET_EXHAUSTED')
        self.retries_used += 1

    def snapshot(self):
        return dict(self.__dict__)
