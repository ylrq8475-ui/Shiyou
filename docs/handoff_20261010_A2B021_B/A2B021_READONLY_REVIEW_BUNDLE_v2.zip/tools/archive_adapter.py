"""Explicit archive-to-declaration reader; no extraction, no raw persistence."""
from pathlib import PurePosixPath
import hashlib
import io
import json
import zipfile
from t1_core import require, fingerprint


def sha(data):
    return hashlib.sha256(data).hexdigest()


def decoded_name(info):
    name = info.filename
    if not info.flag_bits & 0x800:
        try:
            name = name.encode('cp437').decode('gb18030')
        except UnicodeError:
            pass
    name = name.replace('\\', '/')
    path = PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and ':' not in name, 'UNSAFE_ARCHIVE_NAME')
    return name


class ArchiveStore:
    def __init__(self, archive_path, manifest_path):
        self.archive_path = archive_path
        self.manifest_path = manifest_path
        self.archive_hash = sha(archive_path.read_bytes())
        self.manifest_hash = sha(manifest_path.read_bytes())
        self.zip = zipfile.ZipFile(archive_path, 'r')
        infos = [i for i in self.zip.infolist() if not i.is_dir()]
        require(len(infos) == 100 and sum(i.file_size for i in infos) < 100_000_000, 'RAW_INVENTORY_DRIFT')
        self.members = {decoded_name(i): i for i in infos}
        require(len(self.members) == len(infos), 'DUPLICATE_ARCHIVE_MEMBER')
        require(len({n.casefold() for n in self.members}) == len(infos), 'CASE_COLLIDING_MEMBER')
        manifest = json.loads(manifest_path.read_bytes())
        require(manifest['file_count'] == len(manifest['files']) == 100, 'MANIFEST_COUNT_DRIFT')
        self.by_declared = {}
        used = set()
        for item in manifest['files']:
            relative = item['relative_path'].replace('\\', '/')
            hits = [n for n in self.members if n == relative or n.endswith('/'+relative)]
            require(len(hits) == 1 and hits[0] not in used, 'MANIFEST_MEMBER_NOT_UNIQUE')
            member = hits[0]
            used.add(member)
            content = self.zip.read(self.members[member])
            require(len(content) == item['bytes'] and sha(content) == item['sha256'], 'RAW_BYTES_CHANGED')
            self.by_declared[relative] = member
        require(len(used) == len(self.members), 'UNLISTED_RAW_MEMBER')

    def role_members(self, config):
        roles = {}
        for split, role in [('train','history'),('test','history'),('test','template')]:
            declared = config['data']['sources'][split][role]
            members = []
            for entry in declared:
                normalized = entry.replace('\\','/')
                require(normalized in self.by_declared, 'UNMAPPED_DECLARATION')
                members.append(self.by_declared[normalized])
            require(len(members) == len(set(members)), 'DUPLICATE_FILE_WITHIN_ROLE')
            roles[(split,role)] = members
        require(len(roles[('train','history')]) == 88, 'TRAIN_ROLE_COUNT')
        require(len(roles[('test','history')]) == len(roles[('test','template')]) == 10, 'TEST_ROLE_COUNT')
        require(not set(roles[('train','history')]) &
                (set(roles[('test','history')]) | set(roles[('test','template')])), 'TRAIN_TEST_SOURCE_OVERLAP')
        return roles

    def load_tables(self, config, table_type):
        import pandas as pd
        roles = self.role_members(config)
        def read(split, role):
            settings = config['data']['csv']
            frames = [pd.read_csv(io.BytesIO(self.zip.read(self.members[name])),
                                  encoding=settings.get('encoding','utf-8-sig'),
                                  sep=settings.get('delimiter',',')) for name in roles[(split,role)]]
            require(all(list(f.columns) == list(frames[0].columns) for f in frames), 'ROLE_SCHEMA_DRIFT')
            return pd.concat(frames,ignore_index=True)
        train = table_type(read('train','history'),pd.DataFrame(),pd.DataFrame(),None)
        test = table_type(read('test','history'),pd.DataFrame(),pd.DataFrame(),read('test','template'))
        return train,test,{'raw_files_verified':100,'roles':{'train_history':88,'test_history':10,'test_template':10},
                           'ordered_declared_role_digest':fingerprint([[list(k),v] for k,v in roles.items()]),
                           'test_history_template_overlap':len(set(roles[('test','history')]) & set(roles[('test','template')])),
                           'raw_extracted_or_copied':False,'reader':'pd.read_csv(BytesIO); original encoding/delimiter; original declared order'}

    def unchanged(self):
        return sha(self.archive_path.read_bytes()) == self.archive_hash and sha(self.manifest_path.read_bytes()) == self.manifest_hash

    def close(self):
        self.zip.close()
