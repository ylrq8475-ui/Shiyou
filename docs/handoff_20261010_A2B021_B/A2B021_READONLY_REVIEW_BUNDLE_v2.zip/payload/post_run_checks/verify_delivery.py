"""Post-score read-only arithmetic and anonymous interpretation; never trains."""
from pathlib import Path
from datetime import datetime
import hashlib
import io
import json
import math
import statistics
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'execution'
DEST = ROOT/'post_run_checks'
PYTHON = Path(r'D:\codex\b-runtime-20261009-py3137\venv\Scripts\python.exe')


def load(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False)
def mean(x):return math.fsum(x)/len(x)
def close(a,b,tolerance=1e-10):return abs(a-b)<=tolerance


def main():
    result=load(OUT/'FINAL_RESULT.json')
    lock=load(OUT/'IMPLEMENTATION_PRETRAIN_LOCK.json')
    events=[load(p) for p in sorted((OUT/'events').glob('*.json'))]
    checks=[]
    def check(condition,code):
        checks.append({'check':code,'passed':bool(condition)})
        if not condition:raise RuntimeError(code)
    check(result['training_completed'] and len(result['research'])==6,'SIX_RESEARCH_FAMILIES_COMPLETE')
    check(result['budget']=={'pipeline_attempts':120,'preprocess_entered':120,'preprocess_completed':120,
          'model_entered':120,'model_completed':120,'retries_used':0},'EXACT_120_FITS_NO_FAILURES_OR_RETRIES')
    model_entries=[e for e in events if e['event']=='model_fit_entered']
    completions=[e for e in events if e['event']=='fit_completed']
    check(len(model_entries)==len(completions)==120,'EVENT_FIT_COUNTS_MATCH')
    check(all(e['train_rows']==e['train_wells']*(12 if e['tag']['arm']=='B0' else 2) for e in model_entries),'ACTUAL_TRAINING_ROW_SCOPES')
    check(all(e['actual_calls']=={'preprocess':1,'model':1} for e in completions),'OBSERVED_PREPROCESS_MODEL_CALL_COUNTS')
    check(all(Path(p).is_file() and sha(Path(p))==digest for p,digest in lock['source_and_input_files'].items()),'PRESCORE_SOURCE_AND_INPUT_HASHES_UNCHANGED')
    original_manifest=load(OUT/'SHA256SUMS.json')
    check(all(sha(ROOT/name)==digest for name,digest in original_manifest.items()),'END_OF_EXECUTION_ORIGINAL_MANIFEST_MATCHES')
    check([r['seed'] for r in result['research']]==[None,20260917,20261031,20261219,20270107,20270303],'ONLY_PREREGISTERED_RESEARCH_SEEDS')
    params=lock['model_and_preprocess_contracts']
    check(params['B0']['model_get_params']==params['C1']['model_get_params'],'B0_C1_SAME_MODEL_PARAMETERS')
    check([k for k in params['C2']['model_get_params'] if params['C2']['model_get_params'][k]!=params['C3']['model_get_params'][k]]==['loss'],'C2_C3_ONLY_LOSS_DIFFERS')
    for family in result['research']:
        seed=family['seed'];scores=family['arms']
        well_counts={e['tag']['fold']:81-e['train_wells'] for e in model_entries if e['tag']['seed']==seed and e['tag']['arm']=='B0'}
        check(sum(well_counts.values())==81,f'{seed}_OOF_WELL_COUNTS')
        for arm,row in scores.items():
            weighted=row['monthly_official_weighted_loss']
            check(close(row['official_score'],100*(1-math.fsum(weighted))),f'{seed}_{arm}_SCORE_FROM_MONTHLY_LOSS')
            check(all(close(weighted[i],row['monthly_unweighted_relative_error'][i]*2**(-(i+1)),1e-12) for i in range(12)),f'{seed}_{arm}_UNNORMALIZED_MONTH_WEIGHTS')
            check(all(close(row['official_weighted_prefix_loss'][str(n)],math.fsum(weighted[:n]),1e-12) for n in [1,2,4,12]),f'{seed}_{arm}_PREFIX_ARITHMETIC')
            check(close(row['official_score'],math.fsum(s*well_counts[i] for i,s in enumerate(row['fold_scores'],1))/81),f'{seed}_{arm}_OOF_WELL_WEIGHTED_FOLD_SCORE')
            check(close(row['fold_std_ddof0'],statistics.pstdev(row['fold_scores'])) and row['worst_fold']==min(row['fold_scores']),f'{seed}_{arm}_FOLD_STATISTICS')
            check(close(row['delta_vs_B0'],row['official_score']-scores['B0']['official_score']),f'{seed}_{arm}_PAIRED_SCORE_DELTA')
            check(all(close(a,b-c) for a,b,c in zip(row['paired_fold_deltas'],row['fold_scores'],scores['B0']['fold_scores'],strict=True)),f'{seed}_{arm}_PAIRED_FOLD_DELTAS')
            if arm!='B0':
                check(weighted[2:]==scores['B0']['monthly_official_weighted_loss'][2:],f'{seed}_{arm}_LATE_MONTH_LOSSES_IDENTICAL')
                check(row['diagnostics']['monthly_net_weighted_loss_change_vs_B0'][2:]==[0.]*10,f'{seed}_{arm}_LATE_NET_CHANGE_ZERO')
            for group in row['diagnostics']['prediction_state_groups'].values():
                check(group['status']=='SUPPRESSED' or group['group_wells']>=5 and group['complement_wells']>=5,f'{seed}_{arm}_STATE_PRIVACY')
    repeats=result['research'][1:]
    fusion_components={'F12':('C1','C2'),'F13':('C1','C3'),'F23':('C2','C3')}
    for arm,gate in result['research_gates'].items():
        deltas=[r['arms'][arm]['official_score']-r['arms']['B0']['official_score'] for r in repeats]
        expected=mean(deltas)>=.2 and sum(d>0 for d in deltas)>=4 and min(deltas)>=-.2
        check(close(gate['mean_delta'],mean(deltas)) and gate['positive_repeats']==sum(d>0 for d in deltas) and close(gate['worst_repeat_delta'],min(deltas)),f'{arm}_REPEAT_GATE_ARITHMETIC')
        if arm in fusion_components:
            components=fusion_components[arm]
            reference=min(components,key=lambda c:(-mean([r['arms'][c]['official_score'] for r in repeats]),['C1','C2','C3'].index(c)))
            extra=mean([r['arms'][arm]['official_score'] for r in repeats])-mean([r['arms'][reference]['official_score'] for r in repeats])
            check(gate['locked_reference_component']==reference and close(gate['mean_gain_over_reference'],extra),f'{arm}_FIXED_REFERENCE_AND_EXTRA_GAIN')
            expected=expected and extra>=.05
        check(gate['passed']==expected,f'{arm}_PREREGISTERED_GATE_DECISION')
    check(not result['qualified'] and not result['confirmed'] and not (OUT/'CONFIRMATION.json').exists() and not (ROOT/'private_models').exists(),'STOP_WITHOUT_CONFIRMATION_OR_MODELS')
    check(result['current_inputs_unchanged'] and result['environment_unchanged'] and result['raw_data_after']['archive_and_manifest_unchanged'] and result['old_artifacts_after']['all_match'],'INTEGRITY_FINAL_GATES')
    total_seconds=(datetime.fromisoformat(result['finished'])-datetime.fromisoformat(result['started'])).total_seconds()
    timing={'total_elapsed_seconds':total_seconds,'six_family_seconds':[r['elapsed_seconds'] for r in result['research']],
            'active_model_fits':1,'ExtraTrees_n_jobs':-1,'BLAS_OpenMP_threads':1,'fold_parallelism':False,
            'speedup_vs_old_machine':'NOT_MEASURED'}
    save(DEST/'POST_RUN_ARITHMETIC_CHECKS.json',{'scope':'read-only post-score arithmetic; not independent real training reproduction',
         'checks':checks,'all_passed':True,'count':len(checks),'timing':timing})
    # Extract only small anonymous code files from the review bundle, preserving package bytes.
    package=ROOT/'delivery/A2B021_READONLY_REVIEW_BUNDLE.zip'
    tools=DEST/'portable_tools';tools.mkdir()
    with zipfile.ZipFile(package) as z:
        manifest=json.loads(z.read('SHA256SUMS_REVIEW.json'))
        for name in z.namelist():
            if name.startswith('tools/') and name.endswith('.py'):
                relative=Path(name)
                check(len(relative.parts)==2 and relative.name not in ('.','..'),'SAFE_PORTABLE_CODE_PATH')
                value=z.read(name)
                check(hashlib.sha256(value).hexdigest()==manifest[name]['sha256'],'PORTABLE_TOOL_BYTES_MATCH')
                (tools/relative.name).write_bytes(value)
    run=subprocess.run([str(PYTHON),'-E','-B','-m','unittest','test_contracts','test_harness','-v'],cwd=tools,
                       capture_output=True,text=True,encoding='utf-8')
    check(run.returncode==0 and 'Ran 30 tests' in run.stderr and 'OK' in run.stderr,'PACKAGED_SYNTHETIC_CHECKS_PASS')
    identity=subprocess.run([str(PYTHON),'-E','-B','-c',
        'import json,run_research; print(json.dumps({"runner":run_research.__file__,"prior":run_research.prior.__file__}))'],
        cwd=tools,capture_output=True,text=True,encoding='utf-8')
    imported=json.loads(identity.stdout)
    check(all(Path(v).resolve().is_relative_to(tools) for v in imported.values()),'PACKAGED_MODULES_IMPORTED_LOCALLY')
    save(DEST/'PACKAGED_SYNTHETIC_RETEST.json',{'passed':True,'tests':30,'real_fits':0,
         'package_sha256':sha(package),'imports':imported,'stdout':run.stdout,'stderr':run.stderr,
         'claim':'B local byte-exact package retest; not A independent audit'})
    baseline=[r['arms']['B0'] for r in repeats]
    leaf={}
    for arm in ['B0','C1']:
        observations=[s['early_validation_row_tree_visits'] for r in result['research'] for s in r['leaf_support'][arm]]
        leaf[arm]={'validation_visit_weighted_mean_distinct_train_wells':math.fsum(o['mean_distinct_train_wells']*o['leaf_observations'] for o in observations)/sum(o['leaf_observations'] for o in observations),
                   'validation_visit_weighted_fraction_support_lt5':math.fsum(o['fraction_support_lt5']*o['leaf_observations'] for o in observations)/sum(o['leaf_observations'] for o in observations)}
    changes=[r['arms']['C3']['official_score']-r['arms']['C2']['official_score'] for r in repeats]
    profile={'repeat_mean_B0_monthly_relative_error':[mean([r['monthly_unweighted_relative_error'][i] for r in baseline]) for i in range(12)],
             'repeat_mean_B0_monthly_weighted_loss':[mean([r['monthly_official_weighted_loss'][i] for r in baseline]) for i in range(12)],
             'repeat_mean_B0_top10percent_loss_share':mean([r['diagnostics']['loss_concentration']['own_loss_share_top_wells'] for r in baseline]),
             'leaf_support':leaf,'C3_minus_C2_repeat_deltas':changes,'C3_minus_C2_repeat_mean_delta':mean(changes),
             'C3_minus_C2_positive_repeats':sum(d>0 for d in changes),
             'state_groups':[r['diagnostics']['prediction_state_groups'] for r in baseline],
             'not_used_for_selection_or_training':True}
    save(DEST/'ANONYMOUS_DIAGNOSTIC_PROFILE.json',profile)
    relative=profile['repeat_mean_B0_monthly_relative_error']
    early_relative=mean(relative[:2]);next_relative=mean(relative[2:4])
    lines=['# A2B-021 结果解读补充','',
       '本文件在训练结束后只读取匿名聚合生成，不修改模型、切分、门槛或分数前实现锁。', '',
       f'五组重复中，B0前两月平均未加权相对误差为 {early_relative:.9f}，第3—4月为 {next_relative:.9f}。早期官方损失份额受权重影响，不能据份额认定早期特别难。', '',
       f'B0损失最高约10%井（9/81）的损失贡献份额，五组均值为 {profile["repeat_mean_B0_top10percent_loss_share"]:.6%}。这属于回顾性集中度，未用于删除、加权或路由。', '',
       f'B0早期验证行访问叶的独立训练井支持均值为 {leaf["B0"]["validation_visit_weighted_mean_distinct_train_wells"]:.6f}；C1为 {leaf["C1"]["validation_visit_weighted_mean_distinct_train_wells"]:.6f}。低于5井支持的访问占比依次为 {leaf["B0"]["validation_visit_weighted_fraction_support_lt5"]:.6%}、{leaf["C1"]["validation_visit_weighted_fraction_support_lt5"]:.6%}。这是结构描述，未建立与误差的因果关系。', '',
       f'C3相对C2的五组平均完整OOF增量为 {mean(changes):+.9f}，正向 {sum(d>0 for d in changes)}/5。损失函数变化有相对改善，但C3仍低于B0，不能获得独立研究资格。', '',
       'C1最接近B0：五组平均增量−0.030325361，只有3/5正向，最差−0.884974229，三项研究数值门槛均未通过。不能只选择它正向的切分，也不追加搜索。', '',
       f'本轮执行耗时 {total_seconds:.3f} 秒（含结构准备、锁定和评价）；六组训练评价累计 {math.fsum(timing["six_family_seconds"]):.3f} 秒。此值不是与原机器的加速倍数。', '',
       '明确结论：本轮没有支持升级的合格方案，维持当前冻结成果。主要可修复误差机制仍不确定。确认种子20271009只作分数前分组结构检查，没有训练、评分或选择，保留未查看确认成绩的状态。']
    (DEST/'DIAGNOSTIC_INTERPRETATION.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'all_passed':True,'arithmetic_checks':len(checks),'portable_tests':30,'real_new_fits':0,
                      'elapsed_seconds':total_seconds,'profile':profile},ensure_ascii=True))


if __name__=='__main__':main()
