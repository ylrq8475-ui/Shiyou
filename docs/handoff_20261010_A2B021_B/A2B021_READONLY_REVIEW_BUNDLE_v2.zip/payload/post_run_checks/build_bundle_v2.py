"""Append post-run evidence to a new anonymous bundle; preserve v1 and all locks."""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from run_research import prior,sha,dump,old_integrity


def main():
    destination=ROOT/'delivery'
    lock=json.loads((ROOT/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json').read_bytes())
    assert all(Path(p).is_file() and sha(Path(p))==v for p,v in lock['source_and_input_files'].items())
    assert old_integrity()['all_match']
    arithmetic=json.loads((ROOT/'post_run_checks/POST_RUN_ARITHMETIC_CHECKS.json').read_bytes())
    portable=json.loads((ROOT/'post_run_checks/PACKAGED_SYNTHETIC_RETEST.json').read_bytes())
    assert arithmetic['all_passed'] and portable['passed'] and portable['real_fits']==0
    sys.path.insert(0,str(prior.PROJECT/'src'))
    from oil_uplift.config import load_config
    from oil_uplift.a2b013_safe import safe_config
    config=safe_config(load_config(prior.PRIVATE_CONFIG))
    tokens=prior.train_test_wells_for_scan({},config)
    token_set={str(t) for t in tokens if str(t)}|{str(t) for t in config['anchors']['eligible_event_values'] if isinstance(t,str) and len(t)>=2}
    files={}
    for path in ROOT.rglob('*'):
        if not path.is_file():continue
        parts=path.relative_to(ROOT).parts
        if 'private_models' in parts or 'portable_tools' in parts or path.suffix in {'.zip','.joblib','.pyc'}:continue
        files['payload/'+path.relative_to(ROOT).as_posix()]=path
    for path in ROOT.glob('*.py'):files['tools/'+path.name]=path
    for name in ['paired_experiment.py','archive_adapter.py','t1_core.py']:files['tools/'+name]=prior.HERE/name
    for path in (prior.PROJECT/'src').rglob('*.py'):
        assert sha(path)==lock['source_and_input_files'][str(path)]
        files['upstream/src/'+path.relative_to(prior.PROJECT/'src').as_posix()]=path
    entry=prior.HERE/'accepted_entry/received_20261009_v1/payload/audit_payload/migration_acceptance_20261009_r1/boundary_audit.py'
    files['upstream/accepted_boundary_audit.py']=entry
    files['upstream/requirements-lock.txt']=prior.PROJECT/'requirements-lock.txt'
    manifest={name:{'sha256':sha(path),'bytes':path.stat().st_size} for name,path in sorted(files.items())}
    readme=('A2B-021 read-only review bundle v2. v1 preserved; no training repeated.\n'
        'Start with payload/delivery/REPORT_B.md and B2A_021_REVIEW_REQUEST.md.\n'
        'Read payload/post_run_checks/DIAGNOSTIC_INTERPRETATION.md, POST_RUN_ARITHMETIC_CHECKS.json, PACKAGED_SYNTHETIC_RETEST.json.\n'
        'All 26 original runtime Python sources supplied as exact locked bytes under upstream/src.\n'
        'Verify SHA256SUMS_REVIEW.json. Synthetic-only command: cd tools; python -E -B -m unittest test_contracts test_harness -v\n'
        'Do NOT run any training, execution or preparation entrypoint. No raw data, private config, OOF, well identifiers, labels or model weights included.\n'
        'These are account B execution and local retest evidence, not independent A acceptance.\n')
    manifest['README.md']={'sha256':hashlib.sha256(readme.encode()).hexdigest(),'bytes':len(readme.encode())}
    hits=0
    for name,path in files.items():
        if path.suffix in {'.py','.json','.md','.txt','.sha256'}:
            text=path.read_text(encoding='utf-8-sig')
            hits+=sum(bool(re.search(r'(?<![\w])'+re.escape(t)+r'(?![\w])',text)) for t in token_set)
    assert hits==0, 'PRIVATE_IDENTIFIER_FOUND_IN_REVIEW_SOURCE'
    package=destination/'A2B021_READONLY_REVIEW_BUNDLE_v2.zip'
    with zipfile.ZipFile(package,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
        z.writestr('README.md',readme)
        z.writestr('SHA256SUMS_REVIEW.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
    with zipfile.ZipFile(package) as z:
        assert all(hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] and len(z.read(n))==v['bytes'] for n,v in manifest.items())
        assert not any(n.endswith(('.joblib','.csv','.yaml','.yml','.pkl','.npy','.npz')) for n in z.namelist())
    info={'package':str(package),'sha256':sha(package),'bytes':package.stat().st_size,
          'manifest_files':len(manifest),'private_token_hits':hits,'exact_byte_checks_passed':True,
          'post_run_arithmetic_checks':arithmetic['count'],'packaged_synthetic_tests':30,
          'upstream_runtime_py_files':len(list((prior.PROJECT/'src').rglob('*.py'))),
          'real_fits_added':0,'account_A_independent_review':'PENDING',
          'pretrain_source_inputs_unchanged':True,'old_T1_136_files_unchanged':True,
          'excludes_raw_data_private_config_OOF_labels_and_weights':True}
    dump(destination/'REVIEW_PACKAGE_VERIFICATION_v2.json',info)
    (destination/'A2B021_READONLY_REVIEW_BUNDLE_v2.zip.sha256').write_text(info['sha256']+'  '+package.name+'\n',encoding='ascii')
    dump(destination/'SHA256SUMS_FINAL_v2.json',{p.relative_to(ROOT).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in ROOT.rglob('*') if p.is_file()})
    print(json.dumps(info,ensure_ascii=True))


if __name__=='__main__':main()
