"""Synthetic spies only. No sklearn estimator or learning preprocessor is fitted."""
import unittest
from types import SimpleNamespace
import numpy as np
import pandas as pd
from experiment_core import GateError, FitBudget, raw_status
from run_research import fit_one, prediction_states


class JournalSpy:
    def __init__(self): self.events = []
    def add(self, name, **payload): self.events.append((name,payload))


class PrepSpy:
    def __init__(self, failure=None): self.failure = failure
    def fit_transform(self,x,y):
        if self.failure is not None: raise self.failure
        return x.to_numpy(dtype=float)
    def transform(self,x): return x.to_numpy(dtype=float)


class ModelSpy:
    def __init__(self,failure=None): self.failure = failure
    def fit(self,x,y):
        if self.failure is not None: raise self.failure
        return self
    def apply(self,x): return np.ones((len(x),1),dtype=int)


class PipelineSpy:
    def __init__(self,prep_failure=None,model_failure=None):
        self.named_steps = {'preprocess':PrepSpy(prep_failure),'model':ModelSpy(model_failure)}
    def fit(self,x,y):
        z = self.named_steps['preprocess'].fit_transform(x,y)
        self.named_steps['model'].fit(z,y)


class HarnessContracts(unittest.TestCase):
    def setUp(self):
        self.frame = pd.DataFrame({'WELL_ID':np.repeat([f'SYNTHETIC_{i}' for i in range(10)],12),
             'horizon':list(range(1,13))*10,'history__RCYL__last':[2.]*120,'RCYL':[4.]*120})
        self.train,self.valid = self.frame.iloc[:60],self.frame.iloc[60:]
        self.observed = []
        def fit(pipeline,name,x,y,horizon,panel):
            self.observed.append((x.copy(), np.asarray(y), horizon.copy()))
            pipeline.fit(x,np.log1p(np.asarray(y)/raw_status(panel['history__RCYL__last'])[0]))
        self.training = SimpleNamespace(_fit_pipeline=fit,
              _target_scale=lambda panel,name:raw_status(panel['history__RCYL__last'])[0],
              predict_pipeline_output=lambda pipeline,name,x,panel:np.ones(len(x)))
        self.ctx = SimpleNamespace(training=self.training,features=['horizon','history__RCYL__last'],
                  identity_check=lambda:None,budget=FitBudget(),journal=JournalSpy())
        self.factory = lambda ctx,arm,x:PipelineSpy()

    def test_early_scopes_and_wrappers_removed(self):
        pipe,p,_ = fit_one(self.ctx,self.train,self.valid,'C2',{},self.factory)
        self.assertEqual(len(p),10)
        self.assertEqual(self.observed[0][0].horizon.tolist(),[1,2]*5)
        self.assertNotIn('fit_transform',pipe.named_steps['preprocess'].__dict__)
        self.assertNotIn('fit',pipe.named_steps['model'].__dict__)
        self.assertEqual(self.ctx.budget.model_completed,1)
        self.assertEqual(self.ctx.budget.preprocess_completed,1)

    def test_B0_all_twelve_and_independent_well_leaf_support(self):
        _,p,s = fit_one(self.ctx,self.train,self.valid,'B0',{},self.factory)
        self.assertEqual(len(self.observed[0][0]),60)
        self.assertEqual(len(p),60)
        self.assertEqual(s['occupied_training_leaves']['mean_distinct_train_wells'],5)

    def test_validation_well_overlap_blocks_before_fit(self):
        with self.assertRaises(GateError): fit_one(self.ctx,self.train,self.train,'C2',{},self.factory)
        self.assertEqual(self.ctx.budget.model_entered,0)

    def test_validation_preprocess_scope_blocks_before_entry(self):
        self.training._fit_pipeline = lambda pipe,name,x,y,h,panel:pipe.fit(self.valid[self.ctx.features],np.ones(60))
        with self.assertRaises(GateError): fit_one(self.ctx,self.train,self.valid,'C2',{},self.factory)
        self.assertEqual(self.ctx.budget.preprocess_entered,0)
        self.assertEqual(self.ctx.budget.model_entered,0)

    def test_wrong_transformed_target_blocks(self):
        self.training._fit_pipeline = lambda pipe,name,x,y,h,panel:pipe.fit(x,np.zeros(len(x)))
        with self.assertRaises(GateError): fit_one(self.ctx,self.train,self.valid,'C2',{},self.factory)
        self.assertEqual(self.ctx.budget.model_entered,0)

    def test_clear_failed_model_retries_once_and_counts(self):
        calls=[]
        def factory(ctx,arm,x):
            calls.append(1)
            return PipelineSpy(model_failure=MemoryError() if len(calls)==1 else None)
        fit_one(self.ctx,self.train,self.valid,'C2',{},factory)
        self.assertEqual(self.ctx.budget.model_entered,2)
        self.assertEqual(self.ctx.budget.model_completed,1)
        self.assertEqual(self.ctx.budget.retries_used,1)

    def test_failed_preprocess_retry_is_bounded_and_recorded(self):
        calls=[]
        def factory(ctx,arm,x):
            calls.append(1)
            return PipelineSpy(prep_failure=MemoryError() if len(calls)==1 else None)
        fit_one(self.ctx,self.train,self.valid,'C2',{},factory)
        self.assertEqual(self.ctx.budget.preprocess_entered,2)
        self.assertEqual(self.ctx.budget.preprocess_completed,1)
        self.assertEqual(self.ctx.budget.model_entered,1)
        self.assertEqual(self.ctx.budget.retries_used,1)

    def test_policy_failure_is_not_retried(self):
        factory=lambda ctx,arm,x:PipelineSpy(model_failure=OSError(1260,'synthetic policy block'))
        with self.assertRaises(OSError):fit_one(self.ctx,self.train,self.valid,'C2',{},factory)
        self.assertEqual(self.ctx.budget.model_entered,1)
        self.assertEqual(self.ctx.budget.retries_used,0)

    def test_successful_model_prediction_failure_never_refits(self):
        def fail(*args): raise MemoryError()
        self.training.predict_pipeline_output=fail
        with self.assertRaises(MemoryError):fit_one(self.ctx,self.train,self.valid,'C2',{},self.factory)
        self.assertEqual(self.ctx.budget.model_completed,1)
        self.assertEqual(self.ctx.budget.model_entered,1)
        self.assertEqual(self.ctx.budget.retries_used,0)

    def test_identity_change_after_fit_blocks_prediction(self):
        checks=[]; predictions=[]
        def check():
            checks.append(1)
            if len(checks)==2:raise GateError('SYNTHETIC_IDENTITY_CHANGED')
        self.ctx.identity_check=check
        self.training.predict_pipeline_output=lambda *args:predictions.append(1)
        with self.assertRaises(GateError):fit_one(self.ctx,self.train,self.valid,'C2',{},self.factory)
        self.assertEqual(self.ctx.budget.model_completed,1)
        self.assertEqual(predictions,[])

    def test_state_threshold_uses_independent_training_wells(self):
        train=self.train.copy();valid=self.valid.copy()
        train['history__RCYL__last']=np.repeat([1.,2.,3.,4.,5.],12)
        valid['history__RCYL__last']=np.repeat([np.nan,0.,2.,3.,100.],12)
        codes,_=prediction_states(train,valid)
        self.assertEqual(codes.tolist(),list(np.repeat([0,0,1,2,2],12)))


if __name__=='__main__':unittest.main()
