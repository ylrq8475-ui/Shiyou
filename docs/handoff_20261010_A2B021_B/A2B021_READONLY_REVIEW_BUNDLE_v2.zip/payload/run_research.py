"""Finite A2B-021 experiment. No row-level outputs; no automatic resume/restart."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import contextlib
import hashlib
import io
import json
import math
import os
import sys
import time
import numpy as np
import pandas as pd
from experiment_core import (require, GateError, fingerprint, raw_status, state_partition,
    inherited_prediction, fusion_prediction, research_gate, fusion_research_gate,
    confirmation_gate, required_components, FitBudget, transient_fault, score_summary,
    fold_statistics, support_distribution, CANDIDATES, FUSIONS, CONFIRM_SEED)
from diagnostics import diagnostic_summary, fusion_diagnostics

HERE = Path(__file__).resolve().parent
T1 = Path(r'D:\codex\A2B019_T1_20261009_v1')
sys.path.append(str(T1))
import paired_experiment as prior
ENTRY = T1/'accepted_entry/received_20261009_v1/payload/audit_payload/migration_acceptance_20261009_r1/boundary_audit.py'
OLD_MANIFEST = T1/'delivery_20261009_v2/SHA256SUMS_T1_FINAL_v2.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    prior.dump_new(path, value)


class Journal:
    def __init__(self, root):
        self.root = root/'events'; self.root.mkdir(); self.sequence = 0
    def add(self, event, **details):
        self.sequence += 1
        dump(self.root/f'{self.sequence:04d}.json', {'time': prior.stamp(), 'event': event, **details})


def old_integrity():
    records = json.loads(OLD_MANIFEST.read_bytes())
    # Original manifest paths are absolute in some historical deliveries.
    if 'files' in records:
        records = records['files']
    checks = []
    for name, digest in records.items():
        if isinstance(digest, dict):
            digest = digest['sha256']
        path = Path(name)
        if not path.is_absolute():
            path = T1/name
        checks.append(path.is_file() and sha(path) == digest)
    require(all(checks), 'OLD_T1_ARTIFACT_CHANGED')
    return {'manifest_sha256': sha(OLD_MANIFEST), 'files_checked': len(checks), 'all_match': all(checks)}


def inputs():
    values = prior.input_identity(ENTRY)
    for path in sorted(HERE.glob('*.py')):
        values[str(path)] = sha(path)
    for name in ['PLAN.json', 'USER_AUTHORIZATION_REVISED.txt', 'NUMBERING_AND_EXECUTION_CLARIFICATION.json',
                 'ORIGINAL_PREPARATION_REFERENCE.json', 'PRE_FIT_DEBUG_LOG.json', 'SYNTHETIC_TEST_RESULTS.json',
                 'EXECUTION_SUPPLEMENT.json']:
        path = HERE/name
        values[str(path)] = sha(path)
    values[str(OLD_MANIFEST)] = sha(OLD_MANIFEST)
    return values


def build_pipeline(ctx, arm, x):
    if arm in ('B0', 'C1'):
        pipeline = ctx.training._model_pipeline('extra_trees_log_ratio_last', x, ctx.config)
    else:
        from sklearn.pipeline import Pipeline
        from sklearn.ensemble import HistGradientBoostingRegressor
        params = dict(loss='squared_error' if arm == 'C2' else 'absolute_error',
                      learning_rate=.03, max_iter=200, max_leaf_nodes=7, max_depth=3,
                      min_samples_leaf=12, l2_regularization=1., early_stopping=False, random_state=20260916)
        pipeline = Pipeline([('preprocess', ctx.training._preprocessor(x)),
                             ('model', HistGradientBoostingRegressor(**params))])
    require(pipeline.named_steps['model'].get_params() == ctx.plan['complete_model_get_params'][arm], 'MODEL_PARAMETERS_CHANGED')
    return pipeline


def predict(ctx, pipeline, view):
    view = view.drop(columns=['RCYL'])
    answer = np.asarray(ctx.training.predict_pipeline_output(pipeline, 'extra_trees_log_ratio_last',
                                                             view[ctx.features], view), dtype=float)
    answer = np.clip(answer, 0, None)
    require(len(answer) == len(view) and np.isfinite(answer).all(), 'INVALID_PREDICTION')
    return answer


def fit_one(ctx, train, valid, arm, tag, factory=build_pipeline):
    if valid is not None:
        require(not set(train.WELL_ID) & set(valid.WELL_ID), 'FIT_WELL_OVERLAP')
    require('RCYL' not in ctx.features and 'WELL_ID' not in ctx.features, 'PRIVATE_KEY_OR_LABEL_FEATURE')
    if arm != 'B0':
        train = train.loc[train.horizon <= 2]
        if valid is not None:
            valid = valid.loc[valid.horizon <= 2]
    x = train[ctx.features]
    require(len(x) == int(train.WELL_ID.nunique()) * (12 if arm == 'B0' else 2), 'ACTUAL_FIT_ROW_SCOPE')
    scale, _ = raw_status(train['history__RCYL__last'])
    require(np.array_equal(scale, ctx.training._target_scale(train, 'log_ratio_last')), 'FIT_RAW_SCALE_RULE')
    expected = np.log1p(train.RCYL.to_numpy(dtype=float) / scale)
    require(np.isfinite(expected).all(), 'TRANSFORM_NONFINITE')
    while True:
        ctx.identity_check()
        pipeline = factory(ctx, arm, x)
        prep, model = pipeline.named_steps['preprocess'], pipeline.named_steps['model']
        original_prep, original_fit = prep.fit_transform, model.fit
        counts = {'preprocess': 0, 'model': 0}
        completed_before = ctx.budget.model_completed
        entered = False
        ctx.budget.begin_pipeline()
        def prep_fit(xx, yy=None, **kwargs):
            require(isinstance(xx, type(x)) and xx.equals(x), 'PREPROCESS_TRAIN_SCOPE')
            require(np.array_equal(np.asarray(yy), expected), 'PREPROCESS_TARGET_SCOPE')
            counts['preprocess'] += 1
            require(counts['preprocess'] == 1, 'MULTIPLE_PREPROCESS_FITS')
            ctx.budget.begin_preprocess()
            value = original_prep(xx, yy, **kwargs)
            ctx.budget.complete_preprocess()
            return value
        def model_fit(xx, yy, **kwargs):
            nonlocal entered
            require(len(xx) == len(x) and np.array_equal(np.asarray(yy), expected), 'MODEL_TRAIN_SCOPE')
            require(counts['preprocess'] == 1, 'MODEL_WITHOUT_TRAIN_PREPROCESS')
            require(not kwargs, 'UNAUTHORIZED_FIT_ARGUMENTS')
            counts['model'] += 1
            require(counts['model'] == 1, 'MULTIPLE_MODEL_FITS')
            ctx.budget.begin_model(); entered = True
            ctx.journal.add('model_fit_entered', tag=tag, train_rows=len(x),
                            train_wells=int(train.WELL_ID.nunique()), budget=ctx.budget.snapshot())
            value = original_fit(xx, yy, **kwargs)
            ctx.budget.complete_model()
            return value
        prep.fit_transform, model.fit = prep_fit, model_fit
        tick = time.perf_counter()
        try:
            ctx.training._fit_pipeline(pipeline, 'extra_trees_log_ratio_last', x, train.RCYL, train.horizon, train)
            require(counts == {'preprocess': 1, 'model': 1}, 'FIT_CALL_COUNT')
        except Exception as exc:
            ctx.journal.add('fit_failed', tag=tag, error_code=str(exc) if isinstance(exc, GateError) else type(exc).__name__,
                            entered_model_fit=entered, eligible_runtime_retry=transient_fault(exc), budget=ctx.budget.snapshot())
            if not transient_fault(exc) or ctx.budget.model_completed != completed_before:
                raise
            ctx.budget.reserve_retry(exc, completed_before)
            ctx.journal.add('runtime_retry_reserved', tag=tag, budget=ctx.budget.snapshot())
            continue
        finally:
            # Do not serialize wrappers/closures or any data held by those closures.
            del prep.fit_transform
            del model.fit
        ctx.identity_check()
        prediction = None if valid is None else predict(ctx, pipeline, valid)
        support = None
        if valid is not None and arm in ('B0', 'C1'):
            early = valid.loc[valid.horizon <= 2]
            support = support_distribution(model.apply(prep.transform(x)),
                                           model.apply(prep.transform(early[ctx.features])), train.WELL_ID.to_numpy())
        ctx.journal.add('fit_completed', tag=tag, fit_seconds=time.perf_counter()-tick,
                        actual_calls=counts, budget=ctx.budget.snapshot())
        return pipeline, prediction, support


def summary(ctx, frame, prediction):
    result = score_summary(frame, prediction)
    check = frame[['WELL_ID', 'horizon', 'RCYL']].copy()
    check['prediction'] = prediction
    score = ctx.official(check, truth_column='RCYL', prediction_column='prediction', epsilon=1e-6).total
    require(abs(score - result['official_score']) < 1e-10, 'OFFICIAL_METRIC_DISAGREEMENT')
    return result


def prediction_states(train, valid):
    raw = 'history__RCYL__last'
    require(train.groupby('WELL_ID')[raw].nunique(dropna=False).le(1).all(), 'TRAIN_RAW_SCALE_WITHIN_WELL')
    require(valid.groupby('WELL_ID')[raw].nunique(dropna=False).le(1).all(), 'VALID_RAW_SCALE_WITHIN_WELL')
    t = train.drop_duplicates('WELL_ID')[raw].to_numpy()
    v = valid.drop_duplicates('WELL_ID')
    codes, threshold = state_partition(t, v[raw].to_numpy())
    mapping = dict(zip(v.WELL_ID, codes, strict=True))
    return np.asarray([mapping[key] for key in valid.WELL_ID]), fingerprint({'threshold': threshold})


def run_family(ctx, panel, splits, seed, components, fusions, stage):
    arms = ['B0', *components, *fusions]
    arrays = {arm: np.full(len(panel), np.nan) for arm in arms}
    states = np.full(len(panel), -1)
    scores = {arm: [] for arm in arms}
    supports = {'B0': [], **({'C1': []} if 'C1' in components else {})}
    tick = time.perf_counter()
    for fold, (tr, va) in enumerate(splits, 1):
        train, valid = panel.iloc[tr], panel.iloc[va]
        local_states, threshold_hash = prediction_states(train, valid)
        states[va] = local_states
        predictions = {}
        for arm in ['B0', *components]:
            tag = {'stage': stage, 'seed': seed, 'fold': fold, 'arm': arm}
            pipeline, p, support = fit_one(ctx, train, valid, arm, tag)
            del pipeline
            predictions[arm] = p if arm == 'B0' else inherited_prediction(predictions['B0'], p, valid.horizon)
            if support is not None:
                supports[arm].append({'fold': fold, **support})
        for arm in fusions:
            a, b = FUSIONS[arm]
            predictions[arm] = fusion_prediction(predictions[a], predictions[b], predictions['B0'], valid.horizon)
        ctx.identity_check()
        for arm, p in predictions.items():
            require(arm == 'B0' or np.array_equal(p[valid.horizon > 2], predictions['B0'][valid.horizon > 2]), 'LATE_ROW_INHERITANCE')
            arrays[arm][va] = p
            aggregate = summary(ctx, valid, p)
            scores[arm].append(aggregate['official_score'])
        ctx.journal.add('fold_completed', stage=stage, seed=seed, fold=fold,
                        scores={arm: scores[arm][-1] for arm in arms},
                        training_state_quantile_sha256=threshold_hash, well_intersection=0,
                        late_inheritance_checked=True, budget=ctx.budget.snapshot())
        print(json.dumps({'stage': stage, 'seed': seed, 'fold': fold,
                          'successful_fits': ctx.budget.model_completed}, ensure_ascii=True), flush=True)
    ctx.identity_check()
    result = {'stage': stage, 'seed': seed, 'elapsed_seconds': time.perf_counter()-tick,
              'structural_checks_passed': True, 'arms': {}, 'leaf_support': supports,
              'state_thresholds': 'training independent-well linear q25; threshold values not persisted'}
    for arm in arms:
        aggregate = summary(ctx, panel, arrays[arm])
        result['arms'][arm] = {**aggregate, **fold_statistics(scores[arm]),
                              'diagnostics': diagnostic_summary(panel, arrays[arm], arrays['B0'], states)}
        result['arms'][arm]['delta_vs_B0'] = aggregate['official_score'] - result['arms']['B0']['official_score']
        result['arms'][arm]['paired_fold_deltas'] = [a-b for a,b in zip(scores[arm], scores['B0'], strict=True)]
    for arm in fusions:
        a, b = FUSIONS[arm]
        result['arms'][arm]['fusion_diagnostics'] = fusion_diagnostics(panel, arrays[a], arrays[b], arrays['B0'])
        result['arms'][arm]['delta_vs_components'] = {
            component: result['arms'][arm]['official_score']-result['arms'][component]['official_score'] for component in (a,b)}
    name = 'FIXED_FIVE_FOLD' if seed is None else ('CONFIRMATION' if stage == 'confirmation' else f'REPEAT_{seed}')
    dump(ctx.output/f'{name}.json', result)
    return result


def full_save(ctx, panel, confirmed):
    import joblib
    required = required_components(confirmed)
    directory = HERE/'private_models'; directory.mkdir()
    records = {}
    for arm in ['B0', *required]:
        pipeline, _, _ = fit_one(ctx, panel, None, arm, {'stage': 'full_research_save', 'arm': arm})
        view = panel if arm == 'B0' else panel.loc[panel.horizon <= 2]
        before = predict(ctx, pipeline, view)
        path = directory/f'{arm}.joblib'
        require(not path.exists(), 'PRIVATE_ARTIFACT_ALREADY_EXISTS')
        joblib.dump(pipeline, path, compress=3)
        loaded = joblib.load(path)
        after = predict(ctx, loaded, view)
        same = bool(np.array_equal(before, after))
        require(same, 'RELOAD_PREDICTION_MISMATCH')
        records[arm] = {'model_id': arm, 'relative_private_path': f'private_models/{path.name}', 'sha256': sha(path),
                        'bytes': path.stat().st_size, 'reload_exact_prediction_equality': same,
                        'reload_max_abs_difference': float(np.max(np.abs(before-after))),
                        'scope': 'private research artifact; not approved for deployment or sharing',
                        'features': ctx.features, 'target_transform': 'log1p(RCYL/raw_scale)',
                        'scale': 'unimputed history__RCYL__last finite and >0 else1',
                        'implementation_pretrain_lock_sha256': sha(ctx.output/'IMPLEMENTATION_PRETRAIN_LOCK.json'),
                        'cohort_order_sha256': ctx.ready['cohort_order_sha256'],
                        'validation': 'six research families plus fixed confirmation seed; same 81 wells',
                        'historical_dtype_identity': 'UNKNOWN', 'P0': 'UNKNOWN'}
        dump(directory/f'{arm}.metadata.json', records[arm])
        del loaded, pipeline, before, after
    for arm in confirmed:
        if arm not in FUSIONS:
            continue
        components = FUSIONS[arm]
        recipe = {'model_id': arm, 'weights': [.5, .5], 'space': 'original RCYL after inverse, months1,2 only',
                  'late_model': {'id': 'B0', 'sha256': records['B0']['sha256']},
                  'components': [{'id': a, 'sha256': records[a]['sha256']} for a in components],
                  'no_additional_fit': True, 'deployment_approved': False}
        path = directory/f'{arm}.recipe.json'; dump(path, recipe)
        records[arm] = {'relative_private_path': f'private_models/{path.name}', 'sha256': sha(path), 'fixed_recipe_only': True}
    return records


def execute():
    # Constructors/imports only until current implementation, data and environment are sealed.
    import sklearn.svm._libsvm
    from sklearn.model_selection import GroupKFold
    from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
    from threadpoolctl import threadpool_limits
    plan = json.loads((HERE/'PLAN.json').read_bytes())
    clarification = json.loads((HERE/'NUMBERING_AND_EXECUTION_CLARIFICATION.json').read_bytes())
    require(plan['request'] == 'A2B-021' and plan['old_A2B020']['successful_fits'] == 0, 'TASK_AUTHORIZATION_IDENTITY')
    require(plan['families']['confirmation_seed_prior_use'] == 'USER_CONFIRMED_UNUSED', 'CONFIRMATION_SEED_IDENTITY')
    tests = json.loads((HERE/'SYNTHETIC_TEST_RESULTS.json').read_bytes())
    require(tests['passed'] and tests['real_fits'] == 0, 'SYNTHETIC_CHECKS_NOT_PASSING')
    require(sha(HERE/'USER_AUTHORIZATION_REVISED.txt') == plan['authorization']['sha256'], 'AUTHORIZATION_BYTES')
    output = HERE/'execution'; output.mkdir(exist_ok=False)
    journal, budget = Journal(output), FitBudget()
    sys.path.insert(0, str(prior.PROJECT/'src'))
    from oil_uplift import training, a2b013_safe as safe, multistep as multi, config as config_module
    from oil_uplift.scoring import official_twelve_month_score
    require(Path(training.__file__).resolve().is_relative_to(prior.PROJECT), 'SOURCE_IMPORT_ROOT')
    before, env = inputs(), prior.environment()
    old_before = old_integrity()
    final = {'request': 'A2B-021', 'started': prior.stamp(), 'training_completed': False,
             'historical_dtype_identity': 'UNKNOWN', 'P0': 'UNKNOWN', 'deployment_authorized': False,
             'old_A2B020_successful_fits': 0, 'confirmation_seed_user_confirmed_unused': True,
             'research': [], 'research_gates': {}, 'confirmation_gates': {}, 'artifacts': {}}
    store = panel = config = None
    lock_hash = None
    def identities():
        require(inputs() == before, 'INPUT_OR_SOURCE_IDENTITY_CHANGED')
        require(prior.environment() == env, 'PAIRED_ENVIRONMENT_CHANGED')
        if lock_hash is not None:
            require(sha(output/'IMPLEMENTATION_PRETRAIN_LOCK.json') == lock_hash, 'PRETRAIN_LOCK_CHANGED')
    ctx = SimpleNamespace(training=training, plan=plan, output=output, budget=budget,
                          journal=journal, official=official_twelve_month_score, identity_check=identities)
    try:
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            config, panel, unused_boundary, features, families, store, ready = prior.data_prepare(
                ENTRY, np, pd, training, safe, multi, config_module, GroupKFold)
            del unused_boundary
        ctx.config, ctx.features, ctx.ready = config, features, ready
        splits = list(GroupKFold(n_splits=5, shuffle=True, random_state=CONFIRM_SEED).split(panel, groups=panel.WELL_ID))
        prior.validate_splits(np, panel, splits)
        confirmation_hash = fingerprint([(prior.array_hash(np,a), prior.array_hash(np,b)) for a,b in splits])
        schemas = {}
        for arm in ['B0', *CANDIDATES]:
            view = panel if arm == 'B0' else panel.loc[panel.horizon <= 2]
            model = build_pipeline(ctx, arm, view[features])
            model.named_steps['model']._validate_params()
            schemas[arm] = {'ordered_dtype': list(zip(features, view[features].dtypes.astype(str))),
                            'model_get_params': model.named_steps['model'].get_params(),
                            'preprocess_repr': repr(model.named_steps['preprocess']),
                            'training_rows_per_well': 12 if arm == 'B0' else 2}
            del model
        for _, family_splits, _ in [*families, (CONFIRM_SEED,splits,confirmation_hash)]:
            for tr, va in family_splits:
                for arm in CANDIDATES:
                    view = panel.iloc[tr].loc[panel.iloc[tr].horizon <= 2]
                    require(view[features].dtypes.astype(str).tolist() == panel[features].dtypes.astype(str).tolist(), 'EARLY_FEATURE_DTYPE')
                    # Missing-feature dropping is part of the frozen original algorithm, not changed by score.
                    prediction_states(panel.iloc[tr], panel.iloc[va])
        identities()
        dump(output/'STRUCTURAL_GATES.json', {'inherited_readonly_audit': ready,
             'A2B021_current_structure_passed': True, 'horizons_late_inheritance': 'enforced per fold and fusion',
             'all_model_training_row_scopes': 'runtime observed, not presumed',
             'confirmation_split_sha256': confirmation_hash, 'confirmation_well_intersections': [0]*5,
             'test_labels_used': False, 'data_fitting_during_preparation': False,
             'historical_dtype_identity': 'UNKNOWN', 'old_baseline_reuse_gate_not_relabeled': True})
        dump(output/'IMPLEMENTATION_PRETRAIN_LOCK.json', {'request': 'A2B-021', 'locked_at': prior.stamp(),
             'locked_before_first_real_fit_or_candidate_score': True, 'environment': env, 'source_and_input_files': before,
             'current_data_structure': ready, 'model_and_preprocess_contracts': schemas,
             'confirmation_split_sha256': confirmation_hash, 'old_artifact_integrity': old_before,
             'new_B0_authorized': True, 'old_score_reused': False, 'initial_budget': budget.snapshot(),
             'full_feature_order': features, 'same_paired_environment_required': True,
             'historical_dtype_identity': 'UNKNOWN', 'P0': 'UNKNOWN', 'private_config_body_serialized': False})
        lock_hash = sha(output/'IMPLEMENTATION_PRETRAIN_LOCK.json')
        with threadpool_limits(limits=1):
            for seed, family_splits, _ in families:
                final['research'].append(run_family(ctx,panel,family_splits,seed,list(CANDIDATES),list(FUSIONS),'research'))
            repeats = final['research'][1:]
            scores = {arm: [r['arms'][arm]['official_score'] for r in repeats] for arm in ['B0',*CANDIDATES,*FUSIONS]}
            gates = {arm: research_gate([a-b for a,b in zip(scores[arm],scores['B0'],strict=True)]) for arm in CANDIDATES}
            gates.update({arm: fusion_research_gate(arm,scores[arm],scores['B0'],scores) for arm in FUSIONS})
            final['research_gates'] = gates
            qualified = [arm for arm in [*CANDIDATES,*FUSIONS] if gates[arm]['passed']]
            decision = {'locked_at': prior.stamp(), 'qualified': qualified, 'gates': gates,
                        'confirmation_components': required_components(qualified), 'confirmation_seed': CONFIRM_SEED,
                        'locked_before_any_confirmation_fit': True}
            dump(output/'RESEARCH_DECISION_LOCK.json', decision)
            decision_hash = sha(output/'RESEARCH_DECISION_LOCK.json')
            confirmed = []
            if qualified:
                confirmation = run_family(ctx,panel,splits,CONFIRM_SEED,required_components(qualified),
                                          [a for a in qualified if a in FUSIONS],'confirmation')
                require(sha(output/'RESEARCH_DECISION_LOCK.json') == decision_hash, 'RESEARCH_DECISION_CHANGED')
                final['confirmation'] = confirmation
                c_scores = {arm: value['official_score'] for arm,value in confirmation['arms'].items()}
                for arm in qualified:
                    reference = gates[arm].get('locked_reference_component')
                    gate = confirmation_gate(c_scores[arm],c_scores['B0'],reference_score=None if reference is None else c_scores[reference])
                    if reference is not None:
                        gate['locked_reference_component'] = reference
                        gate['delta_vs_locked_reference'] = c_scores[arm]-c_scores[reference]
                    final['confirmation_gates'][arm] = gate
                    if gate['passed']: confirmed.append(arm)
                if confirmed:
                    identities()
                    final['artifacts'] = full_save(ctx,panel,confirmed)
            final['qualified'], final['confirmed'] = qualified, confirmed
            needed = required_components(confirmed)
            final['registry'] = {}
            for arm in [*CANDIDATES,*FUSIONS]:
                if arm in confirmed: status = 'CONFIRM_PASS_PENDING_A'
                elif arm in needed: status = 'COMPONENT_ONLY'
                else: status = 'NO_UPGRADE_SIGNAL'
                final['registry'][arm] = {'status': status, 'research_pass': gates[arm]['passed'],
                    'confirmation_evaluated': arm in qualified, 'artifact_saved': arm in final['artifacts'],
                    'independent_qualification': arm in confirmed, 'deployment_approved': False}
            final.update(training_completed=True,status='COMPLETED_PENDING_A' if confirmed else 'COMPLETED_NO_QUALIFIED_MODEL')
        identities()
    except Exception as exc:
        final.update(status='STOPPED_ACTUAL_BLOCK', error_code=str(exc) if isinstance(exc,GateError) else type(exc).__name__)
        journal.add('stopped', error_code=final['error_code'], budget=budget.snapshot())
    finally:
        final['budget'], final['finished'] = budget.snapshot(), prior.stamp()
        final['current_inputs_unchanged'] = inputs() == before
        final['environment_unchanged'] = prior.environment() == env
        final['old_artifacts_after'] = old_integrity()
        if store is not None:
            final['raw_data_after'] = {'archive_and_manifest_unchanged': store.unchanged(), 'files': len(store.members)}
            store.close()
        dump(output/'FINAL_RESULT.json',final)
        if panel is not None:
            tokens = prior.train_test_wells_for_scan({'control':panel},config)
            scan = prior.privacy_scan(HERE,tokens,config['anchors']['eligible_event_values'])
            dump(output/'PRIVACY_SCAN.json',scan)
            require(scan['passed'],'PRIVACY_SCAN_FAILED')
        dump(output/'SHA256SUMS.json',{p.relative_to(HERE).as_posix(): sha(p) for p in HERE.rglob('*') if p.is_file()})
    print(json.dumps({'status': final['status'], 'budget': budget.snapshot(), 'qualified': final.get('qualified',[]),
                      'confirmed': final.get('confirmed',[]), 'error_code': final.get('error_code')},ensure_ascii=True),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', required=True)
    parser.parse_args()
    execute()
