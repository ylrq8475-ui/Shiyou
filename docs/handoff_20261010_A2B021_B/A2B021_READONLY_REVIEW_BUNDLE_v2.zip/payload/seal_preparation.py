"""Save final no-learning synthetic results before the exclusive real execution."""
from pathlib import Path
import io
import json
import unittest
import sys
import sklearn.svm._libsvm
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from run_research import HERE, prior, dump, old_integrity

if (HERE/'execution').exists():
    raise RuntimeError('Real execution already exists; preparation is sealed.')
suite = unittest.defaultTestLoader.loadTestsFromNames(['test_contracts','test_harness'])
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
record = {'request':'A2B-021','time':prior.stamp(),'passed':result.wasSuccessful(),
          'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
          'real_fits':0,'native_import_check':'PASS in actual interpreter; no security changes',
          'synthetic_spy_calls_are_not_real_estimator_fits':True,
          'environment':prior.environment(),'old_artifact_integrity':old_integrity(),
          'test_log':stream.getvalue()}
dump(HERE/'SYNTHETIC_TEST_RESULTS.json',record)
print(json.dumps({key:record[key] for key in ['request','passed','tests','real_fits','native_import_check']},ensure_ascii=True))
sys.exit(0 if result.wasSuccessful() else 1)
