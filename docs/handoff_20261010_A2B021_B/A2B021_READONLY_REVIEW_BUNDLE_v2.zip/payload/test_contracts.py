"""Synthetic-only A2B-021 contracts; no estimators or preprocessors fitted."""
import unittest
import numpy as np
import pandas as pd
from experiment_core import *
from diagnostics import diagnostic_summary, fusion_diagnostics


class SyntheticContracts(unittest.TestCase):
    def frame(self, wells=10):
        return pd.DataFrame({'WELL_ID': np.repeat([f'SYNTHETIC_{i}' for i in range(wells)], 12),
                             'horizon': list(range(1, 13)) * wells, 'RCYL': [1.] * (12 * wells)})

    def test_raw_one_is_not_fallback(self):
        scales, fallback = raw_status([1, 0, -1, np.nan, np.inf, 2])
        self.assertEqual(fallback.tolist(), [False, True, True, True, True, False])
        self.assertEqual(scales.tolist(), [1, 1, 1, 1, 1, 2])

    def test_linear_independent_well_quantile_and_equal_threshold(self):
        groups, threshold = state_partition([1, 2, 3, 4], [np.nan, 0, 1, 1.75, 2, 4])
        self.assertEqual(threshold, 1.75)
        self.assertEqual(groups.tolist(), [0, 0, 1, 1, 2, 2])

    def test_no_positive_quantile_blocks(self):
        with self.assertRaises(GateError): state_partition([0, np.nan], [1])

    def test_privacy_requires_group_and_complement_five(self):
        self.assertTrue(privacy_pass([True] * 5 + [False] * 5))
        self.assertFalse(privacy_pass([True] * 6 + [False] * 4))

    def test_early_stitch_and_fixed_original_unit_fusion(self):
        h = np.tile(np.arange(1, 13), 10); b = np.arange(120, dtype=float)
        first = inherited_prediction(b, np.ones(20) * 2, h)
        second = inherited_prediction(b, np.ones(20) * 8, h)
        result = fusion_prediction(first, second, b, h)
        np.testing.assert_array_equal(result[h <= 2], np.ones(20) * 5)
        np.testing.assert_array_equal(result[h > 2], b[h > 2])

    def test_late_drift_and_nonfinite_component_block(self):
        h = np.arange(1, 13); b = np.ones(12); a = b.copy(); a[3] = 2
        with self.assertRaises(GateError): fusion_prediction(a, b, b, h)
        with self.assertRaises(GateError): inherited_prediction(b, [np.nan, 1], h)

    def test_official_unnormalized_epsilon_months(self):
        f = self.frame(); result = score_summary(f, np.zeros(120))
        expected = (1 - 2**-12) / (1 + 1e-6)
        self.assertAlmostEqual(result['official_score'], 100 * (1 - expected), 12)
        self.assertAlmostEqual(result['official_weighted_prefix_loss']['2'], .75 / (1 + 1e-6), 14)

    def test_well_order_permutation_and_duplicate_horizon(self):
        f = self.frame(); p = np.arange(120, dtype=float)
        first, second = score_summary(f, p), score_summary(f.iloc[::-1], p[::-1])
        self.assertAlmostEqual(first['official_score'], second['official_score'], 12)
        self.assertEqual(first['well_count'], second['well_count'])
        np.testing.assert_allclose(first['monthly_unweighted_relative_error'], second['monthly_unweighted_relative_error'], rtol=0, atol=1e-15)
        np.testing.assert_allclose(first['monthly_official_weighted_loss'], second['monthly_official_weighted_loss'], rtol=0, atol=1e-15)
        np.testing.assert_allclose(list(first['official_weighted_prefix_loss'].values()), list(second['official_weighted_prefix_loss'].values()), rtol=0, atol=1e-15)
        f.loc[11, 'horizon'] = 11
        with self.assertRaises(GateError): score_summary(f, p)

    def test_research_not_fixed_fold_early_elimination(self):
        self.assertTrue(research_gate([.4, .3, .3, .3, -.2])['passed'])
        self.assertTrue(research_gate([.2] * 5)['passed'])
        self.assertFalse(research_gate([.8, .8, .8, 0, 0])['passed'])
        self.assertFalse(research_gate([1, 1, 1, 1, -.21])['passed'])
        self.assertFalse(research_gate([.19] * 5)['passed'])

    def test_fusion_reference_ties_locked_by_component_order(self):
        score = {'C1': [70] * 5, 'C2': [70] * 5}
        gate = fusion_research_gate('F12', [70.3] * 5, [70] * 5, score)
        self.assertEqual(gate['locked_reference_component'], 'C1')
        self.assertTrue(gate['passed'])

    def test_fusion_requires_extra_gain(self):
        self.assertFalse(fusion_research_gate('F12', [70.3] * 5, [70] * 5,
                                             {'C1': [70.28] * 5, 'C2': [70] * 5})['passed'])

    def test_confirm_strict_baseline_and_nonstrict_reference(self):
        self.assertFalse(confirmation_gate(70, 70)['passed'])
        self.assertTrue(confirmation_gate(70.2, 70, reference_score=70.2)['passed'])
        self.assertFalse(confirmation_gate(70.2, 70, reference_score=70.21)['passed'])

    def test_components_are_shared_and_nonqualified_can_be_needed(self):
        self.assertEqual(required_components(['F12', 'F13', 'C3']), ['C1', 'C2', 'C3'])
        self.assertEqual(required_components([]), [])

    def test_budget_144_successes_and_bounded_preprocess(self):
        b = FitBudget()
        for _ in range(144):
            b.begin_pipeline(); b.begin_preprocess(); b.complete_preprocess(); b.begin_model(); b.complete_model()
        with self.assertRaises(GateError): b.begin_pipeline()
        self.assertEqual(b.model_completed, 144)

    def test_two_clear_retries_but_not_successful_fit_or_policy_fault(self):
        b = FitBudget()
        for _ in range(2):
            before = b.model_completed; b.begin_pipeline(); b.begin_preprocess()
            b.reserve_retry(MemoryError(), before)
        with self.assertRaises(GateError): b.reserve_retry(MemoryError(), 0)
        with self.assertRaises(GateError): FitBudget().reserve_retry(OSError(1260, 'synthetic policy'), 0)
        c = FitBudget(); c.begin_pipeline(); c.begin_preprocess(); c.complete_preprocess(); c.begin_model(); c.complete_model()
        with self.assertRaises(GateError): c.reserve_retry(MemoryError(), 0)

    def test_model_before_preprocess_is_blocked(self):
        with self.assertRaises(GateError): FitBudget().begin_model()

    def test_leaf_support_counts_wells_not_repeated_rows(self):
        result = support_distribution(np.array([[1], [1], [1], [2]]), np.array([[1], [2]]),
                                      ['SYNTHETIC_A', 'SYNTHETIC_A', 'SYNTHETIC_B', 'SYNTHETIC_C'])
        self.assertEqual(result['occupied_training_leaves']['mean_distinct_train_wells'], 1.5)
        self.assertEqual(result['early_validation_row_tree_visits']['quantiles']['max'], 2)

    def test_direction_state_suppression_and_late_zero_loss_change(self):
        f = self.frame(); b = np.ones(120); p = b.copy(); p[f.horizon <= 2] = 2
        states = np.repeat([0] * 4 + [1] * 6, 12)
        result = diagnostic_summary(f, p, b, states)
        self.assertEqual(result['prediction_state_groups']['raw_scale_fallback']['status'], 'SUPPRESSED')
        self.assertEqual(result['prediction_state_groups']['positive_scale_training_q25_low']['status'], 'SUPPRESSED')
        self.assertEqual(result['monthly_net_weighted_loss_change_vs_B0'][2:], [0.] * 10)

    def test_fusion_constant_residual_is_undefined_not_evidence(self):
        f = self.frame(); p = np.ones(120)
        result = fusion_diagnostics(f, p, p, p)
        self.assertIsNone(result['signed_residual_correlations']['first2_pooled_signed_relative_residual'])


if __name__ == '__main__':
    unittest.main()
