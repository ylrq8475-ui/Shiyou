"""Anonymous well-level diagnostics; never routes or weights predictions."""
import math
import numpy as np
from experiment_core import require, privacy_pass, well_arrays, FUSIONS


def group_report(mask, loss, base_loss, early_loss, base_early):
    mask = np.asarray(mask, dtype=bool)
    if not privacy_pass(mask):
        return {'status': 'SUPPRESSED', 'privacy_gate_passed': False}
    return {'status': 'RELEASED', 'privacy_gate_passed': True,
            'group_wells': int(mask.sum()), 'complement_wells': int((~mask).sum()),
            'full_mean_weighted_loss': float(loss[mask].mean()),
            'early_mean_weighted_loss': float(early_loss[mask].mean()),
            'score_delta_vs_B0_in_group': float(100 * (base_loss[mask] - loss[mask]).mean()),
            'net_loss_change_contribution_all_wells': float((loss[mask] - base_loss[mask]).sum() / len(loss)),
            'early_net_loss_change_contribution_all_wells': float((early_loss[mask] - base_early[mask]).sum() / len(loss))}


def proportion(mask):
    mask = np.asarray(mask, dtype=bool)
    if not privacy_pass(mask):
        return {'status': 'SUPPRESSED', 'privacy_gate_passed': False}
    return {'status': 'RELEASED', 'privacy_gate_passed': True,
            'well_count': int(mask.sum()), 'complement_count': int((~mask).sum()),
            'proportion': float(mask.mean())}


def diagnostic_summary(frame, prediction, baseline, state_codes_by_row):
    ids, truth, pred, signed, _, weighted = well_arrays(frame, prediction)
    base_ids, _, _, _, _, base_weighted = well_arrays(frame, baseline)
    require(ids == base_ids, 'DIAGNOSTIC_PAIRED_WELL_ORDER')
    group_codes = []
    row_codes = np.asarray(state_codes_by_row)
    require(len(row_codes) == len(frame) and np.isin(row_codes, [0, 1, 2]).all(), 'STATE_CODES_INCOMPLETE')
    for well in ids:
        local = row_codes[(frame.WELL_ID == well).to_numpy()]
        require(len(np.unique(local)) == 1, 'WITHIN_WELL_STATE_DRIFT')
        group_codes.append(int(local[0]))
    group_codes = np.asarray(group_codes)
    loss, base_loss = weighted.sum(axis=1), base_weighted.sum(axis=1)
    early, base_early = weighted[:, :2].sum(axis=1), base_weighted[:, :2].sum(axis=1)
    groups = {name: group_report(group_codes == code, loss, base_loss, early, base_early)
              for code, name in enumerate(['raw_scale_fallback', 'positive_scale_training_q25_low', 'other_positive_scale'])}
    # These masks use labels retrospectively and are never returned to fitting.
    retrospective = {
        'any_true_zero_first2': group_report((truth[:, :2] == 0).any(axis=1), loss, base_loss, early, base_early),
        'true_month2_at_most_half_month1_positive': group_report((truth[:, 0] > 0) & (truth[:, 1] <= .5 * truth[:, 0]),
                                                               loss, base_loss, early, base_early)}
    directions = {}
    for name, indexes in [('month1', [0]), ('month2', [1]), ('first2', [0, 1])]:
        directions[name] = {}
        for direction, sign_mask in [('over', signed[:, indexes] > 0), ('under', signed[:, indexes] < 0)]:
            well_mask = sign_mask.any(axis=1)
            item = proportion(well_mask)
            if item['privacy_gate_passed']:
                item['official_weighted_loss_contribution_all_wells'] = float((weighted[:, indexes] * sign_mask).sum() / len(ids))
            directions[name][direction] = item
    top_n = int(math.ceil(.10 * len(ids)))
    high = np.zeros(len(ids), dtype=bool)
    high[np.argsort(-loss, kind='stable')[:top_n]] = True
    high_baseline = np.zeros(len(ids), dtype=bool)
    high_baseline[np.argsort(-base_loss, kind='stable')[:top_n]] = True
    concentration = {'status': 'SUPPRESSED'}
    if privacy_pass(high):
        concentration = {'status': 'RELEASED', 'top_well_count': top_n,
                         'top_fraction_definition': 'ceil(0.10*N); stable cohort order for ties',
                         'own_loss_share_top_wells': None if loss.sum() == 0 else float(loss[high].sum() / loss.sum()),
                         'B0_loss_share_B0_top_wells': None if base_loss.sum() == 0 else float(base_loss[high_baseline].sum() / base_loss.sum()),
                         'net_score_delta_contribution_from_B0_top_wells': float(100 * (base_loss[high_baseline] - loss[high_baseline]).sum() / len(ids))}
    improvement = base_loss - loss
    improvement_report = {'positive_wells': proportion(improvement > 0),
                          'negative_wells': proportion(improvement < 0),
                          'net_score_delta': float(100 * improvement.mean())}
    if int((improvement > 0).sum()) >= 5 and int((improvement <= 0).sum()) >= 5 and privacy_pass(high):
        top = np.argsort(-np.maximum(improvement, 0), kind='stable')[:top_n]
        improvement_report['top10percent_share_of_gross_positive_improvement'] = float(np.maximum(improvement[top], 0).sum() / np.maximum(improvement, 0).sum())
    else:
        improvement_report['gross_improvement_concentration'] = 'SUPPRESSED'
    return {'prediction_state_groups': groups, 'retrospective_target_slices': retrospective,
            'early_directional_losses': directions, 'loss_concentration': concentration,
            'improvement_distribution': improvement_report,
            'monthly_net_weighted_loss_change_vs_B0': (weighted - base_weighted).mean(axis=0).tolist(),
            'overlapping_slice_warning': 'do not add shares from overlapping retrospective/directional slices',
            'state_thresholds': 'computed only from training-fold independent raw positive well scales; numeric thresholds not published'}


def fusion_diagnostics(frame, first, second, baseline):
    ids, _, _, ra, _, wa = well_arrays(frame, first)
    other_ids, _, _, rb, _, wb = well_arrays(frame, second)
    base_ids, _, _, _, _, w0 = well_arrays(frame, baseline)
    require(ids == other_ids == base_ids, 'FUSION_DIAGNOSTIC_WELL_PAIRING')
    def corr(a, b):
        return None if np.std(a) == 0 or np.std(b) == 0 else float(np.corrcoef(a, b)[0, 1])
    correlations = {'first2_pooled_signed_relative_residual': corr(ra[:, :2].ravel(), rb[:, :2].ravel()),
                    'month1': corr(ra[:, 0], rb[:, 0]), 'month2': corr(ra[:, 1], rb[:, 1])}
    opposite = (ra[:, :2] * rb[:, :2]) < 0
    opposite_report = proportion(opposite.any(axis=1))
    if opposite_report['privacy_gate_passed']:
        opposite_report['first2_row_frequency'] = float(opposite.mean())
    improve_a = w0.sum(axis=1) > wa.sum(axis=1)
    improve_b = w0.sum(axis=1) > wb.sum(axis=1)
    intersection, union = improve_a & improve_b, improve_a | improve_b
    overlap = proportion(intersection)
    if overlap['privacy_gate_passed'] and privacy_pass(union):
        overlap['jaccard_improvement_wells'] = float(intersection.sum() / union.sum())
    else:
        overlap = {'status': 'SUPPRESSED', 'privacy_gate_passed': False}
    return {'signed_residual_correlations': correlations, 'opposite_direction': opposite_report,
            'improvement_well_overlap': overlap,
            'interpretation': 'low correlation/opposite signs alone do not establish useful fusion; evaluate actual scores'}
