"""A2B-021 contracts. All row-level arrays stay in caller memory."""
import errno
import hashlib
import json
import math
import statistics
import numpy as np

REPEAT_SEEDS = [20260917, 20261031, 20261219, 20270107, 20270303]
CONFIRM_SEED = 20271009
CANDIDATES = ('C1', 'C2', 'C3')
FUSIONS = {'F12': ('C1', 'C2'), 'F13': ('C1', 'C3'), 'F23': ('C2', 'C3')}
PRIVACY_MIN = 5
EPSILON = 1e-6


class GateError(Exception):
    pass


def require(condition, code):
    if not condition:
        raise GateError(code)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def raw_status(values):
    x = np.asarray(values, dtype=float)
    fallback = ~np.isfinite(x) | (x <= 0)
    return np.where(fallback, 1.0, x), fallback


def state_partition(training_raw_by_well, validation_raw_by_well):
    train = np.asarray(training_raw_by_well, dtype=float)
    valid = np.asarray(validation_raw_by_well, dtype=float)
    positive = train[np.isfinite(train) & (train > 0)]
    require(len(positive) > 0, 'NO_POSITIVE_TRAIN_WELL_SCALE_FOR_Q25')
    threshold = float(np.quantile(positive, .25, method='linear'))
    _, fallback = raw_status(valid)
    groups = np.full(len(valid), 2, dtype=int)
    groups[(~fallback) & (valid <= threshold)] = 1
    groups[fallback] = 0
    return groups, threshold


def privacy_pass(mask):
    a = np.asarray(mask, dtype=bool)
    return int(a.sum()) >= PRIVACY_MIN and int((~a).sum()) >= PRIVACY_MIN


def inherited_prediction(baseline, early_prediction, horizons):
    baseline = np.asarray(baseline, dtype=float)
    h = np.asarray(horizons)
    early = np.asarray(early_prediction, dtype=float)
    require(len(baseline) == len(h) and len(early) == int((h <= 2).sum()), 'EARLY_PREDICTION_SHAPE')
    require(np.isfinite(baseline).all() and (baseline >= 0).all(), 'INVALID_BASELINE_PREDICTION')
    require(np.isfinite(early).all() and (early >= 0).all(), 'INVALID_EARLY_PREDICTION')
    answer = baseline.copy()
    answer[h <= 2] = early
    require(np.array_equal(answer[h >= 3], baseline[h >= 3]), 'LATE_BASELINE_INHERITANCE')
    return answer


def fusion_prediction(first, second, baseline, horizons):
    a, b, base, h = map(np.asarray, (first, second, baseline, horizons))
    require(a.shape == b.shape == base.shape == h.shape, 'FUSION_SHAPE')
    require(np.array_equal(a[h >= 3], base[h >= 3]) and np.array_equal(b[h >= 3], base[h >= 3]),
            'FUSION_COMPONENT_LATE_DRIFT')
    require(np.isfinite(a).all() and np.isfinite(b).all() and (a >= 0).all() and (b >= 0).all(),
            'INVALID_FUSION_COMPONENT')
    return inherited_prediction(base, .5 * a[h <= 2] + .5 * b[h <= 2], h)


def research_gate(deltas, structure=True):
    require(len(deltas) == 5 and all(math.isfinite(float(x)) for x in deltas), 'FIVE_FINITE_REPEAT_DELTAS')
    mean = math.fsum(deltas) / 5
    positive = sum(float(x) > 0 for x in deltas)
    worst = min(deltas)
    return {'mean_delta': mean, 'positive_repeats': positive, 'worst_repeat_delta': worst,
            'mean_passed': mean >= .20, 'direction_passed': positive >= 4,
            'worst_passed': worst >= -.20, 'structure_passed': bool(structure),
            'passed': bool(structure) and mean >= .20 and positive >= 4 and worst >= -.20}


def fusion_research_gate(name, scores, baseline_scores, component_scores, structure=True):
    require(name in FUSIONS, 'UNREGISTERED_FUSION')
    first, second = FUSIONS[name]
    require(len(scores) == len(baseline_scores) == 5, 'FIVE_FUSION_REPEAT_SCORES')
    mean_component = {key: math.fsum(component_scores[key]) / 5 for key in (first, second)}
    # Larger mean first; exact ties follow C1,C2,C3.
    reference = min((first, second), key=lambda key: (-mean_component[key], CANDIDATES.index(key)))
    gate = research_gate([a - b for a, b in zip(scores, baseline_scores, strict=True)], structure)
    extra = math.fsum(scores) / 5 - mean_component[reference]
    gate.update({'locked_reference_component': reference, 'mean_gain_over_reference': extra,
                 'reference_gain_passed': extra >= .05, 'passed': gate['passed'] and extra >= .05})
    return gate


def confirmation_gate(score, baseline_score, structure=True, reference_score=None):
    values = [score, baseline_score] + ([] if reference_score is None else [reference_score])
    require(all(math.isfinite(float(x)) for x in values), 'NONFINITE_CONFIRMATION_SCORE')
    delta = score - baseline_score
    ref_ok = reference_score is None or score >= reference_score
    return {'delta': delta, 'positive_delta_passed': delta > 0, 'structure_passed': bool(structure),
            'reference_component_passed': ref_ok,
            'passed': bool(structure) and delta > 0 and ref_ok}


def required_components(qualified):
    components = set()
    for name in qualified:
        if name in CANDIDATES:
            components.add(name)
        else:
            require(name in FUSIONS, 'UNREGISTERED_QUALIFIED_MODEL')
            components.update(FUSIONS[name])
    return [name for name in CANDIDATES if name in components]


def transient_fault(error):
    return isinstance(error, MemoryError) or (isinstance(error, OSError) and error.errno in {errno.ENOMEM, errno.EAGAIN})


class FitBudget:
    def __init__(self, reused_success=0, reused_entries=0, reused_preprocess=0, reused_retries=0,
                 reused_preprocess_completed=0):
        require(0 <= reused_success <= 144 and reused_success <= reused_entries <= 146, 'INVALID_PRIOR_BUDGET')
        require(0 <= reused_preprocess <= 146 and 0 <= reused_retries <= 2, 'INVALID_PRIOR_PREPROCESS_BUDGET')
        require(reused_success <= reused_preprocess_completed <= reused_preprocess, 'PRIOR_PREPROCESS_COMPLETION_UNKNOWN')
        self.pipeline_attempts = reused_preprocess
        self.preprocess_entered = reused_preprocess
        self.preprocess_completed = reused_preprocess_completed
        self.model_entered = reused_entries
        self.model_completed = reused_success
        self.retries_used = reused_retries

    def begin_pipeline(self):
        require(self.pipeline_attempts < 146 and self.model_completed < 144, 'PIPELINE_BUDGET_EXHAUSTED')
        self.pipeline_attempts += 1

    def begin_preprocess(self):
        require(self.preprocess_entered < self.pipeline_attempts, 'PREPROCESS_WITHOUT_RESERVED_ATTEMPT')
        self.preprocess_entered += 1

    def complete_preprocess(self):
        require(self.preprocess_completed < self.preprocess_entered, 'PREPROCESS_COMPLETION_WITHOUT_ENTRY')
        self.preprocess_completed += 1

    def begin_model(self):
        require(self.model_entered < 146 and self.model_completed < 144, 'MODEL_BUDGET_EXHAUSTED')
        require(self.model_entered < self.preprocess_completed, 'MODEL_WITHOUT_COMPLETED_PREPROCESS')
        self.model_entered += 1

    def complete_model(self):
        require(self.model_completed < self.model_entered, 'MODEL_COMPLETION_WITHOUT_ENTRY')
        self.model_completed += 1

    def reserve_retry(self, error, completed_before):
        require(transient_fault(error) and self.model_completed == completed_before, 'RETRY_NOT_ALLOWED')
        require(self.retries_used < 2, 'RETRY_BUDGET_EXHAUSTED')
        self.retries_used += 1

    def snapshot(self):
        return dict(self.__dict__)


def well_arrays(frame, prediction):
    """Returns private per-well matrices, not a serializable report."""
    ids = frame.WELL_ID.drop_duplicates().tolist()
    lookup = {key: index for index, key in enumerate(ids)}
    truth = np.full((len(ids), 12), np.nan)
    pred = np.full_like(truth, np.nan)
    occupied = np.zeros_like(truth, dtype=bool)
    p = np.asarray(prediction, dtype=float)
    require(len(p) == len(frame), 'SCORE_LENGTH')
    for row, value in zip(frame[['WELL_ID', 'horizon', 'RCYL']].itertuples(index=False, name=None), p, strict=True):
        well, step, y = row
        require(float(step).is_integer() and 1 <= step <= 12, 'INVALID_HORIZON')
        i, j = lookup[well], int(step) - 1
        require(not occupied[i, j], 'DUPLICATE_HORIZON')
        truth[i, j], pred[i, j], occupied[i, j] = y, value, True
    require(occupied.all(), 'INCOMPLETE_TWELVE_MONTH_WELL')
    require(np.isfinite(truth).all() and np.isfinite(pred).all() and (truth >= 0).all() and (pred >= 0).all(), 'INVALID_SCORE_VALUES')
    signed = (pred - truth) / (np.abs(pred) + np.abs(truth) + EPSILON)
    relative = np.abs(signed)
    weighted = relative * 2.0 ** (-np.arange(1, 13))
    return ids, truth, pred, signed, relative, weighted


def score_summary(frame, prediction):
    ids, _, _, _, relative, weighted = well_arrays(frame, prediction)
    loss = weighted.sum(axis=1)
    return {'official_score': 100.0 * (1 - float(loss.mean())), 'well_count': len(ids),
            'monthly_unweighted_relative_error': relative.mean(axis=0).tolist(),
            'monthly_official_weighted_loss': weighted.mean(axis=0).tolist(),
            'official_weighted_prefix_loss': {str(n): float(weighted[:, :n].sum(axis=1).mean()) for n in (1, 2, 4, 12)}}


def fold_statistics(scores):
    require(len(scores) == 5 and all(math.isfinite(float(x)) for x in scores), 'FIVE_FOLD_SCORES_REQUIRED')
    return {'fold_scores': list(scores), 'worst_fold': min(scores), 'fold_std_ddof0': statistics.pstdev(scores)}


def support_distribution(training_leaves, validation_early_leaves, training_wells):
    """Anonymous independent-well support over occupied/visited tree leaves."""
    leaves = np.asarray(training_leaves)
    visited = np.asarray(validation_early_leaves)
    wells = np.asarray(training_wells)
    require(leaves.ndim == visited.ndim == 2 and leaves.shape[1] == visited.shape[1] and len(wells) == len(leaves),
            'LEAF_SUPPORT_SHAPE')
    occupied_support, visited_support = [], []
    for tree in range(leaves.shape[1]):
        mapping = {}
        for node, well in zip(leaves[:, tree], wells, strict=True):
            mapping.setdefault(int(node), set()).add(well)
        occupied_support.extend(len(value) for value in mapping.values())
        require(all(int(node) in mapping for node in visited[:, tree]), 'VISITED_LEAF_WITHOUT_TRAIN_SUPPORT')
        visited_support.extend(len(mapping[int(node)]) for node in visited[:, tree])
    def aggregate(values):
        a = np.asarray(values, dtype=float)
        require(len(a) > 0, 'EMPTY_LEAF_SUPPORT')
        return {'leaf_observations': len(a), 'mean_distinct_train_wells': float(a.mean()),
                'quantiles': dict(zip(['min', 'q10', 'q25', 'median', 'q75', 'q90', 'max'],
                                     np.quantile(a, [0, .1, .25, .5, .75, .9, 1], method='linear').tolist())),
                'fraction_support_lt3': float((a < 3).mean()), 'fraction_support_lt5': float((a < 5).mean())}
    return {'occupied_training_leaves': aggregate(occupied_support),
            'early_validation_row_tree_visits': aggregate(visited_support),
            'interpretation': 'structural aggregate; row leaf-size is not independent-well support; no leaf/well identifiers'}
