"""Post-execution anonymous reports/package only. Never fits or loads model weights."""
from pathlib import Path
import hashlib
import json
import math
import re
import statistics
import zipfile
from run_research import HERE, T1, prior, sha, dump, old_integrity


def mean(values): return math.fsum(values)/len(values)


def main():
    out = HERE/'execution'
    final = json.loads((out/'FINAL_RESULT.json').read_bytes())
    destination = HERE/'delivery'; destination.mkdir(exist_ok=False)
    research = final['research']; repeats = research[1:]
    arms = ['B0','C1','C2','C3','F12','F13','F23']
    qualified, confirmed = final.get('qualified',[]), final.get('confirmed',[])
    fixed = research[0] if research else None
    table=[]
    if len(repeats)==5:
        for arm in arms:
            values=[r['arms'][arm]['official_score'] for r in repeats]
            deltas=[r['arms'][arm]['delta_vs_B0'] for r in repeats]
            folds=[score for r in research for score in r['arms'][arm]['fold_scores']]
            early=[r['arms'][arm]['official_weighted_prefix_loss']['2'] for r in repeats]
            table.append({'model_id':arm,'fixed_score':fixed['arms'][arm]['official_score'],
                'fixed_delta':fixed['arms'][arm]['delta_vs_B0'],'repeat_scores':values,'repeat_deltas':deltas,
                'repeat_mean_score':mean(values),'repeat_mean_delta':mean(deltas),
                'repeat_positive_count':sum(d>0 for d in deltas),'repeat_worst_delta':min(deltas),
                'all_30_fold_worst':min(folds),'all_30_fold_std_ddof0':statistics.pstdev(folds),
                'repeat_mean_first2_weighted_loss':mean(early),
                'repeat_mean_monthly_relative_error':[mean([r['arms'][arm]['monthly_unweighted_relative_error'][i] for r in repeats]) for i in range(12)],
                'repeat_mean_monthly_weighted_loss':[mean([r['arms'][arm]['monthly_official_weighted_loss'][i] for r in repeats]) for i in range(12)],
                'research_gate':final.get('research_gates',{}).get(arm),
                'confirmation_gate':final.get('confirmation_gates',{}).get(arm)})
    dump(destination/'MODEL_COMPARISON.json',{'request':'A2B-021','comparisons':table,
        'fold_results_source':'execution/FIXED_FIVE_FOLD.json and REPEAT_*.json; full precision unrounded gates',
        'diagnostics_source':'per-arm diagnostics and leaf_support in the same result files'})
    dump(destination/'MODEL_REGISTRY.json',{'request':'A2B-021','models':final.get('registry',{}),
        'private_artifacts':final.get('artifacts',{}),'B0':'shared research control only; no deployment approval',
        'deployment_approved':False,'A_independent_review':'PENDING'})
    events=[json.loads(p.read_bytes()) for p in sorted((out/'events').glob('*.json'))]
    stage_counts={}
    for event in events:
        if event['event']=='fit_completed':
            stage=event['tag']['stage']
            stage_counts[stage]=stage_counts.get(stage,0)+1
    accounting={'budget':final['budget'],'successful_model_fits_by_stage':stage_counts,
                'failed_entries':[e for e in events if e['event']=='fit_failed'],
                'runtime_retries':[e for e in events if e['event']=='runtime_retry_reserved'],
                'no_real_fits_in_synthetic_checks':True,
                'no_OOF_or_well_mapping_persisted':True,'no_model_weights_in_review_package':True}
    dump(destination/'FIT_ACCOUNTING.json',accounting)
    lines=['# A2B-021 多模型、误差机制与固定融合研究','',
           f"状态：{final['status']}。本轮属于账户B执行证据，待账户A独立复核。",'',
           '用户将原授权中的“A2B-020修订版”明确登记为 A2B-021；旧020未拟合、未运行，确认种子20271009此前未用。旧020不另行补跑。',
           '', '81口完整井、972行、325项有序特征；沿用T1对照信息边界。所有早期候选和固定融合的第3—12月逐值继承同折B0。',
           '', '评分：epsilon=1e-6，未归一化2^-t，先按井求12月损失和，再对井等权；分数100×(1−损失)。研究门槛使用完整精度。',
           '', '|方案|固定OOF|固定增量|重复均分|重复均增量|正向重复|最差重复增量|研究通过|',
           '|---|---:|---:|---:|---:|---:|---:|---|']
    for row in table:
        gate=row['research_gate']; status='对照' if gate is None else ('是' if gate['passed'] else '否')
        lines.append(f"|{row['model_id']}|{row['fixed_score']:.9f}|{row['fixed_delta']:+.9f}|{row['repeat_mean_score']:.9f}|{row['repeat_mean_delta']:+.9f}|{row['repeat_positive_count']}/5|{row['repeat_worst_delta']:+.9f}|{status}|")
    lines += ['', f'进入确认：{qualified or "无"}；确认通过：{confirmed or "无"}。',
              '','没有研究合格方案时不使用确认切分、不全量拟合、不保存模型。确认切分仍来自同一批81口井，不能视为独立新测试集。',
              '', f"实际拟合：{json.dumps(final['budget'],ensure_ascii=False)}；阶段计数：{json.dumps(stage_counts,ensure_ascii=False)}。",
              '', '逐折分数、最差折、ddof=0标准差、12月分解、第1/2/4/12月累计损失及匿名诊断见配套JSON。所有结构有效的固定候选均完成五组重复评价，未用固定折表现提前淘汰。',
              '', '对照与候选使用同一锁定Python/依赖环境。每次预处理与模型实际输入、目标变换、调用次数均受运行时检查；验证井不参加任何拟合。ExtraTrees n_jobs=-1；单模型串行，BLAS/OpenMP限制1，无折级并行。',
              '', '原始赛事ZIP在原位置只读解析，逐文件核验100项。旧T1工件在运行前后按原136项清单复核；旧A2B-017、旧模型和正式ZIP未用于重复拟合或覆盖。',
              '', '历史dtype身份链、事件语义和预测生成时点P0仍UNKNOWN。本轮分数不能证明业务语义正确，也不等于平台提分或统计显著性。',
              '', '全部研究候选及失败结论保留。无自动升级、正式平台打包或上传。私有模型若有，仅保存在本轮private_models，复测包不含权重、数据、配置内容、逐井标签或OOF。']
    if 'error_code' in final:lines += ['',f"实际阻断代码：{final['error_code']}；不自动重训已成功折。"]
    (destination/'REPORT_B.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    mechanism=['# A2B-021 可修复机制台账','',
       '|机制假设|依据与损失范围|对应候选|跨折证据|混杂因素|结论|',
       '|---|---|---|---|---|---|']
    indexed={row['model_id']:row for row in table}
    def evidence(arm):
        row=indexed.get(arm)
        return '未完成，见阻断记录' if row is None else f"重复均增量{row['repeat_mean_delta']:+.9f}，正向{row['repeat_positive_count']}/5，最差{row['repeat_worst_delta']:+.9f}"
    mechanism += [
       f'|早期专用训练可改善早期误差|仅改变前两月；后十月预测严格相同|C1|{evidence("C1")}|每井12行变2行同时改变有效井级支持与正则化|受控整体方案比较；不能单独归因于消除后期干扰|',
       f'|受约束拟合方式改善跨井误差|浅层HGB与早期ExtraTrees的整体比较|C2|{evidence("C2")}|算法、复杂度和拟合机制共同变化|只能支持或否定预注册整体方案；不是单一参数因果结论|',
       f'|训练损失改变有益|C3与C2唯一模型参数差异为loss|C3|{evidence("C3")}|absolute_error针对变换目标，不是官方相对误差精确替代|报告配对差异；不据此解释全部误差机制|',
       '|叶节点井支持不足关联误差|B0/C1占用叶和早期验证叶的独立训练井支持分布见每组leaf_support|C1|全部6组支持分布可复核|叶样本行数不等于独立井数；相关结构不证明主要原因|结构证据；未分离支持强度的因果影响|',
       '|低产/尺度回退与损失集中有关|仅训练折独立井原始正尺度线性q25，验证按<=；回退基于未填补原值|全部|各组匿名损失与改善见diagnostics.prediction_state_groups|小组及补集<5均抑制；阈值随训练折变化|预测前状态相关性分析，不作为路由或加权依据|',
       '|少量高损失井支撑净改善|约10%最高损失井份额、改善井比例及毛收益集中度|全部|全部6组匿名诊断|真实高损失是回顾性切片；不删除样本；重叠份额不能相加|损失集中证据，不自动等于可修复原因|',
       f'|固定融合利用互补误差|原单位0.5平均，残差相关/改善重叠/异号频率与实际分数同时报告|F12/F13/F23|F12：{evidence("F12")}；F13：{evidence("F13")}；F23：{evidence("F23")}|低相关并不保证有用；固定融合还需比锁定较好组件均分高0.05|只按预注册实际收益判资格，不搜索权重|',
       '', '未将早期损失权重份额解释为早期特别难预测。真实零产、快速下降、高损失成员仅用于回顾性切片。总体主要误差机制仍不能仅凭本轮比较确定。']
    (destination/'MECHANISM_LEDGER.md').write_text('\n'.join(mechanism)+'\n',encoding='utf-8')
    request=['【协作请求】','', '请求编号：B2A-021（原批准文本B2A-020编号随用户明确研究编号同步映射，非新增实验）',
       '发送方：账户B；接收方：账户A，由用户转交。请求类型：独立只读复测。', '',
       f"B执行状态：{final['status']}。请核验授权编号映射、分数前锁、当前dtype/队列/切分/代码/配置摘要、实际拟合输入范围和次数、官方指标聚合、研究资格与锁定参考、条件确认及保存。",'',
       '先读取README、SHA256SUMS_REVIEW.json及delivery/REPORT_B.md、MODEL_COMPARISON.json、MECHANISM_LEDGER.md、MODEL_REGISTRY.json、FIT_ACCOUNTING.json，再核对execution各结果、结构、实施锁与事件。',
       '', 'tools目录提供原字节源码及30项无学习合成检查。可运行 python -E -B -m unittest test_contracts test_harness -v；此命令不读取赛事数据，不拟合真实模型。不要运行run_research.py --execute或任何历史训练入口。',
       '', '聚合算术和合成合约可独立复算；真实拟合与数据边界检查属于B运行证据，A若需真实独立复现须单独用户授权，不能把现有材料称为独立算法重写。',
       '', '历史dtype、P0及事件语义UNKNOWN保留；原只读工具的baseline_reuse_verified/training_allowed历史状态未回填PASS。本轮新B0按用户明确授权执行。',
       '', '复测包不含赛事数据、冻结私有配置内容、逐井标签、OOF或模型权重。无需再次传输私有数据。若有私有研究模型，仅在B本机授权目录保留，未部署、升级或上传。',
       '', '请用【协作回复】给出事实等级、算术/结构/资格检查、剩余风险与是否通过独立审查；无需联系B，交用户转发。', '', '【协作请求结束】']
    (destination/'B2A_021_REVIEW_REQUEST.md').write_text('\n'.join(request)+'\n',encoding='utf-8')
    dump(destination/'INTEGRITY_AFTER.json',{'old_T1':old_integrity(),'original_inputs_unchanged':final['current_inputs_unchanged'],
            'environment_unchanged':final['environment_unchanged'],'raw_data':final.get('raw_data_after'),
            'pretrain_lock_sha256':sha(out/'IMPLEMENTATION_PRETRAIN_LOCK.json') if (out/'IMPLEMENTATION_PRETRAIN_LOCK.json').exists() else None})
    # All authorized original well/event tokens used for scanning stay in memory.
    import sys
    sys.path.insert(0,str(prior.PROJECT/'src'))
    from oil_uplift.config import load_config
    from oil_uplift.a2b013_safe import safe_config
    config=safe_config(load_config(prior.PRIVATE_CONFIG))
    tokens=prior.train_test_wells_for_scan({},config)
    scan=prior.privacy_scan(HERE,tokens,config['anchors']['eligible_event_values'])
    if not scan['passed']:raise RuntimeError('PRIVACY_SCAN_FAILED')
    dump(destination/'PRIVACY_SCAN_FINAL.json',scan)
    package = destination/'A2B021_READONLY_REVIEW_BUNDLE.zip'
    files={}
    # No private research artifacts, even metadata inside their private directory, go into the review ZIP.
    for path in HERE.rglob('*'):
        if not path.is_file() or 'private_models' in path.relative_to(HERE).parts or path.suffix in {'.zip','.joblib','.pyc'}:
            continue
        if path.parent==destination and path.name.startswith('SHA256SUMS'):continue
        name=path.relative_to(HERE).as_posix()
        files['payload/'+name]=path
    for path in HERE.glob('*.py'):files['tools/'+path.name]=path
    for name in ['paired_experiment.py','archive_adapter.py','t1_core.py']:files['tools/'+name]=T1/name
    # Byte-exact inherited public runtime sources are supplied without private config or raw manifest contents.
    selected=['__init__.py','a2b013_safe.py','training.py','scoring.py','multistep.py','models.py','config.py','io.py','exceptions.py']
    for name in selected:files['upstream/oil_uplift/'+name]=prior.PROJECT/'src/oil_uplift'/name
    files['upstream/accepted_boundary_audit.py']=prior.HERE/'accepted_entry/received_20261009_v1/payload/audit_payload/migration_acceptance_20261009_r1/boundary_audit.py'
    manifest={name:{'sha256':sha(path),'bytes':path.stat().st_size} for name,path in sorted(files.items())}
    readme=('A2B-021 anonymous read-only review bundle. Account B execution evidence, pending independent A review.\n'
            'Verify SHA256SUMS_REVIEW.json and read payload/delivery/B2A_021_REVIEW_REQUEST.md.\n'
            'Synthetic checks only: cd tools; python -E -B -m unittest test_contracts test_harness -v\n'
            'Never execute run_research.py --execute or historical training entrypoints. No data, private config, OOF, labels or weights included.\n')
    manifest['README.md']={'sha256':hashlib.sha256(readme.encode()).hexdigest(),'bytes':len(readme.encode())}
    with zipfile.ZipFile(package,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
        z.writestr('README.md',readme)
        z.writestr('SHA256SUMS_REVIEW.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
    with zipfile.ZipFile(package) as z:
        checks=[hashlib.sha256(z.read(name)).hexdigest()==v['sha256'] and len(z.read(name))==v['bytes'] for name,v in manifest.items()]
        if not all(checks):raise RuntimeError('PACKAGED_BYTES_DIFFER')
        # Scan every text entry, including source copies and test logs. No identifiers printed.
        private={str(x) for x in tokens if str(x)}|{str(x) for x in config['anchors']['eligible_event_values'] if isinstance(x,str) and len(x)>=2}
        hits=0
        for name in z.namelist():
            if name.endswith(('.py','.json','.md','.txt')):
                text=z.read(name).decode('utf-8-sig')
                hits+=sum(bool(re.search(r'(?<![\w])'+re.escape(t)+r'(?![\w])',text)) for t in private)
        if hits:raise RuntimeError('REVIEW_PACKAGE_PRIVATE_TOKEN_HIT')
    package_info={'path':str(package),'sha256':sha(package),'bytes':package.stat().st_size,
                  'manifest_files':len(manifest),'exact_byte_checks_passed':all(checks),'private_token_hits':hits,
                  'no_weights_data_private_config_or_OOF':True}
    dump(destination/'REVIEW_PACKAGE_VERIFICATION.json',package_info)
    (destination/'A2B021_READONLY_REVIEW_BUNDLE.zip.sha256').write_text(package_info['sha256']+'  '+package.name+'\n',encoding='ascii')
    dump(destination/'SHA256SUMS_FINAL.json',{p.relative_to(HERE).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in HERE.rglob('*') if p.is_file()})
    print(json.dumps({'status':final['status'],'package':package_info,'registry':final.get('registry',{})},ensure_ascii=True))


if __name__=='__main__':main()
