A2B-021 read-only review bundle v2. v1 preserved; no training repeated.
Start with payload/delivery/REPORT_B.md and B2A_021_REVIEW_REQUEST.md.
Read payload/post_run_checks/DIAGNOSTIC_INTERPRETATION.md, POST_RUN_ARITHMETIC_CHECKS.json, PACKAGED_SYNTHETIC_RETEST.json.
All 26 original runtime Python sources supplied as exact locked bytes under upstream/src.
Verify SHA256SUMS_REVIEW.json. Synthetic-only command: cd tools; python -E -B -m unittest test_contracts test_harness -v
Do NOT run any training, execution or preparation entrypoint. No raw data, private config, OOF, well identifiers, labels or model weights included.
These are account B execution and local retest evidence, not independent A acceptance.
