"""Zero-fit tests of new history processing and immutable target boundary."""
from freshness import *
from models035 import forbid_fits

def run():
    tests=[];cut=pd.Period('2001-12',freq='M')
    def frame(months,values):
        return pd.DataFrame({'NY':[str(cut-i) for i in months],**{f:values for f in FIELDS}})
    with forbid_fits():
        out=extra_values(frame([0,1],[3.,2.]),cut);assert all(out[f'fresh__{f}__last_valid_12']==3 and out[f'fresh__{f}__age_months_cap12']==0 for f in FIELDS);tests.append('current finite value age0')
        out=extra_values(frame([0,1],[np.nan,2.]),cut);assert all(out[f'fresh__{f}__last_valid_12']==2 and out[f'fresh__{f}__age_months_cap12']==1 for f in FIELDS);tests.append('one missing month uses only earlier finite value')
        out=extra_values(frame([0,1,2],[np.nan,np.nan,0.]),cut);assert all(out[f'fresh__{f}__last_valid_12']==0 and out[f'fresh__{f}__age_months_cap12']==2 for f in FIELDS);tests.append('finite zero retained as observed')
        out=extra_values(frame([0,11],[np.nan,7.]),cut);assert out[EXTRA[1]]==11 and out[EXTRA[0]]==7;tests.append('oldest allowed month is cutoff minus11')
        out=extra_values(frame([0,12],[np.nan,9.]),cut);assert np.isnan(out[EXTRA[0]]) and out[EXTRA[1]]==12;tests.append('older observations excluded, not unlimited forward fill')
        out=extra_values(frame([0,1],[np.inf,4.]),cut);assert out[EXTRA[0]]==4 and out[EXTRA[1]]==1;tests.append('infinite input not treated as observed')
        a=frame([0,2],[np.nan,8.]);z=frame([-1,-2],['invalid future','invalid future']);expected=extra_values(a,cut);actual=extra_values(pd.concat([a,z],ignore_index=True),cut);assert expected==actual;tests.append('future dynamic strings filtered before numeric parsing')
        assert extra_values(a.iloc[::-1],cut)==expected;tests.append('input row order does not alter age or value')
        a=frame([0,2],[np.nan,8.]);assert extra_values(a,cut)[EXTRA[1]]==2;tests.append('age is calendar months, not observed row count')
        out=extra_values(frame([0,1],[np.nan,np.nan]),cut);assert np.isnan(out[EXTRA[0]]) and out[EXTRA[1]]==12;tests.append('all missing remains NaN with capped missing age')
        try:extra_values(frame([0,0],[1.,2.]),cut)
        except RuntimeError:tests.append('duplicate month rejected')
        else:raise AssertionError('duplicate month accepted')
        assert len(EXTRA)==10 and len(set(EXTRA))==10;tests.append('exactly ten additional named features')
        panel=pd.DataFrame({'__scale035':[1.,4.,1.],'RCYL':[0.,8.,2.]});c=b.load_variant(b.HERE/'configs/B0.json');transformed=b.transform_target(panel,c);expected=np.log1p(panel.RCYL.to_numpy()/panel['__scale035'].to_numpy());np.testing.assert_array_equal(transformed,expected);np.testing.assert_array_equal(b.inverse_target(transformed,panel),np.clip(np.expm1(expected)*panel['__scale035'].to_numpy(),0,None));tests.append('original target and inverse floating-point formulas preserved exactly')
        p=pd.DataFrame({'WELL_ID':['toy_A']*12+['toy_B']*12,'horizon':list(range(1,13))*2,'RCYL':[1.]*24});assert b.summary(p,np.ones(24))['official_score']==100.;tests.append('official metric identity on synthetic perfect prediction')
    return {'tests':tests,'passed':len(tests),'model_fits':0,'preprocessor_fits':0,'no_real_values_in_test_output':True}
