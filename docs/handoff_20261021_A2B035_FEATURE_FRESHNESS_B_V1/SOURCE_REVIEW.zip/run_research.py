"""One candidate, paired CV, RAM-only OOF, and one private full research model."""
from pathlib import Path
import sys,json,hashlib,shutil,time,platform,importlib.metadata as im
from datetime import datetime,timezone,timedelta
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'source'))

def enc(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,v):
    path=T/path;path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists(),str(path.name)+' already exists';path.write_bytes(enc(v))

def environment():
    return {'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({x.metadata['Name']:x.version for x in im.distributions()}.items()))}

def bootstrap(base):
    source=Path(base);target=T/'source/base'
    for p in source.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
        dest=target/p.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert sha(dest)==sha(p)
        else:shutil.copyfile(p,dest)

def load_inputs(data,policy_path):
    import freshness as f
    b=f.b;policy,legacy=b.load_locked_policy(policy_path);allowed=set(legacy['data']['sources']['train']['history'])
    class TrainingOnly(b.Inputs):
        def raw(self,name):
            b.require(name in allowed,'TEST_AND_OTHER_TABLE_READS_FORBIDDEN')
            return super().raw(name)
    store=TrainingOnly(data)
    try:history=b.load_train(store,legacy)
    finally:store.close()
    a,c,af,cf,metadata=f.build(history,policy,legacy)
    return f,history,legacy,a,c,af,cf,metadata

def prepare(args):
    bootstrap(args.base)
    import freshness as f
    from synthetic_freshness import run
    f.b.verify_source_lock();env=environment();old=json.loads((T/'source/base/ENVIRONMENT_LOCK.json').read_bytes())
    assert all(env[k]==old[k] for k in env),'Environment differs from locked paired runtime'
    tests=run()
    with f.b.offline_only():f,history,legacy,a,c,af,cf,metadata=load_inputs(args.data,args.policy)
    probe=f.estimator_for(f.b.load_variant(f.b.HERE/'configs/B0.json'),a[af],legacy)
    assert all(probe.get_params()[k]==v for k,v in f.fixed_spec()['model'].items() if k!='name')
    tests['tests'].append('actual locked learner factory constructs original parameters without fitting');tests['passed']+=1
    write(Path('execution/SYNTHETIC.json'),tests)
    contract=json.loads((T/'source/base/DATA_CONTRACT.json').read_bytes());assert sha(args.data)==contract['raw_archive_sha256'] and sha(args.policy)==contract['private_policy_sha256']
    splits=f.b.split_sets(a);assert f.b.split_fingerprints(splits)==contract['split_fingerprints']
    pre={'control_identity':f.b.identity(a,af),'candidate_identity':f.b.identity(c,cf),'new_feature_names':f.EXTRA,'training_wells':81,'rows':972,'base_features':325,'candidate_features':335,'labels_and_scales_equal':True,'cohort_and_order_equal':True,'raw_archive_sha256':sha(args.data),'policy_sha256':sha(args.policy),'split_fingerprints':f.b.split_fingerprints(splits),'test_CSV_reads':0,'new_features_missing_counts':{n:int(c.loc[~c.WELL_ID.duplicated(),n].isna().sum()) for n in f.EXTRA},'historical_dtype':'UNKNOWN; no backfill'}
    write(Path('PRE_DATA_LOCK.json'),pre);write(Path('ENVIRONMENT_LOCK.json'),env)
    write(Path('USER_AUTHORIZATION.md.json'),{'role':'账户B执行与交付','verbatim_user_request':'然后 你按照这个 诊断报告  进行数据优化 然后 再训练一个模型出来','scope':'one fixed missing-memory candidate, validation and private research model; no platform upload or replacement','previous_R17_search_stop':'This fresh direct user request authorizes only the present single candidate, not resumption of other searches'})
    history_table={'scope':'available authorized local training sources/completion reports and latest published handoff index; not a claim about inaccessible machines','index_commit':'8359dda61a99c759333f74972a1a6a20800ebc26','comparisons':[{'task':'A2B-022','mechanism':'exact duplicate/constant removal','completed':True,'equivalent':False,'conclusion':'negative; no repeat'},{'task':'A2B-023','mechanism':'target ratio removal','completed':True,'equivalent':False},{'task':'A2B035-R14/R15 H,T,HX','mechanism':'scale mixing, early heads, production/measure history','completed':True,'equivalent':False,'conclusion':'stopped; do not resume'},{'task':'R17 feature quality diagnosis','mechanism':'last missing run and freshness counts','completed':True,'model_fits':0,'equivalent_training':False}],'equivalent_completed_training_found':False,'keyword_search':'freshness,staleness,last_valid_12,missing_run,continuous missingness and observation recency; only diagnostic material, unrelated dependency sources excluded','does_not_treat_diagnostic_plan_as_execution':True}
    write(Path('HISTORY_CHECK.json'),history_table)
    plan={'task':'A2B-035/FEATURE_FRESHNESS single-candidate controlled research','role':'账户B执行与交付','authorization':'direct current user request, not a fabricated Claude R18','spec':f.fixed_spec(),'candidate_count':1,'control':'fresh B0 fits; no old score subtraction or OOF reuse','evaluation':'fixed5 plus repeat seeds1,2,3,4,5 each5 grouped by WELL_ID; same81 wells exploratory, not independent confirmation','successful_CV_models':60,'successful_full_candidate_models':1,'successful_model_cap':61,'model_entry_cap_with_fault_retries':63,'fault_retry_cap':2,'preprocessor_pipeline_count':'one per entered model; separately counted','no_score_based_early_stopping':True,'baseline_fixed_reproduction_gate':{'score':73.71410733861434,'tolerance':1e-9,'failure':'stop before candidate evaluation'},'retention_recommendation_all_required':{'fixed_delta_min':-.2,'repeat_mean_delta_min':.2,'positive_repeats_min':4,'worst_repeat_delta_min':-.2,'all_structure_and_integrity_checks':'PASS'},'threshold_provenance':'B prespecified engineering recommendation criteria, not user-quoted criteria or a statistical test','full_model_delivery':'Always fit one full candidate after structurally valid CV, as user requested; if criteria fail label RESEARCH_ONLY_NOT_RECOMMENDED; no automatic deployment','error_groups':'five new-field freshness groups age0/age1/age2plus; scale, last legal production ratio, operating fraction, BX flags, training-fold production tertiles; whole dimension suppressed if any group<5; no row outputs','metric':'original unnormalized2^-t, epsilon1e-6, per well then equal mean','model_parallelism':'one fold at a time, ExtraTrees n_jobs=-1, BLAS/OpenMP1, sequential deterministic predict','unchanged':['raw data','original325','scale and target','lag rolling trend','M-1 cutoff and M+1..M+12 targets','all old packages/weights/locks/environments'],'not_authorized_here':['other learners/candidates','test distribution analysis','formal result ZIP','platform upload','replacement of B0/F70/F50'],'OOF_persistence':False}
    write(Path('PLAN.json'),plan)
    files={p.relative_to(T).as_posix():sha(p) for p in T.rglob('*') if p.is_file() and ('source' in p.relative_to(T).parts or p.name in ['run_research.py','PRE_DATA_LOCK.json','ENVIRONMENT_LOCK.json','USER_AUTHORIZATION.md.json','HISTORY_CHECK.json','PLAN.json']) and '__pycache__' not in p.parts}
    write(Path('IMPLEMENTATION_LOCK.json'),{'files':files,'before_candidate_scores':True})
    print(json.dumps({'prepared':True,'synthetic_tests':tests['passed'],'features':335,'successful_model_cap':61,'model_fit_count_so_far':0}))

def validate_locks(args):
    import freshness as f
    for name,h in json.loads((T/'IMPLEMENTATION_LOCK.json').read_bytes())['files'].items():assert sha(T/name)==h,'SOURCE_OR_LOCK_CHANGED'
    assert environment()==json.loads((T/'ENVIRONMENT_LOCK.json').read_bytes())
    pre=json.loads((T/'PRE_DATA_LOCK.json').read_bytes());assert sha(args.data)==pre['raw_archive_sha256'] and sha(args.policy)==pre['policy_sha256']
    return f

def train(args):
    f=validate_locks(args);b=f.b
    from ledger035 import Ledger
    from models035 import forbid_fits
    start=time.perf_counter();write(Path('execution/STARTED.json'),{'time':datetime.now(timezone(timedelta(hours=8))).isoformat(),'plan_sha256':sha(T/'PLAN.json'),'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json')})
    ledger=Ledger(T/'execution/FIT_EVENTS.json');ledger.value.update(local_successful_model_cap=61,local_model_entry_cap=63,local_fault_retry_cap=2);ledger.save()
    with b.offline_only():
        f,history,legacy,control,candidate,af,cf,metadata=load_inputs(args.data,args.policy)
        pre=json.loads((T/'PRE_DATA_LOCK.json').read_bytes());assert b.identity(control,af)==pre['control_identity'] and b.identity(candidate,cf)==pre['candidate_identity']
        splits=b.split_sets(control);assert b.split_fingerprints(splits)==pre['split_fingerprints']
        reference=json.loads((Path(args.reference)/'execution/CV_COMPLETE17.json').read_bytes())['results']['B0']
        results={};errors={}
        def evaluate(panel,features,folds,label):
            oof=f.np.full(len(panel),f.np.nan);coverage=f.np.zeros(len(panel),int);rows=[]
            for i,(tr,va) in enumerate(folds,1):
                assert not set(panel.iloc[tr].WELL_ID)&set(panel.iloc[va].WELL_ID)
                model=f.fit(panel.iloc[tr],features,legacy,ledger,f'{label}-fold{i}')
                with forbid_fits():p=f.predict(model,panel.iloc[va])
                oof[va]=p;coverage[va]+=1;summary=b.summary(panel.iloc[va],p)
                rows.append({'fold':i,'score':summary['official_score'],'weighted_losses':summary['weighted_losses'],'training_wells':int(panel.iloc[tr].WELL_ID.nunique()),'validation_wells':int(panel.iloc[va].WELL_ID.nunique()),'well_overlap':0,'split_sha256':b.fold_hash(tr,va)})
                (T/'execution/PROGRESS.json').write_bytes(enc({'stage':label,'last_successful_fold':i,'models_completed':ledger.value['models_completed'],'preprocessors_completed':ledger.value['preprocessors_completed']}))
                del model
            assert (coverage==1).all() and f.np.isfinite(oof).all()
            summary=b.summary(panel,oof);scores=[r['score'] for r in rows]
            return {'score':summary['official_score'],'weighted_losses':summary['weighted_losses'],'folds':rows,'fold_scores':scores,'worst_fold':min(scores),'fold_std_population':float(f.np.std(scores))},oof
        for name,folds in splits.items():
            a,pa=evaluate(control,af,folds,name+'-B0')
            assert abs(a['score']-reference[name]['score'])<=1e-9,'BASELINE_REPRODUCTION_FAILED'
            z,pz=evaluate(candidate,cf,folds,name+'-C1')
            results[name]={'B0':a,'candidate':z,'candidate_minus_B0':z['score']-a['score']}
            errors[name]=f.error_groups(control,pa,pz,metadata,folds)
            write(Path('execution')/(name+'.json'),{'evaluation':results[name],'error_groups':errors[name]})
            del pa,pz
        deltas=[results['repeat_'+str(i)]['candidate_minus_B0'] for i in range(1,6)]
        recommendation=results['fixed']['candidate_minus_B0']>=-.2 and f.np.mean(deltas)>=.2 and sum(v>0 for v in deltas)>=4 and min(deltas)>=-.2
        # User requested a new model: save one research artifact even if not recommended.
        full=f.fit(candidate,cf,legacy,ledger,'candidate-full')
        full.update({'research_only':True,'retention_recommended_by_B':bool(recommendation),'not_deployed':True,'private_policy_sha256':pre['policy_sha256'],'raw_archive_sha256':pre['raw_archive_sha256'],'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json')})
        model_path=T/'private/B0_FRESH10_ET400.joblib';model_path.parent.mkdir(parents=True,exist_ok=True);assert not model_path.exists()
        b.joblib.dump(full,model_path,compress=3)
        with forbid_fits():
            expected=f.predict(full,candidate);loaded=b.joblib.load(model_path);actual=f.predict(loaded,candidate)
        assert f.np.array_equal(actual,expected),'SAVED_ARTIFACT_RELOAD_MISMATCH'
        # These full-training predictions are only an artifact equality check, not validation.
        del actual,expected,loaded,full
        assert ledger.value['models_completed']==ledger.value['preprocessors_completed']==61
        validate_locks(args)
        result={'task':'A2B-035/FEATURE_FRESHNESS single candidate','role':'账户B执行与交付','spec':f.fixed_spec(),'plan_sha256':sha(T/'PLAN.json'),'implementation_lock_sha256':sha(T/'IMPLEMENTATION_LOCK.json'),'results':results,'paired_repeat_deltas':deltas,'repeat_mean_delta':float(f.np.mean(deltas)),'positive_repeats':sum(v>0 for v in deltas),'worst_repeat_delta':min(deltas),'retention_recommended_by_B':bool(recommendation),'saved_model_status':'PENDING_INDEPENDENT_REVIEW' if recommendation else 'RESEARCH_ONLY_NOT_RECOMMENDED','full_candidate_model_saved':True,'model_sha256':sha(model_path),'model_bytes':model_path.stat().st_size,'model_full_feature_count':335,'artifact_reload_predictions_exact':True,'reload_predictions_not_validation':True,'model_fits':61,'preprocessor_fits':61,'failures':ledger.value['failures'],'retries':0,'row_OOF_persisted':False,'test_CSV_reads':0,'test_predictions':0,'formal_packages_generated':0,'platform_uploads':0,'old_models_not_replaced':True,'current_input_identity_match':True,'historical_dtype':'UNKNOWN; no backfill','seconds':time.perf_counter()-start}
        write(Path('execution/ERROR_GROUPS.json'),errors);write(Path('execution/RESULT_FRESHNESS.json'),result)
        print(json.dumps({'status':'COMPLETE','fixed_B0':results['fixed']['B0']['score'],'fixed_candidate':results['fixed']['candidate']['score'],'fixed_delta':results['fixed']['candidate_minus_B0'],'repeat_deltas':deltas,'mean_delta':result['repeat_mean_delta'],'positive_repeats':result['positive_repeats'],'retention_recommended':bool(recommendation),'model_saved':str(model_path),'model_fits':61,'preprocessor_fits':61,'seconds':result['seconds']},ensure_ascii=False,indent=2))

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','train']);ap.add_argument('--base',required=True);ap.add_argument('--data',required=True);ap.add_argument('--policy',required=True);ap.add_argument('--reference',required=True);a=ap.parse_args()
    try:{'prepare':prepare,'train':train}[a.mode](a)
    except Exception as exc:
        path=T/'execution/FAILURE.json';path.parent.mkdir(parents=True,exist_ok=True)
        if not path.exists():path.write_bytes(enc({'type':type(exc).__name__,'message':str(exc) if isinstance(exc,AssertionError) else 'see private stderr; no raw content published','model_or_preprocessor_budget_not_reset':True}))
        raise
