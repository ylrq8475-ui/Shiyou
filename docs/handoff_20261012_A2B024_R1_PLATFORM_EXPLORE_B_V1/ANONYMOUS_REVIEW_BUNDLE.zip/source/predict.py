"""A2B-024 R1 exploration: one-command, fit-forbidden, standalone inference."""
import argparse
import contextlib
import hashlib
import importlib.metadata
import io
import json
import os
import platform
import sys
from pathlib import Path

sys.dont_write_bytecode = True
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE/'src'))
import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from deployment_core import (require, DeploymentError, file_sha, digest, predict_system,
                             independent_zip_check, panel_keys)
from runtime_guard import no_fits
from input_reader import read_test_tables
from oil_uplift import a2b013_safe as safe, multistep


def canonical_reference(reference):
    original = reference[['WELL_ID', 'NY']].copy()
    dates = pd.to_datetime(original['NY'], format='mixed', errors='coerce')
    require(dates.notna().all(), 'INVALID_TEMPLATE_DATE')
    normalized = original.copy()
    normalized['NY'] = dates.dt.strftime('%Y/%m/%d')
    require(not normalized.duplicated().any() and len(normalized) == len(original), 'DATE_NORMALIZATION_KEY_COLLISION')
    require(np.array_equal(dates.to_numpy(), pd.to_datetime(normalized['NY'], format='%Y/%m/%d').to_numpy()),
            'DATE_NORMALIZATION_SEMANTIC_CHANGE')
    require(original.WELL_ID.tolist() == normalized.WELL_ID.tolist(), 'NORMALIZATION_WELL_ORDER_CHANGE')
    return normalized, int((original.NY != normalized.NY).sum())


def verify_package():
    record = json.loads((HERE/'INTEGRITY.json').read_bytes())
    for name, expected in record['files'].items():
        p = HERE/name
        require(p.resolve().is_relative_to(HERE.resolve()) and file_sha(p) == expected, 'PACKAGE_INTEGRITY_FAILED')
    require(record['status'] == 'R1_PLATFORM_EXPLORATION_ORIGINAL_CONFIRMATION_FAILED', 'ARTIFACT_STATUS')
    require(platform.python_version() == record['python_version'], 'PYTHON_VERSION_MISMATCH')
    for name, version in record['runtime_versions'].items():
        require(importlib.metadata.version(name) == version, 'DEPENDENCY_VERSION_MISMATCH')
    return record


def run(data_dir, output):
    record = verify_package()
    destination = Path(output).expanduser().resolve()
    require(destination.suffix.lower() == '.zip' and not destination.exists(), 'OUTPUT_MUST_BE_NEW_ZIP_PATH')
    input_path = Path(data_dir).expanduser().resolve()
    require(not (input_path.is_dir() and destination.is_relative_to(input_path)), 'OUTPUT_INSIDE_READONLY_INPUT')
    with no_fits() as counts, threadpool_limits(limits=1), joblib.parallel_backend('sequential'):
        artifact = joblib.load(HERE/'models/model_R1.joblib')
        require(artifact['mode'] == 'R1' and artifact['packaged_source_sha256'] == record['source_sha256'],
                'COMPLETE_MODEL_OR_SOURCE_IDENTITY')
        # Warnings may contain a source token; only anonymous checks are printed.
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            table, reader = read_test_tables(data_dir, artifact['inference_policy'])
            config = artifact['inference_policy']['feature_config']
            tables = multistep.MultiSourceTables(table, pd.DataFrame(), pd.DataFrame(), table.copy())
            test, reference, audit, anchors = safe._build_test_panel(tables, config)
            cutoff = safe.audit_pre_anchor_cutoff(table, anchors, config)
        require(test[['WELL_ID', 'NY']].equals(reference), 'INFERENCE_TEMPLATE_ORDER')
        require(len(test) == 120 and test.WELL_ID.nunique() == 10, 'INFERENCE_TARGET_SHAPE')
        require(digest(panel_keys(test)) == artifact['issued_test_key_sha256'], 'ISSUED_TEMPLATE_IDENTITY')
        feature_hash = hashlib.sha256(pd.util.hash_pandas_object(test[artifact['feature_columns']], index=True).values.tobytes()).hexdigest()
        require(feature_hash == artifact['issued_test_feature_sha256'], 'ISSUED_TEST_FEATURE_IDENTITY')
        prediction, arms = predict_system(artifact, test)
        raw = test['history__RCYL__last'].to_numpy(dtype=float)
        mask = ~(np.isfinite(raw) & (raw > 0))
        require(np.array_equal(prediction, np.where(mask, arms['C1'], arms['B0'])), 'INDEPENDENT_ROUTE_CHECK')
        normalized, date_changes = canonical_reference(reference)
        frame = normalized.copy(); frame['RCYL'] = prediction
        safe.write_result_zip(frame, normalized, destination)
        result = independent_zip_check(destination, normalized)
        require(counts['attempted_fits'] == 0, 'INFERENCE_ATTEMPTED_FIT')
    return {'status': 'PREDICTION_COMPLETED', 'result': result, 'input': reader,
            'canonical_date_rows': date_changes, 'date_semantics_and_order_unchanged': True,
            'fallback_test_wells': int(mask[::12].sum()), 'other_test_wells': int((~mask[::12]).sum()),
            'future_sensitive_features': cutoff['future_sensitive_feature_count'],
            'model_fits': 0, 'preprocessor_fits': 0, 'original_confirmation': 'FAILED',
            'platform_uploaded': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data_dir', required=True, help='Issued data directory or original data ZIP; read only')
    parser.add_argument('--output', required=True, help='New result ZIP path, outside the extracted code directory')
    args = parser.parse_args()
    try:
        print(json.dumps(run(args.data_dir, args.output), ensure_ascii=True)); return 0
    except Exception as exc:
        print(json.dumps({'status': 'STOPPED', 'error_type': type(exc).__name__,
                          'error_code': str(exc) if isinstance(exc, DeploymentError) else 'DETAIL_SUPPRESSED'})); return 1


if __name__ == '__main__':
    raise SystemExit(main())
