"""Synthetic deployment failures use fabricated well keys; no real fits."""
import sys
import contextlib
import uuid
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace

LOCAL_SRC = Path(__file__).resolve().parent/'src'
sys.path.insert(0, str(LOCAL_SRC) if LOCAL_SRC.is_dir() else r'D:/codex/Shiyou_B_private_handoff_20261009_v1/payload/project/src')
import numpy as np
import pandas as pd
from oil_uplift import a2b013_safe as safe
from deployment_core import (DeploymentError, digest, inverse_prediction,
                             independent_zip_check, panel_keys, predict_system)

FEATURES = ['history__RCYL__last', 'horizon'] + [f'history__synthetic_{i}' for i in range(323)]


@contextlib.contextmanager
def synthetic_dir():
    root = Path(__file__).resolve().parent/'synthetic_cases'
    p = root/uuid.uuid4().hex
    p.mkdir(parents=True, exist_ok=False)
    yield p  # Preserve fabricated test artifacts only within the new task directory.


def frame(raw=1.0):
    f = pd.DataFrame({c: np.ones(12) for c in FEATURES})
    f['horizon'] = range(1, 13)
    f['history__RCYL__last'] = raw
    f['WELL_ID'] = 'SYNTHETIC_DEPLOY_WELL'
    f['NY'] = [f'2025/{i:02d}/01' for i in range(1, 13)]
    return f


class FakePipeline:
    def __init__(self, value):
        self.value = value
        self.feature_names_in_ = np.asarray(FEATURES, dtype=object)
        self.named_steps = {'model': SimpleNamespace(get_params=lambda: {'synthetic': True})}
    def predict(self, x):
        return np.full(len(x), np.log1p(self.value))
    def fit(self, *args, **kwargs):
        raise AssertionError('DEPLOYMENT_MUST_NOT_FIT')


def artifact(mode='R1'):
    return {'mode': mode, 'feature_columns': FEATURES, 'feature_order_sha256': digest(FEATURES),
            'model_parameters': {'synthetic': True},
            'pipelines': {a: FakePipeline(v) for a, v in [('B0', 2), ('C1', 5)]
                          if mode == 'R1' or a == 'B0'}}


class Checks(unittest.TestCase):
    def test_positive_one_uses_B0(self):
        p, _ = predict_system(artifact(), frame(1))
        self.assertTrue(np.allclose(p, 2))
    def test_positive_scale_inverse(self):
        p, _ = predict_system(artifact(), frame(3))
        self.assertTrue(np.allclose(p, 6))
    def test_nan_uses_C1(self):
        p, _ = predict_system(artifact(), frame(np.nan))
        self.assertTrue(np.allclose(p, 5))
    def test_zero_negative_infinity_use_C1(self):
        for value in (0, -2, np.inf, -np.inf):
            p, _ = predict_system(artifact(), frame(value))
            self.assertTrue(np.allclose(p, 5))
    def test_B0_alone(self):
        p, _ = predict_system(artifact('B0'), frame(np.nan))
        self.assertTrue(np.allclose(p, 2))
    def test_label_is_rejected(self):
        f = frame(); f['RCYL'] = 999
        with self.assertRaises(DeploymentError): predict_system(artifact(), f)
    def test_missing_arm_rejected(self):
        a = artifact(); del a['pipelines']['C1']
        with self.assertRaises(DeploymentError): predict_system(a, frame())
    def test_corrupt_feature_identity(self):
        a = artifact(); a['feature_order_sha256'] = 'wrong'
        with self.assertRaises(DeploymentError): predict_system(a, frame())
    def test_fitted_feature_order_rejected(self):
        a = artifact(); a['pipelines']['C1'].feature_names_in_ = FEATURES[::-1]
        with self.assertRaises(DeploymentError): predict_system(a, frame())
    def test_wrong_parameters_rejected(self):
        a = artifact(); a['model_parameters'] = {'wrong': True}
        with self.assertRaises(DeploymentError): predict_system(a, frame())
    def test_incomplete_well_rejected(self):
        with self.assertRaises(DeploymentError): panel_keys(frame().iloc[:11])
    def test_raw_state_changes_within_well_rejected(self):
        f = frame(); f.loc[5, 'history__RCYL__last'] = 2
        with self.assertRaises(DeploymentError): panel_keys(f)
    def test_duplicate_keys_rejected(self):
        f = frame(); f.loc[1, 'NY'] = f.loc[0, 'NY']
        with self.assertRaises(DeploymentError): panel_keys(f)
    def test_invalid_inverse_rejected(self):
        for value in (np.inf, np.nan, 1e6):
            with self.assertRaises(DeploymentError): inverse_prediction([value], [1], 'B0')
    def test_nonnegative_inverse(self):
        self.assertEqual(inverse_prediction([-1], [2], 'B0').tolist(), [0])
    def test_zip_lexemes_and_determinism(self):
        f = frame(); reference = f[['WELL_ID', 'NY']]; out = reference.copy(); out['RCYL'] = np.arange(12, dtype=float)
        with synthetic_dir() as tmp:
            a, b = Path(tmp)/'first.zip', Path(tmp)/'second.zip'
            safe.write_result_zip(out, reference, a); safe.write_result_zip(out, reference, b)
            self.assertEqual(a.read_bytes(), b.read_bytes())
            result = independent_zip_check(a, reference)
            self.assertEqual(result['rows'], 12); self.assertTrue(result['passed'])
    def test_zip_extra_root_member_rejected(self):
        reference = frame()[['WELL_ID', 'NY']]; out = reference.copy(); out['RCYL'] = 2
        with synthetic_dir() as tmp:
            p = Path(tmp)/'output.zip'; safe.write_result_zip(out, reference, p)
            with zipfile.ZipFile(p, 'a') as z: z.writestr('README.txt', 'bad')
            with self.assertRaises(DeploymentError): independent_zip_check(p, reference)
    def test_zip_wrong_lexeme_rejected(self):
        reference = frame()[['WELL_ID', 'NY']]; out = reference.copy(); out['RCYL'] = 2
        changed = reference.copy(); changed.loc[0, 'NY'] = '2025/1/1'
        with synthetic_dir() as tmp:
            p = Path(tmp)/'output.zip'; safe.write_result_zip(out, reference, p)
            with self.assertRaises(DeploymentError): independent_zip_check(p, changed)


if __name__ == '__main__':
    unittest.main()
