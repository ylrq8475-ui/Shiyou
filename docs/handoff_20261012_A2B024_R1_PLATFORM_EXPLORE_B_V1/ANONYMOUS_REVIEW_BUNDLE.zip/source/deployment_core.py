"""Portable deployment checks. Importing this module never fits or reads data."""
from pathlib import Path
import csv
import hashlib
import io
import json
import zipfile
import re
import joblib

import numpy as np


class DeploymentError(RuntimeError):
    pass


def require(value, code):
    if not value:
        raise DeploymentError(code)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def valid_features(frame, features):
    require(len(features) == 325 and len(set(features)) == 325, 'FEATURE_COUNT_OR_DUPLICATE')
    require('RCYL' not in frame and 'RCYL' not in features and 'WELL_ID' not in features,
            'LABEL_OR_ID_AS_MODEL_INPUT')
    require(all(c in frame.columns for c in features), 'MISSING_FEATURE')


def panel_keys(frame):
    require({'WELL_ID', 'NY', 'horizon', 'history__RCYL__last'}.issubset(frame.columns),
            'INFERENCE_PANEL_SCHEMA')
    require(not frame[['WELL_ID', 'NY']].duplicated().any(), 'DUPLICATE_TEMPLATE_KEY')
    for _, group in frame.groupby('WELL_ID', sort=False):
        require(group.horizon.tolist() == list(range(1, 13)), 'INCOMPLETE_WELL_HORIZON')
        require(group['history__RCYL__last'].nunique(dropna=False) == 1, 'RAW_STATE_NOT_WELL_CONSTANT')
    return list(frame[['WELL_ID', 'NY']].astype(str).itertuples(index=False, name=None))


def inverse_prediction(z, raw, arm):
    require(arm in ('B0', 'C1'), 'UNKNOWN_ARM')
    z, raw = np.asarray(z, dtype=float), np.asarray(raw, dtype=float)
    require(z.shape == raw.shape and np.isfinite(z).all(), 'INVALID_TRANSFORMED_PREDICTION')
    scale = np.where(np.isfinite(raw) & (raw > 0), raw, 1.0)
    with np.errstate(over='ignore', invalid='ignore'):
        p = np.expm1(z) * (scale if arm == 'B0' else 1.0)
    require(np.isfinite(p).all(), 'NONFINITE_INVERSE')
    return np.clip(p, 0, None)


def predict_system(artifact, frame):
    features = artifact['feature_columns']
    valid_features(frame, features)
    keys = panel_keys(frame)
    require(artifact['feature_order_sha256'] == digest(features), 'FEATURE_IDENTITY')
    require(artifact['mode'] in ('B0', 'R1'), 'UNKNOWN_SYSTEM')
    needed = ('B0', 'C1') if artifact['mode'] == 'R1' else ('B0',)
    require(tuple(artifact['pipelines']) == needed, 'INCOMPLETE_SYSTEM_ARMS')
    raw = frame['history__RCYL__last'].to_numpy(dtype=float)
    predictions = {}
    for arm in needed:
        pipeline = artifact['pipelines'][arm]
        require(pipeline.named_steps['model'].get_params() == artifact['model_parameters'],
                'MODEL_PARAMETER_DRIFT')
        require(list(pipeline.feature_names_in_) == features, 'FITTED_FEATURE_ORDER')
        # Parallel tree summation can differ at roundoff level. Preserve the
        # fitted parameters and use a deterministic execution backend at inference.
        with joblib.parallel_backend('sequential'):
            predictions[arm] = inverse_prediction(pipeline.predict(frame[features]), raw, arm)
        require(predictions[arm].shape == (len(keys),), 'PREDICTION_LENGTH')
    answer = predictions['B0'].copy()
    fallback = ~(np.isfinite(raw) & (raw > 0))
    if artifact['mode'] == 'R1':
        answer[fallback] = predictions['C1'][fallback]
        require(np.array_equal(answer[~fallback], predictions['B0'][~fallback]) and
                np.array_equal(answer[fallback], predictions['C1'][fallback]), 'ROUTE_VALUE_DRIFT')
    return answer, predictions


def independent_zip_check(path, reference):
    """Standard-library check of every output byte; return only anonymous counts."""
    expected = list(reference[['WELL_ID', 'NY']].astype(str).itertuples(index=False, name=None))
    require(len(expected) == len(set(expected)), 'REFERENCE_DUPLICATE')
    seen = {}
    well_members = set()
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(names and len(names) == len(set(n.casefold() for n in names)), 'ZIP_DUPLICATE_OR_EMPTY')
        require(archive.testzip() is None, 'ZIP_CRC')
        for name in names:
            require('/' not in name and '\\' not in name and name.endswith('.csv'), 'ZIP_LAYOUT')
            body = archive.read(name)
            require(body.startswith(b'\xef\xbb\xbf'), 'CSV_ENCODING')
            reader = csv.DictReader(io.StringIO(body.decode('utf-8-sig'), newline=''))
            require(reader.fieldnames == ['WELL_ID', 'NY', 'RCYL'], 'CSV_COLUMNS')
            rows = list(reader)
            require(len(rows) == 12, 'CSV_ROW_COUNT')
            wells = {row['WELL_ID'] for row in rows}
            require(len(wells) == 1 and not (wells & well_members), 'CSV_WELL_PARTITION')
            well_members.update(wells)
            from oil_uplift.submission import well_csv_filename
            require(name == well_csv_filename(rows[0]['WELL_ID']), 'CSV_FILENAME')
            for row in rows:
                require(re.fullmatch(r'\d{4}/\d{2}/\d{2}', row['NY']) is not None, 'CSV_DATE_FORMAT')
                require(re.fullmatch(r'\d+\.\d{6}', row['RCYL']) is not None, 'CSV_PREDICTION_PRECISION')
                key = row['WELL_ID'], row['NY']
                require(key not in seen and key in expected, 'CSV_KEY_MISMATCH')
                value = float(row['RCYL'])
                require(np.isfinite(value) and value >= 0, 'CSV_INVALID_PREDICTION')
                seen[key] = value
            require([(row['WELL_ID'], row['NY']) for row in rows] ==
                    [key for key in expected if key[0] in wells], 'CSV_ROW_ORDER')
    require(set(seen) == set(expected), 'ZIP_MISSING_KEYS')
    return {'passed': True, 'rows': len(seen), 'wells': len(well_members),
            'members': len(names), 'sha256': file_sha(path), 'bytes': Path(path).stat().st_size,
            'exact_normalized_reference_lexemes': True, 'date_format': 'YYYY/MM/DD',
            'decimals': 6, 'finite_nonnegative': True}
