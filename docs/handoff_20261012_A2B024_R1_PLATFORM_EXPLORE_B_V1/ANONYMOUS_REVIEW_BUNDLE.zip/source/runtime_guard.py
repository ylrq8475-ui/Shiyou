"""No fitting is permitted in the delivered inference command."""
import contextlib
from deployment_core import DeploymentError


@contextlib.contextmanager
def no_fits():
    from sklearn.pipeline import Pipeline
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import ExtraTreesRegressor
    from sklearn.tree import DecisionTreeRegressor, ExtraTreeRegressor
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler, OneHotEncoder
    patches = []
    counter = {'attempted_fits': 0}
    def reject(*args, **kwargs):
        counter['attempted_fits'] += 1
        raise DeploymentError('INFERENCE_FIT_FORBIDDEN')
    for cls in (Pipeline, ColumnTransformer, ExtraTreesRegressor, DecisionTreeRegressor,
                ExtraTreeRegressor, SimpleImputer, StandardScaler, OneHotEncoder):
        for name in ('fit', 'fit_transform', 'partial_fit'):
            if hasattr(cls, name):
                patches.append((cls, name, getattr(cls, name), name in cls.__dict__))
                setattr(cls, name, reject)
    try:
        yield counter
    finally:
        for cls, name, old, own in reversed(patches):
            if own: setattr(cls, name, old)
            else: delattr(cls, name)
