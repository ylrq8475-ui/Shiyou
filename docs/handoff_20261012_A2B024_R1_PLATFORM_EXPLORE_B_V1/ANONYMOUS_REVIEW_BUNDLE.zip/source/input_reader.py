"""Read only the issued test CSVs from a directory or original archive."""
import hashlib
import io
import zipfile
from pathlib import Path, PurePosixPath
import pandas as pd
from deployment_core import require


def decoded_name(info):
    name = info.filename
    if not info.flag_bits & 0x800:
        try: name = name.encode('cp437').decode('gb18030')
        except UnicodeError: pass
    name = name.replace('\\', '/')
    path = PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and ':' not in name, 'UNSAFE_INPUT_MEMBER')
    return name


def read_test_tables(data_dir, policy):
    """Order by registered content identities; never read any training table."""
    root = Path(data_dir).expanduser().resolve()
    expected = policy['ordered_test_file_sha256']
    require(len(expected) == len(set(expected)) == 10, 'TEST_POLICY_INVENTORY')
    contents = {}
    if root.is_file():
        require(zipfile.is_zipfile(root), 'INPUT_FILE_MUST_BE_ORIGINAL_ZIP')
        with zipfile.ZipFile(root) as archive:
            items = [(decoded_name(i), i) for i in archive.infolist() if not i.is_dir()]
            require(len(items) == len({n.casefold() for n, _ in items}), 'INPUT_DUPLICATE_MEMBER')
            suffix = policy['test_relative_directory'].strip('/')
            selected = [(n, i) for n, i in items if
                        (str(PurePosixPath(n).parent) == suffix or
                         str(PurePosixPath(n).parent).endswith('/'+suffix) or
                         str(PurePosixPath(n).parent) == PurePosixPath(suffix).name) and n.lower().endswith('.csv')]
            require(len(selected) == 10 and sum(i.file_size for _, i in selected) < 100_000_000,
                    'TEST_ARCHIVE_INVENTORY')
            for _, info in selected:
                body = archive.read(info)
                key = hashlib.sha256(body).hexdigest()
                require(key not in contents, 'TEST_DUPLICATE_CONTENT')
                contents[key] = body
        reader_kind = 'ZIP_READONLY_TEST_FILES_ONLY'
    else:
        require(root.is_dir(), 'INPUT_DIRECTORY_MISSING')
        candidates = [root, root/policy['test_relative_directory'], root/'test_data']
        groups = {}
        for candidate in candidates:
            if not candidate.is_dir(): continue
            actual = candidate.resolve()
            require(actual.is_relative_to(root), 'INPUT_DIRECTORY_ESCAPE')
            files = sorted(candidate.glob('*.csv'))
            if len(files) == 10:
                groups[str(actual)] = files
        require(len(groups) == 1, 'TEST_DIRECTORY_NOT_UNIQUE')
        for item in next(iter(groups.values())):
            require(not item.is_symlink() and item.resolve().is_relative_to(root), 'INPUT_FILE_ESCAPE')
            body = item.read_bytes(); key = hashlib.sha256(body).hexdigest()
            require(key not in contents, 'TEST_DUPLICATE_CONTENT')
            contents[key] = body
        reader_kind = 'DIRECTORY_READONLY_TEST_FILES_ONLY'
    require(set(contents) == set(expected), 'ISSUED_TEST_CONTENT_IDENTITY_MISMATCH')
    settings = policy['csv']
    frames = [pd.read_csv(io.BytesIO(contents[key]), encoding=settings.get('encoding', 'utf-8-sig'),
                          sep=settings.get('delimiter', ',')) for key in expected]
    require(all(list(f.columns) == policy['columns'] for f in frames), 'TEST_CSV_SCHEMA')
    combined = pd.concat(frames, ignore_index=True)
    return combined, {'reader': reader_kind, 'test_files_read': 10, 'training_files_read': 0,
                      'raw_copied_or_extracted': False}
