"""Only fabricated source files are written here; all real fits are forbidden."""
import contextlib
import hashlib
import io
import json
import unittest
import uuid
import zipfile
from pathlib import Path

import pandas as pd
from unittest.mock import patch
from deployment_core import DeploymentError
from input_reader import read_test_tables
from runtime_guard import no_fits
from predict import canonical_reference

HERE = Path(__file__).resolve().parent


@contextlib.contextmanager
def synthetic_dir():
    p = HERE/'fabricated_cases'/uuid.uuid4().hex
    p.mkdir(parents=True); yield p


def bodies():
    return [(f'SYNTHETIC_{i:02d}.csv', f'WELL_ID,NY,RCYL\nSYNTHETIC_{i:02d},2025/1/1,{i}\n'.encode('utf-8-sig')) for i in range(10)]


def policy():
    return {'ordered_test_file_sha256': [hashlib.sha256(b).hexdigest() for _, b in bodies()][::-1],
            'test_relative_directory': 'data/test_data', 'columns': ['WELL_ID', 'NY', 'RCYL'],
            'csv': {'encoding': 'utf-8-sig', 'delimiter': ','}}


def write_sources(p):
    p.mkdir(parents=True, exist_ok=True)
    for name, body in bodies(): (p/name).write_bytes(body)


class PlatformChecks(unittest.TestCase):
    def test_directory_full_root(self):
        with synthetic_dir() as p:
            write_sources(p/'data/test_data')
            table, result = read_test_tables(p, policy())
            self.assertEqual(table.WELL_ID.tolist(), [f'SYNTHETIC_{i:02d}' for i in range(9, -1, -1)])
            self.assertEqual(result['training_files_read'], 0)
    def test_directory_data_root(self):
        with synthetic_dir() as p:
            write_sources(p/'test_data')
            self.assertEqual(len(read_test_tables(p, policy())[0]), 10)
    def test_directory_test_root(self):
        with synthetic_dir() as p:
            write_sources(p)
            self.assertEqual(len(read_test_tables(p, policy())[0]), 10)
    def test_archive_root_wrapper_and_skip_train(self):
        with synthetic_dir() as p:
            path = p/'source.zip'
            with zipfile.ZipFile(path, 'x') as z:
                for name, body in bodies(): z.writestr('wrapper/data/test_data/'+name, body)
                z.writestr('wrapper/data/train_data/DO_NOT_READ.csv', 'INVALID,DO_NOT_PARSE\n')
            _, result = read_test_tables(path, policy())
            self.assertEqual(result['test_files_read'], 10)
            self.assertEqual(result['training_files_read'], 0)
    def test_changed_content_rejected(self):
        with synthetic_dir() as p:
            write_sources(p); (p/'SYNTHETIC_00.csv').write_text('changed')
            with self.assertRaises(DeploymentError): read_test_tables(p, policy())
    def test_missing_file_rejected(self):
        with synthetic_dir() as p:
            for name, body in bodies()[:9]: (p/name).write_bytes(body)
            with self.assertRaises(DeploymentError): read_test_tables(p, policy())
    def test_archive_path_escape_rejected(self):
        with synthetic_dir() as p:
            path = p/'bad.zip'
            with zipfile.ZipFile(path, 'x') as z: z.writestr('../data/test_data/unsafe.csv', 'bad')
            with self.assertRaises(DeploymentError): read_test_tables(path, policy())
    def test_duplicate_content_rejected(self):
        with synthetic_dir() as p:
            write_sources(p); (p/'SYNTHETIC_09.csv').write_bytes(bodies()[0][1])
            with self.assertRaises(DeploymentError): read_test_tables(p, policy())
    def test_date_padding_preserves_semantics(self):
        ref = pd.DataFrame({'WELL_ID': ['SYNTHETIC']*2, 'NY': ['2025/1/1', '2025/2/1']})
        normalized, changes = canonical_reference(ref)
        self.assertEqual(changes, 2)
        self.assertEqual(normalized.NY.tolist(), ['2025/01/01', '2025/02/01'])
    def test_normalized_duplicate_rejected(self):
        ref = pd.DataFrame({'WELL_ID': ['SYNTHETIC']*2, 'NY': ['2025/1/1', '2025/01/01']})
        with self.assertRaises(DeploymentError): canonical_reference(ref)
    def test_invalid_calendar_rejected(self):
        ref = pd.DataFrame({'WELL_ID': ['SYNTHETIC'], 'NY': ['2025/2/30']})
        with self.assertRaises(DeploymentError): canonical_reference(ref)
    def test_model_fit_guard(self):
        from sklearn.ensemble import ExtraTreesRegressor
        with no_fits() as count:
            with self.assertRaises(DeploymentError): ExtraTreesRegressor().fit([[1]], [2])
            self.assertEqual(count['attempted_fits'], 1)
    def test_preprocess_fit_guard(self):
        from sklearn.impute import SimpleImputer
        with no_fits() as count:
            with self.assertRaises(DeploymentError): SimpleImputer().fit_transform([[1]])
            self.assertEqual(count['attempted_fits'], 1)


if __name__ == '__main__': unittest.main()
