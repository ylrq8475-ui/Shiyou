"""Zero-fit LJCYL integrity and training-only geology value screening."""
from routes15 import *
import json,subprocess,io
from scipy.stats import spearmanr

def audit_ljcyl(history,base_panel,legacy):
    compared=0;inconsistent=0;monotonic=0;insufficient=0;pairs=0
    for wid,g in base_panel.groupby('WELL_ID',sort=False):
        t0=pd.Timestamp(g.anchor_time.iloc[0]).to_period('M')+1;q,end=old.legal_history(history,wid,t0,'M_minus_1',legacy);q=q.assign(__period=pd.to_datetime(q.NY).dt.to_period('M')).sort_values('__period')
        if 'LJCYL' not in q or 'YCYL' not in q:insufficient+=1;continue
        cum=pd.to_numeric(q.LJCYL,errors='coerce').to_numpy(float);monthly=pd.to_numeric(q.YCYL,errors='coerce').to_numpy(float);period=q.__period.tolist();good=0;bad=False;decrease=False
        for i in range(1,len(q)):
            if period[i]!=period[i-1]+1 or not np.isfinite([cum[i],cum[i-1],monthly[i]]).all():continue
            tol=.05+1e-6*max(abs(cum[i]),abs(cum[i-1]),abs(monthly[i]));delta=cum[i]-cum[i-1];good+=1;pairs+=1;bad|=abs(delta-monthly[i])>tol;decrease|=delta < -tol
        if good:compared+=1;inconsistent+=int(bad);monotonic+=int(decrease)
        else:insufficient+=1
    enable=compared>=65 and inconsistent==0 and monotonic==0
    return {'training_wells':base_panel.WELL_ID.nunique(),'wells_with_comparable_legal_adjacent_pairs':compared,'inconsistent_wells':inconsistent,'decreasing_cumulative_wells':monotonic,'insufficient_wells':insufficient,'legal_adjacent_pairs':pairs,'tolerance':'absolute0.05 + relative1e-6 times max absolute adjacent cumulative/current monthly','LJCYL_enabled_for_HX':enable,'decision':'include only if >=65 comparable wells, no inconsistent/decreasing wells; otherwise disable conservatively','future_or_test_values_used':False,'interpretation':'inconsistency is a provenance/definition warning; not alone proof of future leakage','model_fits':0,'preprocessor_fits':0}

def geology(store,history,base_panel,b0_oof,legacy,private_config):
    layer_roles=private_config['data']['sources']['train']['layer'];require(bool(layer_roles),'GEOLOGY_LAYER_SOURCE_MISSING');ids=set(base_panel.WELL_ID);frames=[];rows_test_skipped=0
    for name in layer_roles:
        raw=store.raw(name);header,spans=old.header_and_rows(raw,',');require('WELL_ID' in header,'GEOLOGY_WELL_KEY');wi=header.index('WELL_ID');records=[]
        for row in spans:
            wid=old.cell(raw,row[wi],'utf-8-sig')
            if wid not in ids:rows_test_skipped+=1;continue
            records.append({col:old.cell(raw,row[j],'utf-8-sig') for j,col in enumerate(header)})
        frames.append(pd.DataFrame(records))
    layer=pd.concat(frames,ignore_index=True);y=base_panel.RCYL.to_numpy(float).reshape(-1,12);pred=np.asarray(b0_oof).reshape(-1,12);res=np.log((y[:,:2]+1e-6)/(pred[:,:2]+1e-6)).mean(axis=1);wells=base_panel.WELL_ID.drop_duplicates().tolist();fields={'YXHD':'effective_thickness_sum','SYHD':'sandstone_thickness_sum','STL':'permeability_mean','KXD':'porosity_mean','SFSBHD':'original_oil_saturation_mean'};values={name:{} for name in fields.values()};values['kh_sum']={}
    for wid,g in layer.groupby('WELL_ID',sort=False):
        for col,name in fields.items():
            a=pd.to_numeric(g.get(col,pd.Series(dtype=float)),errors='coerce').to_numpy(float);values[name][wid]=float(a.sum() if col in ('YXHD','SYHD') else a.mean()) if len(a) and np.isfinite(a).all() else np.nan
        if 'STL' in g and 'YXHD' in g:
            a=pd.to_numeric(g.STL,errors='coerce').to_numpy(float);b=pd.to_numeric(g.YXHD,errors='coerce').to_numpy(float);values['kh_sum'][wid]=float((a*b).sum()) if np.isfinite(a).all() and np.isfinite(b).all() else np.nan
    result=[];worth=False
    for name,bywell in values.items():
        x=np.asarray([bywell.get(w,np.nan) for w in wells]);mask=np.isfinite(x)&np.isfinite(res);n=int(mask.sum());missing=len(x)-n
        if n<15 or 0<missing<5:result.append({'field':name,'status':'SUPPRESSED_SUPPORT_OR_COMPLEMENT','no_numeric_statistics':True});continue
        coef=float(spearmanr(x[mask],res[mask]).statistic);coef=None if not np.isfinite(coef) else coef;cut=np.quantile(x[mask],[1/3,2/3]);labels=np.where(x[mask]<=cut[0],0,np.where(x[mask]<=cut[1],1,2));counts=[int((labels==i).sum()) for i in range(3)];groups=None if min(counts)<5 else [{'tertile':i+1,'wells':counts[i],'mean_log_ratio_residual':float(res[mask][labels==i].mean())} for i in range(3)];hit=name in ('kh_sum','effective_thickness_sum') and coef is not None and abs(coef)>=.2;worth|=hit;result.append({'field':name,'status':'REPORTED','valid_training_wells':n,'spearman':coef,'tertile_groups':groups,'groups_status':'all>=5' if groups else 'entire grouping suppressed','worth_criterion_met':hit})
    return {'scope':'training wells and same-run fixed B0 OOF only; no G enters model','residual':'per well mean of log((observed+1e-6)/(prediction+1e-6)) for months1,2','static_field_source':'R8 E2 class(a), historical availability remains UNKNOWN','results':result,'decision':'值得争取放行' if worth else '不再投入','decision_rule':'abs(Spearman)>=0.2 for kh or effective thickness','nontraining_layer_rows_dynamic_values_decoded':0,'model_fits':0,'preprocessor_fits':0,'G_model_enabled':False}
