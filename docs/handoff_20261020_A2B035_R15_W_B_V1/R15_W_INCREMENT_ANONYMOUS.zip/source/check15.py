from routes15 import *
from error_budget import budget,weights
from unittest.mock import patch
import routes15 as module,json

def main():
    checks=[];p=pd.DataFrame({'WELL_ID':np.repeat(['SYNTH_'+str(i) for i in range(10)],12),'horizon':np.tile(np.arange(1,13),10),'RCYL':np.full(120,2.),'__scale035':1.,'f':np.arange(120,dtype=float)})
    meta=pd.DataFrame({'WELL_ID':p.WELL_ID.drop_duplicates().tolist(),'production_level':np.arange(10,dtype=float),'M_ratio':[1.]*10,'M_SCTS_fraction':[1.]*10,'scale_fallback':[False]*9+[True]});folds=h.split_sets(p)['fixed'];pred=np.full(120,4.);b=budget(p,pred,meta,folds);require(abs(b['total_weighted_loss']-(1-old.summary(p,pred)['official_score']/100))<1e-12,'P1_01_OFFICIAL');require(b['groups']['scale_fallback']['status']=='ENTIRE_DIMENSION_SUPPRESSED','P1_02_COMPLEMENT');checks+=['A035-R14-01 official score identity','A035-R14-02 suppress entire9+1 dimension and complement']
    p0=p.copy();p0['RCYL']=0.;w,e=weights(p0,pred);require(np.max(w)<.5 and np.isfinite(w).all(),'ZERO_TARGET_OFFICIAL');checks.append('zero target does not create epsilon-scale blowup')
    for bad in (np.full(120,np.inf),np.full(120,-1.)):
        try:weights(p,bad)
        except RuntimeError:pass
        else:raise RuntimeError('INVALID_BUDGET_INPUT_ACCEPTED')
    checks.append('negative and nonfinite budget predictions rejected')
    captured={}
    class Prep:
        def fit_transform(self,x,y):captured['prep_indices']=x.index.tolist();return np.zeros((len(x),1))
    class Model:
        def fit(self,x,y,**kw):captured['weights']=kw.get('sample_weight');return self
    class Ledger:
        def run(self,kind,stage,fn):return fn()
    c=route('SYNTH_W',b0(),W=True);selected=np.asarray([0,1,2,3,4,12,13])
    with patch.object(module,'estimator_for',lambda *x:Model()),patch.object(old.training,'_preprocessor',lambda *x:Prep()):fit_model(p.iloc[selected],['f'],c,{},Ledger(),'SYNTH')
    require(np.array_equal(captured['weights'],2.**(-p.iloc[selected].horizon.to_numpy(float))) and captured['prep_indices']==selected.tolist(),'W_WRONG_ROWS_OR_VALUES');checks.append('actual fit path passes exact unnormalized2^-horizon to estimator fit only, train rows only')
    # HX counts use legal frame only. Future measures/cumulative cannot change it.
    legacy={'anchors':{'date_column':'NY'}};q=pd.DataFrame({'NY':['1980-01-01','1980-02-01'],'CSLB':['SYNTH_A',None],'LJCYL':[1.,3.]});v=hx_values(q,pd.Period('1980-02'),legacy,True);require(v['HX_production_months']==2 and v['HX_measure_count']==1 and v['HX_months_since_measure']==1 and v['HX_LJCYL_last']==3. and 'NCYL' not in v,'HX_DEFINITION');checks.append('HX months, per-type counts, last finite cumulative and no NCYL')
    out={'status':'PASS','checks':checks,'model_fits':0,'preprocessor_fits':0,'fit_spies_only':True,'old_official_metric_code_changed':False};dest=Path(__file__).resolve().parent.parent/'execution/SYNTHETIC_R15.json';dest.write_bytes(encode(out));print(json.dumps(out))
if __name__=='__main__':main()
