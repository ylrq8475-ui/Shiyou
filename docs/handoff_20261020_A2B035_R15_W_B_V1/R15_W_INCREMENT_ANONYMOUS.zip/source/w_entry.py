"""Private B0+W complete version. Pending independent review; no upload action."""
import sys,json,platform,importlib.metadata as im,argparse
from pathlib import Path
ENTRY_DIR=Path(__file__).resolve().parent;sys.path.insert(0,str(ENTRY_DIR));sys.path.insert(0,str(ENTRY_DIR/'base'))
import routes15 as r
from ledger035 import Ledger
from models035 import forbid_fits
def main(operation):
    root=ENTRY_DIR.parent;ap=argparse.ArgumentParser();ap.add_argument('--data_dir',required=True);ap.add_argument('--output',required=True);ap.add_argument('--policy',default=str(root/'runtime_policy.json'));ap.add_argument('--model',default=str(root/'models/model.joblib'));a=ap.parse_args();locked=json.loads((ENTRY_DIR/'base/ENVIRONMENT_LOCK.json').read_bytes());env={'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({d.metadata['Name']:d.version for d in im.distributions()}.items()))};r.require(all(env[k]==locked[k] for k in env),'W_RUNTIME_IDENTITY');r.old.verify_source_lock();config=r.route('B0_W',r.b0(),True);r.valid(config);policy,legacy=r.old.load_locked_policy(a.policy);store=r.old.Inputs(a.data_dir);source_hash=r.old.file_sha(__file__)
    with r.old.offline_only():
        if operation=='train':
            dest=Path(a.output);r.require(not dest.exists(),'W_OUTPUT_EXISTS');dest.mkdir(parents=True);ledger=Ledger(dest/'FIT_COUNTS.json')
            try:history=r.old.load_train(store,legacy)
            finally:store.close()
            provider=r.Provider(history,policy,legacy);p,fs,*_=provider.get(config);artifact=r.fit_model(p,fs,config,legacy,ledger,'W-full');bundle={'artifact':artifact,'config':config,'source_hash':source_hash,'policy_sha':r.old.file_sha(a.policy),'runtime':env};r.old.joblib.dump(bundle,dest/'model.joblib',compress=3);receipt={'model_sha256':r.old.file_sha(dest/'model.joblib'),'config':config,'runtime':env,'source_hash':source_hash,'model_fits':ledger.value['models_completed'],'preprocessor_fits':ledger.value['preprocessors_completed'],'upload_eligible':False,'review':'PENDING_CODEX_W_PATH_AND_PACKAGE'};(dest/'MODEL_RECEIPT.json').write_bytes(r.encode(receipt))
        else:
            model=Path(a.model);receipt=json.loads((model.parent/'MODEL_RECEIPT.json').read_bytes());r.require(r.old.file_sha(model)==receipt['model_sha256'],'W_MODEL_IDENTITY');bundle=r.old.joblib.load(model);r.require(bundle['config']==config and bundle['policy_sha']==r.old.file_sha(a.policy) and bundle['source_hash']==source_hash,'W_MODEL_POLICY_SOURCE_CONFIG')
            try:
                with forbid_fits():
                    p,fs,audit=r.old.build_variant_test(store,policy,legacy,config['base']);pred=r.np.full(len(p),r.np.nan)
                    for wid in p.WELL_ID.drop_duplicates():
                        inds=r.np.flatnonzero((p.WELL_ID==wid).to_numpy());pred[inds]=r.predict_model(bundle['artifact'],p.iloc[inds],config)
                    lint=r.old.write_result(a.output,p,pred);Path(str(a.output)+'.receipt.json').write_bytes(r.encode({'lint':lint,'boundary':audit,'model_fits':0,'preprocessor_fits':0,'upload_eligible':False}))
            finally:store.close()
    print(operation.upper()+'_B0_W_COMPLETE')
