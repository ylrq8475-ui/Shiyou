"""Ordered R15 research, early aggregate handoff checkpoints, memory-only OOF."""
from routes15 import *
from diagnostics15 import audit_ljcyl,geology
from error_budget import budget,pairs
from ledger035 import Ledger
import json,time,sys,platform,importlib.metadata as im,yaml,traceback
TASK=Path(__file__).resolve().parent.parent
DATA=Path(__import__("os").environ["SHIYOU_AUTHORIZED_DATA_ARCHIVE"])
POLICY=TASK.parent/'A2B035_20261019_v1/private/runtime_policy.json'
PRIVATE=TASK.parent/'Shiyou_B_private_handoff_20261009_v1/payload/project'
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(encode(v))
def runtime():return {'python_version':platform.python_version(),'python_build':list(platform.python_build()),'python_compiler':platform.python_compiler(),'dependencies':dict(sorted({d.metadata['Name']:d.version for d in im.distributions()}.items()))}
def verify():
    lock=json.loads((TASK/'RESEARCH_LOCK.json').read_bytes())
    for name,sha in lock['files'].items():require(old.file_sha(TASK/name)==sha,'RESEARCH_SOURCE_OR_CONFIG_CHANGED')
    require(runtime()==json.loads((TASK/'execution/RESEARCH_ENVIRONMENT.json').read_bytes()),'MIXED_RESEARCH_RUNTIME');old.verify_source_lock()
def ranking(r):return (-r['results']['repeated_summary']['mean'],r['results']['repeated_summary']['standard_error'],-r['results']['fixed']['score'],r['config']['variant'])
def main():
    require(not (TASK/'execution/RESEARCH_STARTED.json').exists(),'RESEARCH_ALREADY_STARTED_NO_SUCCESSFUL_FOLDS_RERUN');verify();save(TASK/'execution/RESEARCH_STARTED.json',{'source_lock_sha256':old.file_sha(TASK/'RESEARCH_LOCK.json'),'runtime':runtime(),'before_any_CV_fit':True,'upload_eligible':False,'R15_authorized_research_before_incremental_review':True});tick=time.perf_counter();ledger=Ledger(TASK/'execution/RESEARCH_FITS.json');policy,legacy=old.load_locked_policy(POLICY);contract=json.loads((old.HERE/'DATA_CONTRACT.json').read_bytes());require(old.file_sha(DATA)==contract['raw_archive_sha256'],'DATA_ARCHIVE_CHANGED');manifest=json.loads((PRIVATE/'private_logs/raw_manifest_20260916.json').read_bytes());store=old.Inputs(DATA)
    try:
        for row in manifest['files']:require(old.sha(store.raw(row['relative_path']))==row['sha256'],'DATA_MEMBER_CHANGED')
        history=old.load_train(store,legacy)
    finally:store.close()
    provider=Provider(history,policy,legacy);control=route('B0_U',b0());p=provider.get(control)[0];splits=h.split_sets(p);require(h.split_fingerprints(splits)==contract['split_fingerprints'],'SPLIT_IDENTITY');records={};memory={}
    def checkpoint():
        rank=sorted(records.values(),key=ranking);save(TASK/'execution/PROGRESS.json',{'completed_variants':len(records),'models':ledger.value['models_completed'],'preprocessors':ledger.value['preprocessors_completed'],'top':[{'variant':r['config']['variant'],'repeated_mean':r['results']['repeated_summary']['mean']} for r in rank[:5]],'seconds':time.perf_counter()-tick,'upload_eligible':False})
    def evaluate_all(c,base_predictions=None):
        valid(c);verify();name=c['variant'];require(name not in records,'SUCCESSFUL_VARIANT_NOT_RETRAINED');panel,fs,audit,meta=provider.get(c);require(panel[['WELL_ID','horizon','RCYL']].equals(p[['WELL_ID','horizon','RCYL']]),'TARGET_KEY_ALIGNMENT');folder=TASK/'execution'/name;folder.mkdir()
        save(folder/'PRESCORE.json',{'config':c,'identity':input_identity(panel,fs),'feature_columns':len(fs),'splits':h.split_fingerprints(splits),'runtime':runtime(),'source_lock_sha256':old.file_sha(TASK/'RESEARCH_LOCK.json'),'private_policy_sha256':old.file_sha(POLICY),'raw_archive_sha256':contract['raw_archive_sha256'],'data_members_verified':100,'before_variant_fits':True,'upload_eligible':False});values={};oofs={};budgets={};print('BEGIN '+name,flush=True)
        for sn,folds in splits.items():
            values[sn],oofs[sn]=evaluate(c,provider,folds,ledger,name+'-'+sn,None if base_predictions is None else base_predictions[sn]);budgets[sn]=budget(panel,oofs[sn],meta,folds);save(folder/(sn+'.json'),{'evaluation':values[sn],'error_budget':budgets[sn]})
            if name=='B0_U' and sn=='fixed':require(abs(values[sn]['score']-73.71410733861434)<=1e-9,'B0_FIXED_REPRODUCTION_FAILURE')
        values['repeated_summary']=h.repeated_summary([values['repeat_'+str(i)] for i in range(1,6)]);r={'config':c,'results':values,'error_budget':budgets,'upload_eligible':False,'review':'PENDING_CODEX_INCREMENTAL'};records[name]=r;memory[name]=oofs;save(folder/'RESULT.json',r);checkpoint();print('DONE '+name+' repeat='+str(values['repeated_summary']['mean']),flush=True);return r
    try:
        with old.offline_only():
            b=evaluate_all(control);w=evaluate_all(route('B0_W',b0(),True));comparisons={sn:pairs(p,{'B0_U':memory['B0_U'][sn],'B0_W':memory['B0_W'][sn]}) for sn in splits};save(TASK/'execution/W_BATCH_COMPLETE.json',{'task':'R15/B0+W','role':'账户B执行与交付','records':[b,w],'paired_error_and_blend':comparisons,'delta_fixed':w['results']['fixed']['score']-b['results']['fixed']['score'],'delta_repeated_mean':w['results']['repeated_summary']['mean']-b['results']['repeated_summary']['mean'],'model_fits':ledger.value['models_completed'],'preprocessor_fits':ledger.value['preprocessors_completed'],'source_lock_sha256':old.file_sha(TASK/'RESEARCH_LOCK.json'),'upload_eligible':False})
            hs=[]
            for file in sorted((TASK/'configs').glob('H_*.json')):hs.append(evaluate_all(json.loads(file.read_bytes())))
            best_h=sorted(hs,key=ranking)[0];save(TASK/'execution/H_CHOICE_BEFORE_T.json',{'best_H':best_h['config'],'basis':'prelocked repeat mean/SE/fixed/name rule, exploratory winner; before T fits'})
            prime=route('B0PRIME_T_BASE',h.original_b0prime());pr=evaluate_all(prime);ts=[]
            for source in (pr,best_h):
                c=copy.deepcopy(source['config']);c.update(variant='T_'+c['variant'],T=True);ts.append(evaluate_all(c,memory[source['config']['variant']]))
            best_t=sorted(ts,key=ranking)[0];save(TASK/'execution/HT_BATCH_COMPLETE.json',{'task':'R15/H+W/T','role':'账户B执行与交付','records':hs+[pr]+ts,'best_H':best_h['config']['variant'],'best_T':best_t['config']['variant'],'fits_cumulative':ledger.value['models_completed'],'source_lock_sha256':old.file_sha(TASK/'RESEARCH_LOCK.json'),'upload_eligible':False})
            lj=audit_ljcyl(history,p,legacy);save(TASK/'execution/LJCYL_AUDIT_BEFORE_HX.json',lj);provider.include_ljcyl=lj['LJCYL_enabled_for_HX'];hx=evaluate_all(route('B0_HX',b0(),HX=True));original=yaml.safe_load((PRIVATE/'configs/private_data_inferred_v7_safe_plus_layer.yaml').read_bytes());store=old.Inputs(DATA)
            try:geo=geology(store,history,p,memory['B0_U']['fixed'],legacy,original)
            finally:store.close()
            save(TASK/'execution/GEOLOGY_SCREEN.json',geo);chosen=['B0_U','B0_W','B0PRIME_T_BASE',best_h['config']['variant'],best_t['config']['variant'],'B0_HX'];corr={sn:pairs(p,{n:memory[n][sn] for n in chosen}) for sn in splits};save(TASK/'execution/FINAL_RESEARCH.json',{'status':'R15_INTERNAL_RESEARCH_COMPLETE','records':list(records.values()),'paired_errors_and_equal_blends':corr,'best_H':best_h['config']['variant'],'best_T':best_t['config']['variant'],'LJCYL_audit':lj,'geology':geo,'model_fits':ledger.value['models_completed'],'preprocessor_fits':ledger.value['preprocessors_completed'],'new_paths_upload_eligible':False,'S_v':'UNKNOWN','row_OOF_persisted':False,'test_input_distribution_comparisons':0,'seconds':time.perf_counter()-tick})
        verify();print('R15_INTERNAL_RESEARCH_COMPLETE',flush=True)
    except Exception as exc:
        save(TASK/'execution/RESEARCH_FAILURE.json',{'exception':type(exc).__name__,'code':str(exc) if isinstance(exc,RuntimeError) else 'PRIVATE_TRACEBACK','fit_counts':{k:v for k,v in ledger.value.items() if k!='events'}});(TASK/'private/RESEARCH_TRACEBACK.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
if __name__=='__main__':main()
