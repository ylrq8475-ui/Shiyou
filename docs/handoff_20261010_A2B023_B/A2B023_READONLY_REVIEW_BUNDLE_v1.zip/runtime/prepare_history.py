"""Read authorized experiment identities and public history; never load raw data or fit."""
import hashlib
import json
import re
import subprocess
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
COORD=Path('D:/codex/Shiyou_B_coordination')
PRIVATE=Path('D:/codex/Shiyou_B_private_handoff_20261009_v1/payload/project')
SOURCES=Path('D:/codex/b-training-handoff-20261009-v2/evidence/sources')
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
    with (ROOT/name).open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
fixed=[('5867edc93916e4228791e3d20327ff48a960537d','docs/handoff_20261010_A2B022_B/REPORT_B.md',Path('D:/codex/A2B022_20261010_v1/delivery_v2/REPORT_B.md')),
       ('0fdbc4d99ac7d5883359c923ebd98b69d5241120','docs/handoff_20261010_A2B022_A/REPORT_A.md',COORD/'closeout/A2B022_A_RECEIPT_20261010_v1/received_A/REPORT_A.md'),
       ('64c2d08ffbc4ea89dc008bae38e4001ac61f8973','docs/handoff_20261010_A2B022_B_CLOSEOUT/README.md',COORD/'closeout/A2B022_A_RECEIPT_20261010_v1/upload/README.md')]
(ROOT/'received_public').mkdir()
public=[]
for commit,name,local in fixed:
    url='https://raw.githubusercontent.com/ylrq8475-ui/Shiyou/'+commit+'/'+name
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shiyou-B-A2B023-history'}),timeout=40) as r:b=r.read()
    assert b==local.read_bytes()
    target=ROOT/'received_public'/(commit[:7]+'_'+local.name)
    target.write_bytes(b)
    text=b.decode('utf-8')
    assert 'A2B-022' in text
    public.append({'commit':commit,'path':name,'sha256':sha(b),'matches_existing_frozen_local':True})
repo=ROOT/'history_repo.git'
git=['D:/Program Files/Git/bin/git.exe','--git-dir='+str(repo)]
tip=subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()
assert tip=='d8bc8f198a7acf6cac9cb8753406d6b15579e993'
tracked=subprocess.check_output(git+['ls-tree','-r','--name-only','HEAD'],text=True).splitlines()
source_bindings={}
status=(SOURCES/'STATUS_B.md').read_text(encoding='utf-8')
integration=(SOURCES/'INTEGRATION_LOG.md').read_text(encoding='utf-8')
for p in [SOURCES/'STATUS_B.md',SOURCES/'INTEGRATION_LOG.md',PRIVATE/'src/oil_uplift/a2b006_training.py',PRIVATE/'src/oil_uplift/training.py',PRIVATE/'experiments/a2b013/EXPERIMENT_PLAN.yaml',PRIVATE/'experiments/a2b017/EXECUTION_COMPLETED.json',PRIVATE/'experiments/a2b017/EXPERIMENT_PLAN.yaml',Path('D:/codex/A2B021_20261009_v1/PLAN.json'),Path('D:/codex/A2B021_20261009_v1/execution/FINAL_RESULT.json'),Path('D:/codex/A2B019_T1_20261009_v1/execution/FINAL_RESULT.json'),Path('D:/codex/A2B022_20261010_v1/PLAN.json'),Path('D:/codex/A2B022_20261010_v1/execution/FINAL_RESULT.json')]:
    source_bindings[str(p)]=sha(p.read_bytes())
assert 'A2B-009' in status and '73.714107' in status and 'A2B-015' in status
assert 'only authorizes the explicit log-ratio transform' in (PRIVATE/'src/oil_uplift/a2b006_training.py').read_text()
records=[
    ('A2B-001/002/003/v6/v7','Earlier imported pipeline allows absolute log as a code option; prior model research uses different boundary and/or layer/first-plan/calibration scope.','Not equivalent; an available code option does not prove a completed same-boundary experiment.','historical coordination summaries and public original import','earlier-boundary completed research; individual early trial logs not supplied'),
    ('A2B-006/007','log-ratio only; official-horizon weights and two scale-floor policies; 362-column layered safe reference.','Not equivalent: transform remains ratio and feature scope differs.','STATUS_B sections006/007 and ExplicitCandidateSpec.validate','completed/stopped'),
    ('A2B-009 R2','Six models: three calendar features, unaugmented325-column control, two historical augmentation variants; inherited log_ratio_last.','325-column control matches reference; no absolute-log candidate among recorded six.','STATUS_B section009 and INTEGRATION_LOG row009','all six completed/stopped'),
    ('A2B-011 B2','only11 historical augmentation; log-ratio target;325 columns.','Not equivalent: augmentation candidate, unchanged ratio target.','STATUS_B section011; a2b011_training.transform_target imports ratio-only helper','completed; A real reproduction recorded'),
    ('A2B-013','END_T1_CM1_NL;325 columns; log1p(RCYL/s).','Baseline only; no absolute-target comparison.','original EXPERIMENT_PLAN plus d8bc8f1 public history','completed'),
    ('A2B-014/015','Frozen OOF diagnosis; trend abscissa repair and0.5blend; unchanged ratio target.','Not equivalent: diagnosis or feature/blend experiments.','STATUS_B sections014/015 and INTEGRATION_LOG','completed/stopped'),
    ('A2B-017','Same scaled-target base; two calibration candidates.','Not equivalent: prediction calibration, no absolute-target candidate.','EXPERIMENT_PLAN and EXECUTION_COMPLETED; A reproduction report','completed/stopped; never rerun'),
    ('A2B-019 T1','Same325 columns and scaled target; two history cutoffs.','Not equivalent: information boundary candidate.','T1 execution/FINAL_RESULT.json','completed/stopped'),
    ('A2B-020','Original early-two-month plan; user confirmed no fit/no running process.','No completed result; cannot be treated as an absolute-log execution.','A2B021 numbering clarification and PLAN.old_A2B020','not executed'),
    ('A2B-021','Early-two-month ET/HGB squared/HGB absolute_error and fixed blends; all log1p(RCYL/s).','absolute_error is model loss, not absolute-log target.','PLAN.unchanged and execution/FINAL_RESULT.json','completed/stopped'),
    ('A2B-022','Scaled target unchanged; C1 exact input simplification.','Not equivalent: columns changed, transform unchanged.','PLAN.transform and fixed B/A reports','completed/stopped; A limited review accepted'),
]
lookup={'request':'A2B-023','scope':'authorized local migration inventory plus published numbered experiment ledgers through A2B-022 and pinned public code history',
    'status':'NO_COMPLETED_EQUIVALENT_COMPARISON_IN_CHECKED_NUMBERED_HISTORY',
    'training_eligible':True,'equivalent_completed_result_found':False,
    'missing_key_completion_record_for_an_identified_equivalent_candidate':False,
    'evidence_limit':'Cannot certify undisclosed/off-ledger experiments. Early individual trial logs are not supplied; those earlier documented boundaries/inputs differ, so they are not reused as comparable evidence. Historical dtype remains UNKNOWN.',
    'records':[dict(zip(['experiment','actual_transform_or_scope','comparability','evidence','completion'],r)) for r in records],
    'public_report_bindings':public,'public_baseline_branch_tip':tip,'public_tracked_file_count':len(tracked),
    'local_source_sha256':source_bindings,
    'baseline_reuse':{'used':False,'reason':'Old B0 row-level OOF deliberately not persisted. This comparison needs paired per-state net contribution using the same live OOF; no complete reusable OOF evidence. Train fresh paired B0, not subtract historical score.'},
    'fits':0,'private_data_read':False,'no_missing_evidence_relabelled_PASS':True}
write('HISTORY_LOOKUP.json',lookup)
lines=['# A2B-023 历史查重','', '账户B执行与交付。查重先于新拟合和候选分数。','',
       '结论：已核对的编号台账和实际工件中没有已完成的同边界、同325列、同ET参数和切分的绝对log目标比较。可进入本轮唯一候选。此结论限定于已授权材料，不证明不存在未披露的账外实验。早期个别试验明细未提供，已知边界或字段不同；未发现一个已识别等价候选缺少关键完成记录。','',
       '|实验|实际研究内容|可比性|完成情况|','|---|---|---|---|']
for r in records:lines.append('|'+r[0]+'|'+r[1]+'|'+r[2]+'|'+r[4]+'|')
lines+=['','HGB的absolute_error是损失函数，不能误记为绝对log目标。训练.py支持extra_trees_log只代表代码入口，不代表同边界已执行。',
        '', '旧对照逐行OOF未保存，无法形成本轮配对状态组及诊断所需完整复用材料；本轮新训练B0/C1各30次，不复用旧分数或权重。',
        '', '固定报告远程原始字节与本地冻结副本一致；来源摘要和逐项判断见HISTORY_LOOKUP.json。历史dtype UNKNOWN、事件与P0 OPEN不变。']
with (ROOT/'HISTORY_LOOKUP.md').open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')
print(json.dumps({'history_status':lookup['status'],'training_eligible':True,'records':len(records),'fixed_reports_byte_verified':len(public),'real_fits':0},ensure_ascii=True))
