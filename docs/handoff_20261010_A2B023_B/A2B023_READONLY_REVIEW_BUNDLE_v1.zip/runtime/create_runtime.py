"""Create new A2B-023 implementation from byte-preserved reviewed runtime; no fits."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OLD=Path('D:/codex/A2B022_20261010_v1')
def put(name,text):
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(text)
bridge=(OLD/'bridge.py').read_text(encoding='utf-8')
bridge=bridge.replace('roots = [OLD,prior.HERE,prior.PROJECT]',"roots = [OLD,prior.HERE,prior.PROJECT,Path('D:/codex/A2B022_20261010_v1')]")
bridge=bridge.replace("('USER_AUTHORIZATION.txt','DIAGNOSTIC_PLAN.json','PLAN.json','SYNTHETIC_TEST_RESULTS.json')","('USER_AUTHORIZATION.md','HISTORY_LOOKUP.json','HISTORY_LOOKUP.md','MECHANISM_DECISION.md','PLAN.json','SYNTHETIC_TEST_RESULTS.json')")
put('bridge.py',bridge)
core='''"""A2B-023 target representation, identity selection and independently counted budget."""
import math
import numpy as np
from bridge import require,fingerprint

MODEL_NAMES={'B0':'extra_trees_log_ratio_last','C1':'extra_trees_log'}
def scales(raw):
    values=np.asarray(raw,dtype=float)
    positive=np.isfinite(values)&(values>0)
    return np.where(positive,values,1.0),~positive
def target(values,raw,arm):
    require(arm in MODEL_NAMES,'UNREGISTERED_TARGET_ARM')
    y=np.asarray(values,dtype=float)
    require(np.isfinite(y).all() and (y>=0).all(),'INVALID_TARGET')
    s,_=scales(raw)
    require(y.shape==s.shape,'TARGET_SCALE_SHAPE')
    return np.log1p(y/s) if arm=='B0' else np.log1p(y)
def inverse(values,raw,arm):
    require(arm in MODEL_NAMES,'UNREGISTERED_TARGET_ARM')
    z=np.asarray(values,dtype=float);s,_=scales(raw)
    require(z.shape==s.shape and np.isfinite(z).all(),'INVALID_TRANSFORMED_PREDICTION')
    with np.errstate(over='ignore'):
        result=np.expm1(z)*(s if arm=='B0' else 1.0)
    require(np.isfinite(result).all(),'NONFINITE_INVERSE_PREDICTION')
    return np.clip(result,0,None)
def select_features(train,features,mode):
    require('RCYL' not in train.columns and mode=='identity','LABEL_OR_UNAPPROVED_SELECTOR')
    require(len(features)==325 and 'RCYL' not in features and 'WELL_ID' not in features,'ORIGINAL_INPUT_REQUIRED')
    return list(features),{'mode':'identity','selected_count':325,'removed_count':0,'selected_feature_sha256':fingerprint(features)}
'''
oldcore=(OLD/'a2b022_core.py').read_text(encoding='utf-8')
budget=oldcore[oldcore.index('class FitBudget:'):]
budget=budget.replace('def __init__(self,cap=90):','def __init__(self,cap=63):')
budget=budget.replace("self.model_completed+=1", "require(self.model_completed<61,'SUCCESSFUL_FIT_BUDGET_EXHAUSTED')\n        self.model_completed+=1")
put('a2b023_core.py',core+'\n'+budget)
runtime=(OLD/'run_experiment.py').read_text(encoding='utf-8')
runtime=runtime.replace('A2B-022','A2B-023').replace('<=90 entries','<=63 entries')
runtime=runtime.replace('from a2b022_core import FitBudget,select_features,retention_gate','from a2b023_core import FitBudget,select_features,retention_gate,target,inverse,MODEL_NAMES')
start=runtime.index('def source_snapshot():')
end=runtime.index('def predict(',start)
runtime=runtime[:start]+'''def source_snapshot():
    return input_fingerprints()

'''+runtime[end:]
runtime=runtime.replace('def predict(pipeline,valid,features):','def predict(pipeline,valid,features,arm):')
runtime=runtime.replace("training.predict_pipeline_output(pipeline,'extra_trees_log_ratio_last',view[features],view)","training.predict_pipeline_output(pipeline,MODEL_NAMES[arm],view[features],view)")
runtime=runtime.replace("        if arm!='B0':ctx.budget.begin_selector()\n",'')
runtime=runtime.replace("expected=np.log1p(train.RCYL.to_numpy(dtype=float)/training._target_scale(train,'log_ratio_last'))","expected=target(train.RCYL.to_numpy(dtype=float),train['history__RCYL__last'].to_numpy(dtype=float),arm)")
runtime=runtime.replace("training._model_pipeline('extra_trees_log_ratio_last',x,ctx.config)","training._model_pipeline(MODEL_NAMES[arm],x,ctx.config)")
runtime=runtime.replace("training._fit_pipeline(pipeline,'extra_trees_log_ratio_last',x,train.RCYL,train.horizon,train)","training._fit_pipeline(pipeline,MODEL_NAMES[arm],x,train.RCYL,train.horizon,train)")
runtime=runtime.replace('ctx.budget.model_entered<90','ctx.budget.model_entered<63')
runtime=runtime.replace('predict(pipeline,valid,selected)','predict(pipeline,valid,selected,arm)')
runtime=runtime.replace('predict(pipeline,panel,selected)','predict(pipeline,panel,selected,\'C1\')')
runtime=runtime.replace("predict(loaded['pipeline'],panel,loaded['feature_columns'])","predict(loaded['pipeline'],panel,loaded['feature_columns'],'C1')")
runtime=runtime.replace("'selector_mode':'exact_redundancy'","'selector_mode':'identity'")
runtime=runtime.replace("'target_transform':'log1p(RCYL/raw_scale)'","'target_transform':'log1p(RCYL)'")
runtime=runtime.replace("'target_transform':'log1p(RCYL/raw last RCYL finite positive else1)'","'target_transform':'log1p(RCYL)'")
runtime=runtime.replace("require(json.loads((HERE/'diagnostic_v2/INPUT_DIAGNOSTIC.json').read_bytes())['complete'],'DIAGNOSTIC_NOT_COMPLETE')","require(json.loads((HERE/'HISTORY_LOOKUP.json').read_bytes())['training_eligible'],'HISTORY_LOOKUP_NOT_ELIGIBLE')")
runtime=runtime.replace('FitBudget(90)','FitBudget(63)')
runtime=runtime.replace("        require(identity==json.loads((HERE/'diagnostic_v2/INPUT_DIAGNOSTIC.json').read_bytes())['panel_identity'],'DATA_CHANGED_SINCE_DIAGNOSTIC')", "        require(identity==json.loads((Path('D:/codex/A2B022_20261010_v1')/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json').read_bytes())['panel_identity'],'ORIGINAL_INPUT_IDENTITY_DRIFT')")
runtime=runtime.replace("select_features(panel.iloc[tr].drop(columns=['RCYL']),features,'exact_redundancy')","select_features(panel.iloc[tr].drop(columns=['RCYL']),features,'identity')")
runtime=runtime.replace("'diagnostic_current_panel_identity_match':True","'prior_panel_identity_match':True")
runtime=runtime.replace("'candidate_selector_precomputed_without_labels_or_validation':selectors","'candidate_selector_precomputed_without_labels_or_validation':selectors,'both_arms_original325_no_selection_fit':True")
runtime=runtime.replace("'candidate_feature_identities':selectors,", "'candidate_feature_identities':selectors,'target_representations':MODEL_NAMES,'history_lookup_sha256':sha(HERE/'HISTORY_LOOKUP.json'),")
put('run_experiment.py',runtime)
params=json.loads((Path('D:/codex/A2B021_20261009_v1')/'PLAN.json').read_bytes())['complete_model_get_params']['B0']
plan={
 'request':'A2B-023','account':'B execution and delivery','authorization':'USER_AUTHORIZATION.md',
 'history_lookup':'HISTORY_LOOKUP.json','candidate_count':1,
 'primary_mechanism':'Changing the target representation removes per-well scale division/multiplication while keeping raw last RCYL and all inputs. Tests representation, not causal fallback effect.',
 'first_batch_candidates':{'B0':{'selector':'identity','target':'log1p(RCYL/raw last finite positive else1)','pipeline_name':'extra_trees_log_ratio_last'},'C1':{'selector':'identity','target':'log1p(RCYL)','pipeline_name':'extra_trees_log'}},
 'cohort':{'wells':81,'rows':972,'features':325,'row_and_feature_order':'exact prior panel identity'},
 'boundary':'last continuous event segment END minus one full month history; targets END+1..12; project hypothesis',
 'model':{'class':'ExtraTreesRegressor','all_get_params':params},
 'preprocessing':'exact original training._model_pipeline; no pruning, no additional scaling, train-fold-only learning',
 'families':{'fixed_n_splits':5,'repeat_seeds':[20260917,20261031,20261219,20270107,20270303],'repeat_n_splits':5},
 'metric':{'epsilon':1e-6,'loss':'abs(p-y)/(abs(p)+abs(y)+epsilon)','weights':'unnormalized2^-t,t1..12','aggregation':'sum12 withinwell then equally average wells','score':'100*(1-loss)'},
 'states':'raw-scale fallback determined by finite positive original value; low-positive training-fold Q25; other-positive; explanation only, not routing',
 'retention_conditions':{'fixed_delta_min':-.20,'repeat_mean_delta_min':.20,'positive_repeats_min':4,'positive_definition':'>0','worst_repeat_delta_min':-.20,'structure_and_integrity_required':True},
 'budget':{'planned_fresh_CV_model_fits':60,'planned_CV_preprocess_fits':60,'conditional_private_retention_full_fit_max':1,'successful_model_fit_max':61,'model_fit_entry_hard_cap':63,'runtime_retry_max':2,'no_confirmation_fits':True,'no_unused_budget_search':True},
 'stop_policy':{'all_six_families_mandatory':True,'fixed_score_early_elimination':False,'failed_gate':'stop this candidate, no postscore search','hard_blocks':['leakage','target/cohort mismatch','identity drift','privacy failure','budget exhausted']},
 'baseline_reuse':{'used':False,'reason':'No preserved reusable row-level OOF for paired diagnostics; new B0 and C1, no old-score subtraction.'},
 'retention':{'directory':'private_models_PENDING_A','max_full_fit':1,'only_all_conditions_pass':True,'no_upgrade_or_submission':True,'reload_prediction_equality_in_memory':True},
 'parallelism':{'active_models':1,'model_n_jobs':-1,'BLAS_OpenMP_threads':1,'fold_parallelism':False},
 'privacy':{'raw_data_readonly':True,'row_labels_predictions_keys_persisted':False,'min_group_and_complement_wells':5},
 'historical_dtype':'UNKNOWN','event_semantics_and_P0':'OPEN','A_independent_review':'PENDING'}
put('PLAN.json',json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
put('MECHANISM_DECISION.md','''# A2B-023 分数前机制登记

账户B执行与交付。已完成查重，未见已完成等价目标表示实验，证据边界见HISTORY_LOOKUP。

观察：A2B-022精确去重失败，回退和低正尺度组受损，但该现象混合了抽样变化等因素。最大可修复原因未识别。

假设：同一特征、模型和折下，移除目标及逆变换中的逐井尺度乘除，可能改变训练误差分配并提高跨井官方指标。唯一C1使用绝对log1p(RCYL)。325列、原始last RCYL、预处理和所有模型参数不变。

可证伪条件：不满足PLAN中的固定、重复平均、方向及最差重复保留条件即停止；不按失败组临时路由。不证明尺度回退1本身有害、事件规则正确或所有目标表示无效。通过也只保存待A复核私有研究模型。

本轮新对照，不直接使用历史分数。六组CV共60模型及60原预处理拟合，条件保留1，成功总上限61、故障重试2、模型进入绝对上限63；无确认、升级或平台提交。
''')
print('A2B-023 runtime and pre-score plan created; no fit')

