"""Seal synthetic and environment evidence before first real fit."""
import json
import subprocess
import sys
from bridge import HERE,prior,sha,dump_new,public_environment,forbid_fits

assert not (HERE/'execution').exists()
result=subprocess.run([sys.executable,'-E','-B','-m','unittest','test_contracts','-v'],cwd=HERE,capture_output=True,text=True)
transcript=result.stdout+result.stderr
if result.returncode!=0 or 'Ran 27 tests' not in transcript:
    print(transcript);raise RuntimeError('SYNTHETIC_FAILED')
import sklearn.svm._libsvm
from sklearn.ensemble import ExtraTreesRegressor
with forbid_fits():ExtraTreesRegressor(n_estimators=400,min_samples_leaf=6,max_features=.75,random_state=20260916,n_jobs=-1)._validate_params()
dump_new(HERE/'SYNTHETIC_TEST_RESULTS.json',{'request':'A2B-023','sealed_at':prior.stamp(),'test_cases':27,
    'passed':True,'real_model_fits':0,'real_preprocess_fits':0,'transcript':transcript,
    'source_sha256':{p.name:sha(p) for p in HERE.glob('*.py')},'environment':public_environment(),
    'plan_sha256':sha(HERE/'PLAN.json'),'history_sha256':sha(HERE/'HISTORY_LOOKUP.json'),
    'native_imports':'PASSED','actual_training_target_and_inverse_call_paths_tested':True})
print(json.dumps({'synthetic_tests':27,'passed':True,'real_model_and_preprocess_fits':0},ensure_ascii=True))
