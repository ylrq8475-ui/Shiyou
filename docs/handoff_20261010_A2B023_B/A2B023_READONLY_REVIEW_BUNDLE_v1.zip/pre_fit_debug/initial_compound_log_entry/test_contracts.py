"""Synthetic target/call-boundary/metric contracts; no real preprocessing or model fit."""
import unittest
import numpy as np
import pandas as pd
from bridge import training,GateError,forbid_fits,score_summary
from a2b023_core import MODEL_NAMES,FitBudget,scales,target,inverse,select_features,retention_gate

class Capture:
    def fit(self,x,y,**kwargs):self.x=x.copy();self.y=np.asarray(y).copy();self.kwargs=kwargs
    def predict(self,x):self.x=x.copy();return np.log1p(np.arange(len(x),dtype=float)+1)

class Contracts(unittest.TestCase):
    def setUp(self):
        self.raw=np.array([2.,1.,0.,-1.,np.nan,np.inf])
        self.y=np.array([4.,0.,3.,8.,1.,2.])
        self.panel=pd.DataFrame({'WELL_ID':['a','a','b','b','c','c'],'horizon':[1,2,1,2,1,2],
            'history__RCYL__last':self.raw,'RCYL':self.y,'forecast_step':[1,2,1,2,1,2]})
    def test_01_fallback_and_real_one_differ(self):
        s,f=scales(self.raw);np.testing.assert_array_equal(s,[2,1,1,1,1,1]);np.testing.assert_array_equal(f,[False,False,True,True,True,True])
    def test_02_control_roundtrip(self):np.testing.assert_allclose(inverse(target(self.y,self.raw,'B0'),self.raw,'B0'),self.y)
    def test_03_candidate_roundtrip(self):np.testing.assert_allclose(inverse(target(self.y,self.raw,'C1'),self.raw,'C1'),self.y)
    def test_04_candidate_scale_independent(self):np.testing.assert_array_equal(target(self.y,self.raw,'C1'),target(self.y,self.raw*20,'C1'))
    def test_05_control_scale_sensitive(self):self.assertNotEqual(target(self.y,self.raw,'B0')[0],target(self.y,self.raw*20,'B0')[0])
    def test_06_unknown_arm(self):
        with self.assertRaises(GateError):target(self.y,self.raw,'C2')
    def test_07_negative_target_block(self):
        with self.assertRaises(GateError):target([-1],[1],'C1')
    def test_08_nonfinite_target_block(self):
        with self.assertRaises(GateError):target([np.nan],[1],'B0')
    def test_09_shape_block(self):
        with self.assertRaises(GateError):target([1,2],[1],'C1')
    def test_10_nonfinite_inverse_block(self):
        with self.assertRaises(GateError):inverse([np.inf],[1],'C1')
    def test_11_negative_prediction_clip(self):np.testing.assert_array_equal(inverse([-2],[7],'C1'),[0])
    def test_12_actual_target_call_path(self):
        x=self.panel[['history__RCYL__last','forecast_step']]
        for arm,name in MODEL_NAMES.items():
            fake=Capture()
            with forbid_fits():training._fit_pipeline(fake,name,x,self.panel.RCYL,self.panel.horizon,self.panel)
            np.testing.assert_array_equal(fake.y,target(self.y,self.raw,arm));self.assertTrue(fake.x.equals(x));self.assertEqual(fake.kwargs,{})
    def test_13_actual_inverse_call_path(self):
        x=self.panel[['history__RCYL__last','forecast_step']]
        for arm,name in MODEL_NAMES.items():
            fake=Capture();actual=training.predict_pipeline_output(fake,name,x,self.panel)
            np.testing.assert_allclose(actual,inverse(np.log1p(np.arange(6)+1),self.raw,arm))
    def test_14_parameters_identical(self):
        x=self.panel[['history__RCYL__last','forecast_step']]
        config={'random_seed':20260916,'model_params':{'extra_trees':{'n_estimators':400,'min_samples_leaf':6,'max_features':.75,'n_jobs':-1}}}
        with forbid_fits():
            a=training._model_pipeline(MODEL_NAMES['B0'],x,config)
            b=training._model_pipeline(MODEL_NAMES['C1'],x,config)
        self.assertEqual(a.named_steps['model'].get_params(),b.named_steps['model'].get_params())
        self.assertEqual(a.named_steps['preprocess'].get_params().keys(),b.named_steps['preprocess'].get_params().keys())
    def test_15_identity_keeps325_and_raw(self):
        features=['history__RCYL__last']+['f'+str(i) for i in range(324)]
        frame=pd.DataFrame([[1]*325],columns=features)
        kept,meta=select_features(frame,features,'identity');self.assertEqual(kept,features);self.assertEqual(meta['removed_count'],0)
    def test_16_selector_target_block(self):
        with self.assertRaises(GateError):select_features(self.panel,['f']*325,'identity')
    def test_17_threshold_inclusive(self):self.assertTrue(retention_gate(-.2,[.2]*5)['passed'])
    def test_18_mean_threshold_failure(self):self.assertFalse(retention_gate(0,[.199]*5)['passed'])
    def test_19_positive_strict(self):self.assertEqual(retention_gate(0,[0,.3,.3,.3,.3])['positive_repeats'],4)
    def test_20_worst_threshold(self):self.assertFalse(retention_gate(0,[-.200001,.4,.4,.4,.4])['passed'])
    def test_21_requires_all_groups(self):
        with self.assertRaises(GateError):retention_gate(0,[.3]*4)
    def test_22_structure_blocks_retention(self):self.assertFalse(retention_gate(1,[1]*5,False)['passed'])
    def test_23_success_and_entry_caps(self):
        b=FitBudget()
        for i in range(61):b.begin_pipeline();b.begin_preprocess();b.complete_preprocess();b.begin_model();b.complete_model()
        b.begin_pipeline();b.begin_preprocess();b.complete_preprocess()
        with self.assertRaises(GateError):b.begin_model()
    def test_24_fit_requires_preprocessing(self):
        with self.assertRaises(GateError):FitBudget().begin_model()
    def test_25_no_fit_guard(self):
        from sklearn.ensemble import ExtraTreesRegressor
        with forbid_fits():
            with self.assertRaises(GateError):ExtraTreesRegressor().fit([[1],[2]],[1,2])
    def test_26_validation_labels_cannot_change_prediction(self):
        from run_experiment import predict
        features=['history__RCYL__last','forecast_step']
        changed=self.panel.copy();changed.RCYL=99999
        for arm in MODEL_NAMES:
            fake=Capture();a=predict(fake,self.panel,features,arm);self.assertNotIn('RCYL',fake.x.columns)
            b=predict(fake,changed,features,arm);np.testing.assert_array_equal(a,b)
    def test_27_actual_metric_oracle(self):
        frame=pd.DataFrame({'WELL_ID':['u']*12+['v']*12,'horizon':list(range(1,13))*2,'RCYL':[0.]*12+[2.]*12})
        p=np.array([0.]*12+[1.]*12)
        expected=100*(1-sum(2**(-t) for t in range(1,13))*(1/(3+1e-6))/2)
        self.assertAlmostEqual(score_summary(frame,p)['official_score'],expected,places=12)

if __name__=='__main__':unittest.main()
