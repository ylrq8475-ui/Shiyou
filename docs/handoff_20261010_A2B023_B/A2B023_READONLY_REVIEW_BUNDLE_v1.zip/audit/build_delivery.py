"""Build explicit-allowlist anonymous A2B-023 review delivery, never weights or raw files."""
import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
OLD=Path('D:/codex/A2B021_20261009_v1')
T1=Path('D:/codex/A2B019_T1_20261009_v1')
PROJECT=Path('D:/codex/Shiyou_B_private_handoff_20261009_v1/payload/project')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
mean=lambda v:math.fsum(v)/len(v)
def dump(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def text(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(v)
def main():
    final=load(ROOT/'execution/FINAL_RESULT.json');lock=load(ROOT/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json')
    audit=load(ROOT/'post_run/EXTENDED_CHECKS.json')
    assert final['training_completed'] and audit['passed'] and not final['artifacts']
    delivery=ROOT/'delivery_v2';delivery.mkdir(exist_ok=False)
    bundle=delivery/'bundle';bundle.mkdir()
    families=final['research'];fixed=families[0];repeats=families[1:];gate=final['retention_gate']
    models={}
    for arm in ('B0','C1'):
        models[arm]={'fixed':fixed['arms'][arm],
            'repeat_scores':[r['arms'][arm]['official_score'] for r in repeats],
            'repeat_mean_score':mean([r['arms'][arm]['official_score'] for r in repeats]),
            'repeat_deltas':[r['arms'][arm]['delta_vs_B0'] for r in repeats],
            'repeat_mean_delta':mean([r['arms'][arm]['delta_vs_B0'] for r in repeats]),
            'repeat_mean_weighted_prefix_loss':{str(n):mean([r['arms'][arm]['official_weighted_prefix_loss'][str(n)] for r in repeats]) for n in (1,2,4,12)}}
    attribution={'scope':'paired aggregate decomposition, not causal identification','groups':{},
        'fixed_first2_score_contribution':100*(fixed['arms']['B0']['official_weighted_prefix_loss']['2']-fixed['arms']['C1']['official_weighted_prefix_loss']['2']),
        'repeat_first2_score_contribution':100*(models['B0']['repeat_mean_weighted_prefix_loss']['2']-models['C1']['repeat_mean_weighted_prefix_loss']['2'])}
    for group in fixed['arms']['B0']['diagnostics']['prediction_state_groups']:
        b=[r['arms']['B0']['diagnostics']['prediction_state_groups'][group] for r in repeats]
        c=[r['arms']['C1']['diagnostics']['prediction_state_groups'][group] for r in repeats]
        attribution['groups'][group]={'mean_wells':mean([v['group_wells'] for v in b]),
            'mean_B0_group_loss':mean([v['full_mean_weighted_loss'] for v in b]),
            'mean_C1_group_loss':mean([v['full_mean_weighted_loss'] for v in c]),
            'mean_group_score_delta':mean([v['score_delta_vs_B0_in_group'] for v in c]),
            'seed_net_score_contributions':[-100*v['net_loss_change_contribution_all_wells'] for v in c],
            'mean_net_score_contribution':-100*mean([v['net_loss_change_contribution_all_wells'] for v in c]),
            'positive_seed_count':sum(v['net_loss_change_contribution_all_wells']<0 for v in c)}
    dump(delivery/'MODEL_COMPARISON.json',{'request':'A2B-023','models':models,'gate':gate,'fresh_paired_control':True,'prior_score_reused':False})
    dump(delivery/'ERROR_ATTRIBUTION.json',attribution)
    dump(delivery/'FIT_ACCOUNTING.json',{'actual':final['budget'],'conditional_full_fits':0,'confirmation_fits':0,'models_saved':0,
        'synthetic_failed_attempts':1,'synthetic_failure_cases_before_fix':3,'real_fits_before_synthetic_fix':0,
        'identity_precomputation_not_learning_fit':30,'selector_learning_fits':0,'successful_budget_max':61,'entry_cap':63})
    dump(delivery/'MODEL_REGISTRY.json',{'request':'A2B-023','registry':final['registry'],'A_review':'PENDING','private_artifacts':{},'deployment_approved':False})
    dump(delivery/'INTEGRITY_AFTER.json',{'old_artifact_count':lock['old_artifact_count'],'old_artifact_snapshot_sha256':lock['old_artifact_snapshot_sha256'],
        'old_artifacts_unchanged':final['old_artifacts_unchanged'],'source_and_input_unchanged':final['input_and_source_unchanged'],
        'environment_unchanged':final['environment_unchanged'],'raw_data_after':final['raw_data_after'],'privacy_scan':load(ROOT/'execution/PRIVACY_SCAN.json')})
    for name in ('HISTORY_LOOKUP.md','HISTORY_LOOKUP.json'):shutil.copyfile(ROOT/name,delivery/name)
    shutil.copyfile(ROOT/'post_run/IMPLEMENTATION_NOTE.md',delivery/'IMPLEMENTATION_NOTE.md')
    lines=['# A2B-023 账户B目标表示受控实验报告','','账户B执行与交付。账户A独立复核：PENDING。','',
        '结论：唯一绝对log候选未达到预注册保留条件，完成本批并停止。新对照/候选各30次，共60模型和60原预处理拟合，0失败、0重试。无确认、全量保存、升级或平台提交。','',
        '## 查重与可证伪机制','',
        '已核对授权本地迁移工件、编号台账及固定公开报告，未见完成的同边界绝对log目标比较。代码支持该入口不代表同条件执行；早期个别试验明细未提供，其已知边界/字段不同。该查重结论限定于已检查编号史，不能证明无未披露账外实验。见HISTORY_LOOKUP及源摘要，A需复核查重充分性。','',
        '观察来自A2B-022：精确去重失败及状态组损失变化。假设是目标中逐井尺度乘除可能影响学习与误差分配。B0保留log1p(RCYL/s)；C1改log1p(RCYL)及expm1逆变换，原始last RCYL仍在输入。检验的是整体目标表示，不单独识别回退值1的因果作用。','',
        '两组同81井、972行、325列和行序；同历史截止END前完整月、目标END+1..12，同预处理和完整ET参数。400树、min_samples_leaf6、max_features0.75、模型种子20260916。无删列、额外特征、加权、校准、融合或路由。旧OOF未落盘，缺少完整配对诊断复用材料，故新训B0而非减历史分数。','',
        '## 六组结果','','|切分|本轮B0|C1绝对log|增量|','|---|---:|---:|---:|']
    for r in families:lines.append(f"|{'固定五折' if r['seed'] is None else r['seed']}|{r['arms']['B0']['official_score']:.9f}|{r['arms']['C1']['official_score']:.9f}|{r['arms']['C1']['delta_vs_B0']:+.9f}|")
    lines+=['',f"重复平均：B0 {models['B0']['repeat_mean_score']:.9f}，C1 {models['C1']['repeat_mean_score']:.9f}；增量{gate['repeat_mean_delta']:+.9f}，{gate['positive_repeats']}/5严格正向，最差{gate['worst_repeat_delta']:+.9f}。四项数值门槛均失败。",'',
        '分数前保留条件：固定增量≥−0.20；重复平均≥+0.20；至少4/5严格正向；最差重复≥−0.20；结构完整性通过。这是工程筛选，不是统计显著性证明。六组均按计划执行，未因固定分数追加或缩减验证。','',
        '|固定折统计|B0|C1|','|---|---:|---:|',
        f"|最差折|{fixed['arms']['B0']['worst_fold']:.9f}|{fixed['arms']['C1']['worst_fold']:.9f}|",
        f"|总体折标准差ddof0|{fixed['arms']['B0']['fold_std_ddof0']:.9f}|{fixed['arms']['C1']['fold_std_ddof0']:.9f}|",'',
        '逐折分数B0：'+json.dumps(fixed['arms']['B0']['fold_scores'])+'；C1：'+json.dumps(fixed['arms']['C1']['fold_scores'])+'。总OOF按井等权，不直接平均大小不同的折分。','',
        '## 月份与组贡献','','|前缀窗口|固定B0损失|固定C1损失|重复均B0|重复均C1|','|---|---:|---:|---:|---:|']
    for n in (1,2,4,12):lines.append('|前'+str(n)+'月|'+ '|'.join(f"{v:.9f}" for v in [fixed['arms']['B0']['official_weighted_prefix_loss'][str(n)],fixed['arms']['C1']['official_weighted_prefix_loss'][str(n)],models['B0']['repeat_mean_weighted_prefix_loss'][str(n)],models['C1']['repeat_mean_weighted_prefix_loss'][str(n)]])+'|')
    lines+=['',f"前两月对固定总分贡献{attribution['fixed_first2_score_contribution']:+.9f}，对五重复均分贡献{attribution['repeat_first2_score_contribution']:+.9f}。",'',
        '|预测前状态|重复平均井数|组内平均分差|总分净贡献|改善次数|','|---|---:|---:|---:|---:|']
    for name,v in attribution['groups'].items():lines.append(f"|{name}|{v['mean_wells']:.1f}|{v['mean_group_score_delta']:+.9f}|{v['mean_net_score_contribution']:+.9f}|{v['positive_seed_count']}/5|")
    lines+=['','净贡献按组井数/81加权，三组相加等于总体增量；组内分差不可直接相加。低正尺度阈值来自每个训练折，成员随折变化，回退由原始值有限且>0判断。分组仅解释，不按结果路由。','',
        '本次负结果反对采用此固定绝对log方案，不能证明逐井尺度必然有益、回退值1最优、树模型达到上限或官方事件规则正确。最大可修复误差源仍未识别。同81口井多轮研究，重复切分不是五批独立数据。','',
        '## 实施与证据边界','',
        f"运行窗口{final['started']}至{final['finished']}，六组CV累计{sum(r['elapsed_seconds'] for r in families):.3f}秒。一个模型同时运行，ET n_jobs=-1，BLAS/OpenMP1，无折并行。",'',
        f"27合成和{audit['check_count']}匿名聚合/组贡献/身份检查通过。原100份CSV逐成员身份检查，无提取复制；{lock['old_artifact_count']}项旧工件前后摘要一致，源码、输入、环境未变。只保存匿名聚合。实际环境、构建、依赖、类型摘要和源码/配置身份在分数前锁。",'',
        '首轮3项合成失败发现旧绝对log入口的包装器和参数口径问题，零真实拟合时修复；没有削弱测试。旧代码保留。真实两组共用直接ET，C1显式变换；类名日志误记已在IMPLEMENTATION_NOTE勘误，冻结日志不回写。', '',
        '历史dtype UNKNOWN、事件语义及预测生成时点P0 OPEN，官方补充不可得不作为启动条件。86.2003只是用户报告的平台分数。B自检不等于A真实重训或远端全量实机重哈希。', '',
        '## 下一步','',
        '保持原缩放目标及325列对照；结束本批绝对log支线。若用户另批后续实验，优先提出同输入、同缩放目标、全年共享的树分裂机制单因素对照，并在分数前固定模型差异与预算。先查重，勿从剩余预算临时改尺度下限、组路由或融合。交A只读复核，无需为本批失败重训。','']
    text(delivery/'REPORT_B.md','\n'.join(lines))
    text(delivery/'README.md','# A2B-023 账户B匿名交接\n\n账户B执行与交付；A独立复核PENDING。唯一绝对log候选六组验证已完成，未达门槛，停止。60模型/60预处理拟合，0重试，无模型保存。\n\n先读REPORT_B.md、HISTORY_LOOKUP.md和IMPLEMENTATION_NOTE.md，再核对比较、归因、计数、完整性及复核请求。复核ZIP仅为匿名代码和证据，非正式赛事包；不含原始CSV、私有配置内容、真实井号、逐行OOF、模型或凭据。\n\n校验SHA256后解包到新目录，运行`python -E -B review_only.py --bundle-root <解包目录>`只做字节、合成和匿名算术。不要运行run_experiment.py --execute重训。\n')
    text(delivery/'B2A_023_REVIEW_REQUEST.md','# A2B-023 请求账户A独立复核\n\n账户B执行与交付，由用户转交。\n\n请重点检查历史查重范围及充分性、用户授权、分数前锁及修订时序；C1显式绝对log而两组325列与直接ET参数相同；目标/逆变换实际调用与预处理作用域；六组井隔离、指标和状态组净贡献；60模型/60预处理计数、0运行重试、失败停止、无模型保留；隐私与旧工件完整性证据等级。\n\n首轮27合成有3失败，零真实拟合时修复，旧代码保留；包装器类名误记另附勘误。请勿将早期非等价代码入口或HGB absolute_error认作已完成绝对log比较。\n\n复核入口仅字节+27合成+匿名算术，不读私有数据、不真实训练。若重现请新目录运行；不重跑已成功60次训练。A有限只读复核与独立真实复现分开声明。历史dtype UNKNOWN、业务P0 OPEN；不请求升级、部署或正式提交。\n')
    source_map={}
    def copy(source,relative):
        target=bundle/relative;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target);assert sha(source)==sha(target)
        source_map[str(source)]=relative
    for p in sorted(ROOT.glob('*.py')):copy(p,'runtime/'+p.name)
    for name in ('PLAN.json','USER_AUTHORIZATION.md','HISTORY_LOOKUP.json','HISTORY_LOOKUP.md','MECHANISM_DECISION.md','SYNTHETIC_TEST_RESULTS.json','PRE_FIT_DEBUG_LOG.json'):copy(ROOT/name,'runtime/'+name)
    for folder in ('execution','pre_fit_debug','received_public'):
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_file() and p.suffix in ('.json','.py','.md'):copy(p,p.relative_to(ROOT).as_posix())
    for p in sorted((PROJECT/'src/oil_uplift').glob('*.py')):copy(p,'upstream/project/src/oil_uplift/'+p.name)
    for name in ('paired_experiment.py','archive_adapter.py','t1_core.py'):copy(T1/name,'upstream/t1/'+name)
    for name in ('run_research.py','experiment_core.py','diagnostics.py'):copy(OLD/name,'upstream/a2b021/'+name)
    copy(Path('D:/codex/A2B022_20261010_v1/execution/IMPLEMENTATION_PRETRAIN_LOCK.json'),'upstream/a2b022/IMPLEMENTATION_PRETRAIN_LOCK.json')
    copy(T1/'accepted_entry/received_20261009_v1/payload/audit_payload/migration_acceptance_20261009_r1/boundary_audit.py','upstream/accepted/boundary_audit.py')
    for name in ('STATUS_B.md','INTEGRATION_LOG.md'):copy(Path('D:/codex/b-training-handoff-20261009-v2/evidence/sources')/name,'history_sources/'+name)
    for name in ('EXPERIMENT_PLAN.yaml','EXECUTION_COMPLETED.json'):copy(PROJECT/'experiments/a2b017'/name,'history_sources/a2b017/'+name)
    for p in sorted((ROOT/'post_run').glob('*')):
        if p.is_file() and p.suffix in ('.py','.md','.json'):copy(p,'audit/'+p.name)
    copy(ROOT/'post_run/review_only.py','review_only.py')
    for p in list(delivery.iterdir()):
        if p.is_file():copy(p,p.name)
    bound=[]
    for original,relative in source_map.items():
        expected=lock['source_and_inputs'].get(original)
        if expected is not None:
            assert sha(bundle/relative)==expected;bound.append({'package_path':relative,'pretrain_source_sha256':expected})
    dump(bundle/'PROVIDED_PRETRAIN_BINDINGS.json',{'bindings':bound,'count':len(bound),'unprovided_private_historical_inputs_not_independently_verified':True})
    manifest={p.relative_to(bundle).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(bundle.rglob('*')) if p.is_file()}
    dump(bundle/'BUNDLE_MANIFEST.json',{'request':'A2B-023','files':manifest,'manifest_excludes_itself':True})
    retest=subprocess.run([sys.executable,'-E','-B',str(bundle/'review_only.py'),'--bundle-root',str(bundle)],capture_output=True,text=True)
    if retest.returncode:print(retest.stdout+retest.stderr);raise RuntimeError('PACKAGED_RETEST_FAILED')
    summary=json.loads(retest.stdout.strip().splitlines()[-1]);dump(delivery/'PACKAGED_RETEST.json',summary)
    sys.path.insert(0,str(OLD));import run_research as old
    sys.path.insert(0,str(PROJECT/'src'))
    from oil_uplift import config as config_module,a2b013_safe as safe
    config=safe.safe_config(config_module.load_config(old.prior.PRIVATE_CONFIG))
    tokens=old.prior.train_test_wells_for_scan({},config)
    scan=old.prior.privacy_scan(delivery,tokens,config['anchors']['eligible_event_values']);assert scan['passed']
    private_tokens={str(v) for v in tokens if str(v)}|{str(v) for v in config['anchors']['eligible_event_values'] if isinstance(v,str) and len(v)>=2}
    for p in bundle.rglob('*'):
        if not p.is_file():continue
        assert p.suffix in ('.py','.md','.json','.yaml')
        data=p.read_bytes();assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----',data)
        content=data.decode('utf-8-sig')
        for token in private_tokens:assert not re.search(r'(?<![\w])'+re.escape(token)+r'(?![\w])',content),'PRIVATE_TOKEN_FOUND'
    dump(delivery/'PUBLICATION_PRIVACY_CHECK.json',{**scan,'all_bundle_files_scanned':True,'private_markers_checked_in_memory':len(private_tokens),'no_raw_private_config_contents_weights_or_credentials':True})
    archive=delivery/'A2B023_READONLY_REVIEW_BUNDLE_v1.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(bundle.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(bundle).as_posix())
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    text(delivery/(archive.name+'.sha256'),sha(archive)+'  '+archive.name+'\n')
    dump(delivery/'PUBLICATION_MANIFEST.json',{'account':'B execution and delivery','request':'A2B-023',
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in delivery.iterdir() if p.is_file()},
        'manifest_excludes_itself':True,'A_review':'PENDING','models':60,'no_private_artifacts':True})
    print(json.dumps({'delivery_files':[p.name for p in delivery.iterdir() if p.is_file()],'bundle_files':len(manifest)+1,'bindings':len(bound),
        'zip_sha256':sha(archive),'zip_bytes':archive.stat().st_size,'privacy_passed':True,'retest':summary,'groups':attribution['groups']},ensure_ascii=True))
if __name__=='__main__':main()
