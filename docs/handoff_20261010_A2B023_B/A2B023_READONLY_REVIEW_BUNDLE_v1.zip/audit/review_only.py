"""Portable A2B-023 synthetic and anonymous aggregate review; never loads private inputs."""
import argparse
import __future__
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import math
import os
import sys
import types
import unittest
from typing import Any
from pathlib import Path

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module);return module
def selected(module,path,names):
    nodes=[n for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec',flags=__future__.annotations.compiler_flag),module.__dict__)
def main(root):
    manifest=json.loads((root/'BUNDLE_MANIFEST.json').read_bytes())['files']
    for name,item in manifest.items():
        data=(root/name).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
    sys.dont_write_bytecode=True
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
    import numpy as np
    import pandas as pd
    from sklearn.pipeline import Pipeline
    core=load('experiment_core',root/'upstream/a2b021/experiment_core.py')
    training=types.ModuleType('portable_training')
    training.__dict__.update(np=np,pd=pd,Pipeline=Pipeline,DataContractError=core.GateError,Any=Any)
    selected(training,root/'upstream/project/src/oil_uplift/training.py',
        ['_candidate_spec','_preprocessor','_model_pipeline','_fit_pipeline','_target_scale','_transform_target','predict_pipeline_output'])
    # Original definitions only: no configuration loaders or data path imports.
    source=ast.parse((root/'upstream/project/src/oil_uplift/training.py').read_text(encoding='utf-8'))
    for node in source.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TARGET_SUFFIXES' for t in node.targets):
            training.TARGET_SUFFIXES=ast.literal_eval(node.value)
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler,OneHotEncoder
    from sklearn.ensemble import ExtraTreesRegressor,HistGradientBoostingRegressor
    from sklearn.dummy import DummyRegressor
    from sklearn.compose import TransformedTargetRegressor
    training.__dict__.update(ColumnTransformer=ColumnTransformer,SimpleImputer=SimpleImputer,StandardScaler=StandardScaler,
        OneHotEncoder=OneHotEncoder,ConfigurationError=core.GateError)
    models=types.ModuleType('portable_models')
    models.__dict__.update(np=np,Any=Any,ExtraTreesRegressor=ExtraTreesRegressor,HistGradientBoostingRegressor=HistGradientBoostingRegressor,
        DummyRegressor=DummyRegressor,TransformedTargetRegressor=TransformedTargetRegressor,ConfigurationError=core.GateError)
    selected(models,root/'upstream/project/src/oil_uplift/models.py',['build_model'])
    training.build_model=models.build_model
    bridge=types.ModuleType('bridge')
    bridge.__dict__.update(np=np,pd=pd,Path=Path,contextlib=contextlib,json=json,hashlib=hashlib,
        require=core.require,GateError=core.GateError,fingerprint=core.fingerprint,score_summary=core.score_summary,training=training)
    selected(bridge,root/'runtime/bridge.py',['forbid_fits'])
    sys.modules['bridge']=bridge
    sys.path.insert(0,str(root/'runtime'))
    # The validation-label perturbation test exercises the original prediction wrapper.
    runner=types.ModuleType('run_experiment')
    targetcore=load('a2b023_core',root/'runtime/a2b023_core.py')
    runner.__dict__.update(np=np,training=training,require=core.require,predict_target_pipeline=targetcore.predict_target_pipeline)
    selected(runner,root/'runtime/run_experiment.py',['predict'])
    sys.modules['run_experiment']=runner
    tests=load('portable_tests',root/'runtime/test_contracts.py')
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
    if not result.wasSuccessful():print(stream.getvalue());raise AssertionError('SYNTHETIC_FAILED')
    load('aggregate_check',root/'audit/aggregate_check.py')
    aggregate=load('extended_check',root/'audit/extended_check.py').verify(root)
    print(json.dumps({'request':'A2B-023','bundle_files_checked':len(manifest),'synthetic_cases':result.testsRun,
        'synthetic_passed':True,'aggregate_check_count':aggregate['check_count'],'aggregate_passed':aggregate['passed'],
        'real_model_fits':0,'real_preprocess_fits':0,'private_data_read':False,
        'scope':'Exact byte-bound allowlisted function AST plus original target core; no private loader evaluated; not real retraining'},ensure_ascii=True))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--bundle-root',type=Path,default=Path(__file__).resolve().parent)
    main(parser.parse_args().bundle_root.resolve())
