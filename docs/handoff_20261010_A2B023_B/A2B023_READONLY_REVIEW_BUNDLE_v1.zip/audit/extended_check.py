"""Independent group-accounting and target/configuration checks over anonymous results."""
import json
import math
from pathlib import Path
from aggregate_check import run

ROOT=Path(__file__).resolve().parent.parent
load=lambda p:json.loads(p.read_bytes())
def verify(root):
    base=run(root);checks=base['checks']
    def check(name,value):
        checks.append({'check':name,'passed':bool(value)})
        if not value:raise AssertionError(name)
    close=lambda a,b:math.isclose(a,b,rel_tol=0,abs_tol=1e-10)
    final=load(root/'execution/FINAL_RESULT.json')
    plan=load(root/'runtime/PLAN.json' if (root/'runtime').exists() else root/'PLAN.json')
    lock=load(root/'execution/IMPLEMENTATION_PRETRAIN_LOCK.json')
    check('same_exact_locked_model_parameters',lock['model_parameters']==plan['model']['all_get_params'])
    check('all325_unchanged',len(lock['baseline_feature_order'])==325)
    check('target_single_difference',lock['target_representations']=={'B0':'extra_trees_log_ratio_last','C1':'explicit_absolute_log'})
    for j,r in enumerate(final['research']):
        b,c=r['arms']['B0'],r['arms']['C1']
        bg=b['diagnostics']['prediction_state_groups'];cg=c['diagnostics']['prediction_state_groups']
        check(f'group{j}_sum81',sum(v['group_wells'] for v in bg.values())==81)
        for name in bg:
            x,y=bg[name],cg[name]
            check(f'{j}_{name}_released',x['status']==y['status']=='RELEASED')
            check(f'{j}_{name}_same_population',x['group_wells']==y['group_wells'])
            check(f'{j}_{name}_privacy',min(x['group_wells'],x['complement_wells'])>=5)
            delta=100*(x['full_mean_weighted_loss']-y['full_mean_weighted_loss'])
            contribution=delta*x['group_wells']/81
            check(f'{j}_{name}_group_delta',close(delta,y['score_delta_vs_B0_in_group']))
            check(f'{j}_{name}_net_contribution',close(contribution,-100*y['net_loss_change_contribution_all_wells']))
        check(f'group{j}_net_sum',close(sum(-100*v['net_loss_change_contribution_all_wells'] for v in cg.values()),c['delta_vs_B0']))
    base.update(check_count=len(checks),passed=True,request='A2B-023',additional_group_checks=True)
    return base
if __name__=='__main__':
    result=verify(ROOT)
    with (ROOT/'post_run/EXTENDED_CHECKS.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps({'checks':result['check_count'],'passed':result['passed'],'real_fits':0}))
