"""Independent post-score arithmetic over anonymized aggregates only; never fits."""
import hashlib
import json
import math
import statistics
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
load=lambda p:json.loads(Path(p).read_bytes())
def run(root=ROOT):
    execution=root/'execution'
    final=load(execution/'FINAL_RESULT.json')
    checks=[]
    def check(name,condition):
        checks.append({'check':name,'passed':bool(condition)})
        if not condition:raise AssertionError(name)
    def near(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=1e-10)
    budgets=final['budget']
    events=[load(p) for p in sorted((execution/'events').glob('*.json'))]
    counts=Counter(e['event'] for e in events)
    check('completed',final['training_completed'])
    check('model_entry_budget',budgets['model_entered']<=63 and budgets['model_completed']<=61)
    check('model_entries_equal_journal',counts['model_fit_entered']==budgets['model_entered'])
    check('model_completions_equal_journal',counts['fit_completed']==budgets['model_completed'])
    check('all_30_paired_folds',counts['fold_completed']==30)
    check('zero_model_failures',counts['fit_failed']==0)
    check('preprocessor_count',budgets['preprocess_entered']==budgets['preprocess_completed']==60+len(final['artifacts']))
    check('selector_runtime_calls',budgets['selector_fit_calls']==0)
    entered=[e for e in events if e['event']=='model_fit_entered']
    completed=[e for e in events if e['event']=='fit_completed']
    for i,e in enumerate(entered):
        check(f'fit{i}_full_horizon_training_rows',e['training_rows']==12*e['training_wells'])
        check(f'fit{i}_selector_sum',e['selection']['selected_count']+e['selection']['removed_count']==325)
    for i,e in enumerate(completed):
        check(f'fit{i}_one_each_call',all(v==1 for v in e['counts'].values()))
    families=final['research']
    check('six_families',len(families)==6)
    seeds=[None,20260917,20261031,20261219,20270107,20270303]
    for j,(family,seed) in enumerate(zip(families,seeds,strict=True)):
        check(f'family{j}_seed',family['seed']==seed)
        published=load(execution/('FIXED_FIVE_FOLD.json' if seed is None else f'REPEAT_{seed}.json'))
        check(f'family{j}_final_equal_file',published==family)
        fold_events=[e for e in events if e['event']=='fold_completed' and e['seed']==seed]
        check(f'family{j}_fold_count',len(fold_events)==5)
        for arm in ['B0','C1']:
            r=family['arms'][arm]
            check(f'{j}_{arm}_score_from_monthly',near(r['official_score'],100*(1-math.fsum(r['monthly_official_weighted_loss']))))
            for month,(unweighted,weighted) in enumerate(zip(r['monthly_unweighted_relative_error'],r['monthly_official_weighted_loss'],strict=True),1):
                check(f'{j}_{arm}_month{month}_weight',near(weighted,unweighted*2**(-month)))
            for n in [1,2,4,12]:
                check(f'{j}_{arm}_prefix{n}',near(r['official_weighted_prefix_loss'][str(n)],math.fsum(r['monthly_official_weighted_loss'][:n])))
            check(f'{j}_{arm}_worst_fold',near(r['worst_fold'],min(r['fold_scores'])))
            check(f'{j}_{arm}_fold_std',near(r['fold_std_ddof0'],statistics.pstdev(r['fold_scores'])))
            weighted_fold=math.fsum(e['valid_wells']*e['scores'][arm] for e in fold_events)/81
            check(f'{j}_{arm}_well_weighted_folds',near(r['official_score'],weighted_fold))
            check(f'{j}_{arm}_fold_event_scores',all(near(e['scores'][arm],v) for e,v in zip(fold_events,r['fold_scores'],strict=True)))
        b,c=family['arms']['B0'],family['arms']['C1']
        check(f'{j}_paired_delta',near(c['delta_vs_B0'],c['official_score']-b['official_score']))
        check(f'{j}_paired_fold_deltas',all(near(x,y-z) for x,y,z in zip(c['paired_fold_deltas'],c['fold_scores'],b['fold_scores'],strict=True)))
        check(f'{j}_selected_feature_identity_pretrain',family['feature_selection']['C1']==load(execution/'STRUCTURAL_GATES.json')['candidate_selector_precomputed_without_labels_or_validation'][j]['folds'])
        check(f'{j}_paired_groups',all(e['well_intersection']==0 for e in fold_events))
    deltas=[f['arms']['C1']['delta_vs_B0'] for f in families[1:]]
    gate=final['retention_gate']
    check('gate_fixed_delta',near(gate['fixed_delta'],families[0]['arms']['C1']['delta_vs_B0']))
    check('gate_mean',near(gate['repeat_mean_delta'],math.fsum(deltas)/5))
    check('gate_directions',gate['positive_repeats']==sum(d>0 for d in deltas))
    check('gate_worst',near(gate['worst_repeat_delta'],min(deltas)))
    expected=gate['fixed_delta']>=-.2 and math.fsum(deltas)/5>=.2 and sum(d>0 for d in deltas)>=4 and min(deltas)>=-.2
    check('gate_decision',gate['passed']==expected)
    check('no_model_saved_on_failure',gate['passed'] or not final['artifacts'])
    check('no_confirmation_evaluated',not load(execution/'RESEARCH_DECISION_LOCK.json')['confirmation_evaluated'])
    check('input_source_environment_old_raw_unchanged',final['input_and_source_unchanged'] and final['environment_unchanged'] and final['old_artifacts_unchanged'] and final['raw_data_after']['archive_and_manifest_unchanged'])
    check('privacy',load(execution/'PRIVACY_SCAN.json')['passed'])
    for relative,digest in load(execution/'SHA256SUMS.json').items():
        check('hash_'+relative,hashlib.sha256((execution/relative).read_bytes()).hexdigest()==digest)
    return {'request':'A2B-023','scope':'post-score anonymous arithmetic and byte checks; no row-level or independent training reproduction',
            'checks':checks,'check_count':len(checks),'passed':all(v['passed'] for v in checks),
            'real_fits':0,'model_events':dict(counts),'gate_recomputed':expected,
            'runtime_selector_rule_evaluations':0,'pretrain_identity_selector_rule_evaluations':30,
            'total_selector_rule_evaluations':0}

if __name__=='__main__':
    result=run()
    output=ROOT/'post_run/AGGREGATE_CHECKS.json'
    with output.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k not in ['checks']},ensure_ascii=True))
